Delirium.exe
GDI Malware By P. ĐĂNG

My YouTube Channel:
https://www.youtube.com/channel/UCh5xBsYr8gQzTwcPEZP8nig
https://www.youtube.com/channel/UCgAg64UlUYnbvKGpyStWxWA