#pragma once
DWORD WINAPI s1(LPVOID lpParam) {
	HDC dc = GetDC(NULL);
	HDC dcCopy = CreateCompatibleDC(dc);

	int ws = w / 10;
	int hs = h / 10;

	BITMAPINFO bmpi = { 0 };
	HBITMAP bmp;

	bmpi.bmiHeader.biSize = sizeof(bmpi);
	bmpi.bmiHeader.biWidth = ws;
	bmpi.bmiHeader.biHeight = hs;
	bmpi.bmiHeader.biPlanes = 1;
	bmpi.bmiHeader.biBitCount = 32;
	bmpi.bmiHeader.biCompression = BI_RGB;

	RGBQUAD* rgbquad = NULL;

	bmp = CreateDIBSection(dc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
	SelectObject(dcCopy, bmp);

	INT i = 32;

	SetStretchBltMode(dc, COLORONCOLOR);
	SetStretchBltMode(dcCopy, COLORONCOLOR);

	while (1)
	{
		StretchBlt(dcCopy, 0, 0, ws, hs, dc, 0, 0, w, h, SRCCOPY);

		for (int x = 0; x < ws; x++)
		{
			for (int y = 0; y < hs; y++)
			{
				int index = y * ws + x;

				FLOAT fx = ((double)(tan(x / 456.f - y / h * 0.1) + i / 5));
				FLOAT fx2 = ((double)(sin(y / 567.f - x / w * 0.1) + i / 5));
				FLOAT fx3 = ((double)(tan(x / 678.f - y / h * 0.1) + i / 5));
				FLOAT fx4 = (fx - fx2 + fx3) * (fx - fx2 + fx3);
				FLOAT fx5 = (fx4 - fx3) + (fx2 - fx);

				HSV hsv = Colors::RGBtoHSV(rgbquad[index]);

				hsv.h += fmod(fx5 + i, 360.0);

				rgbquad[index] = Colors::HSVtoRGB(hsv);
			}
		}

		i++;

		StretchBlt(dc, 0, 0, w, h, dcCopy, 0, 0, ws, hs, SRCCOPY);
		Sleep(rand() % 1000);
	}

	return 0x00;
}
DWORD WINAPI s2(LPVOID lpvd) //credits to fr4ctalz, but I modified it
{
	HDC hdc = GetDC(NULL);
	HDC hdcCopy = CreateCompatibleDC(hdc);
	int screenWidth = GetSystemMetrics(SM_CXSCREEN);
	int screenHeight = GetSystemMetrics(SM_CYSCREEN);
	BITMAPINFO bmpi = { 0 };
	HBITMAP bmp;

	bmpi.bmiHeader.biSize = sizeof(bmpi);
	bmpi.bmiHeader.biWidth = screenWidth;
	bmpi.bmiHeader.biHeight = screenHeight;
	bmpi.bmiHeader.biPlanes = 1;
	bmpi.bmiHeader.biBitCount = 32;
	bmpi.bmiHeader.biCompression = BI_RGB;


	RGBQUAD* rgbquad = NULL;
	HSL hslcolor;

	bmp = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
	SelectObject(hdcCopy, bmp);

	INT i = 5;
	float colorShift = 400.0;
	float colorIntensity = 0.15;
	while (1)
	{
		hdc = GetDC(NULL);
		StretchBlt(hdcCopy, 0, 0, screenWidth, screenHeight, hdc, 0, 0, screenWidth, screenHeight, SRCCOPY);

		RGBQUAD rgbquadCopy;

		for (int x = 0; x < screenWidth; x++)
		{
			for (int y = 0; y < screenHeight; y++)
			{
				int index = y * screenWidth + x;
				int fx = (int)((i ^ 4) + (i * 4) * cbrt(x ^ y + i));

				rgbquadCopy = rgbquad[index];

				hslcolor = Colors::rgb2hsl(rgbquadCopy);
				hslcolor.h = fmod(fx / colorShift + y / static_cast<float>(screenHeight) * colorIntensity, 1.0f);
				hslcolor.s = fmod(hslcolor.s + (x % 40) / 400.0f, 1.0f);
				hslcolor.l = fmod(hslcolor.l + (y % 20) / 200.0f, 1.0f);
				rgbquad[index] = Colors::hsl2rgb(hslcolor);
			}
		}

		i++;

		StretchBlt(hdc, 0, 0, screenWidth, screenHeight, hdcCopy, 0, 0, screenWidth, screenHeight, SRCCOPY);
		ReleaseDC(NULL, hdc);
		DeleteDC(hdc);
	}

	return 0x00;
}
DWORD WINAPI s3(LPVOID lpParam) {
	HDC hdcScreen = GetDC(0),
		hdcMem = CreateCompatibleDC(hdcScreen);
	INT w = GetSystemMetrics(0),
		h = GetSystemMetrics(1);
	BITMAPINFO bmi = { 0 };
	_RGBQUAD *rgbquad = { 0 };
	bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
	bmi.bmiHeader.biBitCount = 32;
	bmi.bmiHeader.biPlanes = 1;
	bmi.bmiHeader.biWidth = w;
	bmi.bmiHeader.biHeight = h;
	HBITMAP hbmTemp = CreateDIBSection(hdcScreen, &bmi, NULL, (void**)&rgbquad, NULL, NULL);
	SelectObject(hdcMem, hbmTemp);
	for (;;) {
		hdcScreen = GetDC(0);
		BitBlt(hdcMem, 0, 0, w, h, hdcScreen, 0, 0, SRCCOPY);
		for (INT i = 0; i < w * h; i++) {
			INT x = i % w, y = i / w;
			int average = round((float)(rgbquad[i].b + rgbquad[i].r + rgbquad[i].g) / 4);
			rgbquad[i].r -= average;
			rgbquad[i].g += average;
			rgbquad[i].b -= average;
			rgbquad[i].rgb += 666;
		}
		BitBlt(hdcScreen, 0, 0, w, h, hdcMem, 0, 0, SRCCOPY);
		ReleaseDC(NULL, hdcScreen);
		DeleteDC(hdcScreen);
	}
}
DWORD WINAPI s4(LPVOID lpParam)
{
	HDC desk = GetDC(0);
	HWND wnd = GetDesktopWindow();
	int sw = GetSystemMetrics(0),
		sh = GetSystemMetrics(1);
	BITMAPINFO bmi = { 40, sw, sh, 1, 24 };
	RGBTRIPLE *triple;
	for (;;) {
		desk = GetDC(0);
		HDC deskMem = CreateCompatibleDC(desk);
		HBITMAP scr = CreateDIBSection(desk, &bmi, 0, (void**)&triple, 0, 0);
		SelectObject(deskMem, scr);
		BitBlt(deskMem, 0, 0, sw, sh, desk, 0, 0, SRCCOPY);
		for (int i = 0; i < sw * sh; i++) {
			int x = i % sw, y = i / sh, t = y ^ y | x;
			int sepiaRed = round(.666 * triple[i].rgbtRed + .666 * triple[i].rgbtGreen + .666 * triple[i].rgbtBlue);
			int sepiaGreen = round(.666 * triple[i].rgbtRed + .666 * triple[i].rgbtGreen + .666 * triple[i].rgbtBlue);
			int sepiaBlue = round(.666 * triple[i].rgbtRed + .666 * triple[i].rgbtGreen + .666 * triple[i].rgbtBlue);

			if (sepiaBlue > 255)
			{
				sepiaBlue = 255;
			}

			if (sepiaRed > 255)
			{
				sepiaRed = 255;
			}

			if (sepiaGreen > 255)
			{
				sepiaGreen = 255;
			}
			triple[i].rgbtRed = sepiaRed + RndRGB2();
			triple[i].rgbtGreen = sepiaGreen + RndRGB2();
			triple[i].rgbtBlue = sepiaBlue + RndRGB2();
		}
		BitBlt(desk, 0, 0, sw, sh, deskMem, 0, 0, NOTSRCERASE);
		ReleaseDC(wnd, desk);
		DeleteDC(desk);
		DeleteDC(deskMem);
		DeleteObject(scr);
		DeleteObject(wnd);
		DeleteObject(triple);
		DeleteObject(&sw);
		DeleteObject(&sh);
		DeleteObject(&bmi);
		//Sleep(100);
		if ((rand() % 100 + 1) % 67 == 0) InvalidateRect(0, 0, 0);
	}
}
DWORD WINAPI s5(LPVOID lpParam) {
	int noisex = 5;
	int v = 32;
	{
		HDC desk = GetDC(0);
		HWND wnd = GetDesktopWindow();
		int sw = GetSystemMetrics(0),
			sh = GetSystemMetrics(1);
		BITMAPINFO bmi = { 40, sw, sh, 1, 24 };
		RGBTRIPLE* triple;
		int radius = 14.5f; double angle = 0;
		for (;;) {
			desk = GetDC(0);
			HDC deskMem = CreateCompatibleDC(desk);
			HBITMAP scr = CreateDIBSection(desk, &bmi, 0, (void**)&triple, 0, 0);
			SelectObject(deskMem, scr);
			BitBlt(deskMem, 0, 0, sw, sh, desk, 0, 0, SRCCOPY);
			for (int i = 0; i < sw * sh; i++) {
				int x = i % sw, y = i / sh, t = y ^ y | x;
				int bigd = round((float)(triple[i].rgbtBlue + triple[i].rgbtRed + triple[i].rgbtGreen) / 3);
				triple[i].rgbtRed -= bigd;
				triple[i].rgbtGreen -= bigd + 15;
				triple[i].rgbtBlue -= bigd + v * noisex;
			}
			float x = cos(angle) * radius, y = sin(angle) * radius;
			BitBlt(desk, 0, 0, sw, sh, deskMem, x, y, SRCCOPY);
			ReleaseDC(wnd, desk);
			DeleteDC(desk);
			DeleteDC(deskMem);
			DeleteObject(scr);
			DeleteObject(wnd);
			DeleteObject(triple);
			DeleteObject(&sw);
			DeleteObject(&sh);
			DeleteObject(&bmi);
			angle = fmod(angle + M_PI / radius, M_PI * radius);
		}
	}
}
DWORD WINAPI s6(LPVOID lpvd) //credits to fr4ctalz, but I modified it
{
	HDC hdc = GetDC(NULL);
	HDC hdcCopy = CreateCompatibleDC(hdc);
	int screenWidth = GetSystemMetrics(SM_CXSCREEN);
	int screenHeight = GetSystemMetrics(SM_CYSCREEN);
	BITMAPINFO bmpi = { 0 };
	HBITMAP bmp;

	bmpi.bmiHeader.biSize = sizeof(bmpi);
	bmpi.bmiHeader.biWidth = screenWidth;
	bmpi.bmiHeader.biHeight = screenHeight;
	bmpi.bmiHeader.biPlanes = 1;
	bmpi.bmiHeader.biBitCount = 32;
	bmpi.bmiHeader.biCompression = BI_RGB;


	RGBQUAD* rgbquad = NULL;
	HSL hslcolor;

	bmp = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
	SelectObject(hdcCopy, bmp);

	INT i = 5;
	float colorShift = 600.0;
	float colorIntensity = 0.15;
	while (1)
	{
		hdc = GetDC(NULL);
		StretchBlt(hdcCopy, 0, 0, screenWidth, screenHeight, hdc, 0, 0, screenWidth, screenHeight, SRCCOPY);

		RGBQUAD rgbquadCopy;

		for (int x = 0; x < screenWidth; x++)
		{
			for (int y = 0; y < screenHeight; y++)
			{
				int index = y * screenWidth + x;
				int fx = (int)((i ^ 4) + (i * 4) * cbrt(x & y ^ i ^ 7 | x ^ y - x));

				rgbquadCopy = rgbquad[index];

				hslcolor = Colors::rgb2hsl(rgbquadCopy);
				hslcolor.h = fmod(fx / colorShift + y / static_cast<float>(screenHeight) * colorIntensity, 1.0f);
				hslcolor.s = fmod(hslcolor.s + (x % 40) / 400.0f, 1.0f);
				hslcolor.l = fmod(hslcolor.l + (y % 20) / 200.0f, 1.0f);
				rgbquad[index] = Colors::hsl2rgb(hslcolor);
			}
		}

		i++;

		StretchBlt(hdc, 0, 0, screenWidth, screenHeight, hdcCopy, 0, 0, screenWidth, screenHeight, SRCCOPY);
		ReleaseDC(NULL, hdc);
		DeleteDC(hdc);
	}

	return 0x00;
}
DWORD WINAPI s7(LPVOID lpParam) {
	HDC hdc = GetDC(NULL);
	HDC hdcCopy = CreateCompatibleDC(hdc);
	int screenWidth = GetSystemMetrics(SM_CXSCREEN);
	int screenHeight = GetSystemMetrics(SM_CYSCREEN);
	BITMAPINFO bmpi = { 0 };
	HBITMAP bmp;
	bmpi.bmiHeader.biSize = sizeof(bmpi);
	bmpi.bmiHeader.biWidth = screenWidth;
	bmpi.bmiHeader.biHeight = screenHeight;
	bmpi.bmiHeader.biPlanes = 1;
	bmpi.bmiHeader.biBitCount = 32;
	bmpi.bmiHeader.biCompression = BI_RGB;
	RGBQUAD* rgbquad = NULL;
	HSL hslcolor;
	bmp = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
	SelectObject(hdcCopy, bmp);
	INT i = 0;
	while (true) {
		hdc = GetDC(NULL);
		StretchBlt(hdcCopy, 0, 0, screenWidth, screenHeight, hdc, 0, 0, screenWidth, screenHeight, SRCCOPY);
		RGBQUAD rgbquadCopy;
		for (int x = 0; x < screenWidth; x++) {
			for (int y = 0; y < screenHeight; y++) {
				int index = y * screenWidth + x;
				int fx = (x / 4) * 4 + y;
				rgbquadCopy = rgbquad[index];
				hslcolor = Colors::rgb2hsl(rgbquadCopy);
				hslcolor.h = fmod(fx / 450.f + y / screenHeight * .5f, 1.f);
				rgbquad[index] = Colors::hsl2rgb(hslcolor);
			}
		}
		i++;
		StretchBlt(hdc, 0, 0, screenWidth, screenHeight, hdcCopy, 0, 0, screenWidth, screenHeight, NOTSRCCOPY);
		ReleaseDC(NULL, hdc);
		DeleteDC(hdc);
	}
	return 0x00;
}
DWORD WINAPI s8(LPVOID lpvd)
{
	HDC hdc = GetDC(NULL);
	HDC hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(0);
	int h = GetSystemMetrics(1);
	BITMAPINFO bmpi = { 0 };
	HBITMAP bmp;

	bmpi.bmiHeader.biSize = sizeof(bmpi);
	bmpi.bmiHeader.biWidth = w;
	bmpi.bmiHeader.biHeight = h;
	bmpi.bmiHeader.biPlanes = 1;
	bmpi.bmiHeader.biBitCount = 32;
	bmpi.bmiHeader.biCompression = BI_RGB;

	RGBQUAD* rgbquad = NULL;
	HSL hslcolor;

	bmp = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
	SelectObject(hdcCopy, bmp);

	INT i = 0;

	while (1)
	{
		hdc = GetDC(NULL);
		StretchBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, w, h, SRCCOPY);

		RGBQUAD rgbquadCopy;

		for (int x = 0; x < w; x++)
		{
			for (int y = 0; y < h; y++)
			{
				int index = y * w + x;

				int fx = (int)((4 * i) + ((4 * i) * tan(x / 32.0)) + (4 * i) + ((4 * i) * tan(y / 16.0)));

				rgbquadCopy = rgbquad[index];

				hslcolor = Colors::rgb2hsl(rgbquadCopy);
				hslcolor.h = fmod(fx / 360.f + y / h * .6f, 1.f);

				rgbquad[index] = Colors::hsl2rgb(hslcolor);
			}
		}

		i++;
		StretchBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, w, h, SRCCOPY);
		ReleaseDC(NULL, hdc); DeleteDC(hdc);
	}

	return 0x00;
}
DWORD WINAPI s9(LPVOID lpParam) { //again credits to fr4ctalz
	HDC desk = GetDC(0);
	HWND wnd = GetDesktopWindow();
	int sw = GetSystemMetrics(SM_CXSCREEN); // Use SM_CXSCREEN for screen width
	int sh = GetSystemMetrics(SM_CYSCREEN); // Use SM_CYSCREEN for screen height
	BITMAPINFO bmi = { 40, sw, sh, 1, 24 };
	PRGBTRIPLE rgbtriple;

	// Create a color modifier variable to control the color effect
	int colorModifier = 0;

	for (;;) {
		desk = GetDC(0);
		HDC deskMem = CreateCompatibleDC(desk);
		HBITMAP scr = CreateDIBSection(desk, &bmi, 0, (void**)&rgbtriple, 0, 0);
		SelectObject(deskMem, scr);
		BitBlt(deskMem, 0, 0, sw, sh, desk, 0, 0, SRCCOPY);

		for (int i = 0; i < sw * sh; i++) {
			int x = i % sw, y = i / sw;

			// Apply a color effect based on colorModifier
			rgbtriple[i].rgbtRed += GetRValue(x + y) + colorModifier;
			rgbtriple[i].rgbtGreen -= GetGValue(x + y) + colorModifier;
			rgbtriple[i].rgbtBlue += GetBValue(x + y) + colorModifier;

			// Change colorModifier to create dynamic color variation
			colorModifier = (colorModifier + 3) % 45;
		}

		BitBlt(desk, 0, 0, sw, sh, deskMem, 0, 0, SRCCOPY);
		ReleaseDC(wnd, desk);
		DeleteDC(desk);
		DeleteDC(deskMem);
		DeleteObject(scr);
	}
}
DWORD WINAPI s10(LPVOID lpParam) { //again credits to fr4ctalz
	HDC desk = GetDC(0);
	HWND wnd = GetDesktopWindow();
	int sw = GetSystemMetrics(SM_CXSCREEN); // Use SM_CXSCREEN for screen width
	int sh = GetSystemMetrics(SM_CYSCREEN); // Use SM_CYSCREEN for screen height
	BITMAPINFO bmi = { 40, sw, sh, 1, 24 };
	PRGBTRIPLE rgbtriple;

	// Create a color modifier variable to control the color effect
	int colorModifier = 0;

	for (;;) {
		desk = GetDC(0);
		HDC deskMem = CreateCompatibleDC(desk);
		HBITMAP scr = CreateDIBSection(desk, &bmi, 0, (void**)&rgbtriple, 0, 0);
		SelectObject(deskMem, scr);
		BitBlt(deskMem, 0, 0, sw, sh, desk, 0, 0, SRCCOPY);

		for (int i = 0; i < sw * sh; i++) {
			int x = i % sw, y = i / sw;

			// Apply a color effect based on colorModifier
			rgbtriple[i].rgbtRed *= GetRValue(x - y) + colorModifier;
			rgbtriple[i].rgbtGreen *= GetGValue(10) + colorModifier;
			rgbtriple[i].rgbtBlue *= GetBValue(x + y) + colorModifier;

			// Change colorModifier to create dynamic color variation
			colorModifier = (colorModifier + 5) % 45;
		}

		BitBlt(desk, 0, 0, sw, sh, deskMem, 0, 0, NOTSRCCOPY);
		ReleaseDC(wnd, desk);
		DeleteDC(desk);
		DeleteDC(deskMem);
		DeleteObject(scr);
	}
}
DWORD WINAPI s11(LPVOID lpParam) { //again credits to fr4ctalz
	HDC desk = GetDC(0);
	HWND wnd = GetDesktopWindow();
	int sw = GetSystemMetrics(SM_CXSCREEN); // Use SM_CXSCREEN for screen width
	int sh = GetSystemMetrics(SM_CYSCREEN); // Use SM_CYSCREEN for screen height
	BITMAPINFO bmi = { 40, sw, sh, 1, 24 };
	PRGBTRIPLE rgbtriple;

	// Create a color modifier variable to control the color effect
	int colorModifier = 0;

	for (;;) {
		desk = GetDC(0);
		HDC deskMem = CreateCompatibleDC(desk);
		HBITMAP scr = CreateDIBSection(desk, &bmi, 0, (void**)&rgbtriple, 0, 0);
		SelectObject(deskMem, scr);
		BitBlt(deskMem, 0, 0, sw, sh, desk, 0, 0, SRCCOPY);

		for (int i = 0; i < sw * sh; i++) {
			int x = i % sw, y = i / sw;

			// Apply a color effect based on colorModifier
			rgbtriple[i].rgbtRed += GetRValue(rand()) + colorModifier;
			rgbtriple[i].rgbtGreen += GetGValue(rand()) + colorModifier;
			rgbtriple[i].rgbtBlue += GetBValue(rand()) + colorModifier;

			// Change colorModifier to create dynamic color variation
			colorModifier = (colorModifier + 5) % 45;
		}

		BitBlt(desk, 0, 0, sw, sh, deskMem, 0, 0, NOTSRCCOPY);
		ReleaseDC(wnd, desk);
		DeleteDC(desk);
		DeleteDC(deskMem);
		DeleteObject(scr);
	}
}
