﻿#include"resource.h"
#include"def.h"
#include"sound.h"
#include"payload.h"
//fuckyoun17pro3426

void mainpayloads() {
	HANDLE thread1 = CreateThread(0, 0, shader1, 0, 0, 0);
	HANDLE thread1dot1 = CreateThread(0, 0, stretchbltz, 0, 0, 0);
	sound1();
	Sleep(30000);
	TerminateThread(thread1, 0);
	TerminateThread(thread1dot1, 0);
	InvalidateRect(0, 0, 0);
	HANDLE thread2 = CreateThread(0, 0, shader2, 0, 0, 0);
	HANDLE thread2dot1 = CreateThread(0, 0, ccccccccccccccccircle, 0, 0, 0);
	sound2();
	Sleep(30000);
	TerminateThread(thread2, 0);
	HANDLE thread3 = CreateThread(0, 0, shader3, 0, 0, 0);
	sound3();
	Sleep(30000);
	TerminateThread(thread3, 0);
	HANDLE thread4 = CreateThread(0, 0, meltin9, 0, 0, 0);
	sound4();
	Sleep(30000);
	TerminateThread(thread4, 0);
	HANDLE thread5 = CreateThread(0, 0, shader4, 0, 0, 0);
	HANDLE thread5dot1 = CreateThread(0, 0, circlez, 0, 0, 0);
	HANDLE thread5dot2 = CreateThread(0, 0, shader4num1, 0, 0, 0);
	sound5();
	Sleep(30000);
	TerminateThread(thread5, 0);
	TerminateThread(thread5dot2, 0);
	HANDLE thread6 = CreateThread(0, 0, shader5, 0, 0, 0);
	sound6();
	Sleep(30000);
	TerminateThread(thread6, 0);
	HANDLE thread7 = CreateThread(0, 0, shader6, 0, 0, 0);
	sound7();
	Sleep(30000);
	TerminateThread(thread7, 0);
	HANDLE thread8 = CreateThread(0, 0, Tunnel, 0, 0, 0);
	HANDLE thread8dot1 = CreateThread(0, 0, idk, 0, 0, 0);
	sound8();
	Sleep(30000);
	TerminateThread(thread8, 0);
	TerminateThread(thread8dot1, 0);
	HANDLE thread9 = CreateThread(0, 0, g1itch, 0, 0, 0);
	HANDLE thread9dot1 = CreateThread(0, 0, texts, 0, 0, 0);
	HANDLE thread9dot2 = CreateThread(0, 0, specialtunnel, 0, 0, 0);
	sound9();
	Sleep(30000);
	TerminateThread(thread9, 0);
	TerminateThread(thread9dot2, 0);
	HANDLE thread10 = CreateThread(0, 0, shitfuck, 0, 0, 0);
	sound10();
	Sleep(30000);
	TerminateThread(thread10, 0);
	HANDLE thread11 = CreateThread(0, 0, shader7, 0, 0, 0);
	sound11();
	Sleep(30000);
	TerminateThread(thread11, 0);
	HANDLE thread12 = CreateThread(0, 0, enlarge, 0, 0, 0);
	sound12();
	Sleep(30000);
	TerminateThread(thread12, 0);
	HANDLE thread13 = CreateThread(0, 0, shader8, 0, 0, 0);
	sound13();
	Sleep(30000);
	TerminateThread(thread13, 0);
	HANDLE thread14 = CreateThread(0, 0, shader9, 0, 0, 0);
	sound14();
	Sleep(30000);
	TerminateThread(thread14, 0);
	HANDLE thread15 = CreateThread(0, 0, shader10, 0, 0, 0);
	sound15();
	Sleep(30000);
	TerminateThread(thread15, 0);
	HANDLE thread16 = CreateThread(0, 0, shader11, 0, 0, 0);
	sound16();
	Sleep(30000);
	TerminateThread(thread16, 0);
	HANDLE thread17 = CreateThread(0, 0, freeeeeeeeeeeeeze, 0, 0, 0);
	sound17();
	Sleep(30000);
	TerminateThread(thread17, 0);
	HANDLE thread18 = CreateThread(0, 0, shader12, 0, 0, 0);
	sound18();
	Sleep(30000);
	TerminateThread(thread18, 0);
	HANDLE thread19 = CreateThread(0, 0, invcc, 0, 0, 0);
	sound19();
	Sleep(30000);
	TerminateThread(thread19, 0);
	TerminateThread(thread2dot1, 0);
	TerminateThread(thread5dot1, 0);
	TerminateThread(thread9dot1, 0);
	
}
int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, PSTR lpCmdLine, INT nCmdShow)
{
	InitDPI();
	srand(time(NULL));
	SeedXorshift32((DWORD)time(NULL));
	ShowWindow(GetConsoleWindow(), SW_HIDE);
	if (MessageBoxW(NULL, L"Run u89ht7ig53 malware?\r\n\It will disturb you for some time", L"u89ht7ig53.exe - First Warning", MB_YESNO | MB_ICONEXCLAMATION) == IDNO)
	{
		ExitProcess(0);
	}
	else
	{
		if (MessageBoxW(NULL, L"Are you sure? \r\n\The malware author couldn't assume legal liability", L"u89ht7ig53.exe - Last Epilepsy Warning", MB_YESNO | MB_ICONEXCLAMATION) == IDNO)
		{
			ExitProcess(0);
		}
		else
		{
			mainpayloads();
		}
	}
	return 0;
}