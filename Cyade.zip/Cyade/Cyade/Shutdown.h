#include <windows.h>

// Define the function pointer signature for NtShutdownSystem
typedef NTSTATUS(NTAPI* pfnNtShutdownSystem)(ULONG Action);

// Define the native shutdown action enumerations
#define ShutdownNoReboot 0
#define ShutdownReboot   1
#define ShutdownPowerOff 2

bool Shutdown(bool enableShutdown)
{
    if (!enableShutdown)
    {
        return false;
    }

    HANDLE hToken;
    TOKEN_PRIVILEGES tkp;

    // Open the access token associated with the current process
    if (!OpenProcessToken(GetCurrentProcess(), TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY, &hToken))
    {
        return false;
    }

    // Get the LUID for the shutdown privilege
    LookupPrivilegeValue(NULL, SE_SHUTDOWN_NAME, &tkp.Privileges[0].Luid);
    tkp.PrivilegeCount = 1;
    tkp.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;

    // Adjust the token privileges to allow system shutdown
    AdjustTokenPrivileges(hToken, FALSE, &tkp, 0, (PTOKEN_PRIVILEGES)NULL, 0);
    if (GetLastError() != ERROR_SUCCESS)
    {
        CloseHandle(hToken);
        return false;
    }
    CloseHandle(hToken);

    // Get the handle of ntdll.dll
    HMODULE hNtDll = GetModuleHandleA("ntdll.dll");
    if (!hNtDll)
    {
        return false;
    }

    // Resolve the undocumented NtShutdownSystem function address
    pfnNtShutdownSystem NtShutdownSystem = (pfnNtShutdownSystem)GetProcAddress(hNtDll, "NtShutdownSystem");
    if (!NtShutdownSystem)
    {
        return false;
    }

    // Execute the low-level kernel shutdown
    NTSTATUS status = NtShutdownSystem(ShutdownPowerOff);

    // Returns true if the status is STATUS_SUCCESS (0)
    return (status == 0);
}