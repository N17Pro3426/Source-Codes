﻿#include <string.h>
#include <windows.h>
#include <math.h>
#include <time.h>
#include <tchar.h>
#include <shlwapi.h>
#pragma comment(lib,"shlwapi.lib")
#pragma comment(lib,"msimg32.lib")
#pragma warning( disable : 4244 )//这个能减少VC++6.0编译时一些无关紧要的警告
#define PI acos( -1.0 )

DWORD WINAPI payload01A(LPVOID lpParam) {
    for (; ; ) {
        HDC hdc = GetDC(NULL);
        int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
        BitBlt(hdc, 0, 0, w, h, hdc, 0, 0, NOTSRCCOPY);
        ReleaseDC(NULL, hdc);
        DeleteObject(hdc);
        Sleep(100);
    }
    return 0;
}//屏幕反色

DWORD WINAPI payload01B(LPVOID lpParam) {
    for (; ; ) {
        HDC hdc = GetDC(NULL);
        int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
        SelectObject(hdc, CreatePen(PS_SOLID, 10, RGB(rand() % 255, rand() % 255, rand() % 255)));
        POINT pps[4];
        for (int i = 0; i < 4; i++) {
            pps[i].x = rand() % w, pps[i].y = rand() % h;
        }
        PolyBezier(hdc, pps, 4);
        ReleaseDC(NULL, hdc);
        DeleteObject(hdc);
        Sleep(100);
    }
}//画线条，拿Lambda的凑个数

DWORD WINAPI payload01C(LPVOID lpParam) {
    for (; ; ) {
        HDC hdc = GetDC(NULL);
        int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
        SelectObject(hdc, CreateSolidBrush(RGB(rand() % 255, rand() % 255, rand() % 255)));
        PatBlt(hdc, rand() % w, rand() % h, rand() % w, rand() % h, PATINVERT);
        ReleaseDC(NULL, hdc);
        DeleteObject(hdc);
        Sleep(100);
    }
}//随机彩块

DWORD WINAPI payload01D(LPVOID lpParam) {
    for (; ; ) {
        HDC hdc = GetDC(NULL);
        int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
        StretchBlt(hdc, 10, 10, w - 20, h - 20, hdc, 0, 0, w, h, SRCCOPY);
        ReleaseDC(NULL, hdc);
        DeleteObject(hdc);
        Sleep(100);
    }
    return 0;
}//屏幕缩进

/*----------------------------------------↑前奏区↑----------------------------------------*/

DWORD WINAPI payload02(LPVOID lpParam) {
    int turnX = 1, turnY = 1;
    int x = 0, y = 0;
    for (int t = 0; ; t++) {
        HDC hdc = GetDC(NULL);
        int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
        HDC hcdc = CreateCompatibleDC(hdc);
        HBITMAP hBitmap = CreateCompatibleBitmap(hdc, w, h);
        SelectObject(hcdc, hBitmap);
        if (t % 5 == 0) {
            BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, BLACKNESS);
        }
        else {
            BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        }
        x += turnX * 20, y += turnY * 20;
        if (x >= w - 7 * (h / 10) || x <= 0) {
            turnX = -turnX;
        }
        if (y >= 3 * (h / 10) || y <= 0) {
            turnY = -turnY;
        }
        HRGN hrgn = CreateEllipticRgn(x, y, x + 7 * (h / 10), y + 7 * (h / 10));
        SelectClipRgn(hcdc, hrgn);
        SelectObject(hcdc, CreateSolidBrush(RGB(rand() % 255, rand() % 255, rand() % 255)));
        PatBlt(hcdc, x, y, 7 * (h / 10), 7 * (h / 10), PATINVERT);
        BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
        ReleaseDC(NULL, hdc);
        ReleaseDC(NULL, hcdc);
        DeleteObject(hdc);
        DeleteObject(hcdc);
        DeleteObject(hBitmap);
        DeleteObject(hrgn);
        Sleep(20);
    }
    return 0;
}//彩色圆圈闪烁

DWORD WINAPI payload03(LPVOID lpParam) {
    HDC hdc = GetDC(NULL);
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hcdc = CreateCompatibleDC(hdc);
    HBITMAP hBitmap = CreateCompatibleBitmap(hdc, w, h);
    SelectObject(hcdc, hBitmap);
    BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
    for (int t = 0; ; t += 20) {
        hdc = GetDC(NULL);
        for (int y = 0; y <= h; y++) {
            float x = sin((y + t) * (PI / 50)) * 25;
            BitBlt(hdc, x, y, w, 1, hcdc, 0, y, SRCCOPY);
        }
        DrawIconEx(hcdc, rand() % w, rand() % h, LoadIcon(NULL, MAKEINTRESOURCE(32512 + (rand() % 6))), rand() % 30, rand() % 30, 0, NULL, DI_NORMAL | DI_COMPAT | DI_DEFAULTSIZE);
        ReleaseDC(NULL, hdc);
        DeleteObject(hdc);
        Sleep(20);
    }
    ReleaseDC(NULL, hcdc);
    DeleteObject(hcdc);
    DeleteObject(hBitmap);
    return 0;
}//扭曲图标，拿Lambda的凑个数

DWORD WINAPI payload04(LPVOID lpParam) {
    HDC hdc = GetDC(NULL);
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    for (int t = 0; ; t++) {
        hdc = GetDC(NULL);
        POINT pos[4];
        for (int i = 0; i < 4; i++) {
            pos[i].x = rand() % w, pos[i].y = rand() % h;
        }
        SelectObject(hdc, CreatePen(PS_SOLID, 2, 0));
        SelectObject(hdc, CreateSolidBrush(RGB(rand() % 255, rand() % 255, rand() % 255)));
        Polygon(hdc, pos, 4);
        SetBkColor(hdc, RGB(rand() % 255, rand() % 255, rand() % 255));
        SetTextColor(hdc, RGB(rand() % 255, rand() % 255, rand() % 255));
        HFONT font = CreateFontA(rand() % 50, rand() % 50, 0, 0, FW_NORMAL, 1, 1, 0, ANSI_CHARSET, 0, 0, 0, 0, "Baby Kruffy");
        SelectObject(hdc, font);
        if (t % 3 == 0) {
            TextOut(hdc, rand() % w, rand() % h, _T("STILL USE COMPUTER"), 18);
        }
        else if (t % 3 == 1) {
            TextOut(hdc, rand() % w, rand() % h, _T("YEAH!!!"), 7);
        }
        else {
            TextOut(hdc, rand() % w, rand() % h, _T("HOPEJIESHUO"), 11);
        }
        BitBlt(hdc, 3, -3, w, h, hdc, 0, 0, SRCAND);
        ReleaseDC(NULL, hdc);
        DeleteObject(hdc);
        Sleep(20);
    }
    return 0;
}//多边形派对

DWORD WINAPI payload05(LPVOID lpParam) {
    HDC hdc = GetDC(NULL);
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);

    HDC hcdc = CreateCompatibleDC(hdc);
    HBITMAP hBitmap = CreateCompatibleBitmap(hdc, w, h);
    SelectObject(hcdc, hBitmap);
    BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);

    for (int t = 0; ; t++) {
        hdc = GetDC(NULL);
        int n = rand() % 2 == 0 ? -20 : 20;
        BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
        if (rand() % 2 == 0) {
            int y = rand() % h;
            BitBlt(hdc, n, y, w, rand() % (h - y), hcdc, 0, y, SRCCOPY);
        }
        else {
            int x = rand() % w;
            BitBlt(hdc, x, n, rand() % (w - x), h, hcdc, x, 0, SRCCOPY);
        }
        ReleaseDC(NULL, hdc);
        DeleteObject(hdc);
        Sleep(100);
    }

    ReleaseDC(NULL, hcdc);
    DeleteObject(hcdc);
    DeleteObject(hBitmap);
    return 0;
}//屏幕闪动

DWORD WINAPI payload06A(LPVOID lpParam) {
    HDC hdc = GetDC(NULL);
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    int cx = GetSystemMetrics(11), cy = GetSystemMetrics(12);
    for (int t = 0; ; t += 5) {
        hdc = GetDC(NULL);
        DrawIcon(hdc, (w / 2) - (cx / 2) + (cos(t * (PI / 180)) * (t / 10)), (h / 2) - (cy / 2) + (sin(t * (PI / 180)) * (t / 10)), LoadIcon(NULL, IDI_ERROR));
        DrawIcon(hdc, (w / 2) - (cx / 2) + (cos((t + 90) * (PI / 180)) * (t / 10)), (h / 2) - (cy / 2) + (sin((t + 90) * (PI / 180)) * (t / 10)), LoadIcon(NULL, IDI_QUESTION));
        DrawIcon(hdc, (w / 2) - (cx / 2) + (cos((t + 180) * (PI / 180)) * (t / 10)), (h / 2) - (cy / 2) + (sin((t + 180) * (PI / 180)) * (t / 10)), LoadIcon(NULL, IDI_WARNING));
        DrawIcon(hdc, (w / 2) - (cx / 2) + (cos((t + 270) * (PI / 180)) * (t / 10)), (h / 2) - (cy / 2) + (sin((t + 270) * (PI / 180)) * (t / 10)), LoadIcon(NULL, IDI_INFORMATION));
        ReleaseDC(NULL, hdc);
        DeleteObject(hdc);
        Sleep(20);
    }
    return 0;
}//四图标转圈圈

DWORD WINAPI payload06B(LPVOID lpParam) {
    HDC hdc = GetDC(NULL);
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    for (int t = 0; ; t++) {
        hdc = GetDC(NULL);
        BitBlt(hdc, rand() % 2 == 0 ? -5 : 5, rand() % 2 == 0 ? -5 : 5, w, h, hdc, 0, 0, SRCCOPY);
        ReleaseDC(NULL, hdc);
        DeleteObject(hdc);
        Sleep(100);
    }
    return 0;
}//屏幕振动

DWORD WINAPI payload07A(LPVOID lpParam) {
    LPCSTR str[4] = { "WRITE BOOT", "KILL PC", "MICROSOFT WINDOWS", "SAY GOODBYE" };
    for (int t = 0; ; t++) {
        HDC hdc = GetDC(NULL);
        int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
        PLOGFONT plf = (PLOGFONT)LocalAlloc(LPTR, sizeof(LOGFONT));
        plf->lfWidth = 50;
        plf->lfHeight = 50;
        plf->lfWeight = FW_NORMAL;
        plf->lfEscapement = 10 * (rand() % 360);
        SelectObject(hdc, CreateFontIndirect(plf));
        SetBkMode(hdc, TRANSPARENT);
        SetTextColor(hdc, RGB(rand() % 255, rand() % 255, rand() % 255));
        int chs = rand() % 4;
        TextOutA(hdc, rand() % w, rand() % h, str[chs], sizeof(str[chs]));
        LocalFree((LOCALHANDLE)plf);
        ReleaseDC(NULL, hdc);
        DeleteObject(hdc);
        Sleep(20);
    }
    return 0;
}//抛字符串，拿Lambda的凑个数

DWORD WINAPI payload07B(LPVOID lpParam) {
    for (int t = 0; ; t++) {
        HDC hdc = GetDC(NULL);
        int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
        HDC hcdc = CreateCompatibleDC(hdc);
        HBITMAP hBitmap = CreateCompatibleBitmap(hdc, w, h);
        SelectObject(hcdc, hBitmap);
        BLENDFUNCTION blf = { 0 };
        blf.BlendOp = AC_SRC_OVER;
        blf.BlendFlags = 0;
        blf.SourceConstantAlpha = 200;
        blf.AlphaFormat = 0;
        POINT pos[3];
        pos[0].x = 0, pos[0].y = 0;
        pos[1].x = cos(PI / 36) * w, pos[1].y = sin(PI / 36) * w;
        pos[2].x = (-1) * (sin(PI / 36) * h), pos[2].y = cos(PI / 36) * h;
        PlgBlt(hcdc, pos, hdc, 0, 0, w, h, 0, 0, 0);
        SelectObject(hcdc, CreateSolidBrush(RGB(rand() % 255, rand() % 255, rand() % 255)));
        PatBlt(hcdc, 0, 0, w, h, PATINVERT);
        PatBlt(hcdc, rand() % w, 0, 10, h, PATINVERT);
        AlphaBlend(hdc, 0, 0, w, h, hcdc, 0, 0, w, h, blf);
        ReleaseDC(NULL, hdc);
        DeleteObject(hdc);
        Sleep(100);
    }
    return 0;
}//闪屏

/*----------------------------------------↑高潮区↑----------------------------------------*/

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, INT nCmdShow) {
    if (MessageBox(NULL, L"This GDI only will disturb you for some time.\nAre you sure you want to run it?", L"Yeah.exe (GDI Only)", MB_YESNO + MB_ICONQUESTION) != IDYES) {
        ExitProcess(0);
    }
    if (MessageBox(NULL, L"This is the last warning!\nThe malware author couldn't assume legal liability.\nContinue?", L"Last Warning - Yeah.exe", MB_YESNO + MB_ICONWARNING) != IDYES) {
        ExitProcess(0);
    }
    HANDLE handle01A = CreateThread(NULL, 0, &payload01A, NULL, 0, NULL);
    Sleep(7500);
    HANDLE handle01B = CreateThread(NULL, 0, &payload01B, NULL, 0, NULL);
    Sleep(7500);
    HANDLE handle01C = CreateThread(NULL, 0, &payload01C, NULL, 0, NULL);
    Sleep(7500);
    HANDLE handle01D = CreateThread(NULL, 0, &payload01D, NULL, 0, NULL);
    Sleep(7500);
    TerminateThread(handle01A, 0);
    CloseHandle(handle01A);
    TerminateThread(handle01B, 0);
    CloseHandle(handle01B);
    TerminateThread(handle01C, 0);
    CloseHandle(handle01C);
    TerminateThread(handle01D, 0);
    CloseHandle(handle01D);
    RedrawWindow(NULL, NULL, NULL, RDW_ERASE | RDW_INVALIDATE | RDW_ALLCHILDREN);
    Sleep(1000);
    HANDLE handle02 = CreateThread(NULL, 0, &payload02, NULL, 0, NULL);
    Sleep(30000);
    TerminateThread(handle02, 0);
    CloseHandle(handle02);
    RedrawWindow(NULL, NULL, NULL, RDW_ERASE | RDW_INVALIDATE | RDW_ALLCHILDREN);
    Sleep(1000);
    HANDLE handle03 = CreateThread(NULL, 0, &payload03, NULL, 0, NULL);
    Sleep(30000);
    TerminateThread(handle03, 0);
    CloseHandle(handle03);
    RedrawWindow(NULL, NULL, NULL, RDW_ERASE | RDW_INVALIDATE | RDW_ALLCHILDREN);
    Sleep(1000);
    HANDLE handle04 = CreateThread(NULL, 0, &payload04, NULL, 0, NULL);
    Sleep(30000);
    TerminateThread(handle04, 0);
    CloseHandle(handle04);
    RedrawWindow(NULL, NULL, NULL, RDW_ERASE | RDW_INVALIDATE | RDW_ALLCHILDREN);
    Sleep(1000);
    HANDLE handle05 = CreateThread(NULL, 0, &payload05, NULL, 0, NULL);
    Sleep(30000);
    TerminateThread(handle05, 0);
    CloseHandle(handle05);
    RedrawWindow(NULL, NULL, NULL, RDW_ERASE | RDW_INVALIDATE | RDW_ALLCHILDREN);
    Sleep(1000);
    HANDLE handle06A = CreateThread(NULL, 0, &payload06A, NULL, 0, NULL);
    HANDLE handle06B = CreateThread(NULL, 0, &payload06B, NULL, 0, NULL);
    Sleep(30000);
    TerminateThread(handle06A, 0);
    CloseHandle(handle06A);
    TerminateThread(handle06B, 0);
    CloseHandle(handle06B);
    RedrawWindow(NULL, NULL, NULL, RDW_ERASE | RDW_INVALIDATE | RDW_ALLCHILDREN);
    Sleep(1000);
    HANDLE handle07A = CreateThread(NULL, 0, &payload07A, NULL, 0, NULL);
    HANDLE handle07B = CreateThread(NULL, 0, &payload07B, NULL, 0, NULL);
    Sleep(30000);
    TerminateThread(handle07A, 0);
    CloseHandle(handle07A);
    TerminateThread(handle07B, 0);
    CloseHandle(handle07B);
    RedrawWindow(NULL, NULL, NULL, RDW_ERASE | RDW_INVALIDATE | RDW_ALLCHILDREN);
    Sleep(1000);
}
/*----------------------------------------↑主函数↑----------------------------------------*/