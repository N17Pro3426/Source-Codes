#pragma once
#include<windows.h>

void Writing(int code, const wchar_t* FullFileName);
