﻿// Zoxazolamine.exe: A short GDI malware(no skid)
#include"resource.h"
#include"def.h"
#include"sound.h"
#include"payload.h"
void mainpayloads() {
	HANDLE tb = CreateThread(0, 0, drawicons, 0, 0, 0);
	Sleep(1000);
	CreateThread(0, 0, fakeerror, 0, 0, 0);
	Sleep(5000);
	HANDLE cc = CreateThread(0, 0, chouchu, 0, 0, 0);
	Sleep(1);
	HANDLE t1 = CreateThread(0, 0, move, 0, 0, 0);
	HANDLE fx = CreateThread(0, 0, fansefangxing, 0, 0, 0);
	HANDLE cy = CreateThread(0, 0, coloryuan, 0, 0, 0);
	sound1();
	Sleep(30000);
	InvalidateRect(0, 0, 0);
	TerminateThread(t1, 0);

	HANDLE t2 = CreateThread(0, 0, hatchbrush, 0, 0, 0);
	HANDLE p2 = CreateThread(0, 0, trianglez, 0, 0, 0);
	sound2();
	Sleep(30000);
	InvalidateRect(0, 0, 0);
	TerminateThread(t2, 0);
	TerminateThread(p2, 0);

	HANDLE t3 = CreateThread(0, 0, ppppppppp, 0, 0, 0);
	HANDLE p3 = CreateThread(0, 0, glitch, 0, 0, 0);
	sound3();
	Sleep(30000);
	InvalidateRect(0, 0, 0);
	TerminateThread(t3, 0);
	TerminateThread(p3, 0);

	HANDLE t4 = CreateThread(0, 0, shader1, 0, 0, 0);
	HANDLE p4 = CreateThread(0, 0, textout, 0, 0, 0);
	sound4();
	Sleep(30000);
	InvalidateRect(0, 0, 0);
	TerminateThread(t4, 0);

	HANDLE t5 = CreateThread(0, 0, mess, 0, 0, 0);
	//HANDLE p2dot1 = CreateThread(0, 0, trianglez, 0, 0, 0);
	sound5();
	Sleep(30000);
	InvalidateRect(0, 0, 0);
	TerminateThread(t5, 0);

	HANDLE t6 = CreateThread(0, 0, nein, 0, 0, 0);
	sound6();
	Sleep(30000);
	InvalidateRect(0, 0, 0);
	TerminateThread(t6, 0);
	TerminateThread(fx, 0);
	TerminateThread(cy, 0);

	HANDLE t7 = CreateThread(0, 0, idk, 0, 0, 0);
	HANDLE asdfghjkl = CreateThread(0, 0, shader2, 0, 0, 0);
	sound7();
	Sleep(30000);
	InvalidateRect(0, 0, 0);
	TerminateThread(t7, 0);
	TerminateThread(asdfghjkl, 0);

	HANDLE t8 = CreateThread(0, 0, shader3, 0, 0, 0);
	sound8();
	Sleep(30000);
	InvalidateRect(0, 0, 0);
	TerminateThread(t8, 0);

	HANDLE t9 = CreateThread(0, 0, shader4, 0, 0, 0);
	sound9();
	Sleep(30000);
	InvalidateRect(0, 0, 0);
	TerminateThread(t9, 0);

	HANDLE t10 = CreateThread(0, 0, thing, 0, 0, 0);
	sound10();
	Sleep(30000);
	InvalidateRect(0, 0, 0);
	TerminateThread(t10, 0);

	TerminateThread(cc, 0);
	TerminateThread(p4, 0);
	TerminateThread(tb, 0);
}
int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, PSTR lpCmdLine, INT nCmdShow)
{
	InitDPI();
	srand(time(NULL));
	SeedXorshift32((DWORD)time(NULL));
	ShowWindow(GetConsoleWindow(), SW_HIDE);
	if (MessageBoxW(NULL, L"Run Zoxazolamine malware?\r\n\It will disturb you for some time", L"Zoxazolamine.exe(ｓａｆｅｔｙ　ｖｅｒｓｉｏｎ)", MB_YESNO | MB_ICONEXCLAMATION) == IDNO)
	{
		ExitProcess(0);
	}
	else
	{
		if (MessageBoxW(NULL, L"Are you sure? \r\n\The malware author couldn't assume legal liability", L"Zoxazolamine.exe - Last Epilepsy Warning", MB_YESNO | MB_ICONEXCLAMATION) == IDNO)
		{
			ExitProcess(0);
		}
		else 
		{
			mainpayloads();
		}
	}
	return 0;
}