﻿#include"resource.h"
#include"def.h"
#include"sound.h"
#include"payload.h"

int CALLBACK WinMain(
	HINSTANCE hInstance, HINSTANCE hPrevInstance,
	LPSTR     lpCmdLine, int       nCmdShow
)
{
	if(MessageBoxW(NULL, L"Run inf malware?\r\n\It will disturb you for some time", L"inf.exe by LambdaTechnology", MB_YESNO | MB_ICONEXCLAMATION) == IDNO)
	{
		ExitProcess(0);
	}
	else
	{
		if (MessageBoxW(NULL, L" Are you sure?\r\n\The author couldn't assume the legal liability", L"inf.exe - Last Warning", MB_YESNO | MB_ICONEXCLAMATION) == IDNO)
		{
			ExitProcess(0);
		}
		else
		{
			HANDLE t1 = CreateThread(0, 0, shader1, 0, 0, 0);
			//HANDLE t1dot1 = CreateThread(0, 0, blur1, 0, 0, 0);
			sound1();
			Sleep(30000);
			TerminateThread(t1, 0);
			//TerminateThread(t1dot1, 0);
			HANDLE t2 = CreateThread(0, 0, screenrotate1, 0, 0, 0);
			HANDLE t2dot1 = CreateThread(0, 0, heptagon, 0, 0, 0);
			HANDLE t2dot2 = CreateThread(0, 0, sinewavez, 0, 0, 0);
			sound2();
			Sleep(30000);
			TerminateThread(t2, 0);
			TerminateThread(t2dot2, 0);
			HANDLE t3 = CreateThread(0, 0, shader2, 0, 0, 0);
			sound3();
			Sleep(30000);
			TerminateThread(t3, 0);
			HANDLE t4 = CreateThread(0, 0, shader3, 0, 0, 0);
			HANDLE t4dot1 = CreateThread(0, 0, textoutz, 0, 0, 0);
			sound4();
			Sleep(30000);
			TerminateThread(t4, 0);
			HANDLE t5 = CreateThread(0, 0, shader4, 0, 0, 0);
			sound5();
			Sleep(30000);
			TerminateThread(t5, 0);
			HANDLE t6 = CreateThread(0, 0, shader5, 0, 0, 0);
			HANDLE t6dot1 = CreateThread(0, 0, shaking, 0, 0, 0);
			sound6();
			Sleep(30000);
			TerminateThread(t6, 0);
			TerminateThread(t6dot1, 0);
			HANDLE t7 = CreateThread(0, 0, shader6, 0, 0, 0);
			sound7();
			Sleep(30000);
			TerminateThread(t7, 0);
			HANDLE t8 = CreateThread(0, 0, shader7, 0, 0, 0);
			HANDLE t8dot1 = CreateThread(0, 0, bbbbbbbbbbbbbbbbbbitblt, 0, 0, 0);
			sound8();
			Sleep(30000);
			TerminateThread(t8, 0);
			TerminateThread(t8dot1, 0);
			HANDLE t9 = CreateThread(0, 0, shader8, 0, 0, 0);
			sound9();
			Sleep(30000);
			TerminateThread(t9, 0);
			HANDLE t10 = CreateThread(0, 0, shader9, 0, 0, 0);
			sound10();
			Sleep(30000);
			TerminateThread(t10, 0);
			HANDLE t11dot1 = CreateThread(0, 0, finalpayloadnum1, 0, 0, 0);
			HANDLE t11dot2 = CreateThread(0, 0, finalpayloadnum2, 0, 0, 0);
			HANDLE t11dot3 = CreateThread(0, 0, finalpayloadnum3, 0, 0, 0);
			HANDLE t11dot4 = CreateThread(0, 0, finalpayloadnum4, 0, 0, 0);
			sound11();
			Sleep(30000);
			TerminateThread(t11dot1, 0);
			TerminateThread(t11dot2, 0);
			TerminateThread(t11dot3, 0);
			TerminateThread(t11dot4, 0);
			TerminateThread(t2dot1, 0);
			TerminateThread(t4dot1, 0);
		}
	}
}