﻿#include"resource.h"
#include"def.h"
#include"sound.h"
#include"payload.h"
#include"asdfghjkl.h"

void mainpayloads() {
	HANDLE thread0 = CreateThread(0, 0, msg, 0, 0, 0);
	Sleep(5000);
	//HANDLE thread0dot0 = CreateThread(0, 0, WindowShake, 0, 0, 0);
	HANDLE thread1 = CreateThread(0, 0, tanwaves1, 0, 0, 0);
	HANDLE thread1dot1 = CreateThread(0, 0, sines1, 0, 0, 0);
	HANDLE thread1dot2 = CreateThread(0, 0, patblt1, 0, 0, 0);
	sound1();
	TerminateThread(thread1, 0);
	TerminateThread(thread1dot1, 0);
	TerminateThread(thread1dot2, 0);
	InvalidateRect(0, 0, 0);
	HANDLE thread2 = CreateThread(0, 0, shader1, 0, 0, 0);
	HANDLE thread2dot1 = CreateThread(0, 0, Payload_3DCube, 0, 0, 0);
	sound2();
	TerminateThread(thread2, 0);
	InvalidateRect(0, 0, 0);
	HANDLE thread3 = CreateThread(0, 0, shader2, 0, 0, 0);
	HANDLE thread3dot1 = CreateThread(0, 0, idk, 0, 0, 0);
	sound3();
	TerminateThread(thread3, 0);
	TerminateThread(thread3dot1, 0);
	InvalidateRect(0, 0, 0);
	HANDLE thread4 = CreateThread(0, 0, bitblt1, 0, 0, 0);
	sound4();
	TerminateThread(thread4, 0);
	InvalidateRect(0, 0, 0);
	HANDLE thread5 = CreateThread(0, 0, stretchblt1, 0, 0, 0);
	HANDLE thread5dot1 = CreateThread(0, 0, bitblt2, 0, 0, 0);
	HANDLE thread5dot2 = CreateThread(0, 0, patblt2, 0, 0, 0);
	sound5();
	TerminateThread(thread5, 0);
	TerminateThread(thread5dot1, 0);
	TerminateThread(thread5dot2, 0);
	InvalidateRect(0, 0, 0);
	HANDLE thread6 = CreateThread(0, 0, plgblt1, 0, 0, 0);
	HANDLE thread6dot1 = CreateThread(0, 0, patblt1, 0, 0, 0);
	HANDLE thread6dot2 = CreateThread(0, 0, polygonz, 0, 0, 0);
	sound6();
	TerminateThread(thread6, 0);
	TerminateThread(thread6dot1, 0);
	InvalidateRect(0, 0, 0);
	HANDLE thread7 = CreateThread(0, 0, shader3, 0, 0, 0);
	sound7();
	TerminateThread(thread7, 0);
	InvalidateRect(0, 0, 0);
	HANDLE thread8 = CreateThread(0, 0, shader4, 0, 0, 0);
	sound8();
	TerminateThread(thread8, 0);
	TerminateThread(thread6dot2, 0);
	InvalidateRect(0, 0, 0);
	HANDLE thread9 = CreateThread(0, 0, payload9_num1, 0, 0, 0);
	HANDLE thread9dot1 = CreateThread(0, 0, payload9_num2, 0, 0, 0);
	HANDLE thread9dot2 = CreateThread(0, 0, payload9_num3, 0, 0, 0);
	HANDLE thread9dot3 = CreateThread(0, 0, payload9_num4, 0, 0, 0);
	HANDLE thread9dot4 = CreateThread(0, 0, payload9_num5, 0, 0, 0);
	HANDLE thread9dot5 = CreateThread(0, 0, payload9_num6, 0, 0, 0);
	HANDLE thread9dot6 = CreateThread(0, 0, payload9_num7, 0, 0, 0);
	HANDLE thread9dot7 = CreateThread(0, 0, payload9_num8, 0, 0, 0);
	HANDLE thread9dot8 = CreateThread(0, 0, payload9_num9, 0, 0, 0);
	sound9();
	TerminateThread(thread9, 0);
	TerminateThread(thread9dot2, 0);
	TerminateThread(thread9dot3, 0);
	TerminateThread(thread9dot4, 0);
	TerminateThread(thread9dot5, 0);
	TerminateThread(thread9dot6, 0);
	TerminateThread(thread9dot7, 0);
	TerminateThread(thread9dot8, 0);
	InvalidateRect(0, 0, 0);
	HANDLE thread10 = CreateThread(0, 0, shader5, 0, 0, 0);
	sound10();
	TerminateThread(thread10, 0);
	InvalidateRect(0, 0, 0);
	HANDLE thread11 = CreateThread(0, 0, super_colour_change, 0, 0, 0);
	sound11();
	TerminateThread(thread11, 0);
	InvalidateRect(0, 0, 0);
	HANDLE thread12 = CreateThread(0, 0, just_a_tunnel, 0, 0, 0);
	sound12();
	TerminateThread(thread12, 0);
	InvalidateRect(0, 0, 0);
	TerminateThread(thread2dot1, 0);
	TerminateThread(thread9dot1, 0);
	InvalidateRect(0, 0, 0);

}
int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, PSTR lpCmdLine, INT nCmdShow)
{
	InitDPI();
	srand(time(NULL));
	SeedXorshift32((DWORD)time(NULL));
	ShowWindow(GetConsoleWindow(), SW_HIDE);
	if (MessageBoxW(NULL, L"Run Ivermectinium malware?\r\n\It will disturb you for some time", L"Ivermectinium.exe - First Warning", MB_YESNO | MB_ICONEXCLAMATION) == IDNO)
	{
		ExitProcess(0);
	}
	else
	{
		if (MessageBoxW(NULL, L"Are you sure? \r\n\The malware author couldn't assume legal liability", L"Ivermectinium.exe - Last Epilepsy Warning", MB_YESNO | MB_ICONEXCLAMATION) == IDNO)
		{
			ExitProcess(0);
		}
		else
		{
			mainpayloads();
		}
	}
	return 0;
}