/* THIS FILE WILL BE OVERWRITTEN BY DEV-C++ */
/* DO NOT EDIT ! */

#ifndef ZIP1_01_PRIVATE_H
#define ZIP1_01_PRIVATE_H

/* VERSION DEFINITIONS */
#define VER_STRING	"1.0.1.0"
#define VER_MAJOR	1
#define VER_MINOR	0
#define VER_RELEASE	1
#define VER_BUILD	0
#define COMPANY_NAME	""
#define FILE_VERSION	"1.0.1.0"
#define FILE_DESCRIPTION	"zip version 1.01 fixed hsl"
#define INTERNAL_NAME	""
#define LEGAL_COPYRIGHT	""
#define LEGAL_TRADEMARKS	""
#define ORIGINAL_FILENAME	""
#define PRODUCT_NAME	""
#define PRODUCT_VERSION	"1.0.1.0"

#endif /*ZIP1_01_PRIVATE_H*/
