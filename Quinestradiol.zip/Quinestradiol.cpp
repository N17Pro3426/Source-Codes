﻿#pragma warning(disable:4244)
#pragma warning(disable:4552)
#pragma warning(disable:4554)
#pragma warning(disable:4129)
#pragma warning(disable:4305)
#pragma warning(disable:4715)

#include"def.h"
#include"sound.h"
#include"payload.h"

void mainpayloads() {
	sound1();
	HANDLE s1 = CreateThread(NULL, 0, fault, NULL, 0, NULL);
	HANDLE bb = CreateThread(NULL, 0, bouncyballs, NULL, 0, NULL);
	Sleep(30000);
	TerminateThread(s1, 0);
	TerminateThread(bb, 0);
	InvalidateRect(0, 0, 0);

	sound2();
	HANDLE s2 = CreateThread(NULL, 0, shader1, NULL, 0, NULL);
	HANDLE nein = CreateThread(NULL, 0, textout, NULL, 0, NULL);
	Sleep(30000);
	TerminateThread(s2, 0);
	InvalidateRect(0, 0, 0);

	sound3();
	HANDLE s3 = CreateThread(NULL, 0, shader2, NULL, 0, NULL);
	Sleep(30000);
	TerminateThread(s3, 0);
	InvalidateRect(0, 0, 0);

	sound4();
	HANDLE s4 = CreateThread(NULL, 0, shader3, NULL, 0, NULL);
	Sleep(30000);
	TerminateThread(s4, 0);
	InvalidateRect(0, 0, 0);

	sound5();
	HANDLE s5 = CreateThread(NULL, 0, shader4, NULL, 0, NULL);
	HANDLE q = CreateThread(NULL, 0, sqjslkdjfsjsdjlksdjsdjk, NULL, 0, NULL);
	Sleep(30000);
	TerminateThread(s5, 0);
	InvalidateRect(0, 0, 0);

	sound6();
	HANDLE s6 = CreateThread(NULL, 0, sierpinski, NULL, 0, NULL);
	Sleep(30000);
	TerminateThread(s6, 0);
	InvalidateRect(0, 0, 0);

	sound7();
	HANDLE s7 = CreateThread(NULL, 0, shader5, NULL, 0, NULL);
	Sleep(30000);
	TerminateThread(s7, 0);
	InvalidateRect(0, 0, 0);

	sound8();
	HANDLE s8 = CreateThread(NULL, 0, shader6, NULL, 0, NULL);
	Sleep(30000);
	TerminateThread(s8, 0);
	InvalidateRect(0, 0, 0);

	sound9();
	HANDLE s9 = CreateThread(NULL, 0, shader7, NULL, 0, NULL);
	Sleep(30000);
	TerminateThread(s9, 0);
	InvalidateRect(0, 0, 0);

	sound10();
	HANDLE s10 = CreateThread(NULL, 0, patblt, NULL, 0, NULL);
	HANDLE s = CreateThread(NULL, 0, dick, NULL, 0, NULL);
	Sleep(30000);
	TerminateThread(s10, 0);
	TerminateThread(s, 0);
	InvalidateRect(0, 0, 0);

	sound11();
	HANDLE s11 = CreateThread(NULL, 0, idk, NULL, 0, NULL);
	Sleep(30000);
	TerminateThread(s11, 0);
	InvalidateRect(0, 0, 0);

	TerminateThread(nein, 0);
	TerminateThread(q, 0);
}
int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, PSTR lpCmdLine, INT nCmdShow) {
	InitDPI();
	if (MessageBoxW(NULL, L"Run Quinestradiol malware?\r\n\It will disturb you for some time", L"Quinestradiol.exe -- WARNING", MB_YESNO | MB_ICONWARNING | MB_DEFBUTTON2) == IDYES) {
		if (MessageBoxW(NULL, L"Are you sure?\r\n\The malware author couldn't assume the legal liability", L"Quinestradiol.exe -- FINAL EPILEPSY WARNING", MB_YESNO | MB_ICONWARNING | MB_DEFBUTTON2) == IDYES) {
			mainpayloads();
		}
	}
	return 0;
}