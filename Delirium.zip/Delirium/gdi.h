#pragma once

DWORD WINAPI scarygdi(LPVOID lpParam) {
	HDC desk = GetDC(0);
	HWND wnd = GetDesktopWindow();
	int sw = GetSystemMetrics(0),
		sh = GetSystemMetrics(1);
	BITMAPINFO bmi = { 40, sw, sh, 1, 24 };
	RGBTRIPLE* triple;
	int radius = 25.1f; double angle = 0;
	for (;;) {
		desk = GetDC(0);
		HDC deskMem = CreateCompatibleDC(desk);
		HBITMAP scr = CreateDIBSection(desk, &bmi, 0, (void**)&triple, 0, 0);
		SelectObject(deskMem, scr);
		BitBlt(deskMem, 0, 0, sw, sh, desk, 0, 0, SRCCOPY);
		for (int i = 0; i < sw * sh; i++) {
			int x = i % sw, y = i / sh, t = y ^ y | x;
			triple[i].rgbtRed += 10;
			triple[i].rgbtGreen += 15;
			triple[i].rgbtBlue += x + y;
		}
		float x = sin(angle) * radius, y = tan(angle) + radius;
		BitBlt(desk, 0, 0, sw, sh, deskMem, x, y, NOTSRCERASE);
		ReleaseDC(wnd, desk);
		DeleteDC(desk);
		DeleteDC(deskMem);
		DeleteObject(scr);
		DeleteObject(wnd);
		DeleteObject(triple);
		DeleteObject(&sw);
		DeleteObject(&sh);
		DeleteObject(&bmi);
		angle = fmod(angle + M_PI / radius, M_PI * radius);
		Sleep(1);
	}
}

DWORD WINAPI scaredgdi2(LPVOID lpParam) { 
	HDC hdcScreen = GetDC(0),
		hdcMem = CreateCompatibleDC(hdcScreen);
	INT w = GetSystemMetrics(0),
		h = GetSystemMetrics(1);
	BITMAPINFO bmi = { 0 };
	_RGBQUAD *quad = { 0 };
	bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
	bmi.bmiHeader.biBitCount = 32;
	bmi.bmiHeader.biPlanes = 1;
	bmi.bmiHeader.biWidth = w;
	bmi.bmiHeader.biHeight = h;
	HBITMAP hbmTemp = CreateDIBSection(hdcScreen, &bmi, NULL, (void**)&quad, NULL, NULL);
	SelectObject(hdcMem, hbmTemp);
	for (;;) {
		hdcScreen = GetDC(0);
		BitBlt(hdcMem, 0, 0, w, h, hdcScreen, 0, 0, SRCCOPY);
		for (INT i = 0; i < w * h; i++) {
			INT x = i % w, y = i / w;
			int average = round((float)(quad[i].b + quad[i].r + quad[i].g) / 2);
			quad[i].r = average;
			quad[i].g = average;
			quad[i].b = average;
			quad[i].rgb += x * y;
		}
		BitBlt(hdcScreen, 0, 0, w, h, hdcMem, 0, 0, SRCCOPY);
		ReleaseDC(NULL, hdcScreen);
		DeleteDC(hdcScreen);
	}
}
DWORD WINAPI coptertriple(LPVOID lpParam) {
	HDC hdc = GetDC(0);
	int w = GetSystemMetrics(0);
	int h = GetSystemMetrics(1);
	HDC mdc = CreateCompatibleDC(hdc);
	RGBTRIPLE *triple;
	BITMAPINFO bmi = { 40, w, h, 1, 24 };
	HBITMAP hbm = CreateDIBSection(hdc, &bmi, 0, (void**)&triple, 0, 0);
	while (true) {
		hdc = GetDC(0);
		SelectObject(mdc, hbm);
		BitBlt(mdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		for (int i = 0; i < w * h; i++) {
			int x = i % w, y = i / h, t = y ^ y | x;
			triple[i].rgbtRed += int(sqrt(i)) | (triple[i].rgbtRed) + 123 * x ^ y;
			triple[i].rgbtGreen += int(sqrt(i)) | (triple[i].rgbtGreen) + 123 + x ^ y;
			triple[i].rgbtBlue += int(sqrt(i)) | (triple[i].rgbtBlue) + 123 - x ^ y;
		}
		BitBlt(hdc, 0, 0, w, h, mdc, 0, 0, NOTSRCERASE);
		ReleaseDC(0, hdc);
	}
}
VOID WINAPI SplitBlt(HDC hcdc, HDC hcdc2, int s, int w, int h, DWORD SRC) {
	BitBlt(hcdc, w / 2 + s, 0, w / 2, h / 2, hcdc2, w / 2, s, SRC);
	BitBlt(hcdc, w / 2 + s, h / 2 + s, w / 2, h / 2, hcdc2, w / 2, h / 2, SRC);
	BitBlt(hcdc, 0, 0, w / 2, h / 2, hcdc2, s, s, SRC);
	BitBlt(hcdc, 0, h / 2 + s, w / 2, h / 2, hcdc2, s, h / 2, SRC);
}

DWORD WINAPI geekshader(LPVOID lpParam) { //credits to soheil shahrab, but i modified it
	int w = GetSystemMetrics(0),
		h = GetSystemMetrics(1);
	HDC hdcScreen = GetDC(0), hdcMem = CreateCompatibleDC(hdcScreen);
	BITMAPINFO bmi = { 0 };
	_RGBQUAD *rgbScreen = { 0 };
	bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
	bmi.bmiHeader.biBitCount = 32;
	bmi.bmiHeader.biPlanes = 1;
	bmi.bmiHeader.biWidth = w;
	bmi.bmiHeader.biHeight = h;
	HBITMAP hbmTemp = CreateDIBSection(hdcScreen, &bmi, NULL, (void**)&rgbScreen, NULL, NULL);
	SelectObject(hdcMem, hbmTemp);
	int ii = 0;
	for (;;) {
		hdcScreen = GetDC(0);
		BitBlt(hdcMem, 0, 0, w, h, hdcScreen, 0, 0, SRCCOPY);
		for (INT i = 0; i < w * h; i++) {
			INT x = i % w, y = i / w;
			int code = x ^ y + 3;
			rgbScreen[i].r += y << (code / 1024);
			rgbScreen[i].g += y << (code / 1024);
			rgbScreen[i].b += y << (code / 1024);
		}
		ii++;
		SplitBlt(hdcScreen, hdcMem, cos(ii) * 5, w, h, NOTSRCERASE);
		ReleaseDC(NULL, hdcScreen); DeleteDC(hdcScreen);
	}
	return 0;
}
DWORD WINAPI antandrusshader(LPVOID lpvd) {
	HDC hdc = GetDC(NULL);
	HDC mdc = CreateCompatibleDC(hdc);
	int ws = w / 7, hs = h / 7;
	BITMAPINFO bmpi = { 0 };
	bmpi.bmiHeader.biSize = sizeof(bmpi);
	bmpi.bmiHeader.biWidth = ws;
	bmpi.bmiHeader.biHeight = hs;
	bmpi.bmiHeader.biPlanes = 1;
	bmpi.bmiHeader.biBitCount = 32;
	bmpi.bmiHeader.biCompression = BI_RGB;
	RGBQUAD* rgbquad = NULL;
	HBITMAP hbit = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
	SelectObject(mdc, hbit);
	INT i = 0;
	FLOAT a = 5.0, b = 3.0;
	SetStretchBltMode(hdc, 3);
	SetStretchBltMode(mdc, 3);
	while (true) {
		hdc = GetDC(0);
		StretchBlt(mdc, 0, 0, ws, hs, hdc, 0, 0, w, h, SRCCOPY);
		int randx = rand() % ws;
		int randy = rand() % hs;
		for (int x = 0; x < ws; x++) {
			for (int y = 0; y < hs; y++) {
				int index = y * ws + x;
				int cx = x - randx;
				int cy = y - randy;
				int zx = (cx * cx) / (a * a);
				int zy = (cy * cy) / (b * b);
				int fx = 128.0 + (128.0 * tan(sqrt(zx * zy) / 37.0));
				HSV hsv = Colors::RGBtoHSV(rgbquad[index]);
				hsv.h = fmod(fx + i, 360.0);
				rgbquad[index] = Colors::HSVtoRGB(hsv);
			}
		}
		i++;
		StretchBlt(hdc, 0, 0, w, h, mdc, 0, 0, ws, hs, SRCCOPY);
		ReleaseDC(0, hdc);
		if (rand() % 10 == 5) InvalidateRect(0, 0, 0);
	}
	return 0x00;
}
DWORD WINAPI acroterionshader(LPVOID lpParam) {
	int w = GetSystemMetrics(0),
		h = GetSystemMetrics(1);
	RGBQUAD* data = (RGBQUAD*)VirtualAlloc(0, (w * h + w) * sizeof(RGBQUAD), MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
	int rgb = MAXDWORD64, v = 0, radius = 17.4f;
	double angle = 0;
	for (int i = 0;; i++, i %= 6) {
		HDC hdc = GetDC(0);
		HDC hdcMem = CreateCompatibleDC(hdc);
		HBITMAP hbm = CreateBitmap(w, h, 1, 32, data);
		SelectObject(hdcMem, hbm);
		BitBlt(hdcMem, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		GetBitmapBits(hbm, w * h * 4, data);
		for (int i = 0; w * h > i; i++) {
			if (i % h == 0 && rand() % 100 == 0) v = 2 + rand() % 7;
			rgb ^= (int)data + i % 404;
			((BYTE*)(data + i))[v] += rgb;
		}
		float x = cos(angle) * radius;
		float y = sin(angle) * radius;
		SetBitmapBits(hbm, w * h * 4, data);
		BitBlt(hdc, 0, 0, w, h, hdcMem, x, y, SRCERASE);
		ReleaseDC(0, hdc);
		DeleteObject(hbm); DeleteObject(hdcMem);
		DeleteObject(hdc);
		angle = fmod(angle + M_PI / radius, M_PI * radius);
	}
}
DWORD WINAPI inficshader(LPVOID lpParam)
{
	HDC hdc = GetDC(NULL);
	HDC hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(0);
	int h = GetSystemMetrics(1);
	BITMAPINFO bmpi = { 0 };
	HBITMAP bmp;

	bmpi.bmiHeader.biSize = sizeof(bmpi);
	bmpi.bmiHeader.biWidth = w;
	bmpi.bmiHeader.biHeight = h;
	bmpi.bmiHeader.biPlanes = 1;
	bmpi.bmiHeader.biBitCount = 32;
	bmpi.bmiHeader.biCompression = BI_RGB;

	RGBQUAD* rgbquad = NULL;
	HSL hslcolor;

	bmp = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
	SelectObject(hdcCopy, bmp);

	INT i = 0;

	while (1)
	{
		hdc = GetDC(NULL);
		StretchBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, w, h, SRCCOPY);

		RGBQUAD rgbquadCopy;

		for (int x = 0; x < w; x++)
		{
			for (int y = 0; y < h; y++)
			{
				int index = y * w + x;
				int j = 4 * i;

				//Old-School Plasma effect (Credits to ArTicZera)
				int fx = (int)(j + (j * tan(x / 16.0)) + j + (j * tan(y / 2.0)) + j + (j * tan((x & y) / 16.0)) + j + (j * tan(sqrt((double)(x * x + y * y)) / 2.0))) / 5;

				rgbquadCopy = rgbquad[index];

				hslcolor = Colors::rgb2hsl(rgbquadCopy);
				hslcolor.h = fmod(fx / 404.f + y / h * .10f, 1.f);

				rgbquad[index] = Colors::hsl2rgb(hslcolor);
			}
		}

		i++;
		StretchBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, w, h, SRCCOPY);
		ReleaseDC(NULL, hdc); DeleteDC(hdc);
	}

	return 0x00;
}
DWORD WINAPI debressionpayload(LPVOID lpParam) {
	int i = 0;
	while (true) {
		HDC mhdc = CreateCompatibleDC(0);
		int w = GetSystemMetrics(0);
		int h = GetSystemMetrics(1);
		BITMAPINFO bmi = { 0 };
		bmi.bmiHeader.biSize = sizeof(bmi);
		bmi.bmiHeader.biBitCount = 32;
		bmi.bmiHeader.biPlanes = 1;
		bmi.bmiHeader.biWidth = w;
		bmi.bmiHeader.biHeight = h;
		RGBQUAD* rgbDst = NULL;
		HBITMAP bmp = CreateDIBSection(mhdc, &bmi, DIB_RGB_COLORS, (void**)&rgbDst, 0, NULL);
		SelectObject(mhdc, bmp);
		memset(rgbDst, 0, sizeof(RGBQUAD) * w * h);
		HDC hdc = GetDC(NULL);
		BitBlt(mhdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		for (int x = 0; x < w; x++) {
			for (int y = 0; y < h; y++) {
				FLOAT fx = ((double)(tan(x / 550.f - y / h * 0.1) + i / 5));
				FLOAT fx2 = ((double)(tan(y / 510.f - x / w * 0.1) + i / 5));
				FLOAT fx3 = ((double)(tan(x / 540.f - y / h * 0.1) + i / 5));
				FLOAT fx4 = (fx + fx2 - fx3) * (fx - fx2 + fx3);
				FLOAT fx5 = (fx4 * fx3 + fx2 - fx);
				rgbDst[y * w + x].rgbRed += fx4 - (rgbDst[y * w + x].rgbGreen / 8);
				rgbDst[y * w + x].rgbGreen += fx5 + (rgbDst[y * w + x].rgbBlue / 7);
				rgbDst[y * w + x].rgbBlue += fx5 * (rgbDst[y * w + x].rgbRed / 8);
			}
		}
		i++;
		BitBlt(hdc, 0, 0, w, h, mhdc, 0, 0, NOTSRCERASE);
		ReleaseDC(0, hdc);
		DeleteObject(bmp);
		DeleteDC(mhdc);
	}
}
