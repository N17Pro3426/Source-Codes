// Main libraries
#include <windows.h>
#include <cmath>
#include <ctime>
#include <tchar.h>
#include <iostream>
#include <cstdlib>

// Local libraries
#include "Defines.h"
#include "Payloads.h"
#include "Sounds.h"

// DLLs
#pragma comment(lib, "Winmm.lib")
#pragma comment(lib, "msimg32.lib")
#pragma comment(lib, "ntdll.lib")
#pragma comment(lib, "kernel32.lib")


