/* THIS FILE WILL BE OVERWRITTEN BY DEV-C++ */
/* DO NOT EDIT ! */

#ifndef PROJECT1_PRIVATE_H
#define PROJECT1_PRIVATE_H

/* VERSION DEFINITIONS */
#define VER_STRING	"1.0.0.0"
#define VER_MAJOR	1
#define VER_MINOR	0
#define VER_RELEASE	0
#define VER_BUILD	0
#define COMPANY_NAME	"Very Small Team (Soheil & Chatgpt)"
#define FILE_VERSION	"1.0.0.0"
#define FILE_DESCRIPTION	"Polynizum (Built By Soheil, Chatgpt, DeepSeek)"
#define INTERNAL_NAME	"Polynizum 2.0"
#define LEGAL_COPYRIGHT	""
#define LEGAL_TRADEMARKS	""
#define ORIGINAL_FILENAME	"Polynizum"
#define PRODUCT_NAME	"Polynizum"
#define PRODUCT_VERSION	"1.0.0.0"

#endif /*PROJECT1_PRIVATE_H*/
