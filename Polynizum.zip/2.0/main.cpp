#include <windows.h>
#include <tchar.h>
#include <vector>
#include <random>
#include <cmath>
#include <atomic>
#include <thread>
#include <memory>
#include <algorithm>
#include <gdiplus.h>
#include "Chair.h"

#define PI 3.14159265358979323846264338327950288f
#define INV_255 (1.0f / 255.0f)
const float Bsine = 4.0f / PI;
const float Csine = -4.0f / (PI * PI);
    
// Use atomic variables for thread safety
short SHD = 1; // Which Pattern the HSV Shader Should Render
short Msc = 1; // Which Pattern the Mosaic Should Render
std::atomic<bool> ExT(true); // Exit Payloads
std::atomic<bool> VExT(true); // Exit HSV Payloads

// Fast sine approximation using Bhaskara I's approximation
inline float Fsin(float x) {
    x = fmodf(x + PI, 2 * PI) - PI;
    
    float y = Bsine * x + Csine * x * fabsf(x);
    return 0.225f * (y * fabsf(y) - y) + y;
}

typedef struct {
    float h, s, v;
} HSV;

// Optimized RGB to HSV conversion
inline HSV rgb2hsv(const RGBQUAD& rgb) {
    HSV hsv;
    
    // Normalize RGB values
    const float rd = rgb.rgbRed * INV_255;
    const float gd = rgb.rgbGreen * INV_255;
    const float bd = rgb.rgbBlue * INV_255;
    
	const float maxVal = std::max({rd, gd, bd});
	const float minVal = std::min({rd, gd, bd});
    
    hsv.v = maxVal;
    const float delta = maxVal - minVal;
    
    if (delta <= 0.0f) {
        hsv.h = hsv.s = 0.0f;
        return hsv;
    }
    
    hsv.s = delta / maxVal;
    
	// Calculate hue with optimized branching
    if (maxVal == rd) {
        hsv.h = ((gd - bd) / delta) * 60.0f;
    } 
    else if (maxVal == gd) {
        hsv.h = ((bd - rd) / delta + 2.0f) * 60.0f;
    } 
    else {
        hsv.h = ((rd - gd) / delta + 4.0f) * 60.0f;
    }
    
    // Normalize hue
    hsv.h += (hsv.h < 0.0f) ? 360.0f : 0.0f;
    
    return hsv;
}

// Optimized RGB to HSV conversion without hue calculation
inline HSV rgb2hsvNh(const RGBQUAD& rgb) {
    HSV hsv; 
    hsv.h = 0.0;
    
    const float rd = rgb.rgbRed * INV_255;
    const float gd = rgb.rgbGreen * INV_255;
    const float bd = rgb.rgbBlue * INV_255;
    
	const float maxVal = std::max({rd, gd, bd});
	const float minVal = std::min({rd, gd, bd});
    
    hsv.v = maxVal;
    const float delta = maxVal - minVal;
    
    if (delta <= 0.0f) {
        hsv.s = 0.0f;
        return hsv;
    }
    
    hsv.s = delta / maxVal;
    return hsv;
}

// Optimized HSV to RGB conversion
inline RGBQUAD hsv2rgb(const HSV& hsv) {
    float s = hsv.s;
    float l = hsv.v * 255.0f;
    BYTE v = static_cast<BYTE>(l);
    if (s <= 0) { // Achromatic (gray)
        return { v, v, v, 0 };
    } else {
    	
    float h = fmodf(hsv.h / 60.0f, 60.0f); // Convert hue to [0, 6] (start from red to green to blue to red)
    BYTE i = static_cast<BYTE>(h);
    float f = h - i; // Fractional part of h
    BYTE p = static_cast<BYTE>(l * (1 - s)); //BYTE because there is no more calculation and once it reaches rgb, it becomes BYTE.
    BYTE q = static_cast<BYTE>(l * (1 - f * s)); //BYTE because there is no more calculation and once it reaches rgb, it becomes BYTE.
    BYTE t = static_cast<BYTE>(l * (1 - (1 - f) * s)); //BYTE because there is no more calculation and once it reaches rgb, it becomes BYTE.

    	switch (i % 6) {
        	case 0: return {p, t, v, 0}; break;
        	case 1: return {p, v, q, 0}; break;
        	case 2: return {t, v, p, 0}; break;
        	case 3: return {v, q, p, 0}; break;
        	case 4: return {v, p, t, 0}; break;
        	case 5: return {q, p, v, 0}; break;
        	default: return {0, 0, 0, 0}; break; //fallback (not recomended to reach here but for handling issues)
    	}
	}
}

// Predefined colors for better performance
constexpr COLORREF predefinedColors[] = {
    RGB(255, 0, 0),    // Red
    RGB(0, 255, 0),    // Green
    RGB(0, 0, 255),    // Blue
    RGB(255, 0, 255),  // Magenta
    RGB(255, 255, 0)   // Yellow
};

inline COLORREF RndRGB() {
    return predefinedColors[rand() % (sizeof(predefinedColors)/sizeof(COLORREF))];
}

DWORD WINAPI shaderHSV(LPVOID) { //DRY optimization (Don't Repeat Yourself)
    const int width = GetSystemMetrics(SM_CXSCREEN);
    const int height = GetSystemMetrics(SM_CYSCREEN);
    
    // Initialize DCs and bitmap once
    HDC screenDC = GetDC(nullptr);
    HDC copyDC = CreateCompatibleDC(screenDC);
    BITMAPINFO bmpi = { sizeof(BITMAPINFOHEADER), width, -height, 1, 32, BI_RGB };
    
    RGBQUAD* rgbquad = nullptr;
    HBITMAP bmp = CreateDIBSection(screenDC, &bmpi, DIB_RGB_COLORS, reinterpret_cast<void**>(&rgbquad), nullptr, 0);
    if (!bmp || !rgbquad) {
        ReleaseDC(nullptr, screenDC);
        DeleteDC(copyDC);
        return 1;
    }
    
    SelectObject(copyDC, bmp);
    ReleaseDC(nullptr, screenDC);
    
    std::atomic<long> fc(1);
    const int numThreads = std::thread::hardware_concurrency();
    std::vector<std::thread> threads;
    threads.reserve(numThreads);
    
    while (VExT.load(std::memory_order_relaxed)) {
        screenDC = GetDC(nullptr);
        if (!screenDC) continue;
        
        if (BitBlt(copyDC, 0, 0, width, height, screenDC, 0, 0, SRCCOPY)) {
            const int rowsPerThread = height / numThreads;
            const long currentFc = fc.load(std::memory_order_relaxed);
            
            // Process rows in parallel
            for (int i = 0; i < numThreads; ++i) {
                const int startRow = i * rowsPerThread;
                const int endRow = (i == numThreads - 1) ? height : (startRow + rowsPerThread);
                
            	switch(SHD) {
				case 2: { threads.emplace_back([=, &rgbquad] { for (int y = startRow; y < endRow; ++y) {
                        RGBQUAD* rowStart = rgbquad + y * width;
                        for (int x = 0; x < width; ++x) {
                            HSV currentHsv = rgb2hsvNh(rowStart[x]);
                            currentHsv.h = fmodf(((x*x)^(abs(x-y)+1)) * currentFc / 200.0, 360.0);
                            rowStart[x] = hsv2rgb(currentHsv);
                        } } }); break; }
				case 3: { threads.emplace_back([=, &rgbquad] { for (int y = startRow; y < endRow; ++y) {
                        RGBQUAD* rowStart = rgbquad + y * width;
                        for (int x = 0; x < width; ++x) {
                            HSV currentHsv = rgb2hsvNh(rowStart[x]);
                            currentHsv.h = fmodf(((x&y)^(x+y)) * currentFc / 200.0, 360.0);
                            rowStart[x] = hsv2rgb(currentHsv);
                        } } }); break; }
				case 4: { threads.emplace_back([=, &rgbquad] { for (int y = startRow; y < endRow; ++y) {
                        RGBQUAD* rowStart = rgbquad + y * width;
                        for (int x = 0; x < width; ++x) {
                            HSV currentHsv = rgb2hsvNh(rowStart[x]);
                            currentHsv.h = fmodf((x+(x^(x&(y*y)))) * currentFc / 200.0, 360.0);
                            rowStart[x] = hsv2rgb(currentHsv);
                        } } }); break; }
				case 5: { threads.emplace_back([=, &rgbquad] { for (int y = startRow; y < endRow; ++y) {
                        RGBQUAD* rowStart = rgbquad + y * width;
                        for (int x = 0; x < width; ++x) {
                            HSV currentHsv = rgb2hsvNh(rowStart[x]);
                            currentHsv.h = fmodf((x+(y&(x+y))*(y&x+y)) * currentFc / 200.0, 360.0);
                            rowStart[x] = hsv2rgb(currentHsv);
                        } } }); break; }
				case 6: { threads.emplace_back([=, &rgbquad] { for (int y = startRow; y < endRow; ++y) {
                        RGBQUAD* rowStart = rgbquad + y * width;
                        for (int x = 0; x < width; ++x) {
                            HSV currentHsv = rgb2hsvNh(rowStart[x]);
                            currentHsv.h = fmodf(((x&y*5)^(x*5|y)) * currentFc / 200.0, 360.0);
                            rowStart[x] = hsv2rgb(currentHsv);
                        } } }); break; }
				case 7: { threads.emplace_back([=, &rgbquad] { for (int y = startRow; y < endRow; ++y) {
                        RGBQUAD* rowStart = rgbquad + y * width;
                        for (int x = 0; x < width; ++x) {
                            HSV currentHsv = rgb2hsvNh(rowStart[x]);
                            currentHsv.h = fmodf((((x&y)+(x*x)|y)^(y*(x|y))) / 400.0 + (currentFc * 16.0), 360.0);
                            rowStart[x] = hsv2rgb(currentHsv);
                        } } }); break; }
				case 8: { threads.emplace_back([=, &rgbquad] { for (int y = startRow; y < endRow; ++y) {
                        RGBQUAD* rowStart = rgbquad + y * width;
                        for (int x = 0; x < width; ++x) {
                            HSV currentHsv = rgb2hsvNh(rowStart[x]);
                            currentHsv.s = 0;
                            rowStart[x] = hsv2rgb(currentHsv);
                        } } }); break; }
    			case 9: { threads.emplace_back([=, &rgbquad] { for (int y = startRow; y < endRow; ++y) {
                        RGBQUAD* rowStart = rgbquad + y * width;
                        for (int x = 0; x < width; ++x) {
                            HSV currentHsv = rgb2hsvNh(rowStart[x]);
                            currentHsv.h = fabsf(fmodf((x|(x+x^(x&x/2))^(y^(x/2^y+(y&y/2))|y&(y/2^y))) * currentFc / 200.0f, 240.0f) - 120.0f) / 1.75f;
                            rowStart[x] = hsv2rgb(currentHsv);
                        } } }); break; }
    			case 10: { threads.emplace_back([=, &rgbquad] { for (int y = startRow; y < endRow; ++y) {
                        RGBQUAD* rowStart = rgbquad + y * width;
                        for (int x = 0; x < width; ++x) {
                            HSV currentHsv = rgb2hsvNh(rowStart[x]);
                            currentHsv.h = fabsf(fmodf((x*y/(abs(x^y)+1)) * currentFc / 200.0f, 240.0f) - 120.0f) / 1.75f;
                            rowStart[x] = hsv2rgb(currentHsv);
                        } } }); break; }
    			case 11: { threads.emplace_back([=, &rgbquad] { for (int y = startRow; y < endRow; ++y) {
                        RGBQUAD* rowStart = rgbquad + y * width;
                        for (int x = 0; x < width; ++x) {
                            HSV currentHsv = rgb2hsvNh(rowStart[x]);
                            currentHsv.h = fabsf(fmodf(((x^(y/2+x)&x+(y/2)|y/4+x)^(y^(x/2+y)&y+(x/2)|x/4+y)) * currentFc / 200.0f, 240.0f) - 120.0f) / 1.25f + 160.0f;
                            rowStart[x] = hsv2rgb(currentHsv);
                        } } }); break; }
    			case 12: { threads.emplace_back([=, &rgbquad] { for (int y = startRow; y < endRow; ++y) {
                        RGBQUAD* rowStart = rgbquad + y * width;
                        for (int x = 0; x < width; ++x) {
                            HSV currentHsv = rgb2hsvNh(rowStart[x]);
                            currentHsv.h = fabsf(fmodf(((x^(y/2+x)|y/4+x)^((x|y+(x/3)|y)&(x+y))) * currentFc / 200.0f, 240.0f) - 120.0f) / 1.5f + 160.0f;
                            rowStart[x] = hsv2rgb(currentHsv);
                        } } }); break; }
    			case 13: { threads.emplace_back([=, &rgbquad] { for (int y = startRow; y < endRow; ++y) {
                        RGBQUAD* rowStart = rgbquad + y * width;
                        for (int x = 0; x < width; ++x) {
                            HSV currentHsv = rgb2hsvNh(rowStart[x]);
                            currentHsv.h = fmodf(((x&(y/2+x)|y/4+x)^((x^(y/2)|y)&(x+y))) * currentFc / 200.0, 360.0);
                            rowStart[x] = hsv2rgb(currentHsv);
                        } } }); break; }
    			case 14: { threads.emplace_back([=, &rgbquad] { for (int y = startRow; y < endRow; ++y) {
                        RGBQUAD* rowStart = rgbquad + y * width;
                        for (int x = 0; x < width; ++x) {
                            HSV currentHsv = rgb2hsvNh(rowStart[x]);
                            currentHsv.h = fmodf((x>y?x:y) / 200.0 * currentFc, 360.0);
                            rowStart[x] = hsv2rgb(currentHsv);
                        } } }); break; }
    			case 15: { threads.emplace_back([=, &rgbquad] { for (int y = startRow; y < endRow; ++y) {
                        RGBQUAD* rowStart = rgbquad + y * width;
                        for (int x = 0; x < width; ++x) {
                            HSV currentHsv = rgb2hsvNh(rowStart[x]);
                            currentHsv.h = fabsf(fmodf((Fsin(x*PI/120)+Fsin((y*PI/120)+(PI/2)))*120*(currentFc/100.0f+1), 720.0f) - 360.0f);
                            rowStart[x] = hsv2rgb(currentHsv);
                        } } }); break; }
    			case 16: { threads.emplace_back([=, &rgbquad] { for (int y = startRow; y < endRow; ++y) {
                        RGBQUAD* rowStart = rgbquad + y * width;
                        for (int x = 0; x < width; ++x) {
                            HSV currentHsv = rgb2hsvNh(rowStart[x]);
                            currentHsv.h = fabsf(fmodf((x&(x+y)) * currentFc / 200.0f, 240.0f) - 120.0f) / 1.25f + 200.0f;
                            rowStart[x] = hsv2rgb(currentHsv);
                        } } }); break; }
    			case 17: { threads.emplace_back([=, &rgbquad] { for (int y = startRow; y < endRow; ++y) {
                        RGBQUAD* rowStart = rgbquad + y * width;
                        for (int x = 0; x < width; ++x) {
                            HSV currentHsv = rgb2hsvNh(rowStart[x]);
                            currentHsv.h = fabsf(fmodf(abs((x-int(y*currentFc/50.0f))^(int(x*currentFc/50.0f)+y)) / (currentFc / 50.0f), 240.0f) - 120.0f) / 1.25f + 200.0f;
                            rowStart[x] = hsv2rgb(currentHsv);
                        } } }); break; }
                default: { threads.emplace_back([=, &rgbquad] { for (int y = startRow; y < endRow; ++y) {
                        RGBQUAD* rowStart = rgbquad + y * width;
                        for (int x = 0; x < width; ++x) {
                            HSV currentHsv = rgb2hsvNh(rowStart[x]);
                            currentHsv.h = fmodf((((currentFc ^ 4) + (currentFc * 4) * sqrt(y ^ x * currentFc)) / 600.0f + y / static_cast<float>(height)) * 72.0f, 360.0f);
                            rowStart[x] = hsv2rgb(currentHsv);
                        } } }); break; }
            	}
        	}
            
            // Wait for all threads
            for (auto& thread : threads) {
                thread.join();
            }
            threads.clear();
            
            if (BitBlt(screenDC, 0, 0, width, height, copyDC, 0, 0, SRCCOPY)) {
                Sleep(6); fc.fetch_add(1, std::memory_order_relaxed);
            }
        }
        ReleaseDC(nullptr, screenDC);
    }
    
    if (bmp) DeleteObject(bmp);
    if (copyDC) DeleteDC(copyDC);
    if (screenDC) ReleaseDC(nullptr, screenDC);
    return 0;
}

DWORD WINAPI swirl(LPVOID lpParam) {
    const int sw = GetSystemMetrics(SM_CXSCREEN);
    const int sh = GetSystemMetrics(SM_CYSCREEN);
    const int xSize = sh / 10;
    const int ySize = 9;
    const float invXSize = 1.0f / xSize;
    
    // Pre-calculate wave patterns once
    std::vector<int> horizontalWaves(sw);
    std::vector<int> verticalWaves(sh);
    
    // Pre-calculate sine values to avoid repeated calculations
    for (int i = 0; i < sw; ++i) {
        horizontalWaves[i] = static_cast<int>(Fsin(i * invXSize * PI) * ySize);
    }
    for (int i = 0; i < sh; ++i) {
        verticalWaves[i] = static_cast<int>(Fsin(i * invXSize * PI) * ySize);
    }
    
    // Initialize random number generator
    std::mt19937 gen(GetTickCount());
    std::uniform_int_distribution<> dist(0, 255);
    
    // Initialize graphics objects
    HDC hdc = GetDC(nullptr);
    HDC hdcMem = CreateCompatibleDC(hdc);
    HBITMAP screenshot = CreateCompatibleBitmap(hdc, sw, sh);
    HBITMAP oldBmp = static_cast<HBITMAP>(SelectObject(hdcMem, screenshot));
    
    while (ExT) {
        hdc = GetDC(nullptr);
        
        // Create a random color brush
        HBRUSH brush = CreateSolidBrush(RGB(dist(gen), dist(gen), dist(gen)));
        HBRUSH oldBrush = static_cast<HBRUSH>(SelectObject(hdc, brush));
        SelectObject(hdcMem, brush);
        
        // Capture screen
        BitBlt(hdcMem, 0, 0, sw, sh, hdc, 0, 0, 11272462);
        
        // Apply horizontal waves using pre-calculated values
        for (int i = 0; i < sw; ++i) {
            HBRUSH waveBrush = CreateSolidBrush(RGB(dist(gen), dist(gen), dist(gen)));
            SelectObject(hdcMem, waveBrush);
            BitBlt(hdcMem, i, 0, 1, sh, hdcMem, i, horizontalWaves[i], 11272462);
            DeleteObject(waveBrush);
        }
        
        // Apply vertical waves using pre-calculated values
        for (int i = 0; i < sh; ++i) {
            HBRUSH waveBrush = CreateSolidBrush(RGB(dist(gen), dist(gen), dist(gen)));
            SelectObject(hdcMem, waveBrush);
            BitBlt(hdcMem, 0, i, sw, 1, hdcMem, verticalWaves[i], i, 11272462);
            DeleteObject(waveBrush);
        }
        
        // Draw the result to screen
        BitBlt(hdc, 0, 0, sw, sh, hdcMem, 0, 0, 11272462);
        
        // Clean up
        SelectObject(hdc, oldBrush);
        DeleteObject(brush);
        ReleaseDC(nullptr, hdc);
    }
    
    // Final cleanup
    SelectObject(hdcMem, oldBmp);
    DeleteObject(screenshot);
    DeleteDC(hdcMem);
    
    return 0;
}

DWORD WINAPI TEXTs(LPVOID lpParam) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1), X, Y, thing; HDC hdc = GetDC(0); HDC hdc2 = GetDC(0);
    BitBlt(hdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
    while (ExT) {
        hdc = GetDC(0);
        hdc2 = GetDC(0);
        SetBkMode(hdc, 0);
        SetBkMode(hdc2, 0);
        w = GetSystemMetrics(0), h = GetSystemMetrics(1);
        X = rand() % 50 + 50, Y = rand() % 65 + 65;
        HFONT hfnt = CreateFontA(Y, X, 0, 0, FW_THIN, 1, 0, 0, ANSI_CHARSET, 0, 0, 0, 0, "Fredoka");
        HFONT hfnt2 = CreateFontA(Y, X, 0, 0, FW_THIN, 1, 0, 0, ANSI_CHARSET, 0, 0, 0, 0, "Fredoka");
        SelectObject(hdc, hfnt);
        SelectObject(hdc2, hfnt2);
        LPCSTR things[] = {
            "Polyzium", "High-Complexity", "<?>"
        };
        thing = rand() % 3;
        SetTextColor(hdc, RndRGB());
        SetTextColor(hdc2, RndRGB());
        X = rand() % w, Y = rand() % h;
        TextOutA(hdc, X - 8, Y, things[thing], strlen(things[thing]));
        TextOutA(hdc2, X + 8, Y, things[thing], strlen(things[thing]));
        DeleteObject(hfnt);
        DeleteObject(hfnt2);
        ReleaseDC(0, hdc);
        ReleaseDC(0, hdc2);
        Sleep(10);
    }
    return 0;
}

DWORD WINAPI Pat_BLT(LPVOID lpParam) {
    while (ExT) {
        HDC hdc = GetDC(0);
        int w = GetSystemMetrics(0);
        int h = GetSystemMetrics(1);
        
        // Using DC_BRUSH instead of creating new brushes
        SetDCBrushColor(hdc, RGB(rand() % 255, rand() % 255, rand() % 255));
        SelectObject(hdc, GetStockObject(DC_BRUSH));
        
        PatBlt(hdc, 0, 0, w, h, PATINVERT);
        ReleaseDC(0, hdc);
        Sleep(6);
    }
    return 0;
}

VOID WINAPI sound(BYTE MD, DWORD SMPLRT, BYTE Duration) {
    const int MAX_RETRIES = 10; // Maximum number of retry attempts
    int retry_count = 0;
    bool success = false;
    
    do {
        HWAVEOUT hWaveOut = 0;
        WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, SMPLRT, SMPLRT, 1, 8, 0 };
        MMRESULT result = waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
        
        if (result != MMSYSERR_NOERROR) {
            ++retry_count;
            if (retry_count < MAX_RETRIES) {
                Sleep(84); // Small delay before retry
                continue;
            }
            break; // Give up after max retries
        }

        char buffer[SMPLRT * Duration] = {};
        try {
            switch (MD) {
        		case 1: { for (unsigned int t = 0; t < sizeof(buffer); ++t) buffer[t] = static_cast<char>(2*t^2*t+(t>>7)&t>>12|t>>4-(1^7&t>>19)|t^t>>4^(t>>11+(t>>16)%3)%16*t^3*t); break; }
        		case 2: { for (unsigned int t = 0; t < sizeof(buffer); ++t) buffer[t] = static_cast<char>((((t*-(t>>8|t|t>>9|t>>13)^t)&-t>>(((t>>8|t|t>>9|t>>13)>>5)+1))&255)/2+int((16384/(t%4096+1)&192)/3*2)); break; }
        		case 3: { for (unsigned int t = 0; t < sizeof(buffer); ++t) buffer[t] = static_cast<char>(((-(t&t/2&t/4)*t-1)/4096&255)/2+int((16384/(t%4096+1)&192)/3*2)+int((16384/(t%12288+1)&192)/3*2)); break; }
        		case 4: { for (unsigned int t = 0; t < sizeof(buffer); ++t) buffer[t] = static_cast<char>(t>>6^t>>1&37|t+(t^t>>11)-t*((t%24?2:6)&t>>10)^t*2&t>>(t&598?4:11)); break; }
        		case 5: { for (unsigned int t = 0; t < sizeof(buffer); ++t) buffer[t] = static_cast<char>((t/4*(4|t>>14&3)>>(~t>>12&1)&64)+(3*t*(t>>12&t>>14)%256*(-t/2&2047)/5120)+((t*(t>>13&1?(t/2%256^t/14)*t/10%255:t&16384?2:1)&128)*(-t/2&4095>>(-t>>13&1))/3072>>(t>>13&1))); break; }
        		case 6: { for (unsigned int t = 0; t < sizeof(buffer); ++t) buffer[t] = static_cast<char>(t*4+((t>>4)%64*((t>>9)%128))/64&128); break; }
        		case 7: { for (unsigned int t = 0; t < sizeof(buffer); ++t) buffer[t] = static_cast<char>((((t>>2)*(t>>5)|t>>5)&255)^(((t>>4)*(t>>3)|t>>3)&255)); break; }
        		case 8: { for (unsigned int t = 0; t < sizeof(buffer); ++t) buffer[t] = static_cast<char>(((t&32767)>>13==2|(t&65535)>>12==9?(t^-(t/8&t>>5)*(t/8&127))&(-(t>>5)&255)*((t&65535)>>12==9?2:1):(t&8191)%((t>>5&255^240)==0?1:t>>5&255^240))/4*3); break; }
        		case 9: { for (unsigned int t = 0; t < sizeof(buffer); ++t) buffer[t] = static_cast<char>((t^t%1001+t^t%1002)|t>>t); break; }
        		case 10: { for (unsigned int t = 0; t < sizeof(buffer); ++t) buffer[t] = static_cast<char>(((-t%128|t%130)&127)+((t*(t>>14?(t>>11&42|t>>8&42):0)&255)/3)); break; }
        		case 11: { for (unsigned int t = 0; t < sizeof(buffer); ++t) buffer[t] = static_cast<char>((1+(t>>14&t>>11|(t>>12)^t>>13))*(t/2^t/2+(t>>8&3|t>>9&11|-t>>12&14))); break; }
        		case 12: { for (unsigned int t = 0; t < sizeof(buffer); ++t) buffer[t] = static_cast<char>(t*((t>>12|t>>9)&241&t>>4)); break; }
        		case 13: { for (unsigned int t = 0; t < sizeof(buffer); ++t) buffer[t] = static_cast<char>((2*t&255)*(-t>>6&t>>7)>>8|t&t>>1); break; }
        		case 14: { for (unsigned int t = 0; t < sizeof(buffer); ++t) buffer[t] = static_cast<char>(t>>(t>>12)*t/127|t>>4|t/4*(t>>15)); break; }
       			case 15: { for (unsigned int t = 0; t < sizeof(buffer); ++t) buffer[t] = static_cast<char>((((t>>10|t*5)&(t>>8|t*4)&(t>>4|t*6))&255)/2+(((t>>11|t*8)&(t>>9|t*3)&(t>>3|t*7))&255)/4+(((t>>12|t*12)&(t>>6|t*7)&(t>>10|t*2))&255)/5); break; }     
        		case 16: { for (unsigned int t = 0; t < sizeof(buffer); ++t) buffer[t] = static_cast<char>(t>>6^t&t>>9^t>>12|(t<<(t>>6)%4^-t&-t>>13)%128^-t&t>>3); break; }     
        		case 17: { for (unsigned int t = 0; t < sizeof(buffer); ++t) buffer[t] = static_cast<char>(-t*(t>>3|t>>4|t>>5|t>>6|t>>7|t>>10|t>>12)-t|32768/(t*((t>>11&t>>15)%3+1)%4096+1)); break; }     
        		case 18: { for (unsigned int t = 0; t < sizeof(buffer); ++t) buffer[t] = static_cast<char>((-t&t>>4&t>>4&t>>11)-1|t>>1); break; }       
        		case 19: { for (unsigned int t = 0; t < sizeof(buffer); ++t) buffer[t] = static_cast<char>(((t>>6^t>>8|t*(15&39014>>(t>>14&12))/6)&255)+64); break; }       
        		case 20: { for (unsigned int t = 0; t < sizeof(buffer); ++t) buffer[t] = static_cast<char>(t/4>>(t/4&7)|t/4<<(t/4&42)|t>>9|t<<3); break; }
				case 21: { for (unsigned int t = 0; t < sizeof(buffer); ++t) buffer[t] = static_cast<char>(t/4*(t/4>>((t&16384?t*t:t)>>12))|t<<(t>>9)|t>>((t>>14&3)+4)); break; }       
        		case 22: { for (unsigned int t = 0; t < sizeof(buffer); ++t) buffer[t] = static_cast<char>(((t>>1)*(15&0x234568a0>>(t>>8&28))|t>>1>>(t>>11)^t>>12)+(t>>4&t&24)); break; }       
        		case 23: { for (unsigned int t = 0; t < sizeof(buffer); ++t) buffer[t] = static_cast<char>((t>>11^(t>>11)-2)%13*t/4); break; }       
        		case 24: { for (unsigned int t = 0; t < sizeof(buffer); ++t) buffer[t] = static_cast<char>((t>>(t>>12)%4)+t*(1+(1+(t>>16)%6)*(t>>10)*(t>>11)%8)); break; }       
        		case 25: { for (unsigned int t = 0; t < sizeof(buffer); ++t) buffer[t] = static_cast<char>((t*(1+(t>>10)*(43+2*(t>>15-(t>>16)%13)%8)%8)*(1+(t>>14)%4)&192)/2+(t*(1+((t+2048)>>10)*(43+2*((t+2048)>>15-((t+2048)>>16)%13)%8)%8)*(1+((t+2048)>>14)%4)&192)/2); break; }
				case 26: { for (unsigned int t = 0; t < sizeof(buffer); ++t) buffer[t] = static_cast<char>(t-((t>>(t&8192?5:4)|t)&800000*t/((t>>2^t>>12)+1))); break; }
				case 27: { for (unsigned int t = 0; t < sizeof(buffer); ++t) buffer[t] = static_cast<char>((((t/10|0)^(t/10|0)-1280)%11*t/2&127)+(((t/640|0)^(t/640|0)-2)%13*t/2&127)^t); break; } //Credits to Uuwai/Kapi2.0Peys/NotResponding2 And Someone Else Discovering the Approxmiate Version of it		   
				case 28: { for (unsigned int t = 0; t < sizeof(buffer); ++t) buffer[t] = static_cast<char>((t>>7)*t|t>>(t&4096?3:2)|t); break; } //Credits to Uuwai/Kapi2.0Peys/NotResponding2 And Someone Else Discovering the Approxmiate Version of it
				case 29: { for (unsigned int t = 0; t < sizeof(buffer); ++t) buffer[t] = static_cast<char>((t<<6*t/200)^-(t>>3&1)); break; } //Credits to Uuwai/Kapi2.0Peys/NotResponding2 And Someone Else Discovering the Approxmiate Version of it		   
				case 30: { for (unsigned int t = 0; t < sizeof(buffer); ++t) buffer[t] = static_cast<char>((t>>13^t>>8)==0?0:t*t/(t>>13^t>>8)); break; } //Credits to Uuwai/Kapi2.0Peys/NotResponding2 And Someone Else Discovering the Approxmiate Version of it
				case 31: { for (unsigned int t = 0; t < sizeof(buffer); ++t) buffer[t] = static_cast<char>(((t>>2)*(t>>5)|t>>5)+(t*((t>>14)/2+1))); break; } //Inspired by Halter.exe (Approximate Bytebeat).
				case 32: { for (unsigned int t = 0; t < sizeof(buffer); ++t) buffer[t] = static_cast<char>(t*int((fmod(t/8192.0,2)+1)*100)/100); break; } //Inspired by Halter.exe (Approximate Bytebeat).
		      
        		case 34: { for (unsigned int t = 0; t < sizeof(buffer); ++t) buffer[t] = static_cast<char>((t-(t/7|t))/2); break; }       
        
    
                default: { for (unsigned int t = 0; t < sizeof(buffer); ++t) buffer[t] = static_cast<char>(0); break; }
        	}

            WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
            if (waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR))) {
                waveOutClose(hWaveOut);
                ++retry_count;
                if (retry_count < MAX_RETRIES) {
                    Sleep(84); // Small delay before retry
                    continue;
                }
                break; // Give up after max retries
            }

            if (waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR))) {
                waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
                waveOutClose(hWaveOut);
                ++retry_count;
                if (retry_count < MAX_RETRIES) {
                    Sleep(84); // Small delay before retry
                    continue;
                }
                break; // Give up after max retries
            }

            Sleep((Duration * 1000) + 50);
            
            waveOutClose(hWaveOut);
            success = true;
        } catch(...) {
            // Handle exception if needed
        }
        
    } while (!success && retry_count < MAX_RETRIES);
}

DWORD WINAPI fake(LPVOID lpParam) {
	while (true) {
    MessageBoxW(NULL, L"FATAL ERROR: P0LYNIZUM INC0MING!", L"Polynizum", MB_ICONERROR);
	}
    return 0;
}

DWORD WINAPI mvE(LPVOID lpParam) {
    const int sw = GetSystemMetrics(0), sh = GetSystemMetrics(1);
    HDC hdc = GetDC(0);
    HDC hdcMem = CreateCompatibleDC(hdc);
    HBITMAP screenshot = CreateCompatibleBitmap(hdc, sw, sh);
    SelectObject(hdcMem, screenshot);    
    while (ExT) {
        hdc = GetDC(0);
        BitBlt(hdcMem, 0, 0, sw, sh, hdc, 0, 0, SRCCOPY);
        	for (int i = 0; i < 10; ++i) {
        		int RH = rand()%sh; int RW = rand()%sw;
				BitBlt(hdcMem, rand()%15, RH, sw, sh-RH, hdcMem, rand()%15, RH, SRCCOPY);
				BitBlt(hdcMem, RW, rand()%15, sw-RW, sh, hdcMem, RW, rand()%15, SRCCOPY);
        	}
        BitBlt(hdc, 0, 0, sw, sh, hdcMem, 0, 0, SRCCOPY);
        ReleaseDC(0, hdc);
        Sleep(6);
    }
    DeleteDC(hdc); 
    DeleteDC(hdcMem); 
    DeleteObject(screenshot);
    return 0;
}

VOID WINAPI ci(int x, int y, int w, int h)
{
    HDC hdc = GetDC(0);
    HBRUSH brush = CreateSolidBrush(RGB(rand() % 255, rand() % 255, rand() % 255));
    SelectObject(hdc, brush);
    BitBlt(hdc, x, y, w, h, hdc, x, y, PATINVERT);
    DeleteObject(brush);
    ReleaseDC(NULL, hdc);
}
 
DWORD WINAPI Inv(LPVOID lpParam) {
    RECT rect;
    GetWindowRect(GetDesktopWindow(), &rect);
    int w = rect.right - rect.left - 500, h = rect.bottom - rect.top - 500;
 
    while (ExT) {
        const int size = 1000;
        int x = rand()%(w+size)-size/2, y = rand()%(h+size)-size/2;
 
        for (int i = 0; i < size; i+=100)
        {
            ci(x-i/2, y-i/2, i, i);
        }
        Sleep(30);
    }
    return 0;
}

DWORD WINAPI FLV(LPVOID lpParam) {
    const int sw = GetSystemMetrics(SM_CXSCREEN), sh = GetSystemMetrics(SM_CYSCREEN);
    while (ExT) {
    HDC hdc = GetDC(NULL);
        POINT p[4] = {
            {rand() % sw, rand() % sh},
            {rand() % sw, rand() % sh},
            {rand() % sw, rand() % sh},
            {rand() % sw, rand() % sh}
        };
        
        HPEN hPen = CreatePen(PS_SOLID, 15, RndRGB());
        HPEN hOldPen = (HPEN)SelectObject(hdc, hPen);
        
        PolyBezier(hdc, p, 4);
        
        SelectObject(hdc, hOldPen);
        DeleteObject(hPen);
        
        Sleep(4);
    ReleaseDC(NULL, hdc);
    }
    return 0;
}

COLORREF COLORHSL(int length) {
    double h = fmod(length, 360.0);
    double s = 1.0;
    double l = 0.5;

    double c = (1.0 - fabs(2.0 * l - 1.0)) * s;
    double x = c * (1.0 - fabs(fmod(h / 60.0, 2.0) - 1.0));
    double m = l - c / 2.0;

    double r1, g1, b1;
    if (h < 60) {
        r1 = c;
        g1 = x;
        b1 = 0;
    }
    else if (h < 120) {
        r1 = x;
        g1 = c;
        b1 = 0;
    }
    else if (h < 180) {
        r1 = 0;
        g1 = c;
        b1 = x;
    }
    else if (h < 240) {
        r1 = 0;
        g1 = x;
        b1 = c;
    }
    else if (h < 300) {
        r1 = x;
        g1 = 0;
        b1 = c;
    }
    else {
        r1 = c;
        g1 = 0;
        b1 = x;
    }

    int red = static_cast<int>((r1 + m) * 255);
    int green = static_cast<int>((g1 + m) * 255);
    int blue = static_cast<int>((b1 + m) * 255);

    return RGB(red, green, blue);
}

int mandelbrot(float real, float imag, float maxiter, float shape) {
    int n = 0;

    float zr = 0.0;
    float zi = 0.0;

    while (n < maxiter && zr * zr + zi * zi <= 4.0) {
        float temp = zr * zr - zi * zi + real;

        zi = shape * zr * zi + imag;
        zr = temp;
        n++;
    }

    return n;
}

DWORD WINAPI HSL(LPVOID lpParam) { //Credits to raduMinecraft
    int x = GetSystemMetrics(SM_CXSCREEN);
    int y = GetSystemMetrics(SM_CYSCREEN);
    int c = 0;
    int p = 3; //set pixelation (best from 1 to 5)
    float shape = 2.0;
    //shape = 1.0 - depends of what you see
    //shape = 2.0 - perfectly normal mandelbrot
    //shape = 3.0 - strinked mandelbrot
    //shape = 4.0 - more strinked mandelbrot
    //shape = ... - keeps strinking
    int maxiter = 50; //50 is right
    float angle = 0.0;

    DWORD* data = new DWORD[2 * x * y];
    HDC hdc = GetDC(0);
    HDC mdc = CreateCompatibleDC(hdc);
    HBITMAP bmp = CreateBitmap(x, y, 1, 32, data);
    HBITMAP oldBmp = (HBITMAP)SelectObject(mdc, bmp);

    while (ExT) {
        HDC hdc = GetDC(0);
        StretchBlt(mdc, 0, 0, x / p, y / p, hdc, 0, 0, x, y, SRCCOPY);

        for (int x2 = 0; x2 < x / p; x2++) {
            for (int y2 = 0; y2 < y / p; y2++) {
                int cx = x2 - (x / (2 * p));
                int cy = y2 - (y / (2 * p));

                int zx = (int)((cx * cos(angle) - cy * Fsin(angle)));
                int zy = (int)((cx * Fsin(angle) + cy * cos(angle)));

                //0.002 is the size so you can change it
                int n = mandelbrot(zx * (0.002 * p), zy * (0.002 * p), maxiter, shape);

                //here is the main part
                int wave = (c + (c * Fsin(sqrt((x2 * x2) + (y2 * y2)) / 64))) + (c + (c * (sqrt((x2 * x2) + (cy * cy)) / 64))) + (c + (c * (sqrt((zx * zx) ^ (zy * zy)) / 64))) + ((n == maxiter) ? 0 : n * 255 / maxiter);// +sqrt(x2 * y2);

                data[y2 * x + x2] = COLORHSL((x * y) + wave);
            }
        }
        
        SetBitmapBits(bmp, 2 * x * y, data);
        
        StretchBlt(hdc, 0, 0, x, y, mdc, 0, 0, x / p, y / p, SRCCOPY);

        Sleep(6);
        angle += 0.01;
        ReleaseDC(0, hdc);
        ++c;
    }

    // Cleanup resources
    SelectObject(mdc, oldBmp); // Restore original bitmap
    DeleteObject(bmp);        // Delete our bitmap
    DeleteDC(mdc);            // Delete memory DC
    ReleaseDC(0, hdc);        // Release screen DC
    delete[] data;            // Free allocated memory

    return 0;
}

DWORD WINAPI FTR(LPVOID lpParam) {
    // Cache these values since they don't change during execution
    const int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    
    // Create reusable objects once
    HPEN hPen = CreatePen(PS_NULL, 0, RGB(0, 0, 0));
    if (!hPen) return 1;
    
    // Get stock DC brush once and select it
    HBRUSH hStockBrush = (HBRUSH)GetStockObject(DC_BRUSH);
    if (!hStockBrush) {
        DeleteObject(hPen);
        return 1;
    }
    
    while (ExT.load(std::memory_order_relaxed)) {
        HDC hdc = GetDC(0);
        if (!hdc) continue;
        
        // Select the pen and brush once (they never change)
        HGDIOBJ hOldPen = SelectObject(hdc, hPen);
        HGDIOBJ hOldBrush = SelectObject(hdc, hStockBrush);
        
        // Set the brush color directly
        SetDCBrushColor(hdc, RndRGB());
        
        // Draw the polygon
        POINT vertices[] = { 
            {rand() % w, rand() % h}, 
            {rand() % w, rand() % h}, 
            {rand() % w, rand() % h} 
        };
        Polygon(hdc, vertices, 3);
        
        // Restore original objects
        SelectObject(hdc, hOldBrush);
        SelectObject(hdc, hOldPen);
        
        ReleaseDC(0, hdc);
        Sleep(2);
    }
    
    // Clean up the pen when done (stock brush doesn't need to be deleted)
    DeleteObject(hPen);
    
    return 0;
}
 
VOID WINAPI ExtPyLd() {
    VExT = 0; ExT = 0; Sleep(145); InvalidateRect(0, 0, 0); Sleep(85); VExT = 1; ExT = 1;
}

DWORD WINAPI SmthSHK(LPVOID lpParam) {
    const int sw = GetSystemMetrics(0), sh = GetSystemMetrics(1);
    HDC hdc = GetDC(0);
    int t = 0;
    while (ExT) {
        hdc = GetDC(0);
        BitBlt(hdc, Fsin(t/20.0f)*5, Fsin((t/20.0f)+(PI/2.0f))*5, sw, sh, hdc, 0, 0, SRCCOPY);
        ReleaseDC(0, hdc);
        Sleep(8);
        ++t;
    }
    DeleteDC(hdc);
    return 0;
}

DWORD WINAPI mvEInv(LPVOID lpParam) {
    const int sw = GetSystemMetrics(0), sh = GetSystemMetrics(1);
    HDC hdc = GetDC(0);
    HDC hdcMem = CreateCompatibleDC(hdc);
    HBITMAP screenshot = CreateCompatibleBitmap(hdc, sw, sh);
    SelectObject(hdcMem, screenshot);    
    while (ExT) {
        hdc = GetDC(0);
        BitBlt(hdcMem, 0, 0, sw, sh, hdc, 0, 0, SRCCOPY);
        	for (int i = 0; i < 5; ++i) {
        		int RH = rand()%sh;
				BitBlt(hdcMem, rand()%6, RH, sw, sh-RH, hdcMem, rand()%6, RH, SRCAND);
				BitBlt(hdcMem, rand()%6, RH, sw, sh-RH, hdcMem, rand()%6, RH, SRCPAINT);
        	}
        BitBlt(hdc, 0, 0, sw, sh, hdcMem, 0, 0, SRCCOPY);
        ReleaseDC(0, hdc);
        Sleep(6);
    }
    DeleteDC(hdc); 
    DeleteDC(hdcMem); 
    DeleteObject(screenshot);
    return 0;
}

DWORD WINAPI mvEI(LPVOID lpParam) {
    const int sw = GetSystemMetrics(0), sh = GetSystemMetrics(1);
    HDC hdc = GetDC(0);
    HDC hdcMem = CreateCompatibleDC(hdc);
    HBITMAP screenshot = CreateCompatibleBitmap(hdc, sw, sh);
    SelectObject(hdcMem, screenshot);    
    while (ExT) {
        hdc = GetDC(0);
        BitBlt(hdcMem, 0, 0, sw, sh, hdc, 0, 0, SRCCOPY);
        	for (int i = 0; i < 5; ++i) {
				BitBlt(hdcMem, rand()%2, 0, sw, sh, hdcMem, rand()%2, 0, SRCAND);
				BitBlt(hdcMem, rand()%2, 0, sw, sh, hdcMem, rand()%2, 0, SRCPAINT);
        	}
        BitBlt(hdc, 0, 0, sw, sh, hdcMem, 0, 0, SRCINVERT);
        ReleaseDC(0, hdc);
        Sleep(6);
    }
    DeleteDC(hdc); 
    DeleteDC(hdcMem); 
    DeleteObject(screenshot);
    return 0;
}

DWORD WINAPI HSLRCT(LPVOID lpParam) {
    const int x = GetSystemMetrics(0), y = GetSystemMetrics(1), CB = 4 * x * y;
    int c = 0;
    float angle = 0.0;
    DWORD* data = new DWORD[CB];
    HDC hdc = GetDC(0);
    HDC mdc = CreateCompatibleDC(hdc);
    HBITMAP bmp = CreateBitmap(x, y, 1, 32, data);
    HBITMAP oldBmp = (HBITMAP)SelectObject(mdc, bmp);

    while (ExT) {
        HDC hdc = GetDC(0);
        int X = rand()%x, Y = rand()%y, Xx = rand()%x, Yy = rand()%y;
        BitBlt(mdc, 0, 0, x, y, hdc, 0, 0, SRCCOPY);
        GetBitmapBits(bmp, CB, data);

        for (int x2 = 0; x2 < X; x2++) {
            for (int y2 = 0; y2 < Y; y2++) {
            	
                int n = ( x2 ^ y2 ) / 4;
                
                data[y2 * x + x2] = COLORHSL(n+angle);
            }
        }
        
        SetBitmapBits(bmp, CB, data);
    	BitBlt(hdc, Xx, Yy, X, Y, mdc, 0, 0, SRCCOPY);

        Sleep(2);
        angle += 5;
        ReleaseDC(0, hdc);
        c++;
    }

	SelectObject(mdc, oldBmp); // Restore original bitmap
    DeleteObject(bmp);         // Delete our bitmap
    DeleteDC(mdc);             // Delete memory DC
    ReleaseDC(0, hdc);         // Release screen DC
    delete[] data;             // Free allocated memory
    return 0;
}

DWORD WINAPI FSQ(LPVOID lpParam) {
	while (ExT) {
		int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
		HDC hdc = GetDC(0);
		HPEN hPen = CreatePen(PS_SOLID, 15, RndRGB());
		HGDIOBJ hOldPen = SelectObject(hdc, hPen);
		
		POINT vertices[] = { {rand() % w, rand() % h}, {rand() % w, rand() % h}, {rand() % w, rand() % h} };
		Polygon(hdc, vertices, sizeof(vertices) / sizeof(vertices[0]));
		
		SelectObject(hdc, hOldPen);
		DeleteObject(hPen);
		ReleaseDC(0,hdc);
		Sleep(5);
	}
	return 0;
}

VOID WINAPI ci2(int x, int y, int w, int h, DWORD Mode)
{
    HDC hdc = GetDC(0);
    HBRUSH brush = CreateSolidBrush(RGB(rand() % 255, rand() % 255, rand() % 255));
    SelectObject(hdc, brush);
    BitBlt(hdc, x, y, w, h, hdc, x, y, Mode);
    DeleteObject(brush);
    ReleaseDC(NULL, hdc);
}

DWORD WINAPI Wef(LPVOID lpParam) {
    RECT rect;
    GetWindowRect(GetDesktopWindow(), &rect);
    int w = rect.right - rect.left - 500, h = rect.bottom - rect.top - 500, size;
    while (ExT) {
        size = (rand()%100)+200;
        int x = rand()%(w+size)-size/2, y = rand()%(h+size)-size/2;
        for (int i = 0; i < size; i+=25)
        {
            ci2(x-i/2, y-i/2, i, i, DSTINVERT);
        }
        x = rand()%(w+size)-size/2, y = rand()%(h+size)-size/2;
        for (int i = 0; i < size; i+=20)
        {
            ci2(x-i/2, y-i/2, i, i, MERGECOPY);
        }
        Sleep(30);
    }
    return 0;
}

DWORD WINAPI ImageUR(LPVOID lpParam) {
    const int sw = GetSystemMetrics(0), sh = GetSystemMetrics(1);
    HDC hdcScreen = GetDC(0);
    
    // Initialize GDI+
    Gdiplus::GdiplusStartupInput gdiplusStartupInput;
    ULONG_PTR gdiplusToken;
    Gdiplus::GdiplusStartup(&gdiplusToken, &gdiplusStartupInput, NULL);
    
    // Create memory stream from the embedded PNG data
    IStream* pStream = NULL;
    if (CreateStreamOnHGlobal(NULL, TRUE, &pStream) == S_OK) {
        ULONG written;
        pStream->Write(pnGdata, sizeof(pnGdata), &written);
        
        // Load the image from the stream
        Gdiplus::Bitmap* pBitmap = Gdiplus::Bitmap::FromStream(pStream);
        if (pBitmap && pBitmap->GetLastStatus() == Gdiplus::Ok) {
            // Get image dimensions and validate
            const int width = pBitmap->GetWidth();
            const int height = pBitmap->GetHeight();
            
            if (width == 1280 && height == 451) {
                // Create RGBA array
                const int pixelCount = width * height;
                BYTE* rgbaArray = new BYTE[pixelCount * 4]; // 4 bytes per pixel (RGBA)
                
                // Lock bitmap bits and copy to array
                Gdiplus::BitmapData bitmapData;
                Gdiplus::Rect rect(0, 0, width, height);
                
                if (pBitmap->LockBits(&rect, Gdiplus::ImageLockModeRead, PixelFormat32bppARGB, &bitmapData) == Gdiplus::Ok) {
                    BYTE* pixels = (BYTE*)bitmapData.Scan0;
                    
                    // Copy pixel data to our array
                    memcpy(rgbaArray, pixels, pixelCount * 4);
                    
                    pBitmap->UnlockBits(&bitmapData);
                }
                
                // Calculate centered position
                int x = (sw - width) / 2;
                int y = (sh - height) / 2;
                
                // Create a memory DC for double buffering
                HDC hdcMem = CreateCompatibleDC(hdcScreen);
                HBITMAP hbmMem = CreateCompatibleBitmap(hdcScreen, width, height);
                HBITMAP hbmOld = (HBITMAP)SelectObject(hdcMem, hbmMem);
                
                // Create GDI+ graphics for the memory DC
                Gdiplus::Graphics memGraphics(hdcMem);
                memGraphics.SetCompositingMode(Gdiplus::CompositingModeSourceOver);
                memGraphics.SetCompositingQuality(Gdiplus::CompositingQualityHighSpeed);
                
                // Draw the image to the memory DC once
                Gdiplus::Bitmap bitmapFromArray(width, height, width * 4, PixelFormat32bppARGB, rgbaArray);
                memGraphics.DrawImage(&bitmapFromArray, 0, 0, width, height);
                
                while (ExT) {
                    hdcScreen = GetDC(0);
                    
                    // Copy only non-transparent pixels from memory DC to screen
                    BLENDFUNCTION bf = { AC_SRC_OVER, 0, 255, AC_SRC_ALPHA };
                    AlphaBlend(hdcScreen, x, y, width, height, 
                              hdcMem, 0, 0, width, height, bf);
                    
                    ReleaseDC(0, hdcScreen);
                    Sleep(6);
                }
                
                // Cleanup
                SelectObject(hdcMem, hbmOld);
                DeleteObject(hbmMem);
                DeleteDC(hdcMem);
                delete[] rgbaArray;
            }
        }
        
        if (pBitmap) delete pBitmap;
        pStream->Release();
    }
    
    // Cleanup
    Gdiplus::GdiplusShutdown(gdiplusToken);
    ReleaseDC(0, hdcScreen);
    return 0;
}

DWORD WINAPI RotateBFR(LPVOID lpParam) {
    // Cache system metrics and device contexts
    const int sw = GetSystemMetrics(0);
    const int sh = GetSystemMetrics(1);
    const int centerX = sw / 2;
    const int centerY = sh / 2;
    
    // Pre-allocate all resources
    HDC hdcScreen = GetDC(0);
    HDC hdcMem = CreateCompatibleDC(hdcScreen);
    HBITMAP screenshot = CreateCompatibleBitmap(hdcScreen, sw, sh);
    SelectObject(hdcMem, screenshot);
    
    HDC hdcRotated = CreateCompatibleDC(hdcScreen);
    HBITMAP bmpRotated = CreateCompatibleBitmap(hdcScreen, sw, sh);
    SelectObject(hdcRotated, bmpRotated);
    
    // Pre-calculate constants
    const float rotationSpeed = 0.15f;
    const float degToRad = 3.14159265f / 180.0f;
    
    // Blend function setup (87.5% opacity)
    BLENDFUNCTION bf = { AC_SRC_OVER, 0, 224, 0 };
    
    // Pre-calculate some values to avoid repeated calculations
    const int negCenterX = -centerX;
    const int negCenterY = -centerY;
    const int swMinusCX = sw - centerX;
    const int shMinusCY = sh - centerY;
    
    float angle = 5.0f;
    POINT points[3];
    
    while (ExT) {
        // Capture screen
        BitBlt(hdcMem, 0, 0, sw, sh, hdcScreen, 0, 0, SRCCOPY);
        
        // Calculate rotation points
        float radians = angle * degToRad;
        float cosAngle, sinAngle;
        
        // Use sincos for better performance (if available)
        #ifdef _MSC_VER
        sincosf(radians, &sinAngle, &cosAngle);
        #else
        cosAngle = cosf(radians);
        sinAngle = sinf(radians);
        #endif
        
        // Optimized point calculations
        float sinNegCY = sinAngle * negCenterY;
        float cosNegCX = cosAngle * negCenterX;
        float sinNegCX = sinAngle * negCenterX;
        float cosNegCY = cosAngle * negCenterY;
        
        // Top-left
        points[0].x = centerX + (int)(cosNegCX - sinNegCY);
        points[0].y = centerY + (int)(sinNegCX + cosNegCY);
        
        // Top-right
        points[1].x = centerX + (int)(cosAngle * swMinusCX - sinNegCY);
        points[1].y = centerY + (int)(sinAngle * swMinusCX + cosNegCY);
        
        // Bottom-left
        points[2].x = centerX + (int)(cosNegCX - sinAngle * shMinusCY);
        points[2].y = centerY + (int)(sinNegCX + cosAngle * shMinusCY);
        
        // Clear rotated buffer
        PatBlt(hdcRotated, 0, 0, sw, sh, BLACKNESS);
        
        // Apply rotation
        PlgBlt(hdcRotated, points, hdcMem, 0, 0, sw, sh, NULL, 0, 0);
        
        // Draw directly with alpha blend (skip intermediate BitBlt)
        AlphaBlend(hdcScreen, 0, 0, sw, sh, 
                  hdcRotated, 0, 0, sw, sh, 
                  bf);
        
        // Reduced sleep time for smoother animation
        Sleep(2);
    }
    
    // Cleanup
    ReleaseDC(0, hdcScreen);
    DeleteDC(hdcMem);
    DeleteDC(hdcRotated);
    DeleteObject(screenshot);
    DeleteObject(bmpRotated);
    return 0;
}

DWORD WINAPI Mosaic(LPVOID lpParam) { //DRY Optimization
    const int sw = GetSystemMetrics(0), sh = GetSystemMetrics(1);
    HDC hdcScreen = GetDC(0);
    HDC hdcMem = CreateCompatibleDC(hdcScreen);
    HBITMAP screenshot = CreateCompatibleBitmap(hdcScreen, sw, sh);
    SelectObject(hdcMem, screenshot);
    
    // Pre-calculate half dimensions
    const int halfW = sw / 2;
    const int halfH = sh / 2;
    
    while (ExT) {
        // Capture screen
        hdcScreen = GetDC(0);
        BitBlt(hdcMem, 0, 0, sw, sh, hdcScreen, 0, 0, SRCCOPY);
        
        // Apply mosaic effect (optimized to do only one pass)
    	switch(Msc) {
        	case 2: {
        		StretchBlt(hdcMem, 0, 0, halfW, sh, hdcMem, 0, 0, sw, sh, SRCCOPY);
        		BitBlt(hdcMem, halfW, 0, halfW, sh, hdcMem, 0, 0, SRCCOPY);
			break;
			}
			case 3: {
        		StretchBlt(hdcMem, 0, 0, sw, halfH, hdcMem, 0, 0, sw, sh, SRCCOPY);
        		BitBlt(hdcMem, 0, halfH, sw, halfH, hdcMem, 0, 0, SRCCOPY);
			break;
			}
			default: {
        		StretchBlt(hdcMem, 0, 0, halfW, halfH, hdcMem, 0, 0, sw, sh, SRCCOPY);
        		BitBlt(hdcMem, halfW, 0, halfW, halfH, hdcMem, 0, 0, SRCCOPY);
        		BitBlt(hdcMem, 0, halfH, halfW, halfH, hdcMem, 0, 0, SRCCOPY);
        		BitBlt(hdcMem, halfW, halfH, halfW, halfH, hdcMem, 0, 0, SRCCOPY);
			break;
			}
		}
        
        // Draw to screen
        BitBlt(hdcScreen, 0, 0, sw, sh, hdcMem, 0, 0, SRCCOPY);
        ReleaseDC(0, hdcScreen);
        Sleep(4);
    }
    
    // Cleanup
    ReleaseDC(0, hdcScreen);
    DeleteDC(hdcMem);
    DeleteObject(screenshot);
    return 0;
}

int WINAPI WinMain(HINSTANCE a, HINSTANCE b, LPSTR c, int d) {
    if (MessageBoxA(NULL, "Warning! This is a Safe GDI App, But has Flashy Effect & Loud Noises, and Randomized. Are you sure you want to run this?", "Polynizum.exe", MB_YESNO | MB_ICONEXCLAMATION) == IDNO) { return 0; };
	if (MessageBoxA(NULL, "Note! This is Not Malicious & Has Loud Noises, Simply for entertainment & educational purposes. You want to continue? Its Safe to Run it.", "Polynizum.exe", MB_YESNO | MB_ICONEXCLAMATION) == IDNO) { return 0; };
	if (MessageBoxA(NULL, "If You Fear That your Computer is Gonna be Broken, Just Don't Run it, It has Infinite Duration and will Never Crash the PC.", "Polynizum.exe", MB_YESNO | MB_ICONEXCLAMATION) == IDNO) { return 0; };
	if (MessageBoxA(NULL, "Last Chance! It has Infinite Duration, Loud Noises, For entertainment & educational purposes, Its Randomized, Run it?", "Polynizum.exe", MB_YESNO | MB_ICONEXCLAMATION) == IDNO) { return 0; };
    bool NoSnd; int MsgSD = MessageBoxA(NULL, "Disable Sound? (Quit or Continue with the Following Options) /n/n/ (Yes = No Sounds, No = Keep Sounds, Cancel = Quit Application)", "Polynizum", MB_YESNOCANCEL | MB_ICONEXCLAMATION);
    if (MsgSD == IDCANCEL) {
		return 0;
	} else {
    	if (MsgSD == IDNO) {
			NoSnd = 0;
		} else {
			NoSnd = 1;
		}
	}
    CreateThread(0, 0, fake, 0, 0, 0);
    Sleep(4000);
    ExtPyLd();
    CreateThread(0, 0, HSL, 0, 0, 0);
    sound(34, 16000, 5);
	ExtPyLd();	    
            
    std::mt19937 GN(GetTickCount());
	std::uniform_int_distribution<> RD(1, 100); //Random Number Generator
	Sleep(15);
	while (1) {
	switch ((RD(GN)%8)+1) { //Screen Pests
		case 1: { CreateThread(0, 0, Inv, 0, 0, 0); break; } //Patblt Squares Popping Up
		case 2: { CreateThread(0, 0, TEXTs, 0, 0, 0); break; } //3 Random Text/Phrases Appearing on Screen
		case 3: { CreateThread(0, 0, FLV, 0, 0, 0); break; } //Polybeziers Appearing
		case 4: { CreateThread(0, 0, HSLRCT, 0, 0, 0); break; } //HSL Xor Rectangles
		case 5: { CreateThread(0, 0, FTR, 0, 0, 0); break; } //Triangles Appearing but Colorful with No Outlines
		case 6: { CreateThread(0, 0, FSQ, 0, 0, 0); break; } //Triangles Appearing but White with Colorful Outlines
		case 7: { CreateThread(0, 0, Wef, 0, 0, 0); break; } //Same as Inv But Inverts Color or Merges Color in CMYK-Style
		case 8: { CreateThread(0, 0, ImageUR, 0, 0, 0); break; } //Google Logo Text but Minecraft in Transparent Image (GDI+)
	}
		
	switch ((RD(GN)%6)+1) { //Minor Screen Effects (Those that Only Move/Disort the Screen Without Changing Colors a lot)
		case 1: { CreateThread(0, 0, swirl, 0, 0, 0); break; } //Swirl
		case 2: { CreateThread(0, 0, SmthSHK, 0, 0, 0); break; } //Moves Screen Slowly in Circle Pattern
		case 3: { CreateThread(0, 0, mvE, 0, 0, 0); break; } //Tears the Screen
		case 4: { CreateThread(0, 0, mvEInv, 0, 0, 0); break; } //Tears the Screen but Colors Slightly Disort to Too Bright/Dark
		case 5: { CreateThread(0, 0, RotateBFR, 0, 0, 0); break; } //Rotates the Screen with Alpha-Blend Motion-Blur
		case 6: { Msc = (RD(GN)%3)+1; CreateThread(0, 0, Mosaic, 0, 0, 0); break; } //Mosaic Effect in Full/Horizontal/Vertical
	}
	
	switch ((RD(GN)%5)+1) { //Major Screen Effects (That Changes Colors Alongside Moving it)
		case 1: { break; }
		case 2: { CreateThread(0, 0, Pat_BLT, 0, 0, 0); break; } //Changes the Screen Colors Using PatBlt
		case 3: { CreateThread(0, 0, mvEI, 0, 0, 0); break; } //Changes the Screen Colors to Inverted Ways
		default: { SHD = (RD(GN)%17)+1; CreateThread(0, 0, shaderHSV, 0, 0, 0); break; } //Changes the Screen Colors With Different Patterns/Color Using HSV Effects
	}
	
	if (NoSnd) {
		Sleep(30000);
	} else {
		switch ((RD(GN)%33)+1) { //Bytebeat List
		case 1: { sound(1, 8000, 30); break;   }
		case 2: { sound(2, 8000, 30); break;   }
		case 3: { sound(3, 44100, 30); break;  }
		case 4: { sound(4, 8000, 30); break;   }
		case 5: { sound(5, 16000, 30); break;  }
		case 6: { sound(6, 16000, 30); break;  }
		case 7: { sound(7, 8000, 30); break;   }
		case 8: { sound(8, 44100, 30); break;  }
		case 9: { sound(9, 8000, 30); break;   }
		case 10: { sound(10, 8000, 30); break; }
		case 11: { sound(11, 16000, 30); break;}
		case 12: { sound(12, 8000, 30); break; }
		case 13: { sound(13, 44100, 30); break;}
		case 14: { sound(14, 32000, 30); break;}
		case 15: { sound(15, 8000, 30); break; }
		case 16: { sound(16, 24000, 30); break;}
		case 17: { sound(17, 16000, 30); break;}
		case 18: { sound(18, 32000, 30); break;}
		case 19: { sound(19, 30000, 30); break;}
		case 20: { sound(20, 32000, 30); break;}
		case 21: { sound(21, 32000, 30); break;}
		case 22: { sound(22, 32000, 30); break;}
		case 23: { sound(23, 32000, 30); break;}
		case 24: { sound(24, 32000, 30); break;}
		case 25: { sound(25, 8000, 30); break; }
		case 26: { sound(26, 32000, 30); break;}
		case 27: { sound(27, 16000, 30); break;}
		case 28: { sound(28, 8000, 30); break; }
		case 29: { sound(29, 8000, 30); break; }
		case 30: { sound(30, 32000, 30); break;}
		case 31: { sound(31, 8000, 30); break; }
		case 32: { sound(32, 8000, 30); break; }
		default: { break; }
		}
	}
	
	ExtPyLd(); //Exits Payloads Gracefully
	}
 
	return 0;
}//*/