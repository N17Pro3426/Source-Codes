﻿#include"resource.h"
#include"def.h"
#include"sound.h"
#include"payload.h"
void mainpayloads() {
	HANDLE thread1 = CreateThread(0, 0, shader1, 0, 0, 0);
	HANDLE thread1dot1 = CreateThread(0, 0, jiantou, 0, 0, 0);
	sound1();
	Sleep(30000);
	TerminateThread(thread1, 0);
	InvalidateRect(0, 0, 0);
	Sleep(100);
	HANDLE thread2 = CreateThread(0, 0, masher, 0, 0, 0);
	HANDLE thread2dot1 = CreateThread(0, 0, colorchange, 0, 0, 0);
	HANDLE thread2dot2 = CreateThread(0, 0, textout1, 0, 0, 0);
	//HANDLE thread2dot3 = CreateThread(0, 0, circlez, 0, 0, 0);
	sound2();
	Sleep(30000);
	TerminateThread(thread2, 0);
	TerminateThread(thread2dot1, 0);
	//TerminateThread(thread2dot3, 0);
	InvalidateRect(0, 0, 0);
	HANDLE thread3 = CreateThread(0, 0, shader2, 0, 0, 0);
	sound3();
	Sleep(30000);
	TerminateThread(thread3, 0);
	InvalidateRect(0, 0, 0);
	HANDLE thread4 = CreateThread(0, 0, shader3, 0, 0, 0);
	//HANDLE thread4dot2 = CreateThread(0, 0, textout2, 0, 0, 0);
	sound4();
	Sleep(30000);
	TerminateThread(thread4, 0);
	InvalidateRect(0, 0, 0);
	HANDLE thread5 = CreateThread(0, 0, shader4, 0, 0, 0);
	sound5();
	Sleep(30000);
	TerminateThread(thread5, 0);
	InvalidateRect(0, 0, 0);
	HANDLE thread6 = CreateThread(0, 0, shader5, 0, 0, 0);
	sound6();
	Sleep(30000);
	TerminateThread(thread6, 0);
	InvalidateRect(0, 0, 0);
	HANDLE thread7 = CreateThread(0, 0, shader6, 0, 0, 0);
	sound7();
	Sleep(30000);
	TerminateThread(thread7, 0);
	InvalidateRect(0, 0, 0);
	HANDLE thread8 = CreateThread(0, 0, shader7, 0, 0, 0);
	sound8();
	Sleep(30000);
	TerminateThread(thread8, 0);
	InvalidateRect(0, 0, 0);
	HANDLE thread9 = CreateThread(0, 0, blurz, 0, 0, 0);
	sound9();
	Sleep(30000);
	TerminateThread(thread9, 0);
	InvalidateRect(0, 0, 0);
	TerminateThread(thread1dot1, 0);
	TerminateThread(thread2dot2, 0);
	//TerminateThread(thread4dot2, 0);
}
int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, PSTR lpCmdLine, INT nCmdShow)
{
	InitDPI();
	srand(time(NULL));
	SeedXorshift32((DWORD)time(NULL));
	ShowWindow(GetConsoleWindow(), SW_HIDE);
	if (MessageBoxW(NULL, L"Run arj malware?\r\n\It will disturb you for some time", L"arj.exe - First Warning", MB_YESNO | MB_ICONEXCLAMATION) == IDNO)
	{
		ExitProcess(0);
	}
	else
	{
		if (MessageBoxW(NULL, L"Are you sure? \r\n\The malware author couldn't assume legal liability", L"arj.exe - Last Epilepsy Warning", MB_YESNO | MB_ICONEXCLAMATION) == IDNO)
		{
			ExitProcess(0);
		}
		else
		{
			mainpayloads();
		}
	}
	return 0;
}