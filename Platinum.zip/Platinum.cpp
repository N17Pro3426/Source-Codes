﻿#pragma warning(disable:4244)
#pragma warning(disable:4552)
#pragma warning(disable:4554)
#pragma warning(disable:4129)
#pragma warning(disable:4305)
#pragma warning(disable:4715)

#include"def.h"
#include"sound.h"
#include"payload.h"

void clean() {
	for (int i = 0;i < 30;i++) {
		InvalidateRect(0, 0, 0);
	}
}
HRESULT DwmEnableComposition(UINT uCompositionAction) {
	typedef HRESULT(WINAPI* _dwmEnableComposition)(UINT uCompositionAction);
	HMODULE hm = LoadLibrary(_T("dwmapi.dll"));
	if (hm == NULL) return -1;
	_dwmEnableComposition dwmfunc = (_dwmEnableComposition)GetProcAddress(hm, "DwmEnableComposition");
	return dwmfunc(uCompositionAction);
}
VOID WINAPI MsgBoxCorruptionThread(HWND hwndMsgBox) {
	HDC hdc = GetDC(hwndMsgBox);
	RECT rect;
	GetWindowRect(hwndMsgBox, &rect);
	int w = rect.right - rect.left, h = rect.bottom - rect.top;
	InvalidateRect(0, 0, 0);
	for (;;) {
		SelectObject(hdc, CreateSolidBrush(RGB(rand() % 255, rand() % 255, rand() % 255)));
		PatBlt(hdc, 0, 0, w, h, PATINVERT);
		Sleep(100);
	}
}


void RunPayload() {
	sjflksdjklsdjfklsj();
	Sleep(5000);
	HANDLE thread0 = CreateThread(0, 0, message, 0, 0, 0);
	Sleep(1000);
	
	sound1();
	HANDLE sh1 = CreateThread(NULL, 0, GDIShader1, NULL, 0, NULL);
	HANDLE glit = CreateThread(NULL, 0, Payload_Glitch, NULL, 0, NULL);
	HANDLE pqwoeuri = CreateThread(NULL, 0, nein, NULL, 0, NULL);
	Sleep(30000);
	TerminateThread(sh1, 0);
	TerminateThread(glit, 0);
	TerminateThread(pqwoeuri, 0);
	InvalidateRect(0, 0, 0);
	Sleep(100);

	sound2();
	HANDLE sh2 = CreateThread(NULL, 0, GDIShader2, NULL, 0, NULL);
	Sleep(30000);
	TerminateThread(sh2, 0);
	InvalidateRect(0, 0, 0);
	Sleep(100);

	sound3();
	HANDLE sh3 = CreateThread(NULL, 0, GDIShader3, NULL, 0, NULL);
	HANDLE cir = CreateThread(NULL, 0, Payload_Circle, NULL, 0, NULL);
	Sleep(30000);
	TerminateThread(sh3, 0);
	InvalidateRect(0, 0, 0);
	Sleep(100);

	sound4();
	HANDLE sh4 = CreateThread(NULL, 0, GDIShader4, NULL, 0, NULL);
	Sleep(30000);
	TerminateThread(sh4, 0);
	InvalidateRect(0, 0, 0);
	Sleep(100);

	sound5();
	HANDLE rgb = CreateThread(NULL, 0, Payload_ColourChange, NULL, 0, NULL);
	HANDLE li = CreateThread(NULL, 0, Payload_Lines, NULL, 0, NULL);
	HANDLE sh5 = CreateThread(NULL, 0, GDIShader5, NULL, 0, NULL);
	Sleep(30000);
	TerminateThread(sh5, 0);
	TerminateThread(rgb, 0);
	InvalidateRect(0, 0, 0);
	Sleep(100);

	sound6();
	HANDLE sh6 = CreateThread(NULL, 0, GDIShader6, NULL, 0, NULL);
	Sleep(30000);
	TerminateThread(sh6, 0);
	InvalidateRect(0, 0, 0);
	Sleep(100);

	sound7();
	HANDLE sh7 = CreateThread(NULL, 0, GDIShader7, NULL, 0, NULL);
	Sleep(30000);
	TerminateThread(sh7, 0);
	InvalidateRect(0, 0, 0);
	Sleep(100);
	
	sound8();
	HANDLE sh8 = CreateThread(NULL, 0, GDIShader8, NULL, 0, NULL);
	HANDLE word = CreateThread(NULL, 0, Payload_Word, NULL, 0, NULL);
	Sleep(30000);
	TerminateThread(sh8, 0);
	InvalidateRect(0, 0, 0);
	Sleep(100);
	
	sound9();
	HANDLE sh9 = CreateThread(NULL, 0, GDIShader09, NULL, 0, NULL);
	Sleep(30000);
	TerminateThread(sh9, 0);
	InvalidateRect(0, 0, 0);
	Sleep(100);
	
	sound10();
	HANDLE sh10 = CreateThread(NULL, 0, GDIShader10, NULL, 0, NULL);
	Sleep(30000);
	TerminateThread(sh10, 0);
	InvalidateRect(0, 0, 0);
	Sleep(100);
	
	sound11();
	HANDLE sh11 = CreateThread(NULL, 0, GDIShader11, NULL, 0, NULL);
	HANDLE tess = CreateThread(NULL, 0, Payload_DrawTesseract, NULL, 0, NULL);
	Sleep(30000);
	TerminateThread(sh11, 0);
	InvalidateRect(0, 0, 0);
	Sleep(100);

	sound12();
	HANDLE shl2 = CreateThread(NULL, 0, GDIShader12, NULL, 0, NULL);
	Sleep(30000);
	TerminateThread(shl2, 0);
	InvalidateRect(0, 0, 0);
	Sleep(100);
	
	sound13();
	HANDLE sh13 = CreateThread(NULL, 0, GDIShader13, NULL, 0, NULL);
	Sleep(30000);
	TerminateThread(sh13, 0);
	InvalidateRect(0, 0, 0);
	Sleep(100);

	sound14();
	HANDLE shl4 = CreateThread(NULL, 0, GDIShader14, NULL, 0, NULL);
	Sleep(30000);
	TerminateThread(shl4, 0);
	InvalidateRect(0, 0, 0);
	Sleep(100);

	sound15();
	HANDLE sh15 = CreateThread(NULL, 0, GDIShader15, NULL, 0, NULL);
	Sleep(30000);
	TerminateThread(sh15, 0);
	InvalidateRect(0, 0, 0);
	Sleep(100);
	
	sound16();
	HANDLE sh16 = CreateThread(NULL, 0, GDIShader16, NULL, 0, NULL);
	Sleep(30000);
	TerminateThread(sh16, 0);
	InvalidateRect(0, 0, 0);
	Sleep(100);
	
	sound17();
	HANDLE sh17 = CreateThread(NULL, 0, GDIShader17, NULL, 0, NULL);
	HANDLE sbsbsb = CreateThread(NULL, 0, Payload_Squares, NULL, 0, NULL);
	Sleep(30000);
	TerminateThread(sh17, 0);
	InvalidateRect(0, 0, 0);
	Sleep(100);
	
	sound18();
	HANDLE sh18 = CreateThread(NULL, 0, GDIShader18, NULL, 0, NULL);
	//HANDLE glit2 = CreateThread(NULL, 0, Payload_Glitch, NULL, 0, NULL);
	Sleep(30000);
	TerminateThread(sh18, 0);
	//TerminateThread(glit2, 0);
	InvalidateRect(0, 0, 0);
	Sleep(100);

	sound19();
	HANDLE sh19 = CreateThread(NULL, 0, GDIShader19, NULL, 0, NULL);
	Sleep(30000);
	TerminateThread(sh19, 0);
	InvalidateRect(0, 0, 0);
	Sleep(100);

	sound20();
	HANDLE sh20 = CreateThread(NULL, 0, GDIShader20, NULL, 0, NULL);
	Sleep(30000);
	TerminateThread(sh20, 0);
	InvalidateRect(0, 0, 0);
	Sleep(100);

	sound21();
	HANDLE sh21 = CreateThread(NULL, 0, GDIShader21, NULL, 0, NULL);
	Sleep(30000);
	TerminateThread(sh21, 0);
	InvalidateRect(0, 0, 0);
	Sleep(100);

	sound22();
	HANDLE sh22 = CreateThread(NULL, 0, GDIShader22, NULL, 0, NULL);
	Sleep(30000);
	TerminateThread(sh22, 0);
	InvalidateRect(0, 0, 0);
	Sleep(100);
	
	sound23();
	HANDLE sh23 = CreateThread(NULL, 0, GDIShader23, NULL, 0, NULL);
	Sleep(30000);
	TerminateThread(sh23, 0);
	InvalidateRect(0, 0, 0);
	Sleep(100);

	sound24();
	HANDLE sh24 = CreateThread(NULL, 0, GDIShader24, NULL, 0, NULL);
	Sleep(30000);
	TerminateThread(sh24, 0);
	InvalidateRect(0, 0, 0);
	Sleep(100);

	sound25();
	HANDLE sh25 = CreateThread(NULL, 0, GDIShader25, NULL, 0, NULL);
	Sleep(30000);
	TerminateThread(sh25, 0);
	InvalidateRect(0, 0, 0);
	Sleep(100);

	sound26();
	HANDLE sh26 = CreateThread(NULL, 0, GDIShader26, NULL, 0, NULL);
	Sleep(30000);
	TerminateThread(sh26, 0);
	InvalidateRect(0, 0, 0);
	Sleep(100);

	sound27();
	HANDLE sh27 = CreateThread(NULL, 0, GDIShader27, NULL, 0, NULL);
	Sleep(30000);
	TerminateThread(sh27, 0);
	InvalidateRect(0, 0, 0);
	Sleep(100);

	sound28();
	HANDLE sh28 = CreateThread(NULL, 0, GDIShader28, NULL, 0, NULL);
	Sleep(30000);
	TerminateThread(sh28, 0);
	InvalidateRect(0, 0, 0);
	Sleep(100);

	sound29();
	HANDLE sh29 = CreateThread(NULL, 0, GDIShader29, NULL, 0, NULL);
	Sleep(30000);
	TerminateThread(sh29, 0);
	InvalidateRect(0, 0, 0);
	Sleep(100);

	sound30();
	HANDLE sh30 = CreateThread(NULL, 0, GDIShader30, NULL, 0, NULL);
	Sleep(30000);
	TerminateThread(sh30, 0);
	//TerminateThread(cir, 0);
	//TerminateThread(li, 0);
	//TerminateThread(word, 0);
	//TerminateThread(tess, 0);
	//TerminateThread(sbsbsb, 0);
	InvalidateRect(0, 0, 0);
	Sleep(100);
}
int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, PSTR lpCmdLine, INT nCmdShow)
{
	InitDPI();
	srand(time(NULL));
	SeedXorshift32((DWORD)time(NULL));
	ShowWindow(GetConsoleWindow(), SW_HIDE);
	if (MessageBoxW(NULL, L"If you don't know what this is, please exit this program immediately and delete it. \r\n\This is a malicious software called Platinum(Peaceful Version) that can only run on a relatively secure environment such as Windows Sandbox or VMware, created by LambdaTechnology. \r\n\This malicious software contains many flashing lights and loud sounds. Running this software may cause unnecessary trouble. Because it has enough capability to delete all your files, making your computer useless. \r\n\Please make your choice, run or exit? \r\n\If you accidentally opened it, press' No 'to exit. If you agree to the above terms and are ready to face death, press' yes' to proceed.", L"“We are all in the gutter, but some of us are looking at the stars......”", MB_YESNO | MB_ICONWARNING) == IDYES) {
		if (MessageBoxW(NULL, L"This is the final warning. If the above choices were made due to your haste, please press' No 'immediately to exit. \r\n\Otherwise, the author will not be held responsible for any liability caused by this malicious software.", L"Last Warning.Please choice carefully.", MB_YESNO | MB_ICONWARNING) == IDYES) {
			RunPayload();
		}
	}
	return 0;
}