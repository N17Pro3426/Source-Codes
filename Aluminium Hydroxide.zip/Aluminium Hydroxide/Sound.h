#pragma once
#include <Windows.h>

extern bool Stop_And_Start_Shader;

void Sound1();
void Sound2();
void Sound3();
void Sound4();
DWORD WINAPI Sound5(LPVOID lpParam);
void Sound6();
void Sound7();
void Sound8();
void Sound9();
void Sound10();
void Sound11();
void Sound12();
void Sound13();
DWORD WINAPI Sound14(LPVOID lpParam);
void Sound15();