#include <Windows.h>

#pragma comment(lib, "winmm.lib")

bool Stop_And_Start_Shader = false;

void Sound1() {
	HWAVEOUT hWaveOut;
	WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };

	waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, NULL, NULL, CALLBACK_NULL);
	char buffer[8000 * 30];

	for (INT t = 0; t < sizeof(buffer); t++) {
		buffer[t] = static_cast<char>(t + (t & t ^ t >> 6) - t * (t >> 9 & (t % 16 ? 2 : 6) & t >> 9));
	}

	WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
	waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));

	while (!(header.dwFlags & WHDR_DONE)) {
		Sleep(100);
	}

	Stop_And_Start_Shader = true;

	waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutClose(hWaveOut);
}

void Sound2() {
	HWAVEOUT hWaveOut;
	WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };

	waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, NULL, NULL, CALLBACK_NULL);
	char buffer[8000 * 30];

	for (INT t = 0; t < sizeof(buffer); t++) {
		buffer[t] = static_cast<char>(t * (t >> 5 | t >> 8) & t);
	}

	WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
	waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));

	while (!(header.dwFlags & WHDR_DONE)) {
		Sleep(100);
	}

	Stop_And_Start_Shader = false;

	waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutClose(hWaveOut);
}

void Sound3() {
	HWAVEOUT hWaveOut;
	WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };

	waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, NULL, NULL, CALLBACK_NULL);
	char buffer[8000 * 30];

	for (INT t = 0; t < sizeof(buffer); t++) {
		buffer[t] = static_cast<char>(t >> (t % 32 ? 4 : 3) | (t % 128 ? t >> 3 : t >> 3 | t >> 9));
	}

	WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
	waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));

	while (!(header.dwFlags & WHDR_DONE)) {
		Sleep(100);
	}

	Stop_And_Start_Shader = true;

	waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutClose(hWaveOut);
}

void Sound4() {
	HWAVEOUT hWaveOut;
	WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };

	waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, NULL, NULL, CALLBACK_NULL);
	char buffer[8000 * 30];

	for (INT t = 0; t < sizeof(buffer); t++) {
		buffer[t] = static_cast<char>(t >> 9 & 2 * t & 10 * t | t >> 5 & 6 * t);
	}

	WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
	waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));

	while (!(header.dwFlags & WHDR_DONE)) {
		Sleep(100);
	}

	Stop_And_Start_Shader = false;

	waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutClose(hWaveOut);
}

DWORD WINAPI Sound5(LPVOID Param) {
	HWAVEOUT hWaveOut;
	WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };

	waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, NULL, NULL, CALLBACK_NULL);
	char buffer[8000 * 60];

	for (INT t = 0; t < sizeof(buffer); t++) {
		buffer[t] = static_cast<char>((t & 6) * t / 43 & (t * t + 45));
	}

	WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
	waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));

	while (!(header.dwFlags & WHDR_DONE)) {
		Sleep(100);
	}

	Stop_And_Start_Shader = true;

	waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutClose(hWaveOut);

	return 0;
}

void Sound6() {
	HWAVEOUT hWaveOut;
	WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };

	waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, NULL, NULL, CALLBACK_NULL);
	char buffer[8000 * 30];

	for (INT t = 0; t < sizeof(buffer); t++) {
		buffer[t] = static_cast<char>(9 * t & t >> 4 | 5 * t & t >> 7 | (3 * t & t >> 10) - 1);
	}

	WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
	waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));

	while (!(header.dwFlags & WHDR_DONE)) {
		Sleep(100);
	}

	Stop_And_Start_Shader = false;

	waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutClose(hWaveOut);
}

void Sound7() {
	HWAVEOUT hWaveOut;
	WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 11025, 11025, 1, 8, 0 };

	waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, NULL, NULL, CALLBACK_NULL);
	char buffer[11025 * 30];

	for (INT t = 0; t < sizeof(buffer); t++) {
		buffer[t] = static_cast<char>((t & (t * (t >> 9 | 9))) + 64);
	}

	WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
	waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));

	while (!(header.dwFlags & WHDR_DONE)) {
		Sleep(100);
	}

	Stop_And_Start_Shader = true;

	waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutClose(hWaveOut);
}

void Sound8() {
	HWAVEOUT hWaveOut;
	WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };

	waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, NULL, NULL, CALLBACK_NULL);
	char buffer[8000 * 30];

	for (INT t = 0; t < sizeof(buffer); t++) {
		buffer[t] = static_cast<char>((t >> 6 | t << 1) + (t >> 5 | t << 3 | t >> 3) | t >> 2 | t << 1);
	}

	WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
	waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));

	while (!(header.dwFlags & WHDR_DONE)) {
		Sleep(100);
	}

	Stop_And_Start_Shader = false;

	waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutClose(hWaveOut);
}

void Sound9() {
	HWAVEOUT hWaveOut;
	WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };

	waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, NULL, NULL, CALLBACK_NULL);
	char buffer[8000 * 30];

	for (INT t = 0; t < sizeof(buffer); t++) {
		buffer[t] = static_cast<char>((t >> 2) * (t >> 6) | t >> 4);
	}

	WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
	waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));

	while (!(header.dwFlags & WHDR_DONE)) {
		Sleep(100);
	}

	Stop_And_Start_Shader = true;

	waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutClose(hWaveOut);
}

void Sound10() {
	HWAVEOUT hWaveOut;
	WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 11025, 8000, 1, 8, 0 };

	waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, NULL, NULL, CALLBACK_NULL);
	char buffer[11025 * 30];

	for (INT t = 0; t < sizeof(buffer); t++) {
		buffer[t] = static_cast<char>((((t / 10 | 0) ^ (t / 10 | 0) - 1280) % 11 * t / 2 & 127) + (((t / 640 | 0) ^ (t / 640 | 0) - 2) % 13 * t / 2 & 127));
	}

	WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
	waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));

	while (!(header.dwFlags & WHDR_DONE)) {
		Sleep(100);
	}

	Stop_And_Start_Shader = false;

	waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutClose(hWaveOut);
}

void Sound11() {
	HWAVEOUT hWaveOut;
	WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };

	waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, NULL, NULL, CALLBACK_NULL);
	char buffer[8000 * 30];

	for (INT t = 0; t < sizeof(buffer); t++) {
		buffer[t] = static_cast<char>((t >> 4 % 1) * (t >> 3 + 1) | t >> 3 - 1);
	}

	WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
	waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));

	while (!(header.dwFlags & WHDR_DONE)) {
		Sleep(100);
	}

	Stop_And_Start_Shader = true;

	waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutClose(hWaveOut);
}

void Sound12() {
	HWAVEOUT hWaveOut;
	WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };

	waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, NULL, NULL, CALLBACK_NULL);
	char buffer[8000 * 30];

	for (INT t = 0; t < sizeof(buffer); t++) {
		buffer[t] = static_cast<char>(t * ((t & 4096 ? 6 : 16) + (1 & t >> 14)) >> (3 & t >> 8) | t >> (t & 4096 ? 3 : 4));
	}

	WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
	waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));

	while (!(header.dwFlags & WHDR_DONE)) {
		Sleep(100);
	}

	Stop_And_Start_Shader = false;

	waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutClose(hWaveOut);
}

void Sound13() {
	HWAVEOUT hWaveOut;
	WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };

	waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, NULL, NULL, CALLBACK_NULL);
	char buffer[8000 * 30];

	for (INT t = 0; t < sizeof(buffer); t++) {
		buffer[t] = static_cast<char>(t * (0xCA98CA98 >> (t >> 9 & 30) & 15) | t >> 8);
	}

	WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
	waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));

	while (!(header.dwFlags & WHDR_DONE)) {
		Sleep(100);
	}

	Stop_And_Start_Shader = true;

	waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutClose(hWaveOut);
}

DWORD WINAPI Sound14(LPVOID Param) {
	HWAVEOUT hWaveOut;
	WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };

	waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, NULL, NULL, CALLBACK_NULL);
	char buffer[8000 * 60];

	for (INT t = 0; t < sizeof(buffer); t++) {
		buffer[t] = static_cast<char>(10 * (t >> 6 | t) + (7 & t >> 11));
	}

	WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
	waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));

	while (!(header.dwFlags & WHDR_DONE)) {
		Sleep(100);
	}

	Stop_And_Start_Shader = false;

	waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutClose(hWaveOut);

	return 0;
}

void Sound15() {
	HWAVEOUT hWaveOut;
	WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 16000, 8000, 1, 8, 0 };

	waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, NULL, NULL, CALLBACK_NULL);
	char buffer[16000 * 30];

	for (INT t = 0; t < sizeof(buffer); t++) {
		buffer[t] = static_cast<char>(3 * (t ^ 65 | 5 | t >> 8));
	}

	WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
	waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));

	while (!(header.dwFlags & WHDR_DONE)) {
		Sleep(100);
	}

	Stop_And_Start_Shader = true;

	waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutClose(hWaveOut);
}