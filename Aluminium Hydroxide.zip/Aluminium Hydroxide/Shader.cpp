#include <Windows.h>
#include <math.h>
#include <random>
#include "Shader.h"

using namespace std;

std::atomic<bool> StopThread(false);

int r = 255, g = 0, b = 0;

DWORD WINAPI Payload1(LPVOID lpParam) {
	HDC hdcScreen = GetDC(NULL), hdcMem = CreateCompatibleDC(hdcScreen);

	int w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN);

	BITMAPINFO bmi = { 0 };
	RGBQUAD* rgbScreen = { 0 };
	bmi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
	bmi.bmiHeader.biWidth = w;
	bmi.bmiHeader.biHeight = h;
	bmi.bmiHeader.biBitCount = 32;
	bmi.bmiHeader.biPlanes = 1;
	bmi.bmiHeader.biCompression = BI_RGB;

	HBITMAP hbmTemp = CreateDIBSection(hdcScreen, &bmi, DIB_RGB_COLORS, (void**)&rgbScreen, NULL, NULL);
	SelectObject(hdcMem, hbmTemp);

	DWORD* px = (DWORD*)rgbScreen;

	while (!Stop_And_Start_Shader) {
		BitBlt(hdcMem, 0, 0, w, h, hdcScreen, 0, 0, SRCCOPY);

		for (int i = 0; i < w * h; i++) {
			rgbScreen[i].rgbRed = rgbScreen[i].rgbRed + 360;
			rgbScreen[i].rgbGreen = rgbScreen[i].rgbGreen + 360;
			rgbScreen[i].rgbBlue = rgbScreen[i].rgbBlue + 360;
		}

		BitBlt(hdcScreen, 0, 0, w, h, hdcMem, 0, 0, SRCCOPY);
	}

	DeleteObject(hbmTemp);
	DeleteDC(hdcMem);

	ReleaseDC(NULL, hdcScreen);

	return 0;
}

DWORD WINAPI Payload2(LPVOID lpParam)
{
	HDC hdcScreen = GetDC(NULL);

	int w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN);
	while (Stop_And_Start_Shader)
	{
		StretchBlt(hdcScreen, -1, 1, w, h, hdcScreen, 0, 0, w, h, SRCPAINT);
	}

	ReleaseDC(NULL, hdcScreen);

	return 0;
}

DWORD WINAPI Payload3(LPVOID lpParam)
{
	HDC hdcScreen = GetDC(NULL);

	int w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN);

	while (!Stop_And_Start_Shader)
	{
		random_device rd;
		mt19937 gen(rd());
		uniform_int_distribution<> dis(-255, 255);

		int x = dis(gen), y = dis(gen);

		HBRUSH hBrush = CreateSolidBrush(RGB(rand() % 256, rand() % 256, rand() % 256));
		SelectObject(hdcScreen, hBrush);

		BitBlt(hdcScreen, 0, 0, w, h, hdcScreen, 0, 0, PATINVERT);
		StretchBlt(hdcScreen, x, y, w, h, hdcScreen, 0, 0, w, h, SRCCOPY);
		DeleteObject(hBrush);
	}

	ReleaseDC(NULL, hdcScreen);

	return 0;
}

DWORD WINAPI Payload4(LPVOID lpParam) {
	HDC hdcScreen = GetDC(NULL), hdcMem = CreateCompatibleDC(hdcScreen);

	int w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN);

	BITMAPINFO bmi = { 0 };
	RGBQUAD* rgbScreen = { 0 };
	bmi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
	bmi.bmiHeader.biWidth = w;
	bmi.bmiHeader.biHeight = h;
	bmi.bmiHeader.biBitCount = 32;
	bmi.bmiHeader.biPlanes = 1;
	bmi.bmiHeader.biCompression = BI_RGB;

	HBITMAP hbmTemp = CreateDIBSection(hdcScreen, &bmi, DIB_RGB_COLORS, (void**)&rgbScreen, NULL, NULL);
	SelectObject(hdcMem, hbmTemp);

	DWORD* px = (DWORD*)rgbScreen;

	while (Stop_And_Start_Shader) {
		BitBlt(hdcMem, 0, 0, w, h, hdcScreen, 0, 0, SRCCOPY);

		for (int i = 0; i < w * h; i++) {
			int x = i % w, y = i / w;
			px[i] += x * y;
		}

		BitBlt(hdcScreen, 0, 0, w, h, hdcMem, 0, 0, SRCCOPY);
	}

	DeleteObject(hbmTemp);
	DeleteDC(hdcMem);

	ReleaseDC(NULL, hdcScreen);

	return 0;
}

DWORD WINAPI Payload5(LPVOID lpParam)
{
	HDC hdcScreen = GetDC(NULL), hdcMem = CreateCompatibleDC(hdcScreen);

	int w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN);

	BITMAPINFO bmi = { 0 };
	RGBQUAD* rgbScreen = { 0 };
	bmi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
	bmi.bmiHeader.biWidth = w;
	bmi.bmiHeader.biHeight = h;
	bmi.bmiHeader.biBitCount = 32;
	bmi.bmiHeader.biPlanes = 1;
	bmi.bmiHeader.biCompression = BI_RGB;

	HBITMAP hbmTemp = CreateDIBSection(hdcScreen, &bmi, DIB_RGB_COLORS, (void**)&rgbScreen, NULL, NULL);
	SelectObject(hdcMem, hbmTemp);

	DWORD* px = (DWORD*)rgbScreen;

	while (!StopThread.load())
	{
		BitBlt(hdcMem, 0, 0, w, h, hdcScreen, 0, 0, SRCCOPY);

		for (int i = 0; i < w * h; i++)
		{
			int x = i % w, y = i / w;
			px[i] += asin((sin((x + GetTickCount() / 10.0) / 20.0) + cos((y + GetTickCount() / 10.0) / 20.0)) * 1000);
		}

		BitBlt(hdcScreen, 0, 0, w, h, hdcMem, 0, 0, SRCCOPY);
	}

	DeleteObject(hbmTemp);
	DeleteDC(hdcMem);

	ReleaseDC(NULL, hdcScreen);

	return 0;
}

DWORD WINAPI Payload5_5(LPVOID lpParam)
{
	HDC hdcScreen = GetDC(NULL);

	int w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN);

	while (!Stop_And_Start_Shader)
	{
		std::random_device rd;
		std::mt19937 random(rd());
		std::uniform_int_distribution<int> dist(-5, 5);

		int x = dist(random);
		int y = dist(random);

		BitBlt(hdcScreen, x, y, w, h, hdcScreen, 0, 0, SRCINVERT);

		if ((rand() % 100 + 63) % 100 == 0) {
			SendMessageTimeout(HWND_BROADCAST, WM_SETTINGCHANGE, 0, 0, SMTO_ABORTIFHUNG, 200, NULL);
			Sleep(100);
		}
	}

	ReleaseDC(NULL, hdcScreen);

	return 0;
}

DWORD WINAPI Payload6(LPVOID lpParam)
{
	HDC hdcScreen = GetDC(NULL);

	int w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN);

	while (Stop_And_Start_Shader)
	{
		BitBlt(
			hdcScreen,
			0, 0,
			w - 75, h,
			hdcScreen,
			75, 0,
			SRCCOPY
		);

		BitBlt(
			hdcScreen,
			w - 75, 0,
			75, h,
			hdcScreen,
			0, 0,
			NOTSRCCOPY
		);

		SetBkMode(hdcScreen, TRANSPARENT);
		SetTextColor(hdcScreen, RGB(rand() % 255, rand() % 255, rand() % 255));

		HFONT font = CreateFontA(
			40, 0, 0, 0, FW_BOLD,
			FALSE, FALSE, FALSE,
			ANSI_CHARSET,
			OUT_DEFAULT_PRECIS,
			CLIP_DEFAULT_PRECIS,
			DEFAULT_QUALITY,
			DEFAULT_PITCH | FF_DONTCARE,
			"Arial");

		SelectObject(hdcScreen, font);

		TextOutA(hdcScreen, rand() % w, rand() % h, "Aluminium_Hydroxide.exe", 23);
	}

	ReleaseDC(NULL, hdcScreen);

	return 0;
}

DWORD WINAPI Payload7(LPVOID lpParam)
{
	HDC hdcScreen = GetDC(NULL);

	int w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN);

	while (!Stop_And_Start_Shader) {
		HBRUSH hBrush = CreateSolidBrush(RGB(rand() % 255, rand() % 255, rand() % 255));
		SelectObject(hdcScreen, hBrush);

		POINT point[3] = {
			rand() % w, rand() % h,
			rand() % w, rand() % h,
			rand() % w, rand() % h
		};

		Polygon(hdcScreen, point, 3);

		DeleteObject(hBrush);
	}

	ReleaseDC(NULL, hdcScreen);

	return 0;
}

DWORD WINAPI Payload8(LPVOID lpParam)
{
	HDC hdcScreen = GetDC(NULL), hdcMem = CreateCompatibleDC(hdcScreen);

	int w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN);

	BITMAPINFO bmi = { 0 };
	RGBQUAD* rgbScreen = { 0 };
	bmi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
	bmi.bmiHeader.biWidth = w;
	bmi.bmiHeader.biHeight = h;
	bmi.bmiHeader.biBitCount = 32;
	bmi.bmiHeader.biPlanes = 1;
	bmi.bmiHeader.biCompression = BI_RGB;

	HBITMAP hbmTemp = CreateDIBSection(hdcScreen, &bmi, DIB_RGB_COLORS, (void**)&rgbScreen, NULL, NULL);
	SelectObject(hdcMem, hbmTemp);

	DWORD* px = (DWORD*)rgbScreen;

	while (Stop_And_Start_Shader)
	{
		BitBlt(hdcMem, 0, 0, w, h, hdcScreen, 0, 0, SRCCOPY);

		for (int i = 0; i < w * h; i++)
		{
			int x = i % w, y = i / w;
			px[i] = px[i] * 0xCA98 % RGB(255, 255, 255);
		}

		BitBlt(hdcScreen, 0, 0, w, h, hdcMem, 0, 0, SRCCOPY);
	}

	DeleteObject(hbmTemp);
	DeleteDC(hdcMem);

	ReleaseDC(NULL, hdcScreen);

	return 0;
}

DWORD WINAPI Payload9(LPVOID lpParam)
{
	HDC hdcScreen = GetDC(NULL), hdcMem = CreateCompatibleDC(hdcScreen);

	int w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN);

	while (!Stop_And_Start_Shader)
	{
		StretchBlt(hdcScreen, -100, 0, w * 1.1, h, hdcScreen, 0, 0, w, h, SRCCOPY);

		SetBkMode(hdcScreen, TRANSPARENT);
		SetTextColor(hdcScreen, RGB(rand() % 255, rand() % 255, rand() % 255));

		HFONT font = CreateFontA(
			40, 0, 0, 0, FW_BOLD,
			FALSE, FALSE, FALSE,
			ANSI_CHARSET,
			OUT_DEFAULT_PRECIS,
			CLIP_DEFAULT_PRECIS,
			DEFAULT_QUALITY,
			DEFAULT_PITCH | FF_DONTCARE,
			"Arial");

		SelectObject(hdcScreen, font);

		TextOutA(hdcScreen, rand() % w, rand() % h, "Aluminium_Hydroxide.exe", 23);

		Sleep(100);
	}

	DeleteDC(hdcMem);

	ReleaseDC(NULL, hdcScreen);

	return 0;
}

DWORD WINAPI Payload10(LPVOID lpParam)
{
	HDC hdcScreen = GetDC(NULL);

	int w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN);

	while (Stop_And_Start_Shader)
	{
		HDC hdc = GetDC(0);
		BitBlt(hdcScreen, 0, 0, w, h, hdcScreen, -100, 0, SRCCOPY);
		BitBlt(hdcScreen, 0, 0, w, h, hdcScreen, w - 100, 0, SRCCOPY);
		BitBlt(hdcScreen, 0, 0, w, h, hdcScreen, 0, -100, SRCCOPY);
		BitBlt(hdcScreen, 0, 0, w, h, hdcScreen, 0, h - 100, SRCCOPY);
		HBRUSH brush = CreateSolidBrush(RGB(rand() % 255, rand() % 255, rand() % 255));
		SelectObject(hdcScreen, brush);
		BitBlt(hdcScreen, 0, 0, w, h, hdcScreen, 0, 0, PATINVERT);

		SetBkMode(hdcScreen, TRANSPARENT);
		SetTextColor(hdcScreen, RGB(rand() % 255, rand() % 255, rand() % 255));

		HFONT font = CreateFontA(
			40, 0, 0, 0, FW_BOLD,
			FALSE, FALSE, FALSE,
			ANSI_CHARSET,
			OUT_DEFAULT_PRECIS,
			CLIP_DEFAULT_PRECIS,
			DEFAULT_QUALITY,
			DEFAULT_PITCH | FF_DONTCARE,
			"Arial");

		SelectObject(hdcScreen, font);

		TextOutA(hdcScreen, rand() % w, rand() % h, "Aluminium_Hydroxide.exe", 23);
	}

	ReleaseDC(NULL, hdcScreen);

	return 0;
}

DWORD WINAPI Payload11(LPVOID lpParam)
{
	HDC hdcScreen = GetDC(NULL);

	int w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN);

	while (!Stop_And_Start_Shader)
	{
		random_device rd;
		mt19937 gen(rd());
		uniform_int_distribution<> dis(-255, 255);

		int x = dis(gen), y = dis(gen);

		HBRUSH hBrush = CreateSolidBrush(RGB(rand() % 256, rand() % 256, rand() % 256));
		SelectObject(hdcScreen, hBrush);

		BitBlt(hdcScreen, 0, 0, w, h, hdcScreen, 0, 0, PATINVERT);
		BitBlt(hdcScreen, x, y, w - x, h - y, hdcScreen, 0, 0, MERGECOPY);

		SetBkMode(hdcScreen, TRANSPARENT);
		SetTextColor(hdcScreen, RGB(rand() % 255, rand() % 255, rand() % 255));

		HFONT font = CreateFontA(
			40, 0, 0, 0, FW_BOLD,
			FALSE, FALSE, FALSE,
			ANSI_CHARSET,
			OUT_DEFAULT_PRECIS,
			CLIP_DEFAULT_PRECIS,
			DEFAULT_QUALITY,
			DEFAULT_PITCH | FF_DONTCARE,
			"Arial");

		SelectObject(hdcScreen, font);

		TextOutA(hdcScreen, rand() % w, rand() % h, "Aluminium_Hydroxide.exe", 23);

		DeleteObject(hBrush);
	}

	ReleaseDC(NULL, hdcScreen);

	return 0;
}


DWORD WINAPI Payload12(LPVOID lpParam)
{
	HDC hdcScreen = GetDC(NULL), hdcMem = CreateCompatibleDC(hdcScreen);

	int w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN);

	BITMAPINFO bmi = { 0 };
	RGBQUAD* rgbScreen = { 0 };
	bmi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
	bmi.bmiHeader.biWidth = w;
	bmi.bmiHeader.biHeight = h;
	bmi.bmiHeader.biBitCount = 32;
	bmi.bmiHeader.biPlanes = 1;
	bmi.bmiHeader.biCompression = BI_RGB;

	HBITMAP hbmTemp = CreateDIBSection(hdcScreen, &bmi, DIB_RGB_COLORS, (void**)&rgbScreen, NULL, NULL);
	SelectObject(hdcMem, hbmTemp);

	DWORD* px = (DWORD*)rgbScreen;

	while (Stop_And_Start_Shader)
	{
		BitBlt(hdcMem, 0, 0, w, h, hdcScreen, 0, 0, SRCCOPY);

		for (int i = 0; i < w * h; i++)
		{
			int x = i % w, y = i / w;
			px[i] += (x + y >> 7) ^ RGB(r, g, g);
		}

		BitBlt(hdcScreen, 0, 0, w, h, hdcMem, 0, 0, SRCCOPY);

		if (r == 255 && g < 255 && b == 0) {
			g++; //red >> yellow
		}

		else if (r > 0 && g == 255 && b < 255) {
			r--; //yellow > green
		}

		else if (r < 255 && g == 255 && b < 255) {
			b++; // green > cyan
		}

		else if (r < 255 && g > 0 && b == 255) {
			g--; //cyan > blue
		}

		else if (r < 255 && g < 255 && b == 255) {
			r++; //blue > magenta
		}

		else if (r == 255 && g < 255 && b > 0) {
			b--; //magenta >> red
		}
	}

	DeleteObject(hbmTemp);
	DeleteDC(hdcMem);

	ReleaseDC(NULL, hdcScreen);

	return 0;
}

DWORD WINAPI Payload13(LPVOID lpParam)
{
	HDC hdcScreen = GetDC(NULL), hdcMem = CreateCompatibleDC(hdcScreen);

	int w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN);

	BITMAPINFO bmi = { 0 };
	RGBQUAD* rgbScreen = { 0 };
	bmi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
	bmi.bmiHeader.biWidth = w;
	bmi.bmiHeader.biHeight = h;
	bmi.bmiHeader.biBitCount = 32;
	bmi.bmiHeader.biPlanes = 1;
	bmi.bmiHeader.biCompression = BI_RGB;

	HBITMAP hbmTemp = CreateDIBSection(hdcScreen, &bmi, DIB_RGB_COLORS, (void**)&rgbScreen, NULL, NULL);
	SelectObject(hdcMem, hbmTemp);

	DWORD* px = (DWORD*)rgbScreen;

	while (!Stop_And_Start_Shader)
	{
		BitBlt(hdcMem, 0, 0, w, h, hdcScreen, 0, 0, SRCCOPY);

		for (int i = 0; i < w * h; i++)
		{
			int x = i % w, y = i / w;
			px[i] += x ^ y;
		}

		BitBlt(hdcScreen, 0, 0, w, h, hdcMem, 0, 0, SRCCOPY);

		if (r == 255 && g < 255 && b == 0) {
			g++; //red >> yellow
		}

		else if (r > 0 && g == 255 && b < 255) {
			r--; //yellow > green
		}

		else if (r < 255 && g == 255 && b < 255) {
			b++; // green > cyan
		}

		else if (r < 255 && g > 0 && b == 255) {
			g--; //cyan > blue
		}

		else if (r < 255 && g < 255 && b == 255) {
			r++; //blue > magenta
		}

		else if (r == 255 && g < 255 && b > 0) {
			b--; //magenta >> red
		}
	}

	DeleteObject(hbmTemp);
	DeleteDC(hdcMem);

	ReleaseDC(NULL, hdcScreen);

	return 0;
}

DWORD WINAPI Payload14(LPVOID lpParam)
{
	HDC hdcScreen = GetDC(NULL);

	int w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN);

	while (StopThread.load() && Stop_And_Start_Shader) {
		HBRUSH hbrush = CreateSolidBrush(RGB(r, g, b));
		SelectObject(hdcScreen, hbrush);

		PatBlt(hdcScreen, 0, 0, w, h, PATCOPY);

		if (r == 255 && g < 255 && b == 0) {
			g++; //red >> yellow
		}

		else if (r > 0 && g == 255 && b < 255) {
			r--; //yellow > green
		}

		else if (r < 255 && g == 255 && b < 255) {
			b++; // green > cyan
		}

		else if (r < 255 && g > 0 && b == 255) {
			g--; //cyan > blue
		}

		else if (r < 255 && g < 255 && b == 255) {
			r++; //blue > magenta
		}

		else if (r == 255 && g < 255 && b > 0) {
			b--; //magenta >> red
		}

		DeleteObject(hbrush);
		Sleep(10);
	}

	ReleaseDC(NULL, hdcScreen);
	return 0;
}

DWORD WINAPI squares(LPVOID lpParam) {
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	int signX = 1;
	int signY = 1;
	int signX1 = 1;
	int signY1 = 1;
	int incrementor = 10;
	int x = 10;
	int y = 10;
	while (!StopThread.load()) {
		HDC hdc = GetDC(0);
		x += incrementor * signX;
		y += incrementor * signY;
		int top_x = 0 + x;
		int top_y = 0 + y;
		int bottom_x = 100 + x;
		int bottom_y = 100 + y;
		HBRUSH brush = CreateSolidBrush(RGB(r, g, b));
		SelectObject(hdc, brush);
		Rectangle(hdc, top_x, top_y, bottom_x, bottom_y);
		if (y == GetSystemMetrics(SM_CYSCREEN))
		{
			signY = -1;
		}

		if (x == GetSystemMetrics(SM_CXSCREEN))
		{
			signX = -1;
		}

		if (y == 0)
		{
			signY = 1;
		}

		if (x == 0)
		{
			signX = 1;
		}

		if (r == 255 && g < 255 && b == 0) {
			g++; //red >> yellow
		}

		else if (r > 0 && g == 255 && b < 255) {
			r--; //yellow > green
		}

		else if (r < 255 && g == 255 && b < 255) {
			b++; // green > cyan
		}

		else if (r < 255 && g > 0 && b == 255) {
			g--; //cyan > blue
		}

		else if (r < 255 && g < 255 && b == 255) {
			r++; //blue > magenta
		}

		else if (r == 255 && g < 255 && b > 0) {
			b--; //magenta >> red
		}

		Sleep(10);
		DeleteObject(brush);
		ReleaseDC(0, hdc);
	}

	return 0;
}

DWORD WINAPI mashers(LPVOID lpParam) {
	HDC hdcScreen = GetDC(NULL), hdcMem = CreateCompatibleDC(hdcScreen);

	int w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN);

	while (!StopThread.load()) {
		random_device rd;
		mt19937 gen(rd());
		uniform_int_distribution<> dis(0, 255);

		int x = dis(gen), y = dis(gen);

		BitBlt(hdcScreen, rand() % w, rand() % h, rand() % w, rand() % h, hdcScreen, rand() % w, rand() % h, SRCCOPY);
		BitBlt(hdcScreen, rand() % w, rand() % h, rand() % w, rand() % h, hdcScreen, rand() % w, rand() % h, NOTSRCCOPY);
	}

	ReleaseDC(NULL, hdcScreen);

	return 0;
}

DWORD WINAPI Payload15(LPVOID lpParam)
{
	HDC hdcScreen = GetDC(NULL), hdcMem = CreateCompatibleDC(hdcScreen);

	int w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN);

	BITMAPINFO bmi = {};
	RGBQUAD* rgbScreen = new RGBQUAD[w * h];
	bmi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
	bmi.bmiHeader.biWidth = w;
	bmi.bmiHeader.biHeight = h;
	bmi.bmiHeader.biPlanes = 1;
	bmi.bmiHeader.biBitCount = 32;

	HBITMAP hbmScreen = CreateDIBSection(hdcScreen, &bmi, DIB_RGB_COLORS, (void**)&rgbScreen, NULL, 0);
	SelectObject(hdcMem, hbmScreen);

	DWORD* px = (DWORD*)rgbScreen;

	while (!Stop_And_Start_Shader) {
		BitBlt(hdcMem, 0, 0, w, h, hdcScreen, 0, 0, SRCCOPY);

		for (int i = 0; i < w * h; i++) {
			px[i] = px[i] * 2 % RGB(255, 255, 255);
		}

		BitBlt(hdcScreen, 0, 0, w, h - 50, hdcMem, 0, 50, SRCCOPY);
		BitBlt(hdcScreen, 0, h - 50, w, h - 50, hdcMem, 0, 0, SRCCOPY);
	}

	ReleaseDC(NULL, hdcScreen);

	return 0;
}