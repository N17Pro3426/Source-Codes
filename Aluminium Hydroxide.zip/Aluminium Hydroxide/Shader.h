#pragma once
#include <Windows.h>
#include <atomic>

extern bool Stop_And_Start_Shader;
extern std::atomic<bool> StopThread;

DWORD WINAPI Payload1(LPVOID lpParam);
DWORD WINAPI Payload2(LPVOID lpParam);
DWORD WINAPI Payload3(LPVOID lpParam);
DWORD WINAPI Payload4(LPVOID lpParam);
DWORD WINAPI Payload5(LPVOID lpParam);
DWORD WINAPI Payload5_5(LPVOID lpParam);
DWORD WINAPI Payload6(LPVOID lpParam);
DWORD WINAPI Payload7(LPVOID lpParam);
DWORD WINAPI Payload8(LPVOID lpParam);
DWORD WINAPI Payload9(LPVOID lpParam);
DWORD WINAPI Payload10(LPVOID lpParam);
DWORD WINAPI Payload11(LPVOID lpParam);
DWORD WINAPI Payload12(LPVOID lpParam);
DWORD WINAPI Payload13(LPVOID lpParam);
DWORD WINAPI Payload14(LPVOID lpParam);
DWORD WINAPI squares(LPVOID lpParam);
DWORD WINAPI mashers(LPVOID lpParam);
DWORD WINAPI Payload15(LPVOID lpParam);