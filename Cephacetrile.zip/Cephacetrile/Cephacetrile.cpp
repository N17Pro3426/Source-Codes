﻿#include"resource.h"
#include"def.h"
#include"sound.h"
#include"payload.h"
void mainpayloads() {
	//Sleep(5000);
	//HANDLE thread0 = CreateThread(0, 0, curcrazy, 0, 0, 0);
	//HANDLE thread00 = CreateThread(0, 0, textz, 0, 0, 0);
	Sleep(5000);
	HANDLE thread1 = CreateThread(0, 0, shader1, 0, 0, 0);
	sound1();
	TerminateThread(thread1, 0);
	InvalidateRect(0, 0, 0);
	HANDLE thread2 = CreateThread(0, 0, shader2, 0, 0, 0);
	HANDLE thread2dot1 = CreateThread(0, 0, word1, 0, 0, 0);
	sound2();
	TerminateThread(thread2, 0);
	InvalidateRect(0, 0, 0);
	HANDLE thread3 = CreateThread(0, 0, shader3, 0, 0, 0);
	sound3();
	TerminateThread(thread3, 0);
	InvalidateRect(0, 0, 0);
	HANDLE thread4 = CreateThread(0, 0, bitblt1, 0, 0, 0);
	HANDLE thread4dot1 = CreateThread(0, 0, bitblt2, 0, 0, 0);
	HANDLE thread4dot2 = CreateThread(0, 0, bitblt3, 0, 0, 0);
	sound4();
	TerminateThread(thread4, 0);
	TerminateThread(thread4dot1, 0);
	TerminateThread(thread4dot2, 0);
	InvalidateRect(0, 0, 0);
	InvalidateRect(0, 0, 0);
	HANDLE thread5 = CreateThread(0, 0, shader4, 0, 0, 0);
	sound5();
	TerminateThread(thread5, 0);
	InvalidateRect(0, 0, 0);
	HANDLE thread6 = CreateThread(0, 0, stretchblt1, 0, 0, 0);
	HANDLE thread6dot1 = CreateThread(0, 0, stretchblt2, 0, 0, 0);
	HANDLE thread6dot2 = CreateThread(0, 0, bitblt4, 0, 0, 0);
	sound6();
	TerminateThread(thread6, 0);
	TerminateThread(thread6dot1, 0);
	TerminateThread(thread6dot2, 0);
	InvalidateRect(0, 0, 0);
	HANDLE thread7 = CreateThread(0, 0, train, 0, 0, 0);
	HANDLE thread7dot1 = CreateThread(0, 0, colors, 0, 0, 0);
	sound7();
	TerminateThread(thread7, 0);
	TerminateThread(thread7dot1, 0);
	InvalidateRect(0, 0, 0);
	HANDLE thread8 = CreateThread(0, 0, shader5, 0, 0, 0);
	HANDLE thread8dot1 = CreateThread(0, 0, balls, 0, 0, 0);
	sound8();
	TerminateThread(thread8, 0);
	InvalidateRect(0, 0, 0);
	HANDLE thread9 = CreateThread(0, 0, aaaaaaaaaaaa, 0, 0, 0);
	sound9();
	TerminateThread(thread9, 0);
	InvalidateRect(0, 0, 0);
	HANDLE thread10 = CreateThread(0, 0, bitblt5, 0, 0, 0);
	HANDLE thread10dot1 = CreateThread(0, 0, word2, 0, 0, 0);
	sound10();
	TerminateThread(thread10, 0);
	TerminateThread(thread2dot1, 0);
	InvalidateRect(0, 0, 0);
	HANDLE thread11 = CreateThread(0, 0, wef, 0, 0, 0);
	HANDLE thread11dot1 = CreateThread(0, 0, bitblt6, 0, 0, 0);
	sound11();
	TerminateThread(thread11, 0);
	TerminateThread(thread11dot1, 0);
	InvalidateRect(0, 0, 0);
	HANDLE thread12 = CreateThread(0, 0, trianglez, 0, 0, 0);
	sound12();
	TerminateThread(thread12, 0);
	InvalidateRect(0, 0, 0);
	HANDLE thread13 = CreateThread(0, 0, shader6, 0, 0, 0);
	sound13();
	TerminateThread(thread13, 0);
	InvalidateRect(0, 0, 0);
	HANDLE thread14 = CreateThread(0, 0, swir, 0, 0, 0);
	sound14();
	TerminateThread(thread14, 0);
	InvalidateRect(0, 0, 0);
	HANDLE thread15 = CreateThread(0, 0, shader7, 0, 0, 0);
	sound15();
	TerminateThread(thread15, 0);
	InvalidateRect(0, 0, 0);
	HANDLE thread16 = CreateThread(0, 0, plgblt1, 0, 0, 0);
	sound16();
	TerminateThread(thread16, 0);
	InvalidateRect(0, 0, 0);
	HANDLE thread17 = CreateThread(0, 0, last_shit_fucking_bitch_payload_screen_moveing_nothing_back, 0, 0, 0);
	sound17();
	TerminateThread(thread17, 0);
	InvalidateRect(0, 0, 0);
	TerminateThread(thread8dot1, 0);
	TerminateThread(thread10dot1, 0);
	InvalidateRect(0, 0, 0);
}
int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, PSTR lpCmdLine, INT nCmdShow)
{
	InitDPI();
	srand(time(NULL));
	SeedXorshift32((DWORD)time(NULL));
	ShowWindow(GetConsoleWindow(), SW_HIDE);
	if (MessageBoxW(NULL, L"Run Cephacetrile malware?\r\n\It will disturb you for some time", L"Cephacetrile.exe - First Warning", MB_YESNO | MB_ICONEXCLAMATION) == IDNO)
	{
		ExitProcess(0);
	}
	else
	{
		if (MessageBoxW(NULL, L"Are you sure? \r\n\The malware author couldn't assume legal liability", L"Cephacetrile.exe - Last Epilepsy Warning", MB_YESNO | MB_ICONEXCLAMATION) == IDNO)
		{
			ExitProcess(0);
		}
		else
		{
			mainpayloads();
		}
	}
	return 0;
}