#include <bits/stl_algobase.h>
#include <bits/stl_algo.h>
#include <windows.h>
#include <cstdint>
#include <cmath>

#define PI 3.14159265358979323846264338327950288f
constexpr float Bsine = 4.0f / PI;
constexpr float Csine = -4.0f / (PI * PI);
constexpr double INV_255 = (1.0 / 255.0);
    
// Fast sine approximation using Bhaskara I's approximation
inline float Fsin(float x) {
	while (x < 0) { x += PI; }
    x = fmodf(x + PI, PI * 2) - PI;
    const float y = Bsine * x + Csine * x * fabsf(x);
    return 0.225f * (y * fabsf(y) - y) + y;
}

typedef struct {
    double h, s, v;
} HSV;

// Xoshiro256** PRNG implementation
static uint64_t s[4] = {123456789ULL, 362436069ULL, 521288629ULL, 88675123ULL}; // seed with your own values

static inline uint64_t rotl(const uint64_t x, int k) {
    return (x << k) | (x >> (64 - k));
}

uint64_t GENxoshiro256() {
    const uint64_t result = rotl(s[1] * 5, 7) * 9;

    const uint64_t t = s[1] << 17;

    s[2] ^= s[0];
    s[3] ^= s[1];
    s[1] ^= s[2];
    s[0] ^= s[3];

    s[2] ^= t;

    s[3] = rotl(s[3], 45);

    return result;
}


// Optimized RGB to HSV conversion
inline HSV rgb2hsv(const RGBQUAD& rgb) {
    HSV hsv;
    
    hsv.v = std::max({rgb.rgbRed, rgb.rgbGreen, rgb.rgbBlue}) * INV_255;
    const double delta = hsv.v - ( std::min({rgb.rgbRed, rgb.rgbGreen, rgb.rgbBlue}) * INV_255 );
    
    if (delta <= 0.0f) {
        hsv.h = hsv.s = 0.0f;
        return hsv;
    }
    
    hsv.s = delta / hsv.v;
    
	// Calculate hue with optimized branching
    if (hsv.v == rgb.rgbRed * INV_255) {
        hsv.h = ((rgb.rgbGreen - rgb.rgbBlue) * INV_255 / delta) * 60.0f;
    } 
    else if (hsv.v == rgb.rgbGreen * INV_255) {
        hsv.h = ((rgb.rgbBlue - rgb.rgbRed) * INV_255 / delta + 2.0f) * 60.0f;
    } 
    else {
        hsv.h = ((rgb.rgbRed - rgb.rgbGreen) * INV_255 / delta + 4.0f) * 60.0f;
    }
    
    // Normalize hue
    while (hsv.h < 0.0) hsv.h += 360.0;
    
    return hsv;
}

// Optimized RGB to HSV conversion without hue calculation
inline HSV rgb2hsvNh(const RGBQUAD& rgb) {
    HSV hsv; 
    hsv.h = 0.0;
    
    hsv.v = std::max({rgb.rgbRed, rgb.rgbGreen, rgb.rgbBlue}) * INV_255;
    const double delta = hsv.v - ( std::min({rgb.rgbRed, rgb.rgbGreen, rgb.rgbBlue}) * INV_255 );
    
    	if (delta <= 0.f) {
        	hsv.s = 0.f;
    	} else {
    		hsv.s = delta / hsv.v;
		}

    return hsv;
}

// Optimized HSV to RGB conversion
inline constexpr RGBQUAD hsv2rgb(const HSV& hsv) {
    double l = hsv.v * 255.0f;
    BYTE v = static_cast<BYTE>(l);
    if (hsv.s <= 0) { // Achromatic (gray)
        return { v, v, v, 0 };
    } else {
    	
    	double h = fmod(hsv.h, 3600.0) / 60.0; // Convert hue to [0, 6] (start from red to green to blue to red)
    	double f = h - BYTE(h); // Fractional part of h

		//BYTE because there is no more calculation and once it reaches rgb, it becomes BYTE.
    	const BYTE p = static_cast<BYTE>(l * (1 - hsv.s));
    	const BYTE q = static_cast<BYTE>(l * (1 - f * hsv.s));
    	const BYTE t = static_cast<BYTE>(l * (1 - (1 - f) * hsv.s));
    	
    	switch (BYTE(h) % 6) {
        	case 0: return {p, t, v, 0}; break;
        	case 1: return {p, v, q, 0}; break;
        	case 2: return {t, v, p, 0}; break;
        	case 3: return {v, q, p, 0}; break;
        	case 4: return {v, p, t, 0}; break;
        	case 5: return {q, p, v, 0}; break;
        	default: return {0, 0, 0, 0}; break; //fallback (not recomended to reach here but for handling issues)
    	}
	}
}

// Predefined colors for better performance
constexpr COLORREF predefinedColors[] = {
    RGB(255, 0, 0),    // Red
    RGB(0, 255, 0),    // Green
    RGB(0, 0, 255),    // Blue
    RGB(255, 0, 255),  // Magenta
    RGB(255, 255, 0)   // Yellow
};

inline COLORREF RndRGB() {
    return predefinedColors[rand() % (sizeof(predefinedColors)/sizeof(COLORREF))];
}