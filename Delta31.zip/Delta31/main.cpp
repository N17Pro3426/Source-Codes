#include "AlgorithmPlus.h"
#include <vector>
#include <random>
#include <cmath>
#include <atomic>
#include <thread>

// Use atomic variables for thread safety
short SHD = 1; // Which Pattern the HSV Shader Should Render
short Msc = 1; // Which Pattern the Mosaic Should Render
std::atomic<bool> ExT(true); // Exit Payloads
std::atomic<bool> VExT(true); // Exit HSV Payloads
bool RNING = 1;

DWORD WINAPI shdHSV(LPVOID) { //DRY optimization (Don't Repeat Yourself)
    const int width = GetSystemMetrics(SM_CXSCREEN);
    const int height = GetSystemMetrics(SM_CYSCREEN);
    
    // Initialize DCs and bitmap once
    HDC screenDC = GetDC(nullptr);
    HDC copyDC = CreateCompatibleDC(screenDC);
    BITMAPINFO bmpi = { sizeof(BITMAPINFOHEADER), width, -height, 1, 32, BI_RGB };
    
    RGBQUAD* rgbquad = nullptr;
    HBITMAP bmp = CreateDIBSection(screenDC, &bmpi, DIB_RGB_COLORS, reinterpret_cast<void**>(&rgbquad), nullptr, 0);
    if (!bmp || !rgbquad) {
        ReleaseDC(nullptr, screenDC);
        DeleteDC(copyDC);
        return 1;
    }
    
    SelectObject(copyDC, bmp);
    ReleaseDC(nullptr, screenDC);
    
    std::atomic<long> fc(1);
    const int numThreads = std::thread::hardware_concurrency();
    std::vector<std::thread> threads;
    threads.reserve(numThreads);
    
    while (VExT.load(std::memory_order_relaxed)) {
        screenDC = GetDC(nullptr);
        if (!screenDC) continue;
        if (BitBlt(copyDC, 0, 0, width, height, screenDC, 0, 0, SRCCOPY)) {
            const int rowsPerThread = height / numThreads;
            const long currentFc = fc.load(std::memory_order_relaxed);
            
            // Process rows in parallel
            for (int i = 0; i < numThreads; ++i) {
                const int startRow = i * rowsPerThread;
                const int endRow = (i == numThreads - 1) ? height : (startRow + rowsPerThread);
                
            	switch(SHD) {
                default: { threads.emplace_back([=, &rgbquad] { for (int y = startRow; y < endRow; ++y) {
                        RGBQUAD* rowStart = rgbquad + y * width;
                        for (int x = 0; x < width; ++x) {
                            HSV currentHsv = rgb2hsvNh(rowStart[x]);
                            currentHsv.h = fabsf(fmodf(x+y+(rand()%20), 320.0f) - 160.0f) / 1.5f + 160.0f;
                            rowStart[x] = hsv2rgb(currentHsv);
                        } } }); break; }
            	}
        	}
            
            // Wait for all threads
            for (auto& thread : threads) {
                thread.join();
            }
            threads.clear();
            
            if (BitBlt(screenDC, 0, 0, width, height, copyDC, 0, 0, SRCCOPY)) {
                Sleep(8); fc.fetch_add(1, std::memory_order_relaxed);
            }
        }
        ReleaseDC(nullptr, screenDC);
    }
    
    if (bmp) DeleteObject(bmp);
    if (copyDC) DeleteDC(copyDC);
    if (screenDC) ReleaseDC(nullptr, screenDC);
    return 0;
}

DWORD WINAPI swirl(LPVOID) {
    const int sw = GetSystemMetrics(SM_CXSCREEN);
    const int sh = GetSystemMetrics(SM_CYSCREEN);
    const int xSize = sh / 10;
    const int ySize = 9;
    const float invXSize = 1.0f / xSize;
    
    // Pre-calculate wave patterns once
    std::vector<int> horizontalWaves(sw);
    std::vector<int> verticalWaves(sh);
    
    // Pre-calculate sine values to avoid repeated calculations
    for (int i = 0; i < sw; ++i) {
        horizontalWaves[i] = static_cast<int>(Fsin(i * invXSize * PI) * ySize);
    }
    for (int i = 0; i < sh; ++i) {
        verticalWaves[i] = static_cast<int>(Fsin(i * invXSize * PI) * ySize);
    }
    
    // Initialize graphics objects
    HDC hdc = GetDC(nullptr);
    HDC hdcMem = CreateCompatibleDC(hdc);
    HBITMAP screenshot = CreateCompatibleBitmap(hdc, sw, sh);
    HBITMAP oldBmp = static_cast<HBITMAP>(SelectObject(hdcMem, screenshot));
    
    while (ExT) {
        hdc = GetDC(nullptr);
        
        // Capture screen
        BitBlt(hdcMem, 0, 0, sw, sh, hdc, 0, 0, SRCCOPY);
        
        // Apply horizontal waves using pre-calculated values
        for (int i = 0; i < sw; ++i) {
            BitBlt(hdcMem, i, 0, 1, sh, hdcMem, i, horizontalWaves[i], SRCCOPY);
        }
        
        // Apply vertical waves using pre-calculated values
        for (int i = 0; i < sh; ++i) {
            BitBlt(hdcMem, 0, i, sw, 1, hdcMem, verticalWaves[i], i, SRCCOPY);
        }
        
        // Draw the result to screen
        BitBlt(hdc, 0, 0, sw, sh, hdcMem, 0, 0, SRCINVERT);
        
        // Clean up
        ReleaseDC(nullptr, hdc);
        Sleep(2);
    }
    
    // Final cleanup
    SelectObject(hdcMem, oldBmp);
    DeleteObject(screenshot);
    DeleteDC(hdcMem);
    
    return 0;
}

DWORD WINAPI mvE(LPVOID) {
    const int sw = GetSystemMetrics(0);
    const int sh = GetSystemMetrics(1);
    HDC hdcScreen = GetDC(nullptr);
    HDC hdcMem = CreateCompatibleDC(hdcScreen);
    HBITMAP bitmap = CreateCompatibleBitmap(hdcScreen, sw, sh);
    HBITMAP oldBmp = (HBITMAP)SelectObject(hdcMem, bitmap);

    while (ExT) {
        // Capture screen once
        BitBlt(hdcMem, 0, 0, sw, sh, hdcScreen, 0, 0, SRCCOPY);

        // Draw random rectangles with NOTSRCCOPY
        for (int i = 0; i < 10; ++i) {
            int RH = rand() % sh;
            BitBlt(hdcMem, rand() % 30, RH, sw, sh - RH, hdcMem, rand() % 30, RH, NOTSRCCOPY);
        }

        // Draw to screen
        HDC hdcDest = GetDC(nullptr);
        BitBlt(hdcDest, 0, 0, sw, sh, hdcMem, 0, 0, SRCCOPY);
        ReleaseDC(nullptr, hdcDest);

        Sleep(4);
    }

    // Cleanup
    SelectObject(hdcMem, oldBmp);
    DeleteObject(bitmap);
    DeleteDC(hdcMem);
    ReleaseDC(nullptr, hdcScreen);
    return 0;
}

DWORD WINAPI mvER(LPVOID) {
    const int sw = GetSystemMetrics(0);
    const int sh = GetSystemMetrics(1);
    while (ExT) {
        // Draw to screen
        HDC hdc = GetDC(nullptr);
        BitBlt(hdc, rand() % 30, rand() % 30, sw, sh, hdc, rand() % 30, rand() % 30, SRCCOPY);
        ReleaseDC(nullptr, hdc);
        Sleep(4);
    }
    return 0;
}

// Precompute bytebeat data for a given formula
std::vector<BYTE> generateBytebeatData(BYTE MD, DWORD SMPLRT, BYTE Duration) {
    size_t size = SMPLRT * Duration;
    std::vector<BYTE> buffer(size);

    switch (MD) {
        case 0: for (size_t t = 0; t < size; ++t) { buffer[t] = static_cast<BYTE>((t * ((t >> 14 | t >> 8) & (t >> 5 | t >> 13) & 5) & (t >> 12)) & 255); } break;
        case 1: for (size_t t = 0; t < size; ++t) { buffer[t] = static_cast<BYTE>(((t * t * (t >> 5)) ^ (t >> 6)) & 255); } break;
		case 2: for (size_t t = 0; t < size; ++t) { buffer[t] = static_cast<BYTE>((150 * (t >> 7 | t / 2 | t / 2 >> (t >> 17)) + (7 & t >> 12)) & 255); } break;
		case 3: for (size_t t = 0; t < size; ++t) { buffer[t] = static_cast<BYTE>(( ((t*t/5)%((t>>7)+1))*(t/49%158) ) & 255); } break;
        default: std::fill(buffer.begin(), buffer.end(), 0); break;
    }
    return buffer;
}

VOID WINAPI sound(BYTE MD, DWORD SMPLRT, BYTE Duration) {
    const int MAX_RETRIES = 10;
    int retry_count = 0;
    bool success = false;

    // Generate waveform data once
    std::vector<BYTE> waveData = generateBytebeatData(MD, SMPLRT, Duration);
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, SMPLRT, SMPLRT, 1, 8, 0 };

    do {
        HWAVEOUT hWaveOut = nullptr;
        MMRESULT result = waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
        if (result != MMSYSERR_NOERROR) {
            if (++retry_count < MAX_RETRIES) {
                Sleep(84);
                continue;
            }
            break;
        }

        WAVEHDR header = { reinterpret_cast<LPSTR>(waveData.data()), static_cast<UINT>(waveData.size()), 0, 0, 0, 0, 0, 0 };
        if (waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR))) {
            waveOutClose(hWaveOut);
            if (++retry_count < MAX_RETRIES) {
                Sleep(84);
                continue;
            }
            break;
        }

        if (waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR))) {
            waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
            waveOutClose(hWaveOut);
            if (++retry_count < MAX_RETRIES) {
                Sleep(84);
                continue;
            }
            break;
        }

        // Sleep for the duration of the sound plus a small buffer
        Sleep((Duration * 1000) + 50);

        waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
        waveOutClose(hWaveOut);
        success = true;
    } while (!success && retry_count < MAX_RETRIES);
}

DWORD WINAPI Ivrt(LPVOID) {
    // Cache screen dimensions outside the loop
    int w = GetSystemMetrics(0);
    int h = GetSystemMetrics(1);

    while (ExT) {
        HDC hdc = GetDC(0);
        
        for (BYTE Fc = 0; Fc<10; ++Fc) {
        	// Use DC_BRUSH for faster brush selection
        	SetDCBrushColor(hdc, RGB(rand()%256, rand()%256, rand()%256));
        	HBRUSH hBrush = (HBRUSH)SelectObject(hdc, GetStockObject(DC_BRUSH));

        	// Perform PatBlt with PATINVERT for flicker-free update
        	PatBlt(hdc, 0, 0, w, h, PATINVERT);
        	Sleep(6);
        }
        
        ReleaseDC(0, hdc);
    }
    return 0;
}

DWORD WINAPI Txt(LPVOID) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1), X, Y, thing; HDC hdc = GetDC(0);
    BitBlt(hdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
    while (ExT) {
        hdc = GetDC(0);
        SetBkMode(hdc, 0);
        w = GetSystemMetrics(0), h = GetSystemMetrics(1);
        X = rand() % 100 + 50, Y = rand() % 130 + 65;
        HFONT hfnt = CreateFontA(Y, X, 0, 0, FW_THIN, 1, 0, 0, ANSI_CHARSET, 0, 0, 0, 0, "Fredoka");
        SelectObject(hdc, hfnt);
        LPCSTR things[] = {
            "Scriptor.exe", "Polynizum Alt", "Scripted", "Scripting EXEs"
        };
        thing = rand() % 4;
        SetTextColor(hdc, RGB(35, 35, 255));
        X = rand() % w, Y = rand() % h;
        TextOutA(hdc, X , Y, things[thing], strlen(things[thing]));
        DeleteObject(hfnt);
        ReleaseDC(0, hdc);
        Sleep(4);
    }
    return 0;
}

DWORD WINAPI Trd1(LPVOID) { //Credits to Pankoza2-pl
	HDC hdc = GetDC(NULL);
	HDC dcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(0);
	int h = GetSystemMetrics(1);

	BITMAPINFO bmpi = { 0 };
	BLENDFUNCTION blur;
	HBITMAP bmp;

	bmpi.bmiHeader.biSize = sizeof(bmpi);
	bmpi.bmiHeader.biWidth = w;
	bmpi.bmiHeader.biHeight = h;
	bmpi.bmiHeader.biPlanes = 1;
	bmpi.bmiHeader.biBitCount = 32;
	bmpi.bmiHeader.biCompression = BI_RGB;

	bmp = CreateDIBSection(hdc, &bmpi, 0, 0, NULL, 0);
	SelectObject(dcCopy, bmp);

	blur.BlendOp = AC_SRC_OVER;
	blur.BlendFlags = 0;
	blur.AlphaFormat = 0;
	blur.SourceConstantAlpha = 64;
	while (ExT) {
		hdc = GetDC(nullptr);
		StretchBlt(dcCopy, 0, 1, w, h, hdc, 0, 0, w, h, SRCINVERT);
		AlphaBlend(hdc, 0, 0, w, h, dcCopy, 0, 0, w, h, blur);
		ReleaseDC(nullptr, hdc);
		Sleep(10);
	}
	return 0;
}

BYTE Shape = 1; //Shapes ( 1 = Cube, 2 = Octahedron, 3 = Tetrahedron)
DWORD WINAPI Shpe(LPVOID) {
    // Cache these values since they don't change during execution
    const int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    
    // Create reusable objects once
    HPEN hPen = CreatePen(PS_NULL, 0, RGB(0, 0, 0));
    if (!hPen) return 1;
    
    // Get stock DC brush once and select it
    HBRUSH hStockBrush = (HBRUSH)GetStockObject(DC_BRUSH);
    if (!hStockBrush) {
        DeleteObject(hPen);
        return 1;
    }
    
    HDC hdc;
    while (ExT.load(std::memory_order_relaxed)) {
        hdc = GetDC(0); if (!hdc) continue;
        
        // Select the pen and brush once (they never change)
        HGDIOBJ hOldPen = SelectObject(hdc, hPen);
        HGDIOBJ hOldBrush = SelectObject(hdc, hStockBrush);
        
        // Draw the Fake but True-Looking 3D Shapes
        short X = rand()%w, Y = rand()%h;
		BYTE R_Lozng = rand()%128+128, G_Lozng = rand()%128+128, B_Lozng = rand()%128+128;
		
		switch(Shape) {
			case 1: {
				POINT Fc1[] = { {X, 25+Y}, {100+X, 25+Y}, {100+X, 125+Y}, {X, 125+Y} };
				POINT Fc2[] = { {X, 25+Y}, {100+X, 25+Y}, {85+X, Y}, {15+X, Y} };
				BYTE R_Lozng = rand()%128+128, G_Lozng = rand()%128+128, B_Lozng = rand()%128+128;
				BitBlt(hdc, X-5, Y-5, 110, 135, hdc, X-5, Y-5, SRCCOPY);
        		SetDCBrushColor(hdc, RGB(R_Lozng,G_Lozng,B_Lozng)); Polygon(hdc, Fc1, 4);
        		SetDCBrushColor(hdc, RGB(R_Lozng/1.25,G_Lozng/1.25,B_Lozng/1.25)); Polygon(hdc, Fc2, 4);
        		break;
			}
			
        	case 2: {
        		POINT Fc1[] = { {X, 100+Y}, {100+X, 100+Y}, {100+X, Y} };
				POINT Fc2[] = { {200+X, 100+Y}, {100+X, 100+Y}, {100+X, Y} };
				POINT Fc3[] = { {X, 100+Y}, {100+X, 100+Y}, {100+X, 200+Y} };
				POINT Fc4[] = { {200+X, 100+Y}, {100+X, 100+Y}, {100+X, 200+Y} };
				BitBlt(hdc, X-5, Y-5, 210, 210, hdc, X-5, Y-5, SRCCOPY);
        		SetDCBrushColor(hdc, RGB(R_Lozng,G_Lozng,B_Lozng)); Polygon(hdc, Fc1, 3);
        		SetDCBrushColor(hdc, RGB(R_Lozng/1.25,G_Lozng/1.25,B_Lozng/1.25)); Polygon(hdc, Fc2, 3);
        		SetDCBrushColor(hdc, RGB(R_Lozng/1.25,G_Lozng/1.25,B_Lozng/1.25)); Polygon(hdc, Fc3, 3);
        		SetDCBrushColor(hdc, RGB(R_Lozng/1.5,G_Lozng/1.5,B_Lozng/1.5)); Polygon(hdc, Fc4, 3);
				break;
			}
			
        	case 3: {
        		POINT Fc1[] = { {X, 100+Y}, {50+X, 64+Y}, {50+X, Y} };
        		POINT Fc2[] = { {X+50, 64+Y}, {100+X, 100+Y}, {50+X, Y} };
        		POINT Fc3[] = { {X, 100+Y}, {50+X, 64+Y}, {100+X, 100+Y} };
				BitBlt(hdc, X-5, Y-5, 110, 110, hdc, X-5, Y-5, SRCCOPY);
        		SetDCBrushColor(hdc, RGB(R_Lozng,G_Lozng,B_Lozng)); Polygon(hdc, Fc1, 3);
        		SetDCBrushColor(hdc, RGB(R_Lozng/1.25,G_Lozng/1.25,B_Lozng/1.25)); Polygon(hdc, Fc2, 3);
        		SetDCBrushColor(hdc, RGB(R_Lozng/1.35,G_Lozng/1.35,B_Lozng/1.35)); Polygon(hdc, Fc3, 3);
				break;
			}
			
			default: {break;}
        }
        		
        // Restore original objects
        SelectObject(hdc, hOldBrush);
        SelectObject(hdc, hOldPen);
        
        ReleaseDC(0, hdc);
        Sleep(10);
    }
    
    // Clean up the pen when done (stock brush doesn't need to be deleted)
    DeleteObject(hPen);
    
    return 0;
}

DWORD WINAPI Ivrt32s(LPVOID) {
    const int w = GetSystemMetrics(0);
    const int h = GetSystemMetrics(1);
    HDC hdcScreen = GetDC(nullptr);
    HDC hdcMem = CreateCompatibleDC(hdcScreen);
    HBITMAP bitmap = CreateCompatibleBitmap(hdcScreen, w, h);
    HBITMAP oldBmp = (HBITMAP)SelectObject(hdcMem, bitmap);

    while (ExT) {
        BitBlt(hdcMem, 0, 0, w, h, hdcScreen, 0, 0, SRCCOPY);
        for (int i = 0; i < h; i += 2) {
            BitBlt(hdcMem, 1, i, w, 1, hdcMem, 0, i, SRCCOPY);
            BitBlt(hdcMem, 0, i + 1, w, 1, hdcMem, 1, i + 1, SRCCOPY);
        }
        HDC hdcDest = GetDC(nullptr);
        BitBlt(hdcDest, 0, 0, w, h, hdcMem, 0, 0, SRCCOPY);
        ReleaseDC(nullptr, hdcDest);
        Sleep(6);
    }

    // Cleanup
    SelectObject(hdcMem, oldBmp);
    DeleteObject(bitmap);
    DeleteDC(hdcMem);
    ReleaseDC(nullptr, hdcScreen);
    return 0;
}

VOID WINAPI ExtPyLd() { VExT = 0; ExT = 0; Sleep(145); InvalidateRect(0, 0, 0); Sleep(85); VExT = 1; ExT = 1;
} DWORD WINAPI Main2(LPVOID) {
	
	// Initialize Variables:
	BYTE BT, BT_old, SC, SC_old, OBJt, OBJ_old, SP, SP_old = 0;
	
    // Initialize random number generator
    std::mt19937 gen(GetTickCount());
    std::uniform_int_distribution<> dist(0, 255);
    Sleep(15);
    
	CreateThread(0,0, Ivrt32s, 0,0,0);
	sound(0, 32000, dist(gen)%30+15);
	ExtPyLd();
	
	for (BYTE AP = 0; AP < 3; ++AP) {
    	while (BT == BT_old) { BT = dist(gen)%5+1; }
    	while (SC == SC_old) { SC = dist(gen)%3+1; }
    	while (SP == SP_old) { SP = dist(gen)%3+1; }
    	while (OBJt == OBJ_old) { OBJt = dist(gen)%2+1; }
		CreateThread(0,0, Ivrt, 0,0,0);
		switch(SC) {
			case 1:{CreateThread(0,0, swirl, 0,0,0);break;}
			case 2:{CreateThread(0,0, mvE, 0,0,0);break;}
			case 3:{CreateThread(0,0, mvER, 0,0,0);break;}
			default:{break;}
		}
		switch(OBJt) {
			case 1:{Shape=SP;CreateThread(0,0, Shpe, 0,0,0);break;}
			default:{break;}
		}

		sound(1, 16000, dist(gen)%5+5);
		ExtPyLd();
		BT_old = BT; SC_old = SC; SP_old = SP; OBJ_old = OBJt;
    }
    ExtPyLd();
	CreateThread(0,0, Trd1, 0,0,0);
	CreateThread(0,0, shdHSV, 0,0,0);
	sound(2, 16000, dist(gen)%30+15);
	ExtPyLd();
	for (BYTE AP = 0; AP < 4; ++AP) {
    	switch(dist(gen)%3+1) {
			case 1:{CreateThread(0,0, mvER, 0,0,0);break;}
			case 2:{CreateThread(0,0, mvE, 0,0,0);break;}
			case 3:{CreateThread(0,0, Ivrt, 0,0,0);break;}
			default:{break;}
		}
		switch(dist(gen)%2) {
			case 0:{CreateThread(0,0, swirl, 0,0,0);break;}
			case 1:{CreateThread(0,0, Trd1, 0,0,0);break;}
		}

		sound(3, 16000, dist(gen)%5+5);
		ExtPyLd();
    }
	ExtPyLd();
	RNING = 0;
    return 0;
}




//The Hwnd Zone
//Most Codes is Just for the Hwnd

const int ID_STATIC_TEXT = 1;
const int COLOR_CHANGE_INTERVAL_MS = 50;
const int MOVE_INTERVAL_MS = 15;
const int STATIC_UPDATE_INTERVAL_MS = 35; // Update static effect every 35ms

const int ID_BUTTON_YES = 201;
const int ID_BUTTON_NO = 202;

HINSTANCE hInst;
HWND hwndStaticText1;
HWND hwndStaticText2;
HWND hwndStaticText3;
HWND hwndStaticText4;
HWND hwndStaticBackground;
HFONT hFont;
bool running = true;

// For static effect
std::vector<COLORREF> staticPixels;
int staticWidth = 0;
int staticHeight = 0;
float currentHueOffset = 0.0f;

LRESULT CALLBACK WindowProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
void CreateControls(HWND hwnd);
DWORD WINAPI ColorChangeThread(LPVOID);
DWORD WINAPI MoveWindowThread(LPVOID);
DWORD WINAPI StaticEffectThread(LPVOID);
void UpdateStaticEffect();
void DrawStaticEffect(HDC hdc, const RECT& rect);

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE, LPSTR, int nCmdShow) {
    hInst = hInstance;

    // Register window class
    WNDCLASS wc = {};
    wc.lpfnWndProc = WindowProc;
    wc.hInstance = hInstance;
    wc.lpszClassName = "ErrorDialogClass";
    wc.hCursor = LoadCursor(NULL, IDC_ARROW);
    wc.hbrBackground = (HBRUSH)GetStockObject(BLACK_BRUSH);
    RegisterClass(&wc);

    // Create main window
    HWND hwnd = CreateWindowEx(
        0, "ErrorDialogClass", "Delta31.exe",
        WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU, 
        CW_USEDEFAULT, CW_USEDEFAULT, 450, 200,
        NULL, NULL, hInstance, NULL
    );

    // Make window non-resizable
    SetWindowLong(hwnd, GWL_STYLE, GetWindowLong(hwnd, GWL_STYLE) & ~WS_THICKFRAME);
    ShowWindow(hwnd, nCmdShow);

    // Create threads for static effect and main logic
    CreateThread(NULL, 0, StaticEffectThread, hwnd, 0, NULL);

    // Message loop
    MSG msg;
    while (GetMessage(&msg, NULL, 0, 0)) {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }

    // Cleanup
    DestroyWindow(hwnd);
    return 0;
}

DWORD WINAPI StaticEffectThread(LPVOID lpParam) {
    HWND hwnd = (HWND)lpParam;
    
    // Initialize static effect
    RECT rect;
    GetClientRect(hwnd, &rect);
    staticWidth = rect.right - rect.left;
    staticHeight = rect.bottom - rect.top;
    staticPixels.resize(staticWidth * staticHeight);
    
    while (running) {
        UpdateStaticEffect();
        RedrawWindow(hwnd, NULL, FALSE, 1); // Redraw the window
        std::this_thread::sleep_for(std::chrono::milliseconds(STATIC_UPDATE_INTERVAL_MS));
    }
    
    return 0;
}

void UpdateStaticEffect() {
    currentHueOffset += 4.0f; // Increment hue offset for animation
    for (int i = 0; i < staticWidth * staticHeight; ++i) {
    	int x = i % staticWidth, y = i / staticHeight;
        float hue = fmodf(static_cast<float>((Fsin(x*PI/200.0f)+Fsin((y+0.5)*PI/200.0f))*180+360) + currentHueOffset, 360.0f);
        HSV hsvColor = { hue, 1.0f, 1.0f };
        RGBQUAD rgbQuad = hsv2rgb(hsvColor);
        staticPixels[i] = RGB(rgbQuad.rgbRed, rgbQuad.rgbGreen, rgbQuad.rgbBlue);
    }
}

void DrawStaticEffect(HDC hdc, const RECT& rect) {
    // Create a temporary bitmap
    HBITMAP hBitmap = CreateBitmap(staticWidth, staticHeight, 1, 32, staticPixels.data());
    if (!hBitmap) return;
    
    // Create a memory DC
    HDC hdcMem = CreateCompatibleDC(hdc);
    HBITMAP hOldBitmap = (HBITMAP)SelectObject(hdcMem, hBitmap);
    
    // Draw the static effect
    BitBlt(hdc, rect.left, rect.top, rect.right - rect.left, rect.bottom - rect.top, 
           hdcMem, 0, 0, SRCCOPY);
    
    // Clean up
    SelectObject(hdcMem, hOldBitmap);
    DeleteDC(hdcMem);
    DeleteObject(hBitmap);
}

DWORD WINAPI MoveWindowThread(LPVOID lpParam) {
    HWND hwnd = (HWND)lpParam;
    
    while (running) {
        // Get current window position
        RECT rect;
        GetWindowRect(hwnd, &rect);
        
        SetWindowPos(hwnd, NULL, rect.left+ (rand()%5-2), rect.top + (rand()%5-2), 0, 0, SWP_NOSIZE | SWP_NOZORDER | SWP_NOACTIVATE);
        
        std::this_thread::sleep_for(std::chrono::milliseconds(MOVE_INTERVAL_MS));
    }
    
    return 0;
}

DWORD WINAPI ColorChangeThread(LPVOID lpParam) {
    HWND hwnd = (HWND)lpParam;
    int hue = 0;
    
    while (running) {
        // Cycle through colors using HSL to RGB conversion
        hue = (hue + 5) % 360;
        
        // Convert HSL to RGB (simplified)
        float h = hue / 60.0f;
        float c = 1.0f;
        float x = (1 - fabs(fmod(h, 2) - 1));
        float r, g, b;
        
        if (h < 1) { r = c; g = x; b = 0; }
        else if (h < 2) { r = x; g = c; b = 0; }
        else if (h < 3) { r = 0; g = c; b = x; }
        else if (h < 4) { r = 0; g = x; b = c; }
        else if (h < 5) { r = x; g = 0; b = c; }
        else { r = c; g = 0; b = x; }
        
        COLORREF color = RGB(r * 255, g * 255, b * 255);
        
        // Force the static control to redraw with new color
        InvalidateRect(hwndStaticText1, NULL, TRUE);
        InvalidateRect(hwndStaticText2, NULL, TRUE);
        InvalidateRect(hwndStaticText3, NULL, TRUE);
        UpdateWindow(hwndStaticText1);
        UpdateWindow(hwndStaticText2);
        UpdateWindow(hwndStaticText3);
        
        std::this_thread::sleep_for(std::chrono::milliseconds(COLOR_CHANGE_INTERVAL_MS));
    }
    
    return 0;
}

LRESULT CALLBACK WindowProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam) {
    switch (uMsg) {
    case WM_CREATE:
        CreateControls(hwnd);
        return 0;

    case WM_PAINT:
        {
            PAINTSTRUCT ps;
            HDC hdc = BeginPaint(hwnd, &ps);
            
            // Get client area
            RECT rect;
            GetClientRect(hwnd, &rect);
            
            // Draw static effect
            DrawStaticEffect(hdc, rect);
            
            EndPaint(hwnd, &ps);
        }
        return 0;

    case WM_CTLCOLORSTATIC:
        {
            if ((HWND)lParam == hwndStaticText1 || (HWND)lParam == hwndStaticText2 || (HWND)lParam == hwndStaticText3) {
                static COLORREF currentColor = RGB(255, 255, 255); // Default white
                HDC hdcStatic = (HDC)wParam;
                
                // Get the current time to use in color calculation
                SYSTEMTIME st;
                GetLocalTime(&st);
                int timeValue = st.wMilliseconds + st.wSecond * 1000;
                
                // Create a more dynamic color effect
                BYTE r = (timeValue % 256);
                BYTE g = (timeValue * 2 % 256);
                BYTE b = (timeValue * 3 % 256);
                
                SetTextColor(hdcStatic, RGB(r, g, b));
                SetBkMode(hdcStatic, TRANSPARENT); // Make background transparent to show static
                return (LRESULT)GetStockObject(NULL_BRUSH);
            }
        }
        return DefWindowProc(hwnd, uMsg, wParam, lParam);

    case WM_SIZE:
        {
            // Update static effect dimensions when window is resized
            RECT rect;
            GetClientRect(hwnd, &rect);
            staticWidth = rect.right - rect.left;
            staticHeight = rect.bottom - rect.top;
            staticPixels.resize(staticWidth * staticHeight);
            UpdateStaticEffect();
        }
        return 0;
	case WM_COMMAND:
    {
        int wmId = LOWORD(wParam);
        switch (wmId) {
            case ID_BUTTON_YES:
                // Run main logic thread
                CreateThread(NULL, 0, Main2, 0, 0, NULL);
                DestroyWindow(hwnd);
                while (RNING) {Sleep(100);}
                break;
            case ID_BUTTON_NO:
                DestroyWindow(hwnd);
                break;
        }
    }
    return 0;
    case WM_CTLCOLORBTN:
        {
            HDC hdcBtn = (HDC)wParam;
            SetBkMode(hdcBtn, TRANSPARENT);
            // Optional: set text color if needed
            SetTextColor(hdcBtn, RGB(255,255,255));
            return (LRESULT)GetStockObject(NULL_BRUSH);
        }
    case WM_DESTROY:
        running = false;
        PostQuitMessage(0);
        return 0;
    }

    return DefWindowProc(hwnd, uMsg, wParam, lParam);
}

void CreateControls(HWND hwnd) {
    // Create static text with error message
    hwndStaticText1 = CreateWindowEx(
        WS_EX_TRANSPARENT, "STATIC", 
        "Run Delta31.exe? (Contains Epliepsy)", 
        WS_CHILD | WS_VISIBLE | SS_CENTER | SS_CENTERIMAGE,
        0, 0, 438, 38, 
        hwnd, 
        (HMENU)ID_STATIC_TEXT, 
        hInst, 
        NULL
    );
    hwndStaticText2 = CreateWindowEx(
        WS_EX_TRANSPARENT, "STATIC", 
        "This is a Safe Remake of Melter Trojans.", 
        WS_CHILD | WS_VISIBLE | SS_CENTER | SS_CENTERIMAGE,
        0, 100, 438, 38, 
        hwnd, 
        (HMENU)ID_STATIC_TEXT, 
        hInst, 
        NULL
    );
    hwndStaticText3 = CreateWindowEx(
        WS_EX_TRANSPARENT, "STATIC", 
        "Good Luck Running this! :)", 
        WS_CHILD | WS_VISIBLE | SS_CENTER | SS_CENTERIMAGE,
        0, 125, 438, 38, 
        hwnd, 
        (HMENU)ID_STATIC_TEXT, 
        hInst, 
        NULL
    );
    SendMessage(hwndStaticText1, WM_SETFONT, (WPARAM)hFont, TRUE);
    SendMessage(hwndStaticText2, WM_SETFONT, (WPARAM)hFont, TRUE);
    SendMessage(hwndStaticText3, WM_SETFONT, (WPARAM)hFont, TRUE);

    // Yes Button
    HWND hwndYesButton = CreateWindowEx(
        0, "BUTTON", "Yes", 
        WS_CHILD | WS_VISIBLE | BS_DEFPUSHBUTTON,
        125, 35, 80, 30, hwnd, (HMENU)ID_BUTTON_YES, hInst, NULL
    );

    // No Button
    HWND hwndNoButton = CreateWindowEx(
        0, "BUTTON", "No", 
        WS_CHILD | WS_VISIBLE | BS_DEFPUSHBUTTON,
        225, 35, 80, 30, hwnd, (HMENU)ID_BUTTON_NO, hInst, NULL
    );
    
    // Set font to larger, bold
    hFont = CreateFont(
        26, 0, 0, 0, FW_BOLD, 
        FALSE, FALSE, FALSE, DEFAULT_CHARSET, 
        OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, 
        DEFAULT_QUALITY, DEFAULT_PITCH, "Serif"
    );
    SendMessage(hwndStaticText1, WM_SETFONT, (WPARAM)hFont, TRUE);
    SendMessage(hwndStaticText2, WM_SETFONT, (WPARAM)hFont, TRUE);
    SendMessage(hwndStaticText3, WM_SETFONT, (WPARAM)hFont, TRUE);
}