﻿#include"resource.h"
#include"def.h"
#include"sound.h"
#include"payload.h"
#include"asdfghjkl.h"

void mainpayloads() {
	CreateThread(0, 0, msgbox, 0, 0, 0);
	Sleep(1145);
	HANDLE thread0 = CreateThread(0, 0, ttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttt, 0, 0, 0);
	Sleep(114);
	HANDLE thread1 = CreateThread(0, 0, shader1, 0, 0, 0);
	sound1();
	TerminateThread(thread1, 0);
	InvalidateRect(0, 0, 0);
	HANDLE thread2 = CreateThread(0, 0, colourfulpolygonz, 0, 0, 0);
	HANDLE thread2dot1 = CreateThread(0, 0, payload1, 0, 0, 0);
	sound2();
	TerminateThread(thread2dot1, 0);
	InvalidateRect(0, 0, 0);
	HANDLE thread3 = CreateThread(0, 0, shader2, 0, 0, 0);
	sound3();
	TerminateThread(thread3, 0);
	InvalidateRect(0, 0, 0);
	HANDLE thread4 = CreateThread(0, 0, shader3, 0, 0, 0);
	sound4();
	TerminateThread(thread4, 0);
	InvalidateRect(0, 0, 0);
	HANDLE thread5 = CreateThread(0, 0, circlez, 0, 0, 0);
	HANDLE thread5dot1 = CreateThread(0, 0, payload2, 0, 0, 0);
	HANDLE thread5dot2 = CreateThread(0, 0, blockz, 0, 0, 0);
	HANDLE thread5dot3 = CreateThread(0, 0, idk, 0, 0, 0);
	sound5();
	TerminateThread(thread5, 0);
	TerminateThread(thread5dot1, 0);
	TerminateThread(thread5dot2, 0);
	HANDLE thread6 = CreateThread(0, 0, shader4, 0, 0, 0);
	HANDLE thread6dot1 = CreateThread(0, 0, iconnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn, 0, 0, 0);
	sound6();
	TerminateThread(thread5dot3, 0);
	TerminateThread(thread6, 0);
	InvalidateRect(0, 0, 0);
	HANDLE thread7 = CreateThread(0, 0, shader5, 0, 0, 0);
	sound7();
	TerminateThread(thread7, 0);
	InvalidateRect(0, 0, 0);
	HANDLE thread8 = CreateThread(0, 0, shader6, 0, 0, 0);
	sound8();
	TerminateThread(thread8, 0);
	InvalidateRect(0, 0, 0);
	HANDLE thread9 = CreateThread(0, 0, shader7, 0, 0, 0);
	sound9();
	TerminateThread(thread9, 0);
	InvalidateRect(0, 0, 0);
	HANDLE thread10 = CreateThread(0, 0, shader8, 0, 0, 0);
	sound10();
	TerminateThread(thread10, 0);
	InvalidateRect(0, 0, 0);
	HANDLE thread11 = CreateThread(0, 0, shader9, 0, 0, 0);
	sound11();
	TerminateThread(thread11, 0);
	InvalidateRect(0, 0, 0);
	HANDLE thread12 = CreateThread(0, 0, shader10, 0, 0, 0);
	sound12();
	TerminateThread(thread12, 0);
	InvalidateRect(0, 0, 0);
	HANDLE thread13 = CreateThread(0, 0, payload3, 0, 0, 0);
	HANDLE thread13dot1 = CreateThread(0, 0, payload3num1, 0, 0, 0);
	HANDLE thread13dot2 = CreateThread(0, 0, idk, 0, 0, 0);
	sound13();
	TerminateThread(thread13, 0);
	TerminateThread(thread13dot1, 0);
	TerminateThread(thread13dot2, 0);
	TerminateThread(thread2, 0);
	TerminateThread(thread6dot1, 0);
	InvalidateRect(0, 0, 0);
}
int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, PSTR lpCmdLine, INT nCmdShow)
{
	InitDPI();
	srand(time(NULL));
	SeedXorshift32((DWORD)time(NULL));
	ShowWindow(GetConsoleWindow(), SW_HIDE);
	if (MessageBoxW(NULL, L"Run Neoarsphenamine malware?\r\n\It will disturb you for some time", L"Neoarsphenamine.exe - First Warning", MB_YESNO | MB_ICONEXCLAMATION) == IDNO)
	{
		ExitProcess(0);
	}
	else
	{
		if (MessageBoxW(NULL, L"Are you sure? \r\n\The malware author couldn't assume legal liability", L"Neoarsphenamine.exe - Last Epilepsy Warning", MB_YESNO | MB_ICONEXCLAMATION) == IDNO)
		{
			ExitProcess(0);
		}
		else
		{
			mainpayloads();
		}
	}
	return 0;
}