#include <d3d9.h>
#include <d3dx9.h>
#include <vector>
#include <cstdlib> // For rand() and srand()
#include <ctime>   // For time()
#include <string>  // For std::string
#include <sstream> // For std::ostringstream
#include <thread>  // For multi-threading
#include <mutex>   // For mutex
#include <cmath>   // For sqrt
#include <memory>  // For std::unique_ptr
#include <algorithm>
#include <queue>
#include <chrono>
#include <cfloat>
#include <atomic>
#include <unordered_map>
#include <array>

// jump physics
float jumpVelocity = 0.0f;
constexpr float gravity = 9.8f;

// HSV structure (add near the top with other structs)
struct HSV {
    double h; // Hue in degrees (0-3600 for more precision)
    double s; // Saturation (0-1)
    double v; // Value (0-1)
};

// Optimized HSV to RGB conversion (With Great Accurancy)
inline constexpr RGBQUAD hsv2rgb(const HSV& hsv) {
    double l = hsv.v * 255.0f;
    BYTE v = static_cast<BYTE>(l);
    if (hsv.s <= 0) { // Achromatic (gray)
        return { v, v, v, 0 };
    } else {
        double h = fmod(hsv.h, 3600.0) / 60.0; // Convert hue to [0, 6] (start from red to green to blue to red)
        double f = h - BYTE(h); // Fractional part of h

        const BYTE p = static_cast<BYTE>(l * (1 - hsv.s));
        const BYTE q = static_cast<BYTE>(l * (1 - f * hsv.s));
        const BYTE t = static_cast<BYTE>(l * (1 - (1 - f) * hsv.s));
        
        switch (BYTE(h) % 6) {
            case 0: return {v, t, p, 0}; break;
            case 1: return {q, v, p, 0}; break;
            case 2: return {p, v, t, 0}; break;
            case 3: return {p, q, v, 0}; break;
            case 4: return {t, p, v, 0}; break;
            case 5: return {v, p, q, 0}; break;
            default: return {0, 0, 0, 0}; break; //fallback
        }
    }
}

//Optimized Trignomentry (With Great Accurancy)
class SohlTrgnmntry {
public:
    static constexpr long double S_PI = 3.14159265358979323846264338327950288419716939937510L;
    static double Sin(double x) {
        if (!std::isfinite(x)) return 0;
        
        // Proper range reduction to [-π, π]
        x = std::remainder(x, TWO_PI);
        
        // Handle the case where remainder might return ±π
        if (x == -S_PI) x = S_PI;
        
        // Ultra-fast path for very small angles (|x| < 1e-04)
        if (std::abs(x) < 1e-04) return x;
        
        // Super-fast path for super small angles (|x| < 0.01)
        if (std::abs(x) < 0.01) { return sin_ultrafast(x); }
        
        // Fast path for small angles (|x| < 0.1)
        if (std::abs(x) < 0.1) { return sin_fast(x); }
        
        // Medium precision for small reduced angles (|x| < π/8)
        if (std::abs(x) < PI_OVER_8) { return sin_medium(x); }

        // High precision for larger angles
        return (std::abs(x) > 1.41) ? sine_huge(x) : sin_high(x);
    }
    static double Cos(double x) {
        if (!std::isfinite(x)) return 1;
        
        // Range reduction to [-π, π]
        x = std::remainder(x + HALF_PI, TWO_PI);
        if (x == -S_PI) x = S_PI;
        
        // Now just call Sin with the shifted angle
        return Sin(x);
    }
    
    static double Tan(double x) {
        if (!std::isfinite(x)) return std::numeric_limits<double>::quiet_NaN();
        
        // Range reduction to [-π/2, π/2]
        x = std::remainder(x, S_PI);
        
        // Improved handling of edge cases near π/2 + kπ
        // Uses a more precise threshold and better infinity handling
        const double distance_to_pole = std::abs(std::abs(x) - HALF_PI);
        if (distance_to_pole < 1e-10) {
        	
            // For very close to π/2, return properly signed infinity
            // Also handle cases where x might be exactly π/2 but due to rounding
            // didn't get caught by the distance check
            
            if (distance_to_pole < std::numeric_limits<double>::epsilon() * 4) {
                return std::copysign(std::numeric_limits<double>::infinity(), x);
            }
            // For slightly farther away, use a more precise computation
            // to avoid premature infinity
            const double adjusted_x = x - std::copysign(HALF_PI, x);
            return std::copysign(1.0, x) / adjusted_x;
        }
        
        // For very small angles, use tan(x) ≈ x
        if (std::abs(x) < 1e-04) return x;
        
        // Fast path for small angles (|x| < 0.1)
        if (std::abs(x) < 0.1) {
            const double x2 = x * x;
            return x * (1.0 + x2 * (1.0/3.0 + x2 * (2.0/15.0 + x2 * (17.0/315.0))));
        }
        
        // For larger angles, use sin/cos
        return Sin(x) / Cos(x);
    }

private:
    static constexpr long double TWO_PI = 2.0 * S_PI;
    static constexpr long double HALF_PI = 0.5 * S_PI;
    static constexpr double INV_HALF_PI = 0.6366197723675814; // 1/(π/2)
    static constexpr long double PI_OVER_4 = S_PI / 4.0;
    static constexpr long double PI_OVER_8 = S_PI / 8.0;
    static constexpr long double PI_OVER_16 = S_PI / 16.0;

    // Ultra-fast approximation for very small angles (|x| < 0.01)
    // 3-term polynomial (error < 1e-10 for |x| < 0.01)
    static inline constexpr double sin_ultrafast(double x) {
        const double x2 = x * x;
        return x * (1.0 - x2 * (1.0/6.0 - x2 * (1.0/120.0)));
    }

    // Fast approximation for small angles (|x| < 0.1)
    // 5-term polynomial (error < 1e-15 for |x| < 0.1)
    static inline constexpr double sin_fast(double x) {
        const double x2 = x * x;
        return x * (1.0 - x2 * (1.0/6.0 - x2 * (1.0/120.0 - x2 * (1.0/5040.0 - x2 * (1.0/362880.0)))));
    }

    // Medium precision approximation for [-π/8, π/8]
    // 7th degree minimax polynomial (error < 2e-16)
    static inline constexpr double sin_medium(double x) {
        const double x2 = x * x;
        return x * (0.9999999999999999914771 + 
               x2 * (-0.1666666666666636600137 + 
               x2 * (0.008333333333322118588093 + 
               x2 * (-0.0001984126983676112568858))));
    }

    // High precision approximation for [-π/4, π/4]
    // 9th degree minimax polynomial (error < 1e-16)
    static inline constexpr double sin_high(double x) {
        const double x2 = x * x;
        return x * (0.9999999999999999999847697 + 
               x2 * (-0.1666666666666666666470658 + 
               x2 * (0.0083333333333333333303105 + 
               x2 * (-0.0001984126984126984125397 + 
               x2 * (2.75573192239858883e-6)))));
    }

    // Optimized cosine approximation for [-π/8, π/8]
    static inline constexpr double cos_medium(double x) {
        const double x2 = x * x;
        return 1.0 + x2 * (-0.5 + x2 * (0.041666666666666664 + 
               x2 * (-0.001388888888888889)));
    }

    // High precision cosine approximation for [-π/4, π/4]
    static inline constexpr double cos_high(double x) {
        const double x2 = x * x;
        return 1.0 + x2 * (-0.5 + x2 * (0.0416666666666666666 + 
               x2 * (-0.0013888888888888887 + 
               x2 * (2.48015873015873e-5))));
    }
    
	static inline constexpr double sine_huge(double x) {
        // Fast range reduction using multiplication instead of division
        const double k = std::round(x * INV_HALF_PI);
        const double rem = x - k * HALF_PI;
        
        // Branchless quadrant selection using bitwise AND
        // This is faster than modulo or switch statements
        const int quadrant = static_cast<int>(k) & 3;
        
        // Use a single polynomial approximation for both sin and cos
        // This avoids branching and uses the same precision for all cases
        const double x2 = rem * rem;
        const double s = rem * (0.9999999999999999999847697 + 
                       x2 * (-0.1666666666666666666470658 + 
                       x2 * (0.0083333333333333333303105 + 
                       x2 * (-0.0001984126984126984125397 + 
                       x2 * (2.75573192239858883e-6)))));
        
        const double c = 1.0 + x2 * (-0.5 + x2 * (0.0416666666666666666 + 
                       x2 * (-0.0013888888888888887 + 
                       x2 * (2.48015873015873e-5))));
        
        // Branchless result selection using array lookup
        // The compiler will optimize this to very efficient code
        const double results[4] = {s, c, -s, -c};
        return results[quadrant];
    }

};

HWND hwnd;

// Occlusion-culling global declarations
LPDIRECT3DQUERY9 occlusionQuery = NULL;
std::vector<IDirect3DQuery9*> queryPool;
std::queue<IDirect3DQuery9*> availableQueries;
std::queue<std::pair<IDirect3DQuery9*, bool>> activeQueries; // Stores queries and their availability status

// global declarations for walking
float walkBobbingOffset = 0.0f;
bool isWalking = false;
auto lastFrameTime = std::chrono::high_resolution_clock::now();

// Defines
struct CUSTOMVERTEX {
    float X;
    float Y;
    float Z;
    DWORD COLOR;
};
#define CUSTOMFVF (D3DFVF_XYZ | D3DFVF_DIFFUSE)

// Triangle structure
struct Triangle {
    CUSTOMVERTEX vertices[3];
    float posX;
    float posZ;
};

struct Cube {
    CUSTOMVERTEX vertices[8]; // 8 vertices for a cube
    float posX;
    float posZ;
};

// Global declarations
LPDIRECT3D9 d3d;                                // the pointer to our Direct3D interface
LPDIRECT3DDEVICE9 d3ddev;                       // the pointer to the device class
LPDIRECT3DVERTEXBUFFER9 vertexbuffer = NULL;    // the pointer to the vertex buffer
LPDIRECT3DVERTEXBUFFER9 groundBuffer = NULL;     // the pointer to the ground vertex buffer
LPDIRECT3DVERTEXBUFFER9 octahedronBuffer = NULL;
LPDIRECT3DVERTEXBUFFER9 icosahedronBuffer = NULL;
LPDIRECT3DVERTEXBUFFER9 shadowBuffer = NULL;

// initialize occlusion queries
void initOcclusionQueries() {
    for (int i = 0; i < 100; ++i) { // Pool size - adjust based on expected number of objects
        IDirect3DQuery9* query = NULL;
        if (SUCCEEDED(d3ddev->CreateQuery(D3DQUERYTYPE_OCCLUSION, &query))) {
            queryPool.push_back(query);
            availableQueries.push(query);
        }
    }
}

// Camera parameters
float camAngleXZ = 720.0f; // Angle for X-Z rotation
float posX = 0.0f; // X-position
float posZ = 50.0f; // Z-position
float cameraSpeed = 1.5f; // Speed of camera movement

// Jumping parameters
float jumpHeight = 0.0f; // Current height of the jump
bool isJumping = false;  // Is the object currently jumping
bool wasJumpKeyPressed = false; // Track if space was pressed last frame
float jumpSpeed = 0.1f;  // Speed of the jump
float maxJumpHeight = 10.0f; // Maximum height of the jump

// Triangle storage
std::vector<Triangle> triangles;
std::vector<Cube> cubes;

// Rectangle structure
struct RectangleE {
    CUSTOMVERTEX vertices[4]; // 4 vertices for the rectangle
    float posX;
    float posZ;
};

// Rectangle storage
std::vector<RectangleE> rectangles;


// Pyramid structure
struct Pyramid {
    CUSTOMVERTEX vertices[7]; // 4 for the sides, 1 for the base center
    float posX;
    float posZ;
};

// Key states
bool keyStates[256] = { false };

// Triangle storage
std::vector<Pyramid> pyramids;

// Mutex for thread safety
std::mutex pyramidMutex;

// Hash function for std::pair<int, int>
struct PairHash {
    template <class T1, class T2>
    std::size_t operator() (const std::pair<T1, T2>& p) const {
        auto h1 = std::hash<T1>{}(p.first);
        auto h2 = std::hash<T2>{}(p.second);
        
        // A simple hash combine technique
        return h1 ^ (h2 << 1);
    }
};

//Spaital Paritioning
std::unordered_map<std::pair<int, int>, std::vector<Pyramid*>, PairHash> spatialGrid;

void updateSpatialGrid() {
    spatialGrid.clear();
    const float gridSize = 50.0f; // Adjust based on your needs
    
    for (auto& pyramid : pyramids) {
        int gridX = static_cast<int>(pyramid.posX / gridSize);
        int gridZ = static_cast<int>(pyramid.posZ / gridSize);
        spatialGrid[{gridX, gridZ}].push_back(&pyramid);
    }
}

bool checkCollision(float x, float z, float size) {
    const float gridSize = 50.0f;
    int gridX = static_cast<int>(x / gridSize);
    int gridZ = static_cast<int>(z / gridSize);
    
    // Check current cell and adjacent cells
    for (int dx = -1; dx <= 1; ++dx) {
        for (int dz = -1; dz <= 1; ++dz) {
            auto it = spatialGrid.find({gridX + dx, gridZ + dz});
            if (it != spatialGrid.end()) {
                for (auto pyramid : it->second) {
                    float dx = pyramid->posX - x;
                    float dz = pyramid->posZ - z;
                    if (dx*dx + dz*dz < 9.0f*size) {
                        return true;
                    }
                }
            }
        }
    }
    return false;
}


// This is the function that puts the 3D models into video RAM
inline const void init_graphics() {
	float S = 25000, H = -0.5f;
    CUSTOMVERTEX groundVertices[] = {
		{ -S, H, -S, D3DCOLOR_XRGB(0, 100, 0) },
        { -S, H,  S, D3DCOLOR_XRGB(0, 156, 0) },
        {  S, H, -S, D3DCOLOR_XRGB(0, 192, 0) },
        {  S, H,  S, D3DCOLOR_XRGB(0, 258, 0) }
    };

    d3ddev->CreateVertexBuffer(4 * sizeof(CUSTOMVERTEX), 0, CUSTOMFVF, D3DPOOL_MANAGED, &groundBuffer, NULL);
    
    VOID* pVoid;
    groundBuffer->Lock(0, 0, (void**)&pVoid, 0);
    memcpy(pVoid, groundVertices, sizeof(groundVertices));
    groundBuffer->Unlock();
}

inline const D3DXVECTOR3 getPyramidCenter(const Pyramid& pyramid) {
    return D3DXVECTOR3(pyramid.posX, 0.0f, pyramid.posZ);
}

inline const float getPyramidRadius(const Pyramid& pyramid) {
    // Approximate radius as distance from center to furthest vertex
    float maxDist = 0.0f;
    for (int i = 0; i < 5; ++i) {
        float dx = pyramid.vertices[i].X - pyramid.posX;
        float dz = pyramid.vertices[i].Z - pyramid.posZ;
        float dist = sqrt(dx*dx + dz*dz);
        if (dist > maxDist) maxDist = dist;
    }
    return maxDist;
}

inline const D3DXVECTOR3 getCubeCenter(const Cube& pyramid) {
    return D3DXVECTOR3(pyramid.posX, 0.0f, pyramid.posZ);
}

inline const float getCubeRadius(const Cube& pyramid) {
    // Approximate radius as distance from center to furthest vertex
    float maxDist = 0.0f;
    for (int i = 0; i < 5; ++i) {
        float dx = pyramid.vertices[i].X - pyramid.posX;
        float dz = pyramid.vertices[i].Z - pyramid.posZ;
        float dist = sqrt(dx*dx + dz*dz);
        if (dist > maxDist) maxDist = dist;
    }
    return maxDist;
}

// Function to check if a point is inside the frustum (simple sphere-based check)
inline const bool isSphereInFrustum(const D3DXVECTOR3& center, float radius, const D3DXMATRIX& viewProj) {
    // Extract frustum planes from view-projection matrix
    D3DXPLANE planes[6];

    // Left plane
    planes[0].a = viewProj._13 + viewProj._11;
    planes[0].b = viewProj._23 + viewProj._21;
    planes[0].c = viewProj._33 + viewProj._31;
    planes[0].d = viewProj._43 + viewProj._41;

    // Right plane
    planes[1].a = viewProj._13 - viewProj._11;
    planes[1].b = viewProj._23 - viewProj._21;
    planes[1].c = viewProj._33 - viewProj._31;
    planes[1].d = viewProj._43 - viewProj._41;

    // Top plane
    planes[2].a = viewProj._13 - viewProj._12;
    planes[2].b = viewProj._23 - viewProj._22;
    planes[2].c = viewProj._33 - viewProj._32;
    planes[2].d = viewProj._43 - viewProj._42;

    // Bottom plane
    planes[3].a = viewProj._13 + viewProj._12;
    planes[3].b = viewProj._23 + viewProj._22;
    planes[3].c = viewProj._33 + viewProj._32;
    planes[3].d = viewProj._43 + viewProj._42;

    // Near plane
    planes[4].a = viewProj._13 + viewProj._14;
    planes[4].b = viewProj._23 + viewProj._24;
    planes[4].c = viewProj._33 + viewProj._34;
    planes[4].d = viewProj._43 + viewProj._44;

    // Far plane
    planes[5].a = viewProj._13 - viewProj._14;
    planes[5].b = viewProj._23 - viewProj._24;
    planes[5].c = viewProj._33 - viewProj._34;
    planes[5].d = viewProj._43 - viewProj._44;

    // Normalize planes
    for (int i = 0; i < 6; ++i) {
        float length = sqrt(planes[i].a * planes[i].a + planes[i].b * planes[i].b + planes[i].c * planes[i].c);
        planes[i].a /= length;
        planes[i].b /= length;
        planes[i].c /= length;
        planes[i].d /= length;
    }

    // Check sphere against each plane
    for (int i = 0; i < 6; ++i) {
        float distance = planes[i].a * center.x + planes[i].b * center.y + planes[i].c * center.z + planes[i].d;
        if (distance < -radius) {
            return false; // Outside frustum
        }
    }
    return true; // Inside or intersecting frustum
}

// Helper function to get an available query
IDirect3DQuery9* getAvailableQuery() {
    // First check for completed queries
    while (!activeQueries.empty()) {
        auto& queryPair = activeQueries.front();
        if (queryPair.second) { // If available
            IDirect3DQuery9* query = queryPair.first;
            activeQueries.pop();
            activeQueries.push(std::make_pair(query, false));
            return query;
        }
        
        // Check if front query is done
        DWORD pixels = 0;
        if (queryPair.first->GetData(&pixels, sizeof(DWORD), D3DGETDATA_FLUSH) == S_OK) {
            queryPair.second = true; // Mark as available
            if (pixels > 0) {
                // Object was visible last frame
                IDirect3DQuery9* query = queryPair.first;
                activeQueries.pop();
                activeQueries.push(std::make_pair(query, false));
                return query;
            }
        }
        activeQueries.push(activeQueries.front());
        activeQueries.pop();
    }
    return nullptr; // No queries available
}

// Check occlusion
inline const bool isOccluded(const D3DXVECTOR3& center, float radius, const D3DXMATRIX& viewProj) {
    IDirect3DQuery9* query = getAvailableQuery();
    if (!query) return false; // No queries available, render anyway
    
    // Create a bounding box in world space
    D3DXVECTOR3 corners[8];
    float halfSize = radius;
    corners[0] = D3DXVECTOR3(center.x - halfSize, center.y - halfSize, center.z - halfSize);
    corners[1] = D3DXVECTOR3(center.x - halfSize, center.y - halfSize, center.z + halfSize);
    corners[2] = D3DXVECTOR3(center.x - halfSize, center.y + halfSize, center.z - halfSize);
    corners[3] = D3DXVECTOR3(center.x - halfSize, center.y + halfSize, center.z + halfSize);
    corners[4] = D3DXVECTOR3(center.x + halfSize, center.y - halfSize, center.z - halfSize);
    corners[5] = D3DXVECTOR3(center.x + halfSize, center.y - halfSize, center.z + halfSize);
    corners[6] = D3DXVECTOR3(center.x + halfSize, center.y + halfSize, center.z - halfSize);
    corners[7] = D3DXVECTOR3(center.x + halfSize, center.y + halfSize, center.z + halfSize);
    
    // Begin the query
    query->Issue(D3DISSUE_BEGIN);
    
    // Draw the bounding box (won't be visible)
    d3ddev->SetRenderState(D3DRS_COLORWRITEENABLE, 0); // Disable color writes
    d3ddev->SetRenderState(D3DRS_ZWRITEENABLE, FALSE); // Don't write to depth buffer
    
    // Draw each face of the bounding box
    static const int indices[] = {
        0,1,2, 1,3,2, // front
        4,6,5, 5,6,7, // back
        0,2,4, 4,2,6, // left
        1,5,3, 3,5,7, // right
        0,4,1, 1,4,5, // bottom
        2,3,6, 3,7,6  // top
    };
    
    CUSTOMVERTEX boxVertices[36];
    for (int i = 0; i < 36; i++) {
        boxVertices[i] = { corners[indices[i]].x, corners[indices[i]].y, corners[indices[i]].z, 0 };
    }
    
    d3ddev->DrawPrimitiveUP(D3DPT_TRIANGLELIST, 12, boxVertices, sizeof(CUSTOMVERTEX));
    
    // Restore render states
    d3ddev->SetRenderState(D3DRS_COLORWRITEENABLE, 0x0000000F);
    d3ddev->SetRenderState(D3DRS_ZWRITEENABLE, TRUE);
    
    // End the query
    query->Issue(D3DISSUE_END);
    
    // We'll check the result in the next frame
    return false;
}

// Generate shadow vertices for a cube
inline const void generateCubeShadow(const Cube& cube, CUSTOMVERTEX shadowVertices[4]) {
    float size = (cube.vertices[1].X - cube.vertices[0].X); // cube width
    float rectSize = size * 0.8f; // slightly larger shadow
    
    float x = cube.posX;
    float z = cube.posZ;
    
    // Use consistent alpha value (128) like other shadows
    shadowVertices[0] = { x - rectSize, 0.01f, z - rectSize, D3DCOLOR_ARGB(128, 0, 0, 0) };
    shadowVertices[1] = { x - rectSize, 0.01f, z + rectSize, D3DCOLOR_ARGB(128, 0, 0, 0) };
    shadowVertices[2] = { x + rectSize, 0.01f, z - rectSize, D3DCOLOR_ARGB(128, 0, 0, 0) };
    shadowVertices[3] = { x + rectSize, 0.01f, z + rectSize, D3DCOLOR_ARGB(128, 0, 0, 0) };
}

// Generate shadow vertices for a pyramid
inline const void generatePyramidShadow(const Pyramid& pyramid, CUSTOMVERTEX shadowVertices[4]) {
    const float size = (pyramid.vertices[0].X - pyramid.vertices[2].X) * 0.625f; // 1.25f/2.0f
    const float x = pyramid.posX;
    const float z = pyramid.posZ;
    const float height = pyramid.vertices[4].Y;
    const BYTE alpha = static_cast<BYTE>(128 + (72 * height / 10.0f)); // 72 = 200-128
    
    shadowVertices[0] = {x - size, 0.01f, z - size, D3DCOLOR_ARGB(alpha, 0, 0, 0)};
    shadowVertices[1] = {x - size, 0.01f, z + size, D3DCOLOR_ARGB(alpha, 0, 0, 0)};
    shadowVertices[2] = {x + size, 0.01f, z - size, D3DCOLOR_ARGB(alpha, 0, 0, 0)};
    shadowVertices[3] = {x + size, 0.01f, z + size, D3DCOLOR_ARGB(alpha, 0, 0, 0)};
}


// Octahedron structure with enhanced AI behavior
struct Octahedron {
    CUSTOMVERTEX vertices[6]; // 6 vertices for an octahedron (but we'll render 8 triangles)
    float posX;
    float posZ;
    float velX;
    float velZ;
    float size;
    
    // Enhanced AI behavior variables
    enum State { WANDERING, PAUSING, STARING_AT_SHAPE, STARING_AT_PLAYER, FLEEING };
    State currentState = WANDERING;
    float stateTimer = 0.0f;
    float targetX = 0.0f;
    float targetZ = 0.0f;
    float headAngleX = 0.0f; // Head tilt for looking at targets
    float headAngleZ = 0.0f;
    float interestLevel = 0.0f; // How interested it is in current target
    float awareness = 0.0f; // Awareness of player presence
    float speedMultiplier = 1.0f; // For varying movement speeds
};

std::vector<Octahedron> octahedrons;

// Update the Icosahedron structure to match Octahedron's AI states
struct Icosahedron {
    CUSTOMVERTEX vertices[12]; // 12 vertices for an icosahedron
    float posX;
    float posZ;
    float velX;
    float velZ;
    float size;
    
    // Match Octahedron's AI behavior variables
    enum State { WANDERING, PAUSING, STARING_AT_SHAPE, STARING_AT_PLAYER, FLEEING };
    State currentState = WANDERING;
    float stateTimer = 0.0f;
    float targetX = 0.0f;
    float targetZ = 0.0f;
    float headAngleX = 0.0f; // Head tilt for looking at targets
    float headAngleZ = 0.0f;
    float interestLevel = 0.0f; // How interested it is in current target
    float awareness = 0.0f; // Awareness of player presence
    float speedMultiplier = 1.0f; // For varying movement speeds
    
    // Color cycling (keep this unique to icosahedron)
    float hueOffset;
    float hueSpeed;
    float rotationAngle;
    float rotationSpeed;
};

std::vector<Icosahedron> icosahedrons;

// Add these cleanup functions
inline const void cleanupBatchBuffers() {
    if (octahedronBuffer) {
        octahedronBuffer->Release();
        octahedronBuffer = NULL;
    }
    if (icosahedronBuffer) {
        icosahedronBuffer->Release();
        icosahedronBuffer = NULL;
    }
    if (shadowBuffer) {
        shadowBuffer->Release();
        shadowBuffer = NULL;
    }
}

inline const void resizeBatchBuffers() {
    cleanupBatchBuffers();
    
    // Calculate required buffer sizes with some headroom
    size_t octahedronVerts = octahedrons.size() * 24 * 1.2f; // 20% headroom
    size_t icosahedronVerts = icosahedrons.size() * 60 * 1.2f;
    size_t shadowVerts = (pyramids.size() + cubes.size() + octahedrons.size() + icosahedrons.size()) * 4 * 1.2f;
    
    // Create with minimum sizes to prevent zero-size buffers
    octahedronVerts = fmax(octahedronVerts, 24);
    icosahedronVerts = fmax(icosahedronVerts, 60);
    shadowVerts = fmax(shadowVerts, 4);
    
    d3ddev->CreateVertexBuffer(octahedronVerts * sizeof(CUSTOMVERTEX), 
                             D3DUSAGE_WRITEONLY | D3DUSAGE_DYNAMIC, 
                             CUSTOMFVF, 
                             D3DPOOL_DEFAULT, 
                             &octahedronBuffer, 
                             NULL);
    
    d3ddev->CreateVertexBuffer(icosahedronVerts * sizeof(CUSTOMVERTEX), 
                             D3DUSAGE_WRITEONLY | D3DUSAGE_DYNAMIC, 
                             CUSTOMFVF, 
                             D3DPOOL_DEFAULT, 
                             &icosahedronBuffer, 
                             NULL);
    
    d3ddev->CreateVertexBuffer(shadowVerts * sizeof(CUSTOMVERTEX), 
                             D3DUSAGE_WRITEONLY | D3DUSAGE_DYNAMIC, 
                             CUSTOMFVF, 
                             D3DPOOL_DEFAULT, 
                             &shadowBuffer, 
                             NULL);
}

//-----------------Octahedron Strcuture (Start)------------------


// Function to find the closest shape to an octahedron
inline const void findClosestShape(const Octahedron& octahedron, float& closestDist, float& targetX, float& targetZ) {
    closestDist = FLT_MAX;
    targetX = octahedron.posX;
    targetZ = octahedron.posZ;
    
    // Check pyramids
    for (const auto& pyramid : pyramids) {
        float dx = pyramid.posX - octahedron.posX;
        float dz = pyramid.posZ - octahedron.posZ;
        float dist = dx*dx + dz*dz;
        if (dist < closestDist && dist < 400.0f) { // Only consider shapes within 20 units
            closestDist = dist;
            targetX = pyramid.posX;
            targetZ = pyramid.posZ;
        }
    }
    
    // Check cubes
    for (const auto& cube : cubes) {
        float dx = cube.posX - octahedron.posX;
        float dz = cube.posZ - octahedron.posZ;
        float dist = dx*dx + dz*dz;
        if (dist < closestDist && dist < 400.0f) { // Only consider shapes within 20 units
            closestDist = dist;
            targetX = cube.posX;
            targetZ = cube.posZ;
        }
    }
    
    closestDist = sqrt(closestDist);
}

// Function to calculate distance to player
inline const float distanceToPlayer(const Octahedron& octahedron) {
    float dx = octahedron.posX - posX;
    float dz = octahedron.posZ - posZ;
    return sqrt(dx*dx + dz*dz);
}

// Enhanced AI update functions for both octahedrons and icosahedrons
inline const void updateOctahedrons(float deltaTime) {
    const float maxDistSq = 10000.0f; // 100 units squared
    const float fleeDistSq = 900.0f;  // 30 units squared
    const float stareDistSq = 2500.0f; // 50 units squared
    
    for (auto& octahedron : octahedrons) {
        // Calculate distance to player once per frame
        const float dx = octahedron.posX - posX;
        const float dz = octahedron.posZ - posZ;
        const float playerDistSq = dx*dx + dz*dz;
        const float playerDist = sqrt(playerDistSq);
        
        // Update awareness based on player distance
        octahedron.awareness = std::clamp(octahedron.awareness + 
            (playerDistSq < maxDistSq ? deltaTime * 0.5f : -deltaTime * 0.1f), 0.0f, 1.0f);
        
        octahedron.stateTimer -= deltaTime;
        
        // Target head angles for smooth interpolation
        float targetHeadAngleX = octahedron.headAngleX;
        float targetHeadAngleZ = octahedron.headAngleZ;
        
        // State transitions
        switch (octahedron.currentState) {
            case Octahedron::WANDERING: {
                if (octahedron.stateTimer <= 0.0f || (rand() & 0x3F) == 0) { // ~1.5% chance per frame
                    if ((rand() & 0x7) == 0) { // 12.5% chance to pause
                        octahedron.currentState = Octahedron::PAUSING;
                        octahedron.stateTimer = 1.0f + (rand() % 300) * 0.01f;
                        octahedron.velX = octahedron.velZ = 0.0f;
                    } else {
                        // New wandering direction
                        const float angle = (rand() % 628) * 0.01f;
                        const float speed = 0.5f + (rand() % 100) * 0.005f;
                        octahedron.velX = SohlTrgnmntry::Cos(angle) * speed;
                        octahedron.velZ = SohlTrgnmntry::Sin(angle) * speed;
                        octahedron.speedMultiplier = 0.5f + (rand() % 100) * 0.005f;
                        octahedron.stateTimer = 3.0f + (rand() % 200) * 0.1f;
                    }
                }
                
                // Look in movement direction
                if (octahedron.velX != 0.0f || octahedron.velZ != 0.0f) {
                    targetHeadAngleX = atan2(octahedron.velX, octahedron.velZ);
                }
                
                // Check for player proximity
                if (playerDistSq < stareDistSq && octahedron.awareness > 0.3f) {
                    if ((rand() & 0x3) == 0) { // 25% chance to stare
                        octahedron.currentState = Octahedron::STARING_AT_PLAYER;
                        octahedron.stateTimer = 2.0f + (rand() % 200) * 0.1f;
                        octahedron.velX = octahedron.velZ = 0.0f;
                    } else if ((rand() & 0x7) == 0) { // 12.5% chance to flee
                        octahedron.currentState = Octahedron::FLEEING;
                        octahedron.stateTimer = 5.0f + (rand() % 300) * 0.1f;
                        const float invDist = 1.0f / playerDist;
                        octahedron.velX = dx * invDist * 2.0f;
                        octahedron.velZ = dz * invDist * 2.0f;
                    }
                }
                break;
            }
            
            case Octahedron::PAUSING: {
                if (octahedron.stateTimer <= 0.0f) {
                    octahedron.currentState = Octahedron::WANDERING;
                    octahedron.stateTimer = 3.0f + (rand() % 200) * 0.1f;
                } else if ((rand() & 0x1F) == 0) { // ~3% chance to look around
                    targetHeadAngleX = (rand() % 628) * 0.01f;
                    targetHeadAngleZ = (rand() % 157) * 0.01f - 0.785f;
                }
                break;
            }
            
            case Octahedron::STARING_AT_PLAYER: {
                targetHeadAngleX = atan2(dx, dz);
                targetHeadAngleZ = 0.2f * SohlTrgnmntry::Sin(octahedron.stateTimer * 5.0f);
                
                if (octahedron.stateTimer <= 0.0f || playerDistSq > 4900.0f) { // 70 units
                    octahedron.currentState = Octahedron::WANDERING;
                    octahedron.stateTimer = 3.0f + (rand() % 200) * 0.1f;
                }
                
                if (playerDistSq < 900.0f && (rand() & 0x1F) == 0) { // 30 units, ~3% chance
                    octahedron.currentState = Octahedron::FLEEING;
                    octahedron.stateTimer = 5.0f + (rand() % 300) * 0.1f;
                    const float invDist = 1.0f / playerDist;
                    octahedron.velX = dx * invDist * 2.5f;
                    octahedron.velZ = dz * invDist * 2.5f;
                }
                break;
            }
            
            case Octahedron::FLEEING: {
                if (octahedron.stateTimer <= 0.0f || playerDistSq > maxDistSq) {
                    octahedron.currentState = Octahedron::WANDERING;
                    octahedron.stateTimer = 3.0f + (rand() % 200) * 0.1f;
                }
                targetHeadAngleX = atan2(octahedron.velX, octahedron.velZ);
                targetHeadAngleZ = -0.3f;
                break;
            }
        }
        
        // Smooth head movement
        const float rotSpeed = 5.0f * deltaTime;
        octahedron.headAngleX += (targetHeadAngleX - octahedron.headAngleX) * rotSpeed;
        octahedron.headAngleZ += (targetHeadAngleZ - octahedron.headAngleZ) * rotSpeed;
        
        // Movement for wandering and fleeing states
        if (octahedron.currentState == Octahedron::WANDERING || 
            octahedron.currentState == Octahedron::FLEEING) {
            octahedron.posX += octahedron.velX * octahedron.speedMultiplier * deltaTime * 60.0f;
            octahedron.posZ += octahedron.velZ * octahedron.speedMultiplier * deltaTime * 60.0f;
            
            // Boundary checks with bounce
            if (octahedron.posX < -24000.0f || octahedron.posX > 24000.0f) {
                octahedron.velX *= -0.8f;
                octahedron.posX = std::clamp(octahedron.posX, -24000.0f, 24000.0f);
            }
            if (octahedron.posZ < -24000.0f || octahedron.posZ > 24000.0f) {
                octahedron.velZ *= -0.8f;
                octahedron.posZ = std::clamp(octahedron.posZ, -24000.0f, 24000.0f);
            }
        }
    }
}

inline const void generateOctahedronShadow(const Octahedron& octahedron, CUSTOMVERTEX shadowVertices[4]) {
    float rectSize = octahedron.size * 0.4f; 
    float x = octahedron.posX; 
    float z = octahedron.posZ;
    shadowVertices[0] = { x - rectSize, 0.01f, z - rectSize, D3DCOLOR_ARGB(128, 0, 0, 0) };
    shadowVertices[1] = { x - rectSize, 0.01f, z + rectSize, D3DCOLOR_ARGB(128, 0, 0, 0) };
    shadowVertices[2] = { x + rectSize, 0.01f, z - rectSize, D3DCOLOR_ARGB(128, 0, 0, 0) };
    shadowVertices[3] = { x + rectSize, 0.01f, z + rectSize, D3DCOLOR_ARGB(128, 0, 0, 0) };
}



//-----------------Octahedron Strcuture (End)--------------------
//-----------------Icosahedron Strcuture (Start)-----------------

// Function to find the closest shape to an icosahedron (same as octahedron)
inline const void findClosestShape(const Icosahedron& icosahedron, float& closestDist, float& targetX, float& targetZ) {
    closestDist = FLT_MAX;
    targetX = icosahedron.posX;
    targetZ = icosahedron.posZ;
    
    // Check pyramids
    for (const auto& pyramid : pyramids) {
        float dx = pyramid.posX - icosahedron.posX;
        float dz = pyramid.posZ - icosahedron.posZ;
        float dist = dx*dx + dz*dz;
        if (dist < closestDist && dist < 400.0f) { // Only consider shapes within 20 units
            closestDist = dist;
            targetX = pyramid.posX;
            targetZ = pyramid.posZ;
        }
    }
    
    // Check cubes
    for (const auto& cube : cubes) {
        float dx = cube.posX - icosahedron.posX;
        float dz = cube.posZ - icosahedron.posZ;
        float dist = dx*dx + dz*dz;
        if (dist < closestDist && dist < 400.0f) { // Only consider shapes within 20 units
            closestDist = dist;
            targetX = cube.posX;
            targetZ = cube.posZ;
        }
    }
    
    closestDist = sqrt(closestDist);
}

// Calculate distance to player (same as octahedron)
inline const void updateIcosahedrons(float deltaTime) {
    const float maxDistSq = 10000.0f; // 100 units squared
    const float fleeDistSq = 900.0f;  // 30 units squared
    const float stareDistSq = 2500.0f; // 50 units squared
    
    for (auto& icosahedron : icosahedrons) {
        // Update rotation and color (unique to icosahedron)
        icosahedron.rotationAngle = fmod(icosahedron.rotationAngle + icosahedron.rotationSpeed * deltaTime * 60.0f, 360.0f);
        icosahedron.hueOffset = fmod(icosahedron.hueOffset + icosahedron.hueSpeed * deltaTime * 60.0f, 3600.0f);
        
        // Calculate distance to player once per frame
        const float dx = icosahedron.posX - posX;
        const float dz = icosahedron.posZ - posZ;
        const float playerDistSq = dx*dx + dz*dz;
        const float playerDist = sqrt(playerDistSq);
        
        // Update awareness based on player distance
        icosahedron.awareness = std::clamp(icosahedron.awareness + 
            (playerDistSq < maxDistSq ? deltaTime * 0.5f : -deltaTime * 00.1f), 0.0f, 1.0f);
        
        icosahedron.stateTimer -= deltaTime;
        
        // Target head angles for smooth interpolation
        float targetHeadAngleX = icosahedron.headAngleX;
        float targetHeadAngleZ = icosahedron.headAngleZ;
        
        // State transitions (same logic as octahedron)
        switch (icosahedron.currentState) {
            case Icosahedron::WANDERING: {
                if (icosahedron.stateTimer <= 0.0f || (rand() & 0x3F) == 0) {
                    if ((rand() & 0x7) == 0) {
                        icosahedron.currentState = Icosahedron::PAUSING;
                        icosahedron.stateTimer = 1.0f + (rand() % 300) * 0.01f;
                        icosahedron.velX = icosahedron.velZ = 0.0f;
                    } else {
                        const float angle = (rand() % 628) * 0.01f;
                        const float speed = 0.5f + (rand() % 100) * 0.005f;
                        icosahedron.velX = SohlTrgnmntry::Cos(angle) * speed;
                        icosahedron.velZ = SohlTrgnmntry::Sin(angle) * speed;
                        icosahedron.speedMultiplier = 0.5f + (rand() % 100) * 0.005f;
                        icosahedron.stateTimer = 3.0f + (rand() % 200) * 0.1f;
                    }
                }
                
                if (icosahedron.velX != 0.0f || icosahedron.velZ != 0.0f) {
                    targetHeadAngleX = atan2(icosahedron.velX, icosahedron.velZ);
                }
                
                if (playerDistSq < stareDistSq && icosahedron.awareness > 0.3f) {
                    if ((rand() & 0x3) == 0) {
                        icosahedron.currentState = Icosahedron::STARING_AT_PLAYER;
                        icosahedron.stateTimer = 2.0f + (rand() % 200) * 0.1f;
                        icosahedron.velX = icosahedron.velZ = 0.0f;
                    } else if ((rand() & 0x7) == 0) {
                        icosahedron.currentState = Icosahedron::FLEEING;
                        icosahedron.stateTimer = 5.0f + (rand() % 300) * 0.1f;
                        const float invDist = 1.0f / playerDist;
                        icosahedron.velX = dx * invDist * 2.0f;
                        icosahedron.velZ = dz * invDist * 2.0f;
                    }
                }
                break;
            }
            
            case Icosahedron::PAUSING: {
                if (icosahedron.stateTimer <= 0.0f) {
                    icosahedron.currentState = Icosahedron::WANDERING;
                    icosahedron.stateTimer = 3.0f + (rand() % 200) * 0.1f;
                } else if ((rand() & 0x1F) == 0) {
                    targetHeadAngleX = (rand() % 628) * 0.01f;
                    targetHeadAngleZ = (rand() % 157) * 0.01f - 0.785f;
                }
                break;
            }
            
            case Icosahedron::STARING_AT_PLAYER: {
                targetHeadAngleX = atan2(dx, dz);
                targetHeadAngleZ = 0.2f * SohlTrgnmntry::Sin(icosahedron.stateTimer * 5.0f);
                
                if (icosahedron.stateTimer <= 0.0f || playerDistSq > 4900.0f) {
                    icosahedron.currentState = Icosahedron::WANDERING;
                    icosahedron.stateTimer = 3.0f + (rand() % 200) * 0.1f;
                }
                
                if (playerDistSq < 900.0f && (rand() & 0x1F) == 0) {
                    icosahedron.currentState = Icosahedron::FLEEING;
                    icosahedron.stateTimer = 5.0f + (rand() % 300) * 0.1f;
                    const float invDist = 1.0f / playerDist;
                    icosahedron.velX = dx * invDist * 2.5f;
                    icosahedron.velZ = dz * invDist * 2.5f;
                }
                break;
            }
            
            case Icosahedron::FLEEING: {
                if (icosahedron.stateTimer <= 0.0f || playerDistSq > maxDistSq) {
                    icosahedron.currentState = Icosahedron::WANDERING;
                    icosahedron.stateTimer = 3.0f + (rand() % 200) * 0.1f;
                }
                targetHeadAngleX = atan2(icosahedron.velX, icosahedron.velZ);
                targetHeadAngleZ = -0.3f;
                break;
            }
        }
        
        // Smooth head movement
        const float rotSpeed = 5.0f * deltaTime;
        icosahedron.headAngleX += (targetHeadAngleX - icosahedron.headAngleX) * rotSpeed;
        icosahedron.headAngleZ += (targetHeadAngleZ - icosahedron.headAngleZ) * rotSpeed;
        
        // Movement for wandering and fleeing states
        if (icosahedron.currentState == Icosahedron::WANDERING || 
            icosahedron.currentState == Icosahedron::FLEEING) {
            icosahedron.posX += icosahedron.velX * icosahedron.speedMultiplier * deltaTime * 60.0f;
            icosahedron.posZ += icosahedron.velZ * icosahedron.speedMultiplier * deltaTime * 60.0f;
            
            // Boundary checks with bounce
            if (icosahedron.posX < -20000.0f || icosahedron.posX > 20000.0f) {
                icosahedron.velX *= -0.8f;
                icosahedron.posX = std::clamp(icosahedron.posX, -20000.0f, 20000.0f);
            }
            if (icosahedron.posZ < -20000.0f || icosahedron.posZ > 20000.0f) {
                icosahedron.velZ *= -0.8f;
                icosahedron.posZ = std::clamp(icosahedron.posZ, -20000.0f, 20000.0f);
            }
        }
    }
}

void generateIcosahedronShadow(const Icosahedron& icosahedron, CUSTOMVERTEX shadowVertices[4]) {
    float rectSize = icosahedron.size * 0.6f;
    float x = icosahedron.posX;
    float z = icosahedron.posZ;
    shadowVertices[0] = { x - rectSize, 0.01f, z - rectSize, D3DCOLOR_ARGB(128, 0, 0, 0) };
    shadowVertices[1] = { x - rectSize, 0.01f, z + rectSize, D3DCOLOR_ARGB(128, 0, 0, 0) };
    shadowVertices[2] = { x + rectSize, 0.01f, z - rectSize, D3DCOLOR_ARGB(128, 0, 0, 0) };
    shadowVertices[3] = { x + rectSize, 0.01f, z + rectSize, D3DCOLOR_ARGB(128, 0, 0, 0) };
}


//-----------------Icosahedron Strcuture (End)-------------------

struct RenderBatch {
    std::vector<CUSTOMVERTEX> pyramidVertices;
    std::vector<CUSTOMVERTEX> cubeVertices;
    std::vector<CUSTOMVERTEX> shadowVertices;
    
    void clear() {
        pyramidVertices.clear();
        cubeVertices.clear();
        shadowVertices.clear();
    }
};

RenderBatch currentBatch;
std::mutex batchMutex;
bool batchReady = false;

// Modify the prepare_render_batch function
void prepare_render_batch() {
    std::lock_guard<std::mutex> lock(batchMutex);
    
    // Clear the current batch
    currentBatch.clear();
    
    // Process pyramids
    for (const auto& pyramid : pyramids) {
        // Base (two triangles)
        currentBatch.pyramidVertices.push_back(pyramid.vertices[0]);
        currentBatch.pyramidVertices.push_back(pyramid.vertices[1]);
        currentBatch.pyramidVertices.push_back(pyramid.vertices[2]);
        
        currentBatch.pyramidVertices.push_back(pyramid.vertices[0]);
        currentBatch.pyramidVertices.push_back(pyramid.vertices[2]);
        currentBatch.pyramidVertices.push_back(pyramid.vertices[3]);
        
        // Sides (four triangles)
        for (int i = 0; i < 4; ++i) {
            currentBatch.pyramidVertices.push_back(pyramid.vertices[i]);
            currentBatch.pyramidVertices.push_back(pyramid.vertices[(i + 1) % 4]);
            currentBatch.pyramidVertices.push_back(pyramid.vertices[4]);
        }
        
        // Shadow
        CUSTOMVERTEX shadowVerts[4];
        generatePyramidShadow(pyramid, shadowVerts);
        for (int i = 0; i < 4; i++) {
            currentBatch.shadowVertices.push_back(shadowVerts[i]);
        }
    }
    
    // Process cubes
    static const int cubeIndices[] = {
        0,1,2, 0,2,3, // bottom
        4,5,6, 4,6,7, // top
        0,1,5, 0,5,4, // front
        1,2,6, 1,6,5, // right
        2,3,7, 2,7,6, // back
        3,0,4, 3,4,7  // left
    };
    
    for (const auto& cube : cubes) {
        for (int i = 0; i < 36; ++i) {
            currentBatch.cubeVertices.push_back(cube.vertices[cubeIndices[i]]);
        }
        
        // Shadow
        CUSTOMVERTEX shadowVerts[4];
        generateCubeShadow(cube, shadowVerts);
        for (int i = 0; i < 4; i++) {
            currentBatch.shadowVertices.push_back(shadowVerts[i]);
        }
    }
    
    // Process octahedrons
    static const int octahedronIndices[] = {
        // Top 4 faces
        0,1,2, 0,2,3, 0,3,4, 0,4,1,
        // Bottom 4 faces
        5,1,2, 5,2,3, 5,3,4, 5,4,1
    };
    
    for (const auto& octahedron : octahedrons) {
        // Transform vertices with position and rotation
        D3DXMATRIX matRotateX, matRotateY, matTranslate, matWorld;
        D3DXMatrixRotationX(&matRotateX, octahedron.headAngleZ);
        D3DXMatrixRotationY(&matRotateY, octahedron.headAngleX);
        D3DXMatrixMultiply(&matWorld, &matRotateX, &matRotateY);
        D3DXMatrixTranslation(&matTranslate, octahedron.posX, 0, octahedron.posZ);
        D3DXMatrixMultiply(&matWorld, &matWorld, &matTranslate);

        // Add transformed vertices to batch
        for (int i = 0; i < 24; i++) {
            CUSTOMVERTEX v = octahedron.vertices[octahedronIndices[i]];
            D3DXVECTOR3 pos(v.X, v.Y, v.Z);
            D3DXVec3TransformCoord(&pos, &pos, &matWorld);
            currentBatch.pyramidVertices.push_back({pos.x, pos.y, pos.z, v.COLOR});
        }
        
        // Shadow
        CUSTOMVERTEX shadowVerts[4];
        generateOctahedronShadow(octahedron, shadowVerts);
        for (int i = 0; i < 4; i++) {
            currentBatch.shadowVertices.push_back(shadowVerts[i]);
        }
    }
    
    // Process icosahedrons
    static const int icosahedronIndices[] = {
        // 5 faces around vertex 0
        0, 11, 5,   0, 5, 1,   0, 1, 7,   0, 7, 10,  0, 10, 11,
        // 5 adjacent faces
        1, 5, 9,   5, 11, 4,  11, 10, 2,  10, 7, 6,  7, 1, 8,
        // 5 faces around vertex 3
        3, 9, 4,   3, 4, 2,   3, 2, 6,   3, 6, 8,   3, 8, 9,
        // 5 adjacent faces
        4, 9, 5,   2, 4, 11,  6, 2, 10,  8, 6, 7,   9, 8, 1
    };
    
    for (const auto& icosahedron : icosahedrons) {
        // Transform vertices with position and rotation
        D3DXMATRIX matRotateX, matRotateY, matTranslate, matWorld;
        D3DXMatrixRotationX(&matRotateX, icosahedron.headAngleZ);
        D3DXMatrixRotationY(&matRotateY, icosahedron.headAngleX);
        D3DXMatrixMultiply(&matWorld, &matRotateX, &matRotateY);
        D3DXMatrixTranslation(&matTranslate, icosahedron.posX, 0, icosahedron.posZ);
        D3DXMatrixMultiply(&matWorld, &matWorld, &matTranslate);

        // Add vertices to batch with hue coloring
        for (int i = 0; i < 60; i++) {
            CUSTOMVERTEX vertex = icosahedron.vertices[icosahedronIndices[i]];
            float hue = fmod(icosahedron.hueOffset, 3600.0f);
            HSV hsv = { hue, 1.0f-(i/120.0f), 1.0f };
            RGBQUAD rgb = hsv2rgb(hsv);
            
            // Transform vertex position
            D3DXVECTOR3 pos(vertex.X, vertex.Y, vertex.Z);
            D3DXVec3TransformCoord(&pos, &pos, &matWorld);
            
            currentBatch.pyramidVertices.push_back({
                pos.x, pos.y, pos.z,
                D3DCOLOR_XRGB(rgb.rgbRed, rgb.rgbGreen, rgb.rgbBlue)
            });
        }
        
        // Shadow
        CUSTOMVERTEX shadowVerts[4];
        generateIcosahedronShadow(icosahedron, shadowVerts);
        for (int i = 0; i < 4; i++) {
            currentBatch.shadowVertices.push_back(shadowVerts[i]);
        }
    }
    
    batchReady = true;
}


void initBatchBuffers() {
    // Create vertex buffers buffers for batch rendering
    d3ddev->CreateVertexBuffer(octahedrons.size() * 24 * sizeof(CUSTOMVERTEX), 
                              D3DUSAGE_WRITEONLY | D3DUSAGE_DYNAMIC, 
                              CUSTOMFVF, 
                              D3DPOOL_DEFAULT, 
                              &octahedronBuffer, 
                              NULL);
    
    d3ddev->CreateVertexBuffer(icosahedrons.size() * 60 * sizeof(CUSTOMVERTEX), 
                              D3DUSAGE_WRITEONLY | D3DUSAGE_DYNAMIC, 
                              CUSTOMFVF, 
                              D3DPOOL_DEFAULT, 
                              &icosahedronBuffer, 
                              NULL);
    
    // Calculate total shadows needed (4 vertices per object)
    size_t totalShadows = (pyramids.size() + cubes.size() + octahedrons.size() + icosahedrons.size()) * 4;
    if (totalShadows == 0) totalShadows = 4; // Minimum size
    
    d3ddev->CreateVertexBuffer(totalShadows * sizeof(CUSTOMVERTEX), 
                              D3DUSAGE_WRITEONLY | D3DUSAGE_DYNAMIC, 
                              CUSTOMFVF, 
                              D3DPOOL_DEFAULT, 
                              &shadowBuffer, 
                              NULL);
}

void renderPyramidsBatch() {
    if (pyramids.empty()) return;

    // Calculate total vertices needed (18 per pyramid: 6 triangles * 3 vertices)
    const size_t totalVertices = pyramids.size() * 18;
    std::vector<CUSTOMVERTEX> vertices(totalVertices);
    
    size_t vertexIndex = 0;
    for (const auto& pyramid : pyramids) {
        // Transform vertices to world space
        D3DXMATRIX matTranslate;
        D3DXMatrixTranslation(&matTranslate, pyramid.posX, 0, pyramid.posZ);

        // Base (two triangles)
        for (int i = 0; i < 3; i++) {
            D3DXVECTOR3 pos(pyramid.vertices[i].X, pyramid.vertices[i].Y, pyramid.vertices[i].Z);
            D3DXVec3TransformCoord(&pos, &pos, &matTranslate);
            vertices[vertexIndex++] = {pos.x, pos.y, pos.z, pyramid.vertices[i].COLOR};
        }
        
        for (int i = 0; i < 3; i++) {
            int idx = (i == 0) ? 0 : 3 - (i == 1);
            D3DXVECTOR3 pos(pyramid.vertices[idx].X, pyramid.vertices[idx].Y, pyramid.vertices[idx].Z);
            D3DXVec3TransformCoord(&pos, &pos, &matTranslate);
            vertices[vertexIndex++] = {pos.x, pos.y, pos.z, pyramid.vertices[idx].COLOR};
        }

        // Sides (four triangles)
        for (int i = 0; i < 4; ++i) {
            // Vertex 1 (base)
            D3DXVECTOR3 pos1(pyramid.vertices[i].X, pyramid.vertices[i].Y, pyramid.vertices[i].Z);
            D3DXVec3TransformCoord(&pos1, &pos1, &matTranslate);
            vertices[vertexIndex++] = {pos1.x, pos1.y, pos1.z, pyramid.vertices[i].COLOR};
            
            // Vertex 2 (next base)
            int nextIdx = (i + 1) % 4;
            D3DXVECTOR3 pos2(pyramid.vertices[nextIdx].X, pyramid.vertices[nextIdx].Y, pyramid.vertices[nextIdx].Z);
            D3DXVec3TransformCoord(&pos2, &pos2, &matTranslate);
            vertices[vertexIndex++] = {pos2.x, pos2.y, pos2.z, pyramid.vertices[nextIdx].COLOR};
            
            // Vertex 3 (apex)
            D3DXVECTOR3 pos3(pyramid.vertices[4].X, pyramid.vertices[4].Y, pyramid.vertices[4].Z);
            D3DXVec3TransformCoord(&pos3, &pos3, &matTranslate);
            vertices[vertexIndex++] = {pos3.x, pos3.y, pos3.z, pyramid.vertices[4].COLOR};
        }
    }

    // Set identity world transform since vertices are already transformed
    D3DXMATRIX matIdentity;
    D3DXMatrixIdentity(&matIdentity);
    d3ddev->SetTransform(D3DTS_WORLD, &matIdentity);

    // Draw all pyramids in one call (6 triangles per pyramid)
    d3ddev->DrawPrimitiveUP(D3DPT_TRIANGLELIST, pyramids.size() * 6, vertices.data(), sizeof(CUSTOMVERTEX));
}

void renderCubesBatch() {
    if (cubes.empty()) return;

    // Calculate total vertices needed (36 per cube: 12 triangles * 3 vertices)
    const size_t totalVertices = cubes.size() * 36;
    std::vector<CUSTOMVERTEX> vertices(totalVertices);
    
    size_t vertexIndex = 0;
    static constexpr int cubeIndices[] = {
        0,1,2,0,2,3, // Bottom face
        4,5,6,4,6,7, // Top face
        0,1,5,0,5,4, // Front face
        2,3,7,2,7,6, // Back face
        3,0,4,3,4,7, // Left face
        1,2,6,1,6,5  // Right face
    };

    for (const auto& cube : cubes) {
        // Transform vertices to world space
        D3DXMATRIX matTranslate;
        D3DXMatrixTranslation(&matTranslate, cube.posX, 0, cube.posZ);

        for (int i = 0; i < 36; ++i) {
            CUSTOMVERTEX v = cube.vertices[cubeIndices[i]];
            D3DXVECTOR3 pos(v.X, v.Y, v.Z);
            D3DXVec3TransformCoord(&pos, &pos, &matTranslate);
            vertices[vertexIndex++] = {pos.x, pos.y, pos.z, v.COLOR};
        }
    }

    // Set identity world transform since vertices are already transformed
    D3DXMATRIX matIdentity;
    D3DXMatrixIdentity(&matIdentity);
    d3ddev->SetTransform(D3DTS_WORLD, &matIdentity);

    // Draw all cubes in one call (12 triangles per cube)
    d3ddev->DrawPrimitiveUP(D3DPT_TRIANGLELIST, cubes.size() * 12, vertices.data(), sizeof(CUSTOMVERTEX));
}


void renderOctahedronsBatch() {
    if (octahedrons.empty()) return;

    // Lock the buffer and fill with octahedron data
    CUSTOMVERTEX* pVertices;
    octahedronBuffer->Lock(0, 0, (void**)&pVertices, D3DLOCK_DISCARD);

    int vertexCount = 0;
    static const int octahedronIndices[] = {
        0,1,2, 0,2,3, 0,3,4, 0,4,1, // Top faces
        5,1,2, 5,2,3, 5,3,4, 5,4,1 // Bottom faces
    };

    for (const auto& octahedron : octahedrons) {
        // Transform vertices with position and rotation
        D3DXMATRIX matRotateX, matRotateY, matTranslate, matWorld;
        D3DXMatrixRotationX(&matRotateX, octahedron.headAngleZ);
        D3DXMatrixRotationY(&matRotateY, octahedron.headAngleX);
        D3DXMatrixMultiply(&matWorld, &matRotateX, &matRotateY);
        D3DXMatrixTranslation(&matTranslate, octahedron.posX, 0, octahedron.posZ);
        D3DXMatrixMultiply(&matWorld, &matWorld, &matTranslate);

        // Transform each vertex
        for (int i = 0; i < 24; i++) {
            CUSTOMVERTEX v = octahedron.vertices[octahedronIndices[i]];
            D3DXVECTOR3 pos(v.X, v.Y, v.Z);
            D3DXVec3TransformCoord(&pos, &pos, &matWorld);
            pVertices[vertexCount++] = { pos.x, pos.y, pos.z, v.COLOR };
        }
    }

    octahedronBuffer->Unlock();

    // Set identity world transform since vertices are already transformed
    D3DXMATRIX matIdentity;
    D3DXMatrixIdentity(&matIdentity);
    d3ddev->SetTransform(D3DTS_WORLD, &matIdentity);

    // Draw all octahedrons in one call
    d3ddev->SetStreamSource(0, octahedronBuffer, 0, sizeof(CUSTOMVERTEX));
    d3ddev->DrawPrimitive(D3DPT_TRIANGLELIST, 0, octahedrons.size() * 8);
}

constexpr int icosahedronIndices[] = {
    0,11,5,0,55,1,0,1,7,0,7,10,0,10,11,  //5 faces around vertex 0
    1,5,9,5,11,4,11,10,2,10,7,6,7,1,8,  //5 adjacent faces
    3,9,4,3,4,2,3,2,6,3,6,8,3,8,9,   //5 faces around vertex 3
    4,9,5,2,4,11,6,2,10,8,6,7,9,8,1   //5 adjacent faces
};
void renderIcosahedronsBatch() {
    if (icosahedrons.empty()) return;

    // Lock the buffer and fill with icosahedron data
    CUSTOMVERTEX* pVertices;
    icosahedronBuffer->Lock(0, 0, (void**)&pVertices, D3DLOCK_DISCARD);

    int vertexCount = 0;

    for (const auto& icosahedron : icosahedrons) {
        // Transform vertices with position and rotation
        D3DXMATRIX matRotateX, matRotateY, matTranslate, matWorld;
        D3DXMatrixRotationX(&matRotateX, icosahedron.headAngleZ);
        D3DXMatrixRotationY(&matRotateY, icosahedron.headAngleX);
        D3DXMatrixMultiply(&matWorld, &matRotateX, &matRotateY);
        D3DXMatrixTranslation(&matTranslate, icosahedron.posX, 0, icosahedron.posZ);
        D3DXMatrixMultiply(&matWorld, &matWorld, &matTranslate);

        // Add vertices to buffer with hue coloring
        float hue = fmod(icosahedron.hueOffset, 3600.0f);
        for (int i = 0; i < 60; i++) {
            CUSTOMVERTEX vertex = icosahedron.vertices[icosahedronIndices[i]];
            RGBQUAD rgb = hsv2rgb({ hue, 0.75f+(i/240.0f), 1.0f-(i/480.0f) });
            
            // Transform vertex position
            D3DXVECTOR3 pos(vertex.X, vertex.Y, vertex.Z);
            D3DXVec3TransformCoord(&pos, &pos, &matWorld);
            
            pVertices[vertexCount++] = {
                pos.x, pos.y, pos.z,
                D3DCOLOR_XRGB(rgb.rgbRed, rgb.rgbGreen, rgb.rgbBlue)
            };
        }
    }

    icosahedronBuffer->Unlock();

    // Set identity world transform since vertices are already transformed
    D3DXMATRIX matIdentity;
    D3DXMatrixIdentity(&matIdentity);
    d3ddev->SetTransform(D3DTS_WORLD, &matIdentity);

    // Draw all icosahedrons in one call (20 triangles per icosahedron)
    d3ddev->SetStreamSource(0, icosahedronBuffer, 0, sizeof(CUSTOMVERTEX));
    d3ddev->DrawPrimitive(D3DPT_TRIANGLELIST, 0, icosahedrons.size() * 20);
}

void renderAllShadowsBatch() {
    size_t totalShadows = pyramids.size() + cubes.size() + octahedrons.size() + icosahedrons.size();
    if (totalShadows == 0) return;

    // 6 vertices per shadow (2 triangles to make a quad)
    const size_t totalVertices = totalShadows * 6;
    std::vector<CUSTOMVERTEX> vertices(totalVertices);
    
    size_t vertexIndex = 0;
    CUSTOMVERTEX shadowVerts[4];

    // Add pyramid shadows
    for (const auto& pyramid : pyramids) {
        generatePyramidShadow(pyramid, shadowVerts);
        // First triangle
        vertices[vertexIndex++] = shadowVerts[0];
        vertices[vertexIndex++] = shadowVerts[1];
        vertices[vertexIndex++] = shadowVerts[2];
        // Second triangle
        vertices[vertexIndex++] = shadowVerts[1];
        vertices[vertexIndex++] = shadowVerts[3];
        vertices[vertexIndex++] = shadowVerts[2];
    }

    // Add cube shadows
    for (const auto& cube : cubes) {
        generateCubeShadow(cube, shadowVerts);
        // First triangle
        vertices[vertexIndex++] = shadowVerts[0];
        vertices[vertexIndex++] = shadowVerts[1];
        vertices[vertexIndex++] = shadowVerts[2];
        // Second triangle
        vertices[vertexIndex++] = shadowVerts[1];
        vertices[vertexIndex++] = shadowVerts[3];
        vertices[vertexIndex++] = shadowVerts[2];
    }

    // Add octahedron shadows
    for (const auto& octahedron : octahedrons) {
        generateOctahedronShadow(octahedron, shadowVerts);
        // First triangle
        vertices[vertexIndex++] = shadowVerts[0];
        vertices[vertexIndex++] = shadowVerts[1];
        vertices[vertexIndex++] = shadowVerts[2];
        // Second triangle
        vertices[vertexIndex++] = shadowVerts[1];
        vertices[vertexIndex++] = shadowVerts[3];
        vertices[vertexIndex++] = shadowVerts[2];
    }

    // Add icosahedron shadows
    for (const auto& icosahedron : icosahedrons) {
        generateIcosahedronShadow(icosahedron, shadowVerts);
        // First triangle
        vertices[vertexIndex++] = shadowVerts[0];
        vertices[vertexIndex++] = shadowVerts[1];
        vertices[vertexIndex++] = shadowVerts[2];
        // Second triangle
        vertices[vertexIndex++] = shadowVerts[1];
        vertices[vertexIndex++] = shadowVerts[3];
        vertices[vertexIndex++] = shadowVerts[2];
    }

    // Enable alpha blending for shadows
    d3ddev->SetRenderState(D3DRS_ALPHABLENDENABLE, TRUE);
    d3ddev->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);
    d3ddev->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA);
    d3ddev->SetRenderState(D3DRS_BLENDOP, D3DBLENDOP_ADD);

    // Set identity world transform
    D3DXMATRIX matIdentity;
    D3DXMatrixIdentity(&matIdentity);
    d3ddev->SetTransform(D3DTS_WORLD, &matIdentity);

    // Draw all shadows in one call (2 triangles per shadow)
    d3ddev->DrawPrimitiveUP(D3DPT_TRIANGLELIST, totalShadows * 2, vertices.data(), sizeof(CUSTOMVERTEX));

    // Disable alpha blending
    d3ddev->SetRenderState(D3DRS_ALPHABLENDENABLE, FALSE);
}


void render_frame() {
    RECT clientRect;
    GetClientRect(hwnd, &clientRect);
    float aspectRatio = static_cast<float>(clientRect.right - clientRect.left) / 
                       static_cast<float>(clientRect.bottom - clientRect.top);
                       
    auto currentTime = std::chrono::high_resolution_clock::now();
    float deltaTime = std::chrono::duration<float>(currentTime - lastFrameTime).count();
    lastFrameTime = currentTime;

    // Clear the screen and depth buffer
    d3ddev->Clear(0, NULL, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER, D3DCOLOR_XRGB(135, 206, 235), 1.0f, 0);
    
    // Begin the scene
    if (FAILED(d3ddev->BeginScene())) {
        return;
    }

    // Set the vertex format
    d3ddev->SetFVF(CUSTOMFVF);

    // Handle jumping physics with proper delta time
    if (isJumping && jumpHeight == 0.0f) {
        jumpVelocity = 15.0f; // initial upward velocity
        isJumping = false;
    }
    jumpVelocity -= gravity * deltaTime;
    jumpHeight += jumpVelocity * deltaTime;
    if (jumpHeight < 0.0f) {
        jumpHeight = 0.0f;
        jumpVelocity = 0.0f;
    }

    // Update walking bobbing effect with delta time
    isWalking = (keyStates[VK_UP] || keyStates[VK_DOWN]) && !isJumping && jumpHeight == 0.0f;
    
    if (isWalking) {
        static float walkTime = 0.0f;
        walkTime += deltaTime * 5.0f; // Slower, more natural bobbing
        walkBobbingOffset = SohlTrgnmntry::Sin(walkTime) * 0.3f; // Smaller amplitude
    } else {
        // Smoothly return to normal position when not walking
        if (walkBobbingOffset != 0.0f) {
            walkBobbingOffset *= 0.9f;
            if (fabs(walkBobbingOffset) < 0.001f) walkBobbingOffset = 0.0f;
        }
    }

    // Set up camera and transforms with proper rotation
    D3DXMATRIX matView, matProjection, viewProj, matIdentity;
    float camHeight = jumpHeight * 2.0f + 1.5f + walkBobbingOffset;
    D3DXVECTOR3 camPos(posX, camHeight, posZ);
    
    // Calculate look-at point based on camera angle
    float lookDistance = 10.0f;
    float lookX = posX + SohlTrgnmntry::Sin(camAngleXZ) * lookDistance;
    float lookZ = posZ + SohlTrgnmntry::Cos(camAngleXZ) * lookDistance;
    D3DXVECTOR3 lookAt(lookX, camHeight * 0.9f, lookZ);
    
    D3DXVECTOR3 upVector = D3DXVECTOR3(0.0f, 1.0f, 0.0f);
    D3DXMatrixLookAtLH(&matView, &camPos, &lookAt, &upVector);
    D3DXMatrixPerspectiveFovLH(&matProjection, D3DXToRadian(60), aspectRatio, 0.1f, 50000.0f);
    D3DXMatrixMultiply(&viewProj, &matView, &matProjection);
    D3DXMatrixIdentity(&matIdentity);
    
    d3ddev->SetTransform(D3DTS_VIEW, &matView);
    d3ddev->SetTransform(D3DTS_PROJECTION, &matProjection);
    d3ddev->SetTransform(D3DTS_WORLD, &matIdentity);

    // Draw the ground
    d3ddev->SetStreamSource(0, groundBuffer, 0, sizeof(CUSTOMVERTEX));
    d3ddev->DrawPrimitive(D3DPT_TRIANGLESTRIP, 0, 2);

    // Render All Batches
    renderPyramidsBatch();
    renderCubesBatch();
    renderOctahedronsBatch();
    renderIcosahedronsBatch();
    renderAllShadowsBatch();

    d3ddev->EndScene(); // End the scene
    d3ddev->Present(NULL, NULL, NULL, NULL); // Present the scene
}


void initD3D(HWND hwnd) {
    d3d = Direct3DCreate9(D3D_SDK_VERSION);
    if (d3d == NULL) { MessageBox(hwnd, "Failed to create Direct3D interface", "Error", MB_OK); return; }

    // Get the current display mode to determine the screen resolution
    D3DDISPLAYMODE displayMode;
    if (FAILED(d3d->GetAdapterDisplayMode(D3DADAPTER_DEFAULT, &displayMode))) { MessageBox(hwnd, "Failed to get display mode", "Error", MB_OK); return; }

    // Get window dimensions
    RECT windowRect;
    GetClientRect(hwnd, &windowRect);
    int width = windowRect.right - windowRect.left;
    int height = windowRect.bottom - windowRect.top;

    // Use full screen resolution if window is maximized
    bool fullscreen = false;
    if (IsZoomed(hwnd)) {
        width = displayMode.Width;
        height = displayMode.Height;
        fullscreen = true;
    }

    D3DPRESENT_PARAMETERS d3dpp;
    ZeroMemory(&d3dpp, sizeof(d3dpp));
    
    d3dpp.Windowed = !fullscreen;
    d3dpp.SwapEffect = D3DSWAPEFFECT_DISCARD;
    d3dpp.hDeviceWindow = hwnd;
    d3dpp.BackBufferFormat = displayMode.Format;
    d3dpp.BackBufferWidth = width;
    d3dpp.BackBufferHeight = height;
    d3dpp.EnableAutoDepthStencil = TRUE;
    d3dpp.AutoDepthStencilFormat = D3DFMT_D24S8;
    d3dpp.FullScreen_RefreshRateInHz = fullscreen ? displayMode.RefreshRate : 0;

    // Create the D3DDevice
    HRESULT result = d3d->CreateDevice(D3DADAPTER_DEFAULT,
                                      D3DDEVTYPE_HAL, hwnd,
                                      D3DCREATE_HARDWARE_VERTEXPROCESSING,
                                      &d3dpp, &d3ddev);

    if (FAILED(result)) {
        // Try again with software vertex processing
        result = d3d->CreateDevice(D3DADAPTER_DEFAULT,
                                  D3DDEVTYPE_HAL, hwnd,
                                  D3DCREATE_SOFTWARE_VERTEXPROCESSING,
                                  &d3dpp, &d3ddev);
        
        if (FAILED(result)) { MessageBox(hwnd, "Failed to create Direct3D device", "Error", MB_OK); return; }
    }

    // Create resources
    init_graphics();
    initBatchBuffers();

    // Set render states
    d3ddev->SetRenderState(D3DRS_LIGHTING, FALSE);    // turn off the 3D lighting
    d3ddev->SetRenderState(D3DRS_CULLMODE, D3DCULL_NONE); // both sides of the triangles
    d3ddev->SetRenderState(D3DRS_ZENABLE, TRUE);      // turn on the z-buffer
    
    initOcclusionQueries();
    prepare_render_batch();
}


// This function that cleans up Direct3D and COM
void cleanD3D() {
    // Clear active queries first
    while (!activeQueries.empty()) {
        if (activeQueries.front().first) {
            activeQueries.front().first->Release();
        }
        activeQueries.pop();
    }
    
    // Clear available queries
    while (!availableQueries.empty()) {
        if (availableQueries.front()) {
            availableQueries.front()->Release();
        }
        availableQueries.pop();
    }
    
    // Clear query pool
    for (auto query : queryPool) {
        if (query) query->Release();
    }
    queryPool.clear();
    
    if (groundBuffer) groundBuffer->Release();
    if (d3ddev) d3ddev->Release();
    if (d3d) d3d->Release();
}

void Spawn(float size, int type) {
    float randomX, randomZ;
    int attempts = 0;
    const int maxAttempts = 10;

    do {
        randomX = (rand() * rand()) % 50000 - 25000;
        randomZ = (rand() * rand()) % 50000 - 25000;
        attempts++;
    } while (checkCollision(randomX, randomZ, size) && attempts < maxAttempts);
    if (attempts < maxAttempts) {
    switch(type%5) {
	case 1: {
        Pyramid newPyramid;
        newPyramid.posX = randomX;
        newPyramid.posZ = randomZ;

        // Simplified pyramid vertices creation
        newPyramid.vertices[0] = { 3.0f*size, 0.0f, 3.0f*size, D3DCOLOR_XRGB(127, 0, 0) };
        newPyramid.vertices[1] = { 3.0f*size, 0.0f, -3.0f*size, D3DCOLOR_XRGB(112, 0, 0) };
        newPyramid.vertices[2] = { -3.0f*size, 0.0f, -3.0f*size, D3DCOLOR_XRGB(88, 0, 0) };
        newPyramid.vertices[3] = { -3.0f*size, 0.0f, 3.0f*size, D3DCOLOR_XRGB(154, 0, 0) };
        newPyramid.vertices[4] = { 0.0f, 6.0f*size, 0.0f, D3DCOLOR_XRGB(255, 0, 0) };

        std::lock_guard<std::mutex> lock(pyramidMutex);
        pyramids.push_back(newPyramid);
		break;
	}
	case 2: {
        Cube newCube;
        newCube.posX = randomX;
        newCube.posZ = randomZ;

        float halfSize = size / 2.0f;

    // Simplified cube vertices creation with gradient colors
    newCube.vertices[0] = {-halfSize, 0.0f, -halfSize, D3DCOLOR_XRGB(0, 0, 128)}; // Bottom left
    newCube.vertices[1] = { halfSize, 0.0f, -halfSize, D3DCOLOR_XRGB(0, 0, 160)}; // Bottom right
    newCube.vertices[2] = { halfSize, 0.0f,  halfSize, D3DCOLOR_XRGB(0, 0, 192)}; // Top right
    newCube.vertices[3] = {-halfSize, 0.0f,  halfSize, D3DCOLOR_XRGB(0, 0, 224)}; // Top left
    
    // Top vertices with lighter colors
    newCube.vertices[4] = {-halfSize, size, -halfSize, D3DCOLOR_XRGB(0, 0, 192)}; 
    newCube.vertices[5] = { halfSize, size, -halfSize, D3DCOLOR_XRGB(0, 0, 224)}; 
    newCube.vertices[6] = { halfSize, size,  halfSize, D3DCOLOR_XRGB(0, 0, 255)}; 
    newCube.vertices[7] = {-halfSize, size,  halfSize, D3DCOLOR_XRGB(0, 0, 255)};

        std::lock_guard<std::mutex> lock(pyramidMutex);
        cubes.push_back(newCube);
		break;
	}
	case 3: {
        Octahedron newOctahedron;
        newOctahedron.posX = randomX;
        newOctahedron.posZ = randomZ;
        newOctahedron.velX = (rand() % 100 - 50) / 50.0f;
        newOctahedron.velZ = (rand() % 100 - 50) / 50.0f;
        newOctahedron.size = size;

        // Create octahedron vertices (two pyramids base-to-base)
        float halfSize = size / 2.0f;
        newOctahedron.vertices[0] = { 0.0f, halfSize*2, 0.0f, D3DCOLOR_XRGB(0, 255, 0) }; // Top
        newOctahedron.vertices[1] = { -halfSize, halfSize, 0.0f, D3DCOLOR_XRGB(0, 200, 0) }; // Left
        newOctahedron.vertices[2] = { 0.0f, halfSize, -halfSize, D3DCOLOR_XRGB(0, 180, 0) }; // Front
        newOctahedron.vertices[3] = { halfSize, halfSize, 0.0f, D3DCOLOR_XRGB(0, 160, 0) }; // Right
        newOctahedron.vertices[4] = { 0.0f, halfSize, halfSize, D3DCOLOR_XRGB(0, 140, 0) }; // Back
        newOctahedron.vertices[5] = { 0.0f, 0.0f, 0.0f, D3DCOLOR_XRGB(0, 100, 0) }; // Bottom

        std::lock_guard<std::mutex> lock(pyramidMutex);
        octahedrons.push_back(newOctahedron);
		break;
	}
	default: {
        Icosahedron newIcosahedron;
        newIcosahedron.posX = randomX;
        newIcosahedron.posZ = randomZ;
        newIcosahedron.velX = (rand() % 100 - 50) / 50.0f;
        newIcosahedron.velZ = (rand() % 100 - 50) / 50.0f;
        newIcosahedron.size = size;
        newIcosahedron.rotationAngle = 0.0f;
        newIcosahedron.rotationSpeed = (rand() % 100) / 500.0f + 0.01f;
        newIcosahedron.hueOffset = rand() % 3600;
        newIcosahedron.hueSpeed = (rand() % 100) / 100.0f + 0.1f;
        newIcosahedron.awareness = 0.0f;
        newIcosahedron.interestLevel = 0.0f;

        // Create vertices for a more spherical icosahedron
        float radius = size;
        float t = (1.0f + sqrt(5.0f)) / 2.0f; // Golden ratio
        
        // Normalize vertices to unit sphere
        std::array<D3DXVECTOR3, 12> vertices = {
            D3DXVECTOR3(-1.0f,  t, 0.0f), D3DXVECTOR3(1.0f,  t, 0.0f),
            D3DXVECTOR3(-1.0f, -t, 0.0f), D3DXVECTOR3(1.0f, -t, 0.0f),
            
            D3DXVECTOR3(0.0f, -1.0f,  t), D3DXVECTOR3(0.0f, 1.0f,  t),
            D3DXVECTOR3(0.0f, -1.0f, -t), D3DXVECTOR3(0.0f, 1.0f, -t),
            
            D3DXVECTOR3( t, 0.0f, -1.0f), D3DXVECTOR3( t, 0.0f, 1.0f),
            D3DXVECTOR3(-t, 0.0f, -1.0f), D3DXVECTOR3(-t, 0.0f, 1.0f)
        };
        
        // Normalize and scale vertices
        for (auto& v : vertices) {
            D3DXVec3Normalize(&v, &v);
            v *= radius;
        }
        
        // Shift all vertices up so the bottom is at y=0
        float minY = FLT_MAX;
        for (const auto& v : vertices) { if (v.y < minY) minY = v.y; }
        for (auto& v : vertices) { v.y -= minY; }
        
        // Assign to icosahedron vertices with color
        for (int i = 0; i < 12; i++) {
            newIcosahedron.vertices[i] = {
                vertices[i].x, 
                vertices[i].y, 
                vertices[i].z, 
                D3DCOLOR_XRGB(255, 0, 0) // Initial color (will be overwritten by hue cycling)
            };
        }

        std::lock_guard<std::mutex> lock(pyramidMutex);
        icosahedrons.push_back(newIcosahedron);
		break;
	}
		}
	resizeBatchBuffers();
    }
}


// This is the main message handler for the program
LRESULT CALLBACK WindowProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam) {
    switch (message) {
        case WM_DESTROY: ExitProcess(0); break;
        case WM_KEYDOWN: keyStates[wParam] = true; break;
        case WM_KEYUP: keyStates[wParam] = false; break;
        default: return DefWindowProc(hWnd, message, wParam, lParam);
    }
    return 0;
}

// Threaded AI updates
std::atomic<bool> aiThreadRunning(false);
std::thread aiThread;

void start_ai_thread() {
    aiThreadRunning = true;
    aiThread = std::thread([]() {
        auto lastUpdate = std::chrono::high_resolution_clock::now();
        
        while (aiThreadRunning) {
            auto now = std::chrono::high_resolution_clock::now();
            float deltaTime = std::chrono::duration<float>(now - lastUpdate).count();
            lastUpdate = now;
            
            updateOctahedrons(deltaTime);
            
            updateIcosahedrons(deltaTime);
            
            // Limit update rate to ~60Hz
            std::this_thread::sleep_for(std::chrono::milliseconds(14));
        }
    });
}

void stop_ai_thread() {
    aiThreadRunning = false;
    if (aiThread.joinable()) {
        aiThread.join();
    }
}

// The entry point for any Windows program
int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow) {
    srand(static_cast<unsigned int>(time(0))); // Seed random number generator
	bool PreGen = (MessageBox(NULL, "Do you want to Pre-Generate the Entites & Objects?", "Question", MB_ICONINFORMATION | MB_YESNO) == IDYES);
	
    WNDCLASSEX wc;
    MSG msg;

    ZeroMemory(&wc, sizeof(WNDCLASSEX));
    wc.cbSize = sizeof(WNDCLASSEX);
    wc.style = CS_HREDRAW | CS_VREDRAW;
    wc.lpfnWndProc = WindowProc;
    wc.hInstance = hInstance;
    wc.hCursor = LoadCursor(NULL, IDC_ARROW);
    wc.hbrBackground = (HBRUSH)COLOR_WINDOW;
    wc.lpszClassName = "WindowClass";
    wc.hIcon = LoadIcon(NULL, IDI_APPLICATION);
    wc.hIconSm = LoadIcon(NULL, IDI_APPLICATION);

    if (!RegisterClassEx(&wc)) {
        MessageBox(NULL, "Window Registration Failed!", "Error!", MB_ICONEXCLAMATION | MB_OK);
        return 0;
    }

    hwnd = CreateWindowEx(
        0,
        "WindowClass",
        "Playground",
        WS_OVERLAPPEDWINDOW,
        CW_USEDEFAULT, CW_USEDEFAULT,
    	GetSystemMetrics(SM_CXSCREEN), GetSystemMetrics(SM_CYSCREEN),  // Use screen dimensions
        NULL,
        NULL,
        hInstance,
        NULL);

    if (hwnd == NULL) { MessageBox(NULL, "Window Creation Failed!", "Error!", MB_ICONEXCLAMATION | MB_OK); return 0; }

    ShowWindow(hwnd, nCmdShow);
    UpdateWindow(hwnd);

    // Set up and initialize Direct3D
    initD3D(hwnd);
	
	if (PreGen > 0) {
	for (int I = 0; I < 3000; ++I) { Spawn(((rand()%100)/50+2)*2, 1); Spawn(((rand()%100)/50+2)*8, 2); }
    for (int I = 0; I < 800; ++I) { Spawn(((rand()%100)/50+2)*8, 3); }
    for (int I = 0; I < 200; ++I) { Spawn(((rand()%100)/50+2)*8, 4); }
	}
    // Enter the main loop
    start_ai_thread();
    while (TRUE) {
        if (PeekMessage(&msg, NULL, 0, 0, PM_REMOVE)) {
            if (msg.message == WM_QUIT)
                break;
            
            TranslateMessage(&msg);
            DispatchMessage(&msg);
        } else {
            // Handle continuous movement
            if (keyStates[VK_RIGHT]) camAngleXZ += 0.02f; // Rotate to right
            if (keyStates[VK_LEFT]) camAngleXZ -= 0.02f; // Rotate to left 
            if (keyStates[VK_UP]) {
                // Move forward based on angle
                posX += SohlTrgnmntry::Sin(camAngleXZ) * cameraSpeed;
                posZ += SohlTrgnmntry::Cos(camAngleXZ) * cameraSpeed;
            }
            if (keyStates[VK_DOWN]) {
                // Move backward based on angle
                posX -= SohlTrgnmntry::Sin(camAngleXZ) * cameraSpeed;
                posZ -= SohlTrgnmntry::Cos(camAngleXZ) * cameraSpeed;
            }
            if (keyStates[VK_SPACE]) { if (!wasJumpKeyPressed && jumpHeight == 0.0f) { isJumping = true; } } wasJumpKeyPressed = keyStates[VK_SPACE];
            if (keyStates[VK_F1]) { Spawn(((rand()%100)/50+2)*2, 1); Spawn(((rand()%100)/50+2)*2, 1); Spawn(((rand()%100)/50+2)*2, 1); }
            if (keyStates[VK_F2]) { Spawn(((rand()%100)/50+2)*8, 2); Spawn(((rand()%100)/50+2)*8, 2); Spawn(((rand()%100)/50+2)*8, 2); }
            if (keyStates[VK_F3]) { Spawn(((rand()%100)/50+2)*8, 3); Spawn(((rand()%100)/50+2)*8, 3); Spawn(((rand()%100)/50+2)*8, 3); }
            if (keyStates[VK_F4]) { Spawn(((rand()%100)/50+2)*6, 4); Spawn(((rand()%100)/50+2)*6, 4); Spawn(((rand()%100)/50+2)*6, 4); }
            
            // Render the scene
            render_frame();
        }
    }

    // Clean up DirectX and COM
    cleanD3D();
	stop_ai_thread();
	
    return msg.wParam;
}