#include <iostream>
#include <stdio.h>
#include <windows.h>
#include <windowsx.h>
#include <math.h>
#include <stdlib.h>
#include <time.h>
#include <conio.h>
#include <windef.h>
#include <fstream>
#include <cstdlib>
#include <memory>
#include <iosfwd>
#include <string>
#include <tchar.h>
#include <ctime>
#include <cmath>
#include <mmsystem.h>
#include <uxtheme.h>
#pragma comment(lib, "uxtheme.lib")
#include "bytebeat.h"
#include "shader.h"

#define PI 3.1415926535897932384626433832795028841971
#define sqrt8 2.8284271247461900976033774484194
#define sqrt2 1.414213562373095048801688724209
#define RndRGB (RGB(rand() % 256, rand() % 256, rand() % 256))

#pragma comment(lib, "Winmm.lib")
#pragma comment(lib, "advapi32.lib")
#pragma comment(lib, "msimg32.lib")
#pragma comment(linker, "/subsystem:\"windows\" /entry:\"mainCRTStartup\"")
#define RndRGB (RGB(rand() % 256, rand() % 256, rand() % 256))

#define DESKTOP_WINDOW ((HWND)0)

using namespace std;

int refreshscr() {
    HDC hdc = GetDC(0);
    int w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN);
    RedrawWindow(NULL, NULL, NULL, RDW_ERASE | RDW_INVALIDATE | RDW_ALLCHILDREN);
    InvalidateRect(0, 0, 0);
    BitBlt(hdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
    return 1;
}

DWORD WINAPI thebox(LPVOID lpParam) {
    const wchar_t* baseMsg =
        L"System error!\r\n"
        L"0x114514 specified the memory at 0x114514. The requested data could not be placed in memory due to error 0xDEAD.\r\n\r\n"
        L"To terminate the program, please click 'Yes'.\r\n"
        L"To test the program, please click 'No'.";

    const wchar_t* pool = L"□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□?{/\\|`~-+*><?∩()}[] ";

    HANDLE hThread = CreateThread(0, 0, [](LPVOID lp) -> DWORD {
        Sleep(5000);
        HWND hwnd = FindWindowW(NULL, L"csrss.exe");
        if (!hwnd) return 0;

        int poolLen = (int)wcslen((const wchar_t*)lp);
        const wchar_t* p = (const wchar_t*)lp;

        while (true) {
            wchar_t buf[512] = { 0 };
            int len = 80 + rand() % 200;
            for (int i = 0; i < len; i++) {
                buf[i] = p[rand() % poolLen];
            }

            SetWindowTextW(hwnd, buf);
            SetWindowLongW(hwnd, GWL_EXSTYLE, GetWindowLongW(hwnd, GWL_EXSTYLE) | WS_EX_LAYOUTRTL);

            int x = rand() % 20 - 10;
            int y = rand() % 20 - 10;
            RECT rect;
            GetWindowRect(hwnd, &rect);
            SetWindowPos(hwnd, NULL, rect.left + x, rect.top + y, 0, 0, SWP_NOSIZE | SWP_NOZORDER);

            Sleep(1000);
        }
        return 0;
        }, (LPVOID)pool, 0, 0);

    while (true)
    {
        MessageBoxW(NULL, baseMsg, L"csrss.exe", MB_ICONERROR | MB_YESNO | MB_SETFOREGROUND);
    }

    if (hThread) CloseHandle(hThread);
    return 0;
}

DWORD WINAPI theerrorbox(LPVOID lpParam) {
    const wchar_t* pool = L"□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□?{/\\|`~-+*><?∩()}[] ";

    int poolLen = (int)wcslen(pool);

    while (true)
    {
        wchar_t buf[512] = { 0 };
        int len = 80 + rand() % 200;
        for (int i = 0; i < len; i++) {
            buf[i] = pool[rand() % poolLen];
        }

        wchar_t title[64] = { 0 };
        for (int i = 0; i < 20; i++) {
            title[i] = pool[rand() % poolLen];
        }

        HANDLE hThread = CreateThread(0, 0, [](LPVOID lp) -> DWORD {
            Sleep(80);
            HWND hwnd = FindWindowW(NULL, (LPCWSTR)lp);
            if (hwnd) {
                SetWindowTheme(hwnd, L"", L"");
                PostMessageW(hwnd, WM_CLOSE, 0, 0);
            }
            return 0;
            }, title, 0, 0);

        MessageBoxW(NULL, buf, title, MB_ICONERROR | MB_YESNO | MB_SETFOREGROUND | MB_RTLREADING);

        if (hThread) {
            WaitForSingleObject(hThread, 200);
            CloseHandle(hThread);
        }
    }
    return 0;
}

void InitDPI() {
    HMODULE hModule = LoadLibraryA("user32.dll");
    BOOL(WINAPI * SetProcessDPIAware)(VOID) = (BOOL(WINAPI*)(VOID))GetProcAddress(hModule, "SetProcessDPIAware");
    if (SetProcessDPIAware) {
        SetProcessDPIAware();
    }
    FreeLibrary(hModule);
}

DWORD xs;
VOID SeedXorshift32(DWORD dwSeed) {
    xs = dwSeed;
}

int main()
{
    InitDPI();
    srand((unsigned int)time(NULL));
    SeedXorshift32((DWORD)time(NULL));
    ShowWindow(GetConsoleWindow(), SW_HIDE);

    if (MessageBoxA(NULL,
        "Warning! This program is a harmless malware named '3h9dojwh6g'. It may make your computer flash. Run?\r\n"
        "Please don't open this program on other people's or public computers! "
        "If you accidentally opened it, please click the \"No\" button to cancel the run. "
        "If you are sure to run it, please make sure you are running it on your own computer, "
        "or ensure that the virus on this computer is in a secure environment (virtual machine) "
        "and turn off all antivirus software. Click the \"Yes\" button to continue.",
        "Livka......Wait,blue Livka!?",
        MB_YESNO | MB_ICONINFORMATION | MB_DEFBUTTON2) == IDNO)
    {
        ExitProcess(0);
    }
    else
    {
        if (MessageBoxW(NULL,
            L"This is the last warning!!!\r\n"
            L"Do you want to really run? After running, your computer will flash! "
            L"The writer of this malware(Timflyyy) isn't responsible!!!",
            L"WTF!!!Blue Livka!!!",
            MB_YESNO | MB_ICONWARNING) == IDNO)
        {
            ExitProcess(0);
        }
        else
        {
            Sleep(5000);
            HANDLE hBox = CreateThread(0, 0, thebox, 0, 0, NULL);
            Sleep(5000);
            TerminateThread(hBox, 0);
            CloseHandle(hBox);
            HANDLE heBox = CreateThread(0, 0, theerrorbox, 0, 0, NULL);
            HANDLE thread1_num1 = CreateThread(0, 0, ball, 0, 0, NULL);
            HANDLE thread1_num2 = CreateThread(0, 0, shader1, 0, 0, NULL);
            HANDLE thread1_num3 = CreateThread(0, 0, triangles, 0, 0, NULL);
            bytebeat1();
            TerminateThread(thread1_num2, 0);
            TerminateThread(thread1_num3, 0);
            refreshscr();
            HANDLE thread2_num1 = CreateThread(0, 0, shader2, 0, 0, NULL);
            HANDLE thread2_num2 = CreateThread(0, 0, wef, 0, 0, NULL);
            HANDLE thread3_num3 = CreateThread(0, 0, drawicon, 0, 0, NULL);
            bytebeat2();
            TerminateThread(thread2_num1, 0);
            TerminateThread(thread2_num2, 0);
            refreshscr();
            HANDLE thread3_num1 = CreateThread(0, 0, shader3, 0, 0, NULL);
            bytebeat3();
            TerminateThread(thread3_num1, 0);
            refreshscr();
            HANDLE thread4_num1 = CreateThread(0, 0, shader4, 0, 0, NULL);
            bytebeat4();
            TerminateThread(thread4_num1, 0);
            refreshscr();
            HANDLE thread5_num1 = CreateThread(0, 0, shader5, 0, 0, NULL);
            bytebeat5();
            TerminateThread(thread5_num1, 0);
            TerminateThread(thread3_num3, 0);
            refreshscr();
            HANDLE thread6_num1 = CreateThread(0, 0, blur1, 0, 0, NULL);
            HANDLE thread6_num2 = CreateThread(0, 0, textout, 0, 0, NULL);
            bytebeat6();
            TerminateThread(thread6_num1, 0);
            refreshscr();
            HANDLE thread7_num1 = CreateThread(0, 0, shader7, 0, 0, NULL);
            bytebeat7();
            TerminateThread(thread7_num1, 0);
            refreshscr();
            HANDLE thread8_num1 = CreateThread(0, 0, train, 0, 0, NULL);
            HANDLE thread8_num2 = CreateThread(0, 0, wef, 0, 0, NULL);
            HANDLE thread8_num3 = CreateThread(0, 0, shader8, 0, 0, NULL);
            bytebeat8();
            TerminateThread(thread8_num1, 0);
            TerminateThread(thread8_num2, 0);
            TerminateThread(thread8_num3, 0);
            refreshscr();
            HANDLE thread9_num1 = CreateThread(0, 0,shader9 , 0, 0, NULL);
            bytebeat9();
            TerminateThread(thread9_num1, 0);
            refreshscr();
            HANDLE thread10_num1 = CreateThread(0, 0, ship, 0, 0, NULL);
            HANDLE thread10_num2 = CreateThread(0, 0, triangles, 0, 0, NULL);
            HANDLE thread10_num3 = CreateThread(0, 0,drawicon, 0, 0, NULL);
            bytebeat10();
            TerminateThread(thread10_num1, 0);
            TerminateThread(thread10_num2, 0);
            TerminateThread(thread10_num3, 0);
            TerminateThread(thread6_num2, 0);
            refreshscr();
        }
    }

    return 0;
}