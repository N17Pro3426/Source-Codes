#pragma once
#include <windows.h>
#include <math.h>
#define PI 3.1415926535897932384626433832795028841971
#include "resource.h"
#define RndRGB (RGB(rand() % 256, rand() % 256, rand() % 256))

typedef struct
{
	FLOAT h;
	FLOAT s;
	FLOAT l;
} HSL;

namespace Colors
{
	//thanks to Wipet
	HSL rgb2hsl(RGBQUAD rgb)
	{
		HSL hsl;

		BYTE r = rgb.rgbRed;
		BYTE g = rgb.rgbGreen;
		BYTE b = rgb.rgbBlue;

		FLOAT _r = (FLOAT)r / 255.f;
		FLOAT _g = (FLOAT)g / 255.f;
		FLOAT _b = (FLOAT)b / 255.f;

		FLOAT rgbMin = min(min(_r, _g), _b);
		FLOAT rgbMax = max(max(_r, _g), _b);

		FLOAT fDelta = rgbMax - rgbMin;
		FLOAT deltaR;
		FLOAT deltaG;
		FLOAT deltaB;

		FLOAT h = 0.f;
		FLOAT s = 0.f;
		FLOAT l = (FLOAT)((rgbMax + rgbMin) / 2.f);

		if (fDelta != 0.f)
		{
			s = l < .5f ? (FLOAT)(fDelta / (rgbMax + rgbMin)) : (FLOAT)(fDelta / (2.f - rgbMax - rgbMin));
			deltaR = (FLOAT)(((rgbMax - _r) / 6.f + (fDelta / 2.f)) / fDelta);
			deltaG = (FLOAT)(((rgbMax - _g) / 6.f + (fDelta / 2.f)) / fDelta);
			deltaB = (FLOAT)(((rgbMax - _b) / 6.f + (fDelta / 2.f)) / fDelta);

			if (_r == rgbMax)      h = deltaB - deltaG;
			else if (_g == rgbMax) h = (1.f / 3.f) + deltaR - deltaB;
			else if (_b == rgbMax) h = (2.f / 3.f) + deltaG - deltaR;
			if (h < 0.f)           h += 1.f;
			if (h > 1.f)           h -= 1.f;
		}

		hsl.h = h;
		hsl.s = s;
		hsl.l = l;
		return hsl;
	}

	RGBQUAD hsl2rgb(HSL hsl)
	{
		RGBQUAD rgb;

		FLOAT r = hsl.l;
		FLOAT g = hsl.l;
		FLOAT b = hsl.l;

		FLOAT h = hsl.h;
		FLOAT sl = hsl.s;
		FLOAT l = hsl.l;
		FLOAT v = (l <= .5f) ? (l * (1.f + sl)) : (l + sl - l * sl);

		FLOAT m;
		FLOAT sv;
		FLOAT fract;
		FLOAT vsf;
		FLOAT mid1;
		FLOAT mid2;

		INT sextant;

		if (v > 0.f)
		{
			m = l + l - v;
			sv = (v - m) / v;
			h *= 6.f;
			sextant = (INT)h;
			fract = h - sextant;
			vsf = v * sv * fract;
			mid1 = m + vsf;
			mid2 = v - vsf;

			switch (sextant)
			{
			case 0:
				r = v;
				g = mid1;
				b = m;
				break;
			case 1:
				r = mid2;
				g = v;
				b = m;
				break;
			case 2:
				r = m;
				g = v;
				b = mid1;
				break;
			case 3:
				r = m;
				g = mid2;
				b = v;
				break;
			case 4:
				r = mid1;
				g = m;
				b = v;
				break;
			case 5:
				r = v;
				g = m;
				b = mid2;
				break;
			}
		}

		rgb.rgbRed = (BYTE)(r * 255.f);
		rgb.rgbGreen = (BYTE)(g * 255.f);
		rgb.rgbBlue = (BYTE)(b * 255.f);

		return rgb;
	}
}

union _RGBQUAD {
	COLORREF rgb;
	struct {
		BYTE b;
		BYTE g;
		BYTE r;
		BYTE Reserved;
	};
};
typedef union _RGBQUAD RGBQUAD2;
typedef union _RGBQUAD* PRGBQUAD;

VOID WINAPI train_function(HDC hdc, int w, int h, int xPower, int yPower, DWORD dwRop) {
	if (xPower >= w) xPower = w - 1; if (yPower >= h) yPower = h - 1;
	HBITMAP screenshot = CreateCompatibleBitmap(hdc, w, h);
	HDC hdc2 = CreateCompatibleDC(hdc);
	SelectObject(hdc2, screenshot);
	BitBlt(hdc2, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
	BitBlt(hdc, xPower > 0 ? xPower : 0, yPower > 0 ? yPower : 0, w - abs(xPower), h - abs(yPower), hdc, xPower < 0 ? -xPower : 0, yPower < 0 ? -yPower : 0, dwRop);
	BitBlt(hdc, xPower < 0 ? w + xPower : 0, 0, abs(xPower), h, hdc2, xPower > 0 ? w - xPower : 0, 0, dwRop);
	BitBlt(hdc, 0, yPower < 0 ? h + yPower : 0, w, abs(yPower), hdc2, 0, yPower > 0 ? h - yPower : 0, dwRop);
	DeleteDC(hdc2);
	DeleteObject(screenshot);
}



DWORD WINAPI drawicon(LPVOID lpParam) {
	HICON shellIcons[8];
	HICON moriIcons[8];
	int shellCount = 0, moriCount = 0;

	for (int i = 0; i < 8; i++) {
		HICON hLarge = NULL, hSmall = NULL;
		if (ExtractIconEx(L"shell32.dll", i * 12 + 2, &hLarge, &hSmall, 1) > 0) {
			shellIcons[shellCount++] = hLarge;
		}
		if (ExtractIconEx(L"moricons.dll", i * 6, &hLarge, &hSmall, 1) > 0) {
			moriIcons[moriCount++] = hLarge;
		}
	}

	while (true)
	{
		HDC DC = GetDC(0);

		int iconW = GetSystemMetrics(SM_CXICON);
		int iconH = GetSystemMetrics(SM_CYICON);
		int sw = GetSystemMetrics(SM_CXSCREEN);
		int sh = GetSystemMetrics(SM_CYSCREEN);

		HICON appIcon = LoadIcon(GetModuleHandle(NULL), MAKEINTRESOURCE(IDI_3H9DOJWH6G));

		for (int y = 0; y < sh; y += iconH)
		{
			for (int x = 0; x < sw; x += iconW)
			{
				if (rand() % 10 == 0) {
					continue;
				}

				HICON ico;
				if (rand() % 4 == 0)
				{
					ico = appIcon;
				}
				else
				{
					switch (rand() % 8)
					{
					case 0:
						ico = LoadIcon(NULL, IDI_QUESTION);
						break;
					case 1:
						ico = LoadIcon(NULL, IDI_ERROR);
						break;
					case 2:
						ico = LoadIcon(NULL, IDI_WARNING);
						break;
					case 3:
						ico = LoadIcon(NULL, IDI_INFORMATION);
						break;
					case 4:
					case 5:
						ico = shellIcons[rand() % (shellCount > 0 ? shellCount : 1)];
						break;
					case 6:
					case 7:
						ico = moriIcons[rand() % (moriCount > 0 ? moriCount : 1)];
						break;
					default:
						ico = LoadIcon(NULL, IDI_QUESTION);
						break;
					}
				}

				DrawIconEx(DC, x, y, ico, iconW, iconH, 0, 0, DI_NORMAL);
			}
		}

		ReleaseDC(0, DC);
		Sleep(2000);
	}
}

int stage = 0;
int r = 0, g = 0, b = 0;

COLORREF Hue(int shift) {
	switch (stage) {
	case 0:
		r = 255;
		b = 0;
		g < 255 ? g += shift : stage++;
		break;
	case 1:
		g = 255;
		b = 0;
		r > 0 ? r -= shift : stage++;
		break;
	case 2:
		g = 255;
		r = 0;
		b < 255 ? b += shift : stage++;
		break;
	case 3:
		b = 255;
		r = 0;
		g > 0 ? g -= shift : stage++;
		break;
	case 4:
		b = 255;
		g = 0;
		r < 255 ? r += shift : stage++;
		break;
	case 5:
		r = 255;
		g = 0;
		b > 0 ? b -= shift : stage = 0;
		break;
	}
	return RGB(r, g, b);
}

DWORD WINAPI triangles(LPVOID lpParam) {
	while (1) {
		int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
		HDC hdc = GetDC(0);

		POINT vertices[3] = {
			{ rand() % w, rand() % h },
			{ rand() % w, rand() % h },
			{ rand() % w, rand() % h }
		};

		int minX = min(vertices[0].x, min(vertices[1].x, vertices[2].x));
		int maxX = max(vertices[0].x, max(vertices[1].x, vertices[2].x));
		int minY = min(vertices[0].y, min(vertices[1].y, vertices[2].y));
		int maxY = max(vertices[0].y, max(vertices[1].y, vertices[2].y));
		int rw = maxX - minX;
		int rh = maxY - minY;
		if (rw <= 0 || rh <= 0) {
			ReleaseDC(0, hdc);
			continue;
		}

		BeginPath(hdc);
		Polygon(hdc, vertices, 3);
		EndPath(hdc);

		SelectClipPath(hdc, RGN_AND);

		TRIVERTEX vert[2];
		vert[0].x = minX;
		vert[0].y = minY;
		vert[0].Red = 0xE0 << 8;
		vert[0].Green = 0xF4 << 8;
		vert[0].Blue = 0xFF << 8;
		vert[0].Alpha = 0x0000;

		vert[1].x = maxX;
		vert[1].y = maxY;
		vert[1].Red = 0x00 << 8;
		vert[1].Green = 0xBF << 8;
		vert[1].Blue = 0xFF << 8;
		vert[1].Alpha = 0x0000;

		GRADIENT_RECT gRect = { 0, 1 };
		GradientFill(hdc, vert, 2, &gRect, 1, GRADIENT_FILL_RECT_V);

		SelectClipRgn(hdc, NULL);

		ReleaseDC(0, hdc);
		Sleep(1);
	}
}

//DWORD WINAPI drawicon(LPVOID lpParam) {
//	srand(time(NULL));
//	int v1 = 1;
//	int xLeft = 10;
//	int v2 = 1;
//	int yTop = 10;
//	while (true)
//	{
//		HDC DC = GetDC(0);
//		xLeft += 10 * v1;
//		yTop += 10 * v2;
//		HICON ico = LoadIcon(GetModuleHandle(NULL), MAKEINTRESOURCE(107));
//		DrawIconEx(DC, xLeft, yTop, ico, 5 * GetSystemMetrics(11), 5 * GetSystemMetrics(12), 0, 0, 3u);
//		if (yTop >= GetSystemMetrics(1))
//			v2 = -1;
//		if (xLeft >= GetSystemMetrics(0))
//			v1 = -1;
//		if (!yTop)
//			v2 = 1;
//		if (!xLeft)
//			v1 = 1;
//		ReleaseDC(0, DC);
//		Sleep(10);
//	}
//}
DWORD WINAPI gradientfillrect(LPVOID lpvd)
{
	HDC hdc;
	int w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN);
	while (true)
	{
		HDC hdc = GetDC(0);
		int w = GetSystemMetrics(0);
		int h = GetSystemMetrics(1);
		int rr[4] = { 0x5700, 0x6000,0x7300,0x4000 }, gg[4] = { 0x900,0x0,0x0c00,0x0 }, bb[4] = { 0xc100,0xc000,0xff00,0x8000 }, a = rand() % 4, b = rand() % 4;
		TRIVERTEX vtx[2];
		vtx[0].x = w - (rand() % w); vtx[0].y = h - (rand() % h);
		vtx[1].x = rand() % w; vtx[1].y = rand() % h;
		vtx[0].Red = rr[a]; vtx[0].Green = gg[a]; vtx[0].Blue = bb[a]; vtx[0].Alpha = 0xff00;
		vtx[1].Red = rr[b]; vtx[1].Green = gg[b]; vtx[1].Blue = bb[b]; vtx[1].Alpha = 0xff00;
		GRADIENT_RECT rc;
		rc.UpperLeft = 0; rc.LowerRight = 1;
		DWORD mode[4] = { GRADIENT_FILL_RECT_H,GRADIENT_FILL_RECT_V,GRADIENT_FILL_TRIANGLE, GRADIENT_FILL_OP_FLAG };
		GradientFill(hdc, vtx, 2, &rc, 1, mode[rand() % 4]);
		ReleaseDC(0, hdc);
		Sleep(2.5);
	}
	return 0;
}

DWORD WINAPI ball(LPVOID lpParam) {
	HDC hdc = GetDC(NULL);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	int maxRadius = 50;         
	int x = 10, y = 10;
	int xx = 1, yy = 1;
	int incrementor = 5;

	while (true) {
		hdc = GetDC(0);

		COLORREF color = Hue(3);

		HBRUSH brush = CreateSolidBrush(color);
		HPEN pen = CreatePen(PS_SOLID, 1, RGB(0, 0, 0));  
		HBRUSH oldBrush = (HBRUSH)SelectObject(hdc, brush);
		HPEN oldPen = (HPEN)SelectObject(hdc, pen);

		int cx = x + maxRadius;
		int cy = y + maxRadius;

		for (int r = maxRadius; r > 0; r -= 10) {
			Ellipse(hdc, cx - r, cy - r, cx + r, cy + r);
		}

		SelectObject(hdc, oldBrush);
		SelectObject(hdc, oldPen);
		DeleteObject(brush);
		DeleteObject(pen);

		x += incrementor * xx;
		y += incrementor * yy;

		if (y >= h - maxRadius * 2) { yy = -1; }
		if (x >= w - maxRadius * 2) { xx = -1; }
		if (y <= 0) { yy = 2; }
		if (x <= 0) { xx = 2; }

		ReleaseDC(0, hdc);
		Sleep(10);
	}
	return 0;
}

DWORD WINAPI shader1(LPVOID lpvd) { //credits to simpleemarie
	HDC hdcScreen = GetDC(0), hdcMem = CreateCompatibleDC(hdcScreen);
	INT w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	BITMAPINFO bmi = { 0 };
	PRGBQUAD rgbScreen = { 0 };
	bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
	bmi.bmiHeader.biBitCount = 32;
	bmi.bmiHeader.biPlanes = 1;
	bmi.bmiHeader.biWidth = w;
	bmi.bmiHeader.biHeight = h;
	HBITMAP hbmTemp = CreateDIBSection(hdcScreen, &bmi, NULL, (void**)&rgbScreen, NULL, NULL);
	SelectObject(hdcMem, hbmTemp);

	for (;;) {
		hdcScreen = GetDC(0);
		BitBlt(hdcMem, 0, 0, w, h, hdcScreen, 0, 0, SRCCOPY);
		for (INT i = 0; i < w * h; i++) {
			INT x = i % w, y = i / w;
			int average = round((float)(rgbScreen[i].b + rgbScreen[i].r + rgbScreen[i].g) / 10);
			rgbScreen[i].r = average + x;
			rgbScreen[i].r = average + y;
			rgbScreen[i].b = average + x;
			rgbScreen[i].rgb -= x;
		}
		BitBlt(hdcScreen, 0, 0, w, h, hdcMem, 0, 0, SRCCOPY);
		ReleaseDC(NULL, hdcScreen); DeleteDC(hdcScreen);
	}

	Sleep(10);
}

DWORD WINAPI shader2(LPVOID lpParam) {
    int sw = GetSystemMetrics(0);
    int sh = GetSystemMetrics(1);
    float radius = 0.f;
    double angle = 0;

    while (1) {
        HDC hdc = GetDC(0);
        float x = (float)(cos(angle) * radius);
        float y = (float)(sin(angle) * radius);

        StretchBlt(hdc, (int)x, (int)y, sw - (int)x * 2, sh - (int)y * 2,
            hdc, 0, 0, sw, sh, SRCCOPY);

        radius += 0.1f;
        ReleaseDC(0, hdc);
        angle = fmod(angle + PI / radius, PI * radius) / 1.001;
    }
    
	
	return 0;
}

DWORD WINAPI shader3(LPVOID lpParam) {
	int time = GetTickCount();
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	RGBQUAD* data = (RGBQUAD*)VirtualAlloc(0, (w * h + w) * sizeof(RGBQUAD), MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
	for (int i = 0;; i++, i %= 3) {
		HDC desk = GetDC(NULL);
		HDC hdcdc = CreateCompatibleDC(desk);
		HBITMAP hbm = CreateBitmap(w, h, 1, 32, data);
		SelectObject(hdcdc, hbm);
		BitBlt(hdcdc, 0, 0, w, h, desk, 0, 0, SRCCOPY);
		GetBitmapBits(hbm, w * h * 4, data);
		int v = 0;
		BYTE byte = 0;
		if ((GetTickCount() - time) > 60000)
			byte = rand() % 0xff;
		for (int i = 0; w * h > i; i++) {
			if (i % h && rand() % 110)
				v = rand() % 2;
			*((BYTE*)data + 4 * i + v) = i;
		}
		SetBitmapBits(hbm, w * h * 4, data);
		BitBlt(desk, 0, 0, w, h, hdcdc, 0, 0, NOTSRCERASE);
		DeleteObject(hbm);
		DeleteObject(hdcdc);
		DeleteObject(desk);
	}
	return 0;
}

DWORD WINAPI shader4(LPVOID lpvd)
{
	HDC hdc = GetDC(NULL);
	HDC hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(0);
	int h = GetSystemMetrics(1);
	BITMAPINFO bmpi = { 0 };
	HBITMAP bmp;

	bmpi.bmiHeader.biSize = sizeof(bmpi);
	bmpi.bmiHeader.biWidth = w;
	bmpi.bmiHeader.biHeight = h;
	bmpi.bmiHeader.biPlanes = 1;
	bmpi.bmiHeader.biBitCount = 32;
	bmpi.bmiHeader.biCompression = BI_RGB;

	RGBQUAD* rgbquad = NULL;
	HSL hslcolor;

	bmp = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
	SelectObject(hdcCopy, bmp);

	INT i = 0;

	while (1)
	{
		hdc = GetDC(NULL);
		StretchBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, w, h, SRCCOPY);

		RGBQUAD rgbquadCopy;

		for (int x = 0; x < w; x++)
		{
			for (int y = 0; y < h; y++)
			{
				int index = y * w + x;

				int fx = (int)((x ^ y) * ((x & y) -5));

				rgbquad[index].rgbRed += fx;
				rgbquad[index].rgbGreen += fx;
				rgbquad[index].rgbBlue += fx;
			}
		}

		i++;
		StretchBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, w, h, SRCCOPY);
		ReleaseDC(NULL, hdc); DeleteDC(hdc);
	}

	return 0x00;
}

VOID WINAPI ci2(int x, int y, int w, int h)
{
	HDC hdc = GetDC(0);

	int cx = x + w / 2;
	int cy = y + h / 2;
	int rx = w / 2;
	int ry = h / 2;

	POINT pts[8];
	for (int i = 0; i < 8; i++) {
		double a = (3.14159265358979323846 / 4.0) * i;
		pts[i].x = cx + (int)(rx * cos(a));
		pts[i].y = cy + (int)(ry * sin(a));
	}

	HRGN hrgn = CreatePolygonRgn(pts, 8, WINDING);
	SelectClipRgn(hdc, hrgn);
	HBRUSH brush = CreateSolidBrush(RGB(rand() % 255, rand() % 255, rand() % 255));
	SelectObject(hdc, brush);
	BitBlt(hdc, x, y, w, h, hdc, x, y, 0x2837E28);
	DeleteObject(hrgn);
	DeleteObject(brush);
	ReleaseDC(NULL, hdc);
}

DWORD WINAPI wef(LPVOID lpParam) {
	RECT rect;
	GetWindowRect(GetDesktopWindow(), &rect);
	int w = rect.right - rect.left - 500, h = rect.bottom - rect.top - 500;

	for (int t = 0;; t++)
	{
		const int size = 1000;
		int x = rand() % (w + size) - size / 2, y = rand() % (h + size) - size / 2;

		for (int i = 0; i < size; i += 100)
		{
			ci2(x - i / 2, y - i / 2, i, i);
		}
		Sleep(20);
	}
}

DWORD WINAPI shader5(LPVOID lpvd)
{
	HDC hdc = GetDC(NULL);
	HDC hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(0);
	int h = GetSystemMetrics(1);
	BITMAPINFO bmpi = { 0 };
	HBITMAP bmp;

	bmpi.bmiHeader.biSize = sizeof(bmpi);
	bmpi.bmiHeader.biWidth = w;
	bmpi.bmiHeader.biHeight = h;
	bmpi.bmiHeader.biPlanes = 1;
	bmpi.bmiHeader.biBitCount = 32;
	bmpi.bmiHeader.biCompression = BI_RGB;

	RGBQUAD* rgbquad = NULL;
	HSL hslcolor;

	bmp = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
	if (!bmp) { ReleaseDC(NULL, hdc); DeleteDC(hdcCopy); return 0; }
	SelectObject(hdcCopy, bmp);

	INT i = 0;

	while (1)
	{
		hdc = GetDC(NULL);
		StretchBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, w, h, SRCCOPY);

		RGBQUAD rgbquadCopy;

		for (int x = 0; x < w; x++)
		{
			for (int y = 0; y < h; y++)
			{
				int index = y * w + x;

				int cx = x - (w / 2);
				int cy = y - (h / 2);
				int fx = (int)((cx ^ cy) ^ ((cx & cy) << 1) ^ ((cx | cy) >> 2) + (i * ((cx ^ cy) & 7)));

				rgbquadCopy = rgbquad[index];

				hslcolor = Colors::rgb2hsl(rgbquadCopy);
				hslcolor.h = fmod(fx / 300.f + y / h * .1f, 1.f);

				rgbquad[index] = Colors::hsl2rgb(hslcolor);
			}
		}

		i++;
		StretchBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, w, h, SRCCOPY);
		ReleaseDC(NULL, hdc); DeleteDC(hdc);
	}

	DeleteObject(bmp);
	DeleteDC(hdcCopy);
	ReleaseDC(0, hdc);
	return 0x00;
}

DWORD WINAPI blur1(LPVOID lpvd)
{
	HDC hdc = GetDC(NULL);
	HDC hdcCopy = CreateCompatibleDC(hdc);
	RECT rekt;
	POINT wPt[3];
	int w = GetSystemMetrics(0);
	int h = GetSystemMetrics(1);

	BITMAPINFO bmpi = { 0 };
	BLENDFUNCTION blur;
	HBITMAP bmp;

	bmpi.bmiHeader.biSize = sizeof(bmpi);
	bmpi.bmiHeader.biWidth = w;
	bmpi.bmiHeader.biHeight = h;
	bmpi.bmiHeader.biPlanes = 1;
	bmpi.bmiHeader.biBitCount = 32;
	bmpi.bmiHeader.biCompression = BI_RGB;

	bmp = CreateDIBSection(hdc, &bmpi, 0, 0, NULL, 0);
	SelectObject(hdcCopy, bmp);

	blur.BlendOp = AC_SRC_OVER;
	blur.BlendFlags = 0;
	blur.AlphaFormat = 0;
	blur.SourceConstantAlpha = 10;

	while (1) {
		hdc = GetDC(NULL);
		GetWindowRect(GetDesktopWindow(), &rekt);
		wPt[0].x = rand() % w; wPt[0].y = rand() % h;
		wPt[1].x = rand() % w; wPt[1].y = rand() % h;
		wPt[2].x = rand() % w; wPt[2].y = rand() % h;
		PlgBlt(hdcCopy, wPt, hdc, rekt.left, rekt.top, rekt.right - rekt.left, rekt.bottom - rekt.top, 0, 0, 0);
		AlphaBlend(hdc, 0, 0, w, h, hdcCopy, 0, 0, w, h, blur);
		ReleaseDC(0, hdc);
		Sleep(1);
	}

	DeleteObject(bmp);
	DeleteDC(hdcCopy);
	return 0x00;
}

DWORD WINAPI textout(LPVOID lpvd)
{
	HDC hdc;
	HFONT hfnt;
	int sw, sh;
	while (true)
	{
		hdc = GetDC(0);
		sw = GetSystemMetrics(0), sh = GetSystemMetrics(1);
		hfnt = CreateFont(10 + rand() % 40, 10 + rand() % 40, 0, 0, FW_NORMAL, false, false, false, ANSI_CHARSET, 0, 0, 0, 0, L"System");
		LPCSTR lpSystemStrings[6] = { "3h9dojwh6g.exe", "by Timflyyy", "err...", "nothing there", "Loser", "Blue...blue livka?" };
		int SystemStringCount = rand() % 6;
		SelectObject(hdc, hfnt);
		SetTextColor(hdc, RndRGB);
		SetBkColor(hdc, RndRGB);
		SetBkMode(hdc, OPAQUE);
		TextOutA(hdc, rand() % sw, rand() % sh, lpSystemStrings[SystemStringCount], strlen(lpSystemStrings[SystemStringCount]));
		DeleteObject(hfnt);
		ReleaseDC(NULL, hdc);
		Sleep(10);
	}
}

DWORD WINAPI shader7(LPVOID lpParam) {
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	_RGBQUAD* data = (_RGBQUAD*)VirtualAlloc(0, (w * h + w) * sizeof(_RGBQUAD), MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
	for (int i = 0;; i++, i %= 3) {
		HDC desk = GetDC(NULL);
		HDC hdcdc = CreateCompatibleDC(desk);
		HBITMAP hbm = CreateBitmap(w, h, 1, 32, data);
		SelectObject(hdcdc, hbm);
		BitBlt(hdcdc, 0, 0, w, h, desk, 0, 0, SRCCOPY);
		GetBitmapBits(hbm, w * h * 4, data);
		for (int i = 0; i < w * h; i++) {
			int x = i % w, y = i / h;
			data[i].rgb -= (data[i].rgb & rand()) ^ x & y;
		}
		SetBitmapBits(hbm, w * h * 4, data);
		BitBlt(desk, 0, 0, w, h, hdcdc, 0, 0, SRCCOPY);
		DeleteObject(hbm);
		DeleteObject(hdcdc);
		DeleteObject(desk);
	}
	return 0;
}

DWORD WINAPI train(LPVOID lpParam) {//thanks to LambdaTechnology
	HDC hdc = GetDC(0);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	while (true)
	{
		for (int angle = 0; angle < 720; angle++) {
			int x = (-100) * cos(angle * PI / 180.F), y = (-100) * sin(angle * PI / 180.F);
			hdc = GetDC(0);
			train_function(hdc, w, h, x, y, SRCCOPY);
			ReleaseDC(0, hdc);
			Sleep(1);
		}
	}
}

DWORD WINAPI shader8(LPVOID lpParam) {
	int time = GetTickCount();
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	RGBQUAD* data = (RGBQUAD*)VirtualAlloc(0, (w * h + w) * sizeof(RGBQUAD), MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
	for (int i = 0;; i++, i %= 3) {
		HDC desk = GetDC(NULL);
		HDC hdcdc = CreateCompatibleDC(desk);
		HBITMAP hbm = CreateBitmap(w, h, 1, 32, data);
		SelectObject(hdcdc, hbm);
		BitBlt(hdcdc, 0, 0, w, h, desk, 0, 0, SRCCOPY);
		GetBitmapBits(hbm, w * h * 4, data);
		int v = 0;
		BYTE byte = 0;
		if ((GetTickCount() - time) > 60000)
			byte = rand() % 0xff;
		for (int i = 0; w * h > i; i++) {
			if (i % h == 0 && rand() % 100 == 0)
				v = rand() % 2;
			*((BYTE*)data + 4 * i + v) = *((BYTE*)(data + i + v));
		}
		SetBitmapBits(hbm, w * h * 4, data);
		BitBlt(desk, 0, 0, w, h, hdcdc, 0, 0, SRCCOPY);
		DeleteObject(hbm);
		DeleteObject(hdcdc);
		DeleteObject(desk);
	}
	return 0;
}

DWORD WINAPI shader9(LPVOID lpParam) {
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	_RGBQUAD* data = (_RGBQUAD*)VirtualAlloc(0, (w * h + w) * sizeof(_RGBQUAD), MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
	if (!data) return 0;
	for (int i = 0;; i++, i %= 3) {
		HDC desk = GetDC(NULL);
		HDC hdcdc = CreateCompatibleDC(desk);
		HBITMAP hbm = CreateBitmap(w, h, 1, 32, data);
		SelectObject(hdcdc, hbm);
		BitBlt(hdcdc, 0, 0, w, h, desk, 0, 0, SRCCOPY);
		GetBitmapBits(hbm, w * h * 4, data);
		for (int j = 0; j < w * h; j++) {
			int x = j % w, y = j / w;
			int fx = ((x ^ y) + ((x & y) << 1) + ((x | y) >> 2) + i * 3);
			BYTE g = (BYTE)(fx & 0xFF);
			data[j].r = 0;
			data[j].g = g;
			data[j].b = 0;
		}
		SetBitmapBits(hbm, w * h * 4, data);
		BitBlt(desk, 0, 0, w, h, hdcdc, 0, 0, SRCCOPY);
		DeleteObject(hbm);
		DeleteObject(hdcdc);
		DeleteObject(desk);
	}
	return 0;
}


DWORD WINAPI ship(LPVOID lpvd)
{
	HDC hdc = GetDC(NULL);
	HDC hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(0);
	int h = GetSystemMetrics(1);
	BITMAPINFO bmpi = { 0 };
	HBITMAP bmp;

	bmpi.bmiHeader.biSize = sizeof(bmpi);
	bmpi.bmiHeader.biWidth = w;
	bmpi.bmiHeader.biHeight = h;
	bmpi.bmiHeader.biPlanes = 1;
	bmpi.bmiHeader.biBitCount = 32;
	bmpi.bmiHeader.biCompression = BI_RGB;

	RGBQUAD* rgbquad = NULL;
	HSL hslcolor;

	bmp = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
	if (!bmp) { ReleaseDC(NULL, hdc); DeleteDC(hdcCopy); return 0; }
	SelectObject(hdcCopy, bmp);

	INT i = 0;

	while (1)
	{
		hdc = GetDC(NULL);
		StretchBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, w, h, SRCCOPY);

		RGBQUAD rgbquadCopy;

		for (int x = 0; x < w; x++)
		{
			for (int y = 0; y < h; y++)
			{
				int index = y * w + x;

				double fractalX = (3.5f / w);
				double fractalY = (2.0f / h);

				double cx = x * fractalX - 2.5f;
				double cy = y * fractalY - 1.0f;

				double zx = 0;
				double zy = 0;

				int fx = 0;

				while (((zx * zx) + (zy * zy)) < 4.0 && fx < 50)
				{
					double ax = fabs(zx);
					double ay = fabs(zy);
					double fczx = ax * ax - ay * ay + cx;
					double fczy = 2 * ax * ay + cy;

					zx = fczx;
					zy = fczy;
					fx++;

					rgbquadCopy = rgbquad[index];

					hslcolor = Colors::rgb2hsl(rgbquadCopy);
					hslcolor.h = fmod(fx / 300.f + y / h * .1f, 1.f);

					rgbquad[index] = Colors::hsl2rgb(hslcolor);
				}
			}
		}

		i++;
		StretchBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, w, h, NOTSRCERASE);
		ReleaseDC(NULL, hdc); DeleteDC(hdc);
	}

	return 0x00;
}