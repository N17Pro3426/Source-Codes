#include <windows.h>
#include <tchar.h>
#include <vector>
#include <random>
#include <cmath>
#include <atomic>
#include <thread>
#include <memory>
#define PI 3.14159265358979323846264338327950288
short int SHD = 1; //Which Pattern the HSV Shader Should Render
bool ExT = 1; //Exit Payloads
bool AExT = 1; //Exit More Payloads
std::atomic<bool> VExT = 1; //Exit HSV Payloads

/*

Note:
1. When Compiling, its Recomended to Set to Highest Optimization Settings in Compiler.
2. Anything NOT EXPLAINED IN CHANGES MEANS ITS FROM ORIGINAL APPLICATION.
3. THE ERROR IN fake() THREAD IS OBVIOUSLY FAKE.
4. ORIGINAL APPLICATION IS NOT CREATED BY ME.

Changes:
1. PRGBTRIPLE REMOVED FROM SHADER2 THREAD (Compatiblity Issues, but Barely Much have Visual Difference when Combo with Patblt).

2. SHADER EFFICIENCY HAS BEEN INCREASED:
2.1: Different Efficienct Value Converters (Complex HSL to RGB or vice versa has been Replaced by Efficient HSV Converters).
2.2: Multi-thread has been Added! (Atomic, thread, Memory).
2.3: Added Hue-less HSV Converter.

3. Instead of Random Number Strings (String()), its just Empty String.

4. Option to Disable Noises.

5. DRY (Don't Repeat Yourself) Optimization Added!

*/

inline float Fsin(float x) {
    // Fast sine approximation with reduced operations
    x = fmodf(x + PI, 2 * PI) - PI;
    const float B = 4 / PI;
    const float C = -4 / (PI * PI);
    
    float y = B * x + C * x * fabsf(x);
    return 0.225f * (y * fabsf(y) - y) + y; // Folded P into the return
}

typedef struct {
    FLOAT h, s, v;
} HSV;

inline HSV rgb2hsv(const RGBQUAD& rgb) {
    // Precompute normalized values with integer math where possible
    constexpr double inv255 = 1.0 / 255.0;
    const double rd = rgb.rgbRed * inv255, gd = rgb.rgbGreen * inv255, bd = rgb.rgbBlue * inv255;

    HSV hsv;
    
    // Find min/max using branchless approach
    const double maxVal = (rd > gd) ? (rd > bd ? rd : bd) : (gd > bd ? gd : bd);
    const double minVal = (rd < gd) ? (rd < bd ? rd : bd) : (gd < bd ? gd : bd);
    
    hsv.v = maxVal;
    const double delta = maxVal - minVal;
    
    if (delta <= 0.0) {
        hsv.h = 0.0;
        hsv.s = 0.0;
        return hsv;
    }
    
    hsv.s = (maxVal > 0.0) ? (delta / maxVal) : 0.0;
    
    // Calculate hue with optimized branching
    if (maxVal == rd) {
        hsv.h = ((gd - bd) / delta) * 60.0;
    } else if (maxVal == gd) {
        hsv.h = ((bd - rd) / delta + 2.0) * 60.0;
    } else {
        hsv.h = ((rd - gd) / delta + 4.0) * 60.0;
    }
    
    // Branchless normalization
    hsv.h += (hsv.h < 0.0) ? 360.0 : 0.0;
    
    return hsv;
}

// Optimized RGB to HSV conversion without hue calculation
inline HSV rgb2hsvNh(const RGBQUAD& rgb) {
    double rd = rgb.rgbRed / 255.0;
    double gd = rgb.rgbGreen / 255.0;
    double bd = rgb.rgbBlue / 255.0;

    HSV hsv; hsv.h = 0;
        
    // Find min/max using branchless approach
    const double maxVal = (rd > gd) ? (rd > bd ? rd : bd) : (gd > bd ? gd : bd);
    const double minVal = (rd < gd) ? (rd < bd ? rd : bd) : (gd < bd ? gd : bd);
    
    hsv.v = maxVal;
    const double delta = maxVal - minVal;
    
    if (delta <= 0.0) {
        hsv.h = 0.0;
        hsv.s = 0.0;
        return hsv;
    }
    
    hsv.s = (maxVal > 0.0) ? (delta / maxVal) : 0.0;

	return hsv;	
}


inline HSV rgb2hsvOLD(const RGBQUAD& rgb) {
    double rd = rgb.rgbRed / 255.0;
    double gd = rgb.rgbGreen / 255.0;
    double bd = rgb.rgbBlue / 255.0;

    HSV hsv;
    double maxVal = fmax(rd, fmax(gd, bd)); //std::max(rd, std::max(gd, bd));
    double minVal = fmin(rd, fmin(gd, bd)); //std::min(rd, std::min(gd, bd));

    hsv.v = maxVal;
    double delta = maxVal - minVal;

    if (delta <= 0) {
        hsv.h = 0;
        hsv.s = 0;
        return hsv;
    } else {
        hsv.s = (maxVal > 0) ? (delta / maxVal) : 0;

        // Calculate hue
        if (maxVal == rd) {
            hsv.h = fmod((gd - bd) / delta, 6.0) * 60;
        } else if (maxVal == gd) {
            hsv.h = ((bd - rd) / delta + 2) * 60;
        } else {
            hsv.h = ((rd - gd) / delta + 4) * 60;
        }

        if (hsv.h < 0) hsv.h += 360;
    }

    return hsv;
}

// Optimized RGB to HSV conversion without hue calculation
inline HSV rgb2hsvNhOLD(const RGBQUAD& rgb) {
    double rd = rgb.rgbRed / 255.0;
    double gd = rgb.rgbGreen / 255.0;
    double bd = rgb.rgbBlue / 255.0;

    HSV hsv; hsv.h = 0;
    double maxVal = fmax(rd, fmax(gd, bd)); //std::max(rd, std::max(gd, bd));
    double minVal = fmin(rd, fmin(gd, bd)); //std::min(rd, std::min(gd, bd));

    hsv.v = maxVal;
    double delta = maxVal - minVal;

    hsv.s = delta <= 0 ? 0 : (maxVal > 0) ? (delta / maxVal) : 0;

	return hsv;	
}


// Optimized HSV to RGB conversion
inline RGBQUAD hsv2rgb(const HSV& hsv) {
    double s = hsv.s;
    double l = hsv.v * 255;
    BYTE v = round(l);
    if (s <= 0) { // Achromatic (gray)
        return { v, v, v, 0 };
    } else {
    	
    double h = hsv.h / 60; // Convert hue to [0, 6] (start from red to green to blue to red)
    BYTE i = static_cast<BYTE>(h);
    double f = h - i; // Fractional part of h
    BYTE p = round(l * (1 - s)); //BYTE because there is no more calculation and once it reaches rgb, it becomes BYTE.
    BYTE q = round(l * (1 - f * s)); //BYTE because there is no more calculation and once it reaches rgb, it becomes BYTE.
    BYTE t = round(l * (1 - (1 - f) * s)); //BYTE because there is no more calculation and once it reaches rgb, it becomes BYTE.

    	switch (i % 6) {
        	case 0: return {p, t, v, 0}; break;
        	case 1: return {p, v, q, 0}; break;
        	case 2: return {t, v, p, 0}; break;
        	case 3: return {v, q, p, 0}; break;
        	case 4: return {v, p, t, 0}; break;
        	case 5: return {q, p, v, 0}; break;
        	default: return {0, 0, 0, 0}; break; //fallback (not recomended to reach here but for handling issues)
    	}
	}
}

COLORREF RndRGB() {
    int clr = rand() % 5 + 1;
    switch (clr) {
    case 1: return RGB(255, 0, 0); break;
    case 2: return RGB(0, 255, 0); break;
    case 3: return RGB(0, 0, 255); break;
    case 4: return RGB(255, 0, 255); break;
    case 5: return RGB(255, 255, 0); break;
    default: return RGB(0, 0, 0); break;
	}
}

DWORD WINAPI shaderHSV(LPVOID) { //DRY optimization (Don't Repeat Yourself)
    const int width = GetSystemMetrics(SM_CXSCREEN);
    const int height = GetSystemMetrics(SM_CYSCREEN);
    
    // Initialize DCs and bitmap once
    HDC screenDC = GetDC(nullptr);
    HDC copyDC = CreateCompatibleDC(screenDC);
    BITMAPINFO bmpi = { sizeof(BITMAPINFOHEADER), width, -height, 1, 32, BI_RGB };
    
    RGBQUAD* rgbquad = nullptr;
    HBITMAP bmp = CreateDIBSection(screenDC, &bmpi, DIB_RGB_COLORS, reinterpret_cast<void**>(&rgbquad), nullptr, 0);
    if (!bmp || !rgbquad) {
        ReleaseDC(nullptr, screenDC);
        DeleteDC(copyDC);
        return 1;
    }
    
    SelectObject(copyDC, bmp);
    ReleaseDC(nullptr, screenDC);
    
    std::atomic<long> fc(0);
    const int numThreads = std::thread::hardware_concurrency();
    std::vector<std::thread> threads;
    threads.reserve(numThreads);
    
    while (VExT.load(std::memory_order_relaxed)) {
        screenDC = GetDC(nullptr);
        if (!screenDC) continue;
        
        if (BitBlt(copyDC, 0, 0, width, height, screenDC, 0, 0, SRCCOPY)) {
            const int rowsPerThread = height / numThreads;
            const long currentFc = fc.load(std::memory_order_relaxed);
            
            // Process rows in parallel
            for (int i = 0; i < numThreads; ++i) {
                const int startRow = i * rowsPerThread;
                const int endRow = (i == numThreads - 1) ? height : (startRow + rowsPerThread);
                
            	switch(SHD) {
				case 2: {
                	threads.emplace_back([=, &rgbquad] { for (int y = startRow; y < endRow; ++y) {
                        RGBQUAD* rowStart = rgbquad + y * width;
                        for (int x = 0; x < width; ++x) {
                            HSV currentHsv = rgb2hsvNh(rowStart[x]);
                            currentHsv.h = fmodf((((y + (currentFc * 4)) ^ (x - y)) / 600.0 + y / height ) * 72.f, 360.0);
                            rowStart[x] = hsv2rgb(currentHsv);
                        } } });
					break;
					}
				case 3: {
                	threads.emplace_back([=, &rgbquad] { for (int y = startRow; y < endRow; ++y) {
                        RGBQUAD* rowStart = rgbquad + y * width;
                        for (int x = 0; x < width; ++x) {
                            HSV currentHsv = rgb2hsvNh(rowStart[x]);
                            currentHsv.h = fmodf(((x&y)^(x+y)) * currentFc / 200.0, 360.0);
                            rowStart[x] = hsv2rgb(currentHsv);
                        } } });
					break;
					}
                default: {
                	threads.emplace_back([=, &rgbquad] { for (int y = startRow; y < endRow; ++y) {
                        RGBQUAD* rowStart = rgbquad + y * width;
                        for (int x = 0; x < width; ++x) {
                            HSV currentHsv = rgb2hsvNh(rowStart[x]);
                            currentHsv.h = fmodf((((currentFc ^ 4) + (currentFc * 4) * sqrt(y ^ x * currentFc)) / 600.0f + y / static_cast<float>(height)) * 72.0f, 360.0f);
                            rowStart[x] = hsv2rgb(currentHsv);
                        } } });
					break;
					}
            	}
        	}
            
            // Wait for all threads
            for (auto& thread : threads) {
                thread.join();
            }
            threads.clear();
            
            if (BitBlt(screenDC, 0, 0, width, height, copyDC, 0, 0, SRCCOPY)) {
                Sleep(6);
                fc.fetch_add(1, std::memory_order_relaxed);
            }
        }
        ReleaseDC(nullptr, screenDC);
    }
    
    DeleteObject(bmp);
    DeleteDC(copyDC);
    return 0;
}


DWORD WINAPI swirl(LPVOID lpParam) {
    const int sw = GetSystemMetrics(0), sh = GetSystemMetrics(1);
    const int xSize = sh / 10;
    const int ySize = 9;
    const float invXSize = 1.0f / xSize;
    
    // Pre-calculate wave patterns
    std::vector<int> horizontalWaves(sw);
    std::vector<int> verticalWaves(sh);
    
    for (int i = 0; i < sw; ++i) {
        horizontalWaves[i] = Fsin(i * invXSize * M_PI) * ySize;
    }
    for (int i = 0; i < sh; ++i) {
        verticalWaves[i] = Fsin(i * invXSize * M_PI) * ySize;
    }
    
    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_int_distribution<> dist(0, 255);
    
    HDC hdc = GetDC(0);
    HDC hdcMem = CreateCompatibleDC(hdc);
    HBITMAP screenshot = CreateCompatibleBitmap(hdc, sw, sh);
    SelectObject(hdcMem, screenshot);
    
    while (ExT) {
        hdc = GetDC(0);
        HBRUSH brush = CreateSolidBrush(RGB(dist(gen), dist(gen), dist(gen)));
        SelectObject(hdc, brush);
        SelectObject(hdcMem, brush);
        
        BitBlt(hdcMem, 0, 0, sw, sh, hdc, 0, 0, 11272462);
        
        // Horizontal waves using pre-calculated values
        for (int i = 0; i < sw; ++i) {
            HBRUSH brush = CreateSolidBrush(RGB(dist(gen), dist(gen), dist(gen)));
            SelectObject(hdcMem, brush);
            BitBlt(hdcMem, i, 0, 1, sh, hdcMem, i, horizontalWaves[i], 11272462);
            DeleteObject(brush);
        }
        
        // Vertical waves using pre-calculated values
        for (int i = 0; i < sh; ++i) {
            HBRUSH brush = CreateSolidBrush(RGB(dist(gen), dist(gen), dist(gen)));
            SelectObject(hdcMem, brush);
            BitBlt(hdcMem, 0, i, sw, 1, hdcMem, verticalWaves[i], i, 11272462);
            DeleteObject(brush);
        }
        
        BitBlt(hdc, 0, 0, sw, sh, hdcMem, 0, 0, 11272462);
        DeleteObject(brush);
        ReleaseDC(0, hdc);
    }
    
    DeleteDC(hdc); 
    DeleteDC(hdcMem); 
    DeleteObject(screenshot);
    return 0;
}

/*DWORD WINAPI swirl(LPVOID lpParam) {
    const int sw = GetSystemMetrics(0), sh = GetSystemMetrics(1);
    int xSize = sh / 10, ySize = 9;
    while (true) {
        HDC hdc = GetDC(0);
        HDC hdcMem = CreateCompatibleDC(hdc);
        HBITMAP screenshot = CreateCompatibleBitmap(hdc, sw, sh);
        SelectObject(hdcMem, screenshot);
        HBRUSH brush = CreateSolidBrush(RGB(rand() % 255, rand() % 255, rand() % 255));
        SelectObject(hdc, brush);
        SelectObject(hdcMem, brush);
        BitBlt(hdcMem, 0, 0, sw, sh, hdc, 0, 0, 0x1900AC010E);
        for (int i = 0; i < sh * 2; ++i) {
            int wave = sinf(i / float(xSize) * PI) * ySize;
            HBRUSH brush = CreateSolidBrush(RGB(rand() % 255, rand() % 255, rand() % 255));
            SelectObject(hdcMem, brush);
            BitBlt(hdcMem, i, 0, 1, sh, hdcMem, i, wave, 0x1900AC010E);
            DeleteObject(brush);
        }
        for (int i = 0; i < sw * 2; ++i) {
            int wave = sinf(i / float(xSize) * PI) * ySize;
            HBRUSH brush = CreateSolidBrush(RGB(rand() % 255, rand() % 255, rand() % 255));
            SelectObject(hdcMem, brush);
            BitBlt(hdcMem, 0, i, sw, 1, hdcMem, wave, i, 0x1900AC010E);
            DeleteObject(brush);
        }
        BitBlt(hdc, 0, 0, sw, sh, hdcMem, 0, 0, 0x1900AC010E);
        DeleteObject(brush);
        ReleaseDC(0, hdc);
        DeleteDC(hdc); DeleteDC(hdcMem); DeleteObject(screenshot);
    }
}//*/

DWORD WINAPI textout(LPVOID lpParam) {
    int w = GetSystemMetrics(0);
    int h = GetSystemMetrics(1);
    HDC hdc = GetDC(0);
    int thing;
	BitBlt(hdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
    while (true) {
        HDC hdc = GetDC(0);
        SetBkMode(hdc, 0);
        w = GetSystemMetrics(0), h = GetSystemMetrics(1);
        HFONT hfnt = CreateFontA(rand() % 50, rand() % 50, 0, 0, FW_THIN, 1, 0, 0, ANSI_CHARSET, 0, 0, 0, 0, "Fredoka");
        SelectObject(hdc, hfnt);
        LPCSTR things[] = {
            "csv", "Enjoy!", "This is Masterpiece!",
            "this is NOT the end!", "hello!"
        };
        thing = rand() % 5;
        SetTextColor(hdc, RndRGB());
        TextOutA(hdc, rand() % w, rand() % h, things[thing], strlen(things[thing]));
        DeleteObject(hfnt);
        ReleaseDC(0, hdc);
        Sleep(50);
    }
    return 0;
}

DWORD WINAPI shader2(LPVOID lpParam) {
    MessageBoxA(NULL, "Prgbtriple Does NOT EXIST, Good luck Dev-c++ Users (Including me). :) (You can Safely Compile it)", "Note", MB_YESNO);
    return 0;
}

DWORD WINAPI patblt(LPVOID lpParam) {
    while (ExT) {
        HDC hdc = GetDC(0);
        int w = GetSystemMetrics(0);
        int h = GetSystemMetrics(1);
        HBRUSH brush = CreateSolidBrush(RGB(rand() % 255, rand() % 255, rand() % 255));
        SelectObject(hdc, brush);
        BitBlt(hdc, 0, 0, w, h, hdc, 0, 0, PATINVERT);
        DeleteObject(brush);
        ReleaseDC(0, hdc);
        Sleep(10);
    }
    return 0;
}

DWORD WINAPI pixels(LPVOID lpvd) {
    HDC hdc = GetDC(0);
    HDC mdc = CreateCompatibleDC(hdc);
    int w = GetSystemMetrics(0);
    int h = GetSystemMetrics(1);
    HBITMAP hbit = CreateCompatibleBitmap(hdc, w, h);
    SelectObject(mdc, hbit);
    while (AExT) {
        hdc = GetDC(0);
        SetStretchBltMode(mdc, COLORONCOLOR);
        SetStretchBltMode(hdc, COLORONCOLOR);
        StretchBlt(mdc, 0, 0, w / 9, h / 9, hdc, 0, 0, w, h, SRCCOPY);
        StretchBlt(hdc, 0, 0, w, h, mdc, 0, 0, w / 9, h / 9, SRCCOPY);
        ReleaseDC(0, hdc);
        Sleep(10);
    }
    return 0;
}

DWORD WINAPI lines(LPVOID lpParam) {
    while (AExT) {
        HDC hdc = GetDC(0);
        int w = GetSystemMetrics(0);
        int h = GetSystemMetrics(1);
        LineTo(hdc, rand() % (0 - w), 0);
        LineTo(hdc, rand() % (0 - w), h);
        Sleep(10);
        ReleaseDC(0, hdc);
    }
    return 0;
}

DWORD WINAPI shader4(LPVOID lpParam) {
    int ticks = GetTickCount();
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    RGBQUAD* data = (RGBQUAD*)VirtualAlloc(0, (w * h + w) * sizeof(RGBQUAD), MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
    while (ExT) {
        for (int c = 0; c < 100; c++) InvalidateRect(0, 0, 0);
        HDC hdc = GetDC(0);
        HDC hdcMem = CreateCompatibleDC(hdc);
        HBITMAP hbm = CreateBitmap(w, h, 1, 32, data);
        SelectObject(hdcMem, hbm);
        BitBlt(hdcMem, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        GetBitmapBits(hbm, w * h * 4, data);
        int v = 0; BYTE bt = 0;
        if ((GetTickCount() - ticks) > 60000)
            bt = 2 + rand() & 255;
        for (int i = 1; w * h > i; i++) {
            if (i % h == 0 && rand() % 100 == 0)
                v = 3 + rand() % 50;
            ((BYTE*)(data + i))[v % 3] += ((BYTE*)(data + bt))[bt] ^ i;
        }
        SetBitmapBits(hbm, w * h * 4, data);
        BitBlt(hdc, 0, 0, w, h, hdcMem, 0, 0, SRCCOPY);
        DeleteObject(hbm);
        DeleteObject(hdcMem);
        DeleteObject(hdc);
        ReleaseDC(0, hdc);
    }
    return 0;
}

VOID WINAPI sound(BYTE MD, DWORD SMPLRT) { //DRY optimization (Don't Repeat Yourself)
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, SMPLRT, SMPLRT, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[SMPLRT * 30] = {};
    switch (MD) {
    case 1: { for (unsigned int t = 0; t < sizeof(buffer); ++t) buffer[t] = static_cast<char>(t ^ t >> 8 - t ^ t >> 5 - t ^ t << 4); break; }
    case 2: { for (unsigned int t = 0; t < sizeof(buffer); ++t) buffer[t] = static_cast<char>(127 * ((t ^ t >> 12) * t >> 8)); break; }
    case 3: { for (unsigned int t = 0; t < sizeof(buffer); ++t) buffer[t] = static_cast<char>(t * (t >> 1 & t >> 8 & 73 & t >> 3)); break; }
    case 4: { for (unsigned int t = 0; t < sizeof(buffer); ++t) buffer[t] = static_cast<char>(t >> t / ((t >> 12 & 3) + 6)); break; }
    case 5: { for (unsigned int t = 0; t < sizeof(buffer); ++t) buffer[t] = static_cast<char>(((t ^ t >> 7) * (t | t >> 9) + (t | t << 9) + (t | t >> 5)) / 1000); break; }
    case 6: { for (unsigned int t = 0; t < sizeof(buffer); ++t) buffer[t] = static_cast<char>((t>>12&t/4*5)|(t>>10&t)|(t>>6&t/2*3)); break; }
    default: { for (unsigned int t = 0; t < sizeof(buffer); ++t) buffer[t] = static_cast<char>(0); break; }
	}

    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}

DWORD WINAPI fake(LPVOID lpParam) {
    MessageBoxW(NULL, L"Fatal error: 0x083420uf", L"Windows", MB_ICONERROR);
    return 0;
}

DWORD WINAPI msg(LPVOID lpParam) {
    while (true) {
        MessageBoxA(NULL, "...", "csv", MB_ICONERROR);
    }
    return 0;
}

DWORD WINAPI cur1(LPVOID lpParam) {
    while (true) {
        POINT cpt;
        GetCursorPos(&cpt);
        int x = cpt.x, y = cpt.y;
        SetCursorPos(x + rand() % 2 + rand() % 2, y + rand() % 2 + rand() % 2);
        Sleep(10);
        SetCursorPos(x - rand() % 2 + rand() % 2, y - rand() % 2 + rand() % 2);
        Sleep(10);
    }
}

DWORD WINAPI mvE(LPVOID lpParam) {
    const int sw = GetSystemMetrics(0), sh = GetSystemMetrics(1);
    HDC hdc = GetDC(0);
    HDC hdcMem = CreateCompatibleDC(hdc);
    HBITMAP screenshot = CreateCompatibleBitmap(hdc, sw, sh);
    SelectObject(hdcMem, screenshot);    
    while (ExT) {
        hdc = GetDC(0);
        BitBlt(hdcMem, 0, 0, sw, sh, hdc, 0, 0, SRCCOPY);
        	for (int i = 0; i < 10; ++i) {
        		int RH = rand()%sh; int RW = rand()%sw;
				BitBlt(hdcMem, rand()%15, RH, sw, sh-RH, hdcMem, rand()%15, RH, SRCCOPY);
				BitBlt(hdcMem, RW, rand()%15, sw-RW, sh, hdcMem, RW, rand()%15, SRCCOPY);
        	}
        BitBlt(hdc, 0, 0, sw, sh, hdcMem, 0, 0, SRCCOPY);
        ReleaseDC(0, hdc);
        Sleep(6);
    }
    DeleteDC(hdc); 
    DeleteDC(hdcMem); 
    DeleteObject(screenshot);
    return 0;
}

VOID WINAPI ExtPyLd() {
    VExT = 0; ExT = 0; Sleep(50); InvalidateRect(0, 0, 0); Sleep(100); VExT = 1; ExT = 1;
}

VOID WINAPI ExtMrPyLd() {
    VExT = 0; ExT = 0; AExT = 0; Sleep(50); InvalidateRect(0, 0, 0); Sleep(100); VExT = 1; ExT = 1; AExT = 1;
}

int WINAPI WinMain(HINSTANCE a, HINSTANCE b, LPSTR c, int d) {
    if (MessageBoxW(NULL, L"Warning! This is a Safe GDI App, But has Flashy Effect. Are you sure you want to run this?", L"csv Rewritten", MB_YESNO | MB_ICONEXCLAMATION) == IDNO) {
        ExitProcess(0);
    }
    else {
        if (MessageBoxW(NULL, L"Note! This is Not Malicious, Simply for entertainment and educational purposes. Are you sure you want to continue? Its Safe to Run it.", L"csv Rewritten", MB_YESNO | MB_ICONEXCLAMATION) == IDNO) {
            ExitProcess(0);
        }
        else {
        	bool Sound;
        	if (MessageBoxW(NULL, L"Disable Sound?", L"csv Rewritten", MB_YESNO | MB_ICONEXCLAMATION) == IDNO) {
        	Sound = 1;
			} else {
			Sound = 0;
			}
            CreateThread(0, 0, fake, 0, 0, 0);
            Sleep(4000);
            CreateThread(0, 0, msg, 0, 0, 0);
            Sleep(1000);
            if (Sound == 1) { sound(1, 24000); }
            SHD = 1; CreateThread(0, 0, shaderHSV, 0, 0, 0);
            Sleep(30000);
            ExtPyLd();
            if (Sound == 1) { sound(2, 24000); }
            CreateThread(0, 0, cur1, 0, 0, 0);
            CreateThread(0, 0, swirl, 0, 0, 0);
            CreateThread(0, 0, textout, 0, 0, 0);
            Sleep(30000);
            ExtPyLd();
            if (Sound == 1) { sound(3, 24000); }
            CreateThread(0, 0, patblt, 0, 0, 0);
            Sleep(30000);
            ExtPyLd();
            if (Sound == 1) { sound(4, 24000); }
            SHD = 2; CreateThread(0, 0, shaderHSV, 0, 0, 0);
            CreateThread(0, 0, pixels, 0, 0, 0);
            CreateThread(0, 0, lines, 0, 0, 0);
            Sleep(30000);
            ExtPyLd();
            if (Sound == 1) { sound(5, 24000); }
            CreateThread(0, 0, shader4, 0, 0, 0);
            Sleep(30000);
            ExtMrPyLd();
            if (Sound == 1) { sound(6, 32000); }
            CreateThread(0, 0, mvE, 0, 0, 0);
            SHD = 3; CreateThread(0, 0, shaderHSV, 0, 0, 0);
            Sleep(30000);
            ExtMrPyLd();
        }
    }
    return 0;
}//*/