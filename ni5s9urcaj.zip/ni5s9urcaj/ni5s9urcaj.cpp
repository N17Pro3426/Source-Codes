﻿#include"resource.h"
#include"def.h"
#include"sound.h"
#include"payload.h"
DWORD WINAPI error(LPVOID lpParam) {
	while (1) {
		MessageBox(NULL, L"Goodbye,N17Pro3426.", L"Damn", MB_ICONERROR);
	}
	return 0;
}
void mainpayloads() {
	Sleep(5000);
	CreateThread(0, 0, error, 0, 0, 0);
	Sleep(500);
	HANDLE thread1 = CreateThread(0, 0, shader1, 0, 0, 0);
	HANDLE thread1dot1 = CreateThread(0, 0, pie1, 0, 0, 0);
	sound1();
	TerminateThread(thread1, 0);
	InvalidateRect(0, 0, 0);
	HANDLE thread2 = CreateThread(0, 0, shader2, 0, 0, 0);
	sound2();
	TerminateThread(thread2, 0);
	InvalidateRect(0, 0, 0);
	HANDLE thread3 = CreateThread(0, 0, stretchblt1, 0, 0, 0);
	HANDLE thread3dot1 = CreateThread(0, 0, pie2, 0, 0, 0);
	sound3();
	TerminateThread(thread3, 0);
	TerminateThread(thread3dot1, 0);
	InvalidateRect(0, 0, 0);
	HANDLE thread4 = CreateThread(0, 0, shader3, 0, 0, 0);
	sound4();
	TerminateThread(thread4, 0);
	InvalidateRect(0, 0, 0);
	HANDLE thread5 = CreateThread(0, 0, shader4, 0, 0, 0);
	sound5();
	TerminateThread(thread5, 0);
	InvalidateRect(0, 0, 0);
	HANDLE thread6 = CreateThread(0, 0, shader5, 0, 0, 0);
	HANDLE thread6dot1 = CreateThread(0, 0, textout, 0, 0, 0);
	sound6();
	TerminateThread(thread6, 0);
	InvalidateRect(0, 0, 0);
	HANDLE thread7 = CreateThread(0, 0, shader6, 0, 0, 0);
	sound7();
	TerminateThread(thread7, 0);
	InvalidateRect(0, 0, 0);
	HANDLE thread8 = CreateThread(0, 0, pathell, 0, 0, 0);
	sound8();
	TerminateThread(thread8, 0);
	InvalidateRect(0, 0, 0);
	HANDLE thread9 = CreateThread(0, 0, blur1, 0, 0, 0);//<-----------
	sound9();                                           //           |
	Sleep(30000);                                       //           |
	TerminateThread(thread9, 0);                        //           |
	CloseHandle(thread9);                               //           |
	InvalidateRect(0, 0, 0);                            //           |
	HANDLE thread9dot1 = CreateThread(0, 0, blur2, 0, 0, 0);//<------------They are n0t b1urs i think
	Sleep(30000);
	TerminateThread(thread9dot1, 0);
	CloseHandle(thread9dot1);
	InvalidateRect(0, 0, 0);
	HANDLE thread10 = CreateThread(0, 0, moveing, 0, 0, 0);
	sound10();
	TerminateThread(thread10, 0);
	InvalidateRect(0, 0, 0);
	HANDLE thread11 = CreateThread(0, 0, screenwind, 0, 0, 0);
	sound11();
	TerminateThread(thread11, 0);
	InvalidateRect(0, 0, 0);
	HANDLE thread12 = CreateThread(0, 0, shader7, 0, 0, 0);
	sound12();
	TerminateThread(thread12, 0);
	InvalidateRect(0, 0, 0);
	HANDLE thread13 = CreateThread(0, 0, shader8, 0, 0, 0);
	sound13();
	TerminateThread(thread13, 0);
	InvalidateRect(0, 0, 0);
	HANDLE thread14 = CreateThread(0, 0, shader9, 0, 0, 0);
	sound14();
	TerminateThread(thread14, 0);
	InvalidateRect(0, 0, 0);
	TerminateThread(thread1dot1, 0);
	TerminateThread(thread6dot1, 0);
	InvalidateRect(0, 0, 0);

}
int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, PSTR lpCmdLine, INT nCmdShow)
{
	InitDPI();
	srand(time(NULL));
	SeedXorshift32((DWORD)time(NULL));
	ShowWindow(GetConsoleWindow(), SW_HIDE);
	if (MessageBoxW(NULL, L"Run ni5s9urcaj malware?\r\n\It will disturb you for some time", L"ni5s9urcaj.exe - First Warning", MB_YESNO | MB_ICONEXCLAMATION) == IDNO)
	{
		ExitProcess(0);
	}
	else
	{
		if (MessageBoxW(NULL, L"Are you sure? \r\n\The malware author couldn't assume legal liability", L"ni5s9urcaj.exe - Last Epilepsy Warning", MB_YESNO | MB_ICONEXCLAMATION) == IDNO)
		{
			ExitProcess(0);
		}
		else
		{
			mainpayloads();
		}
	}
	return 0;
}