@echo off

nasm -f bin clutter.asm -l test.lst -o test.img
pause