﻿#pragma warning(disable: 4995)
#pragma comment(lib, "Dwmapi.lib")
#include<iostream>
#include<stdio.h>
#include<windows.h>
#include<windowsx.h>
#include<math.h>
#include<stdlib.h>
#include<time.h>
#include<conio.h>
#include<tchar.h>
#include<fstream>
#include<windef.h>
#include<memory>
#include<iosfwd>
#include<dwmapi.h>
#include"resource.h"
#pragma comment(lib,"winmm.lib")
#pragma comment(lib,"msimg32.lib")
#define RndRGB RGB(rand() % 255, rand() % 255, rand() % 255)
#pragma optimize("", off)
typedef union _RGBQUAD {
    COLORREF rgb;
    struct {
        BYTE r;
        BYTE g;
        BYTE b;
        BYTE Reserved;
    };

}_RGBQUAD, * PRGBQUAD;
#define PI 3.14159265358979323846
LPCWSTR GetRandomChar(int length) {
    wchar_t* strRandom = new wchar_t[length + 1];
    for (int i = 0; i < length; i++) {
        strRandom[i] = (rand() % 256) + 1024;
    }
    strRandom[length] = L'\0';
    return strRandom;
}
LPCSTR iconLibraryNames[] = { "imageres.dll","shell32.dll","moricons.dll","pifmgr.dll" };
int RotateDC(HDC hdc, int Angle, POINT ptCenter) {
    int nGraphicsMode = SetGraphicsMode(hdc, GM_ADVANCED);
    XFORM xform;
    if (Angle != 0) {
        double fangle = (double)Angle / 180. * 3.1415926;
        xform.eM11 = (float)cos(fangle);
        xform.eM12 = (float)sin(fangle);
        xform.eM21 = (float)-sin(fangle);
        xform.eM22 = (float)cos(fangle);
        xform.eDx = (float)(ptCenter.x - cos(fangle) * ptCenter.x + sin(fangle) * ptCenter.y);
        xform.eDy = (float)(ptCenter.y - cos(fangle) * ptCenter.y - sin(fangle) * ptCenter.x);
        SetWorldTransform(hdc, &xform);
    }
    return nGraphicsMode;
}
int red, green, blue; bool ifblue = false;
COLORREF Hue(int length) {
    if (red != length) {
        red < length; red++;
        if (ifblue == true) {
            return RGB(red, 0, length);
        }
        else {
            return RGB(red, 0, 0);
        }
    }
    else {
        if (green != length) {
            green < length; green++;
            return RGB(length, green, 0);
        }
        else {
            if (blue != length) {
                blue < length; blue++;
                return RGB(0, length, blue);
            }
            else {
                red = 0; green = 0; blue = 0;
                ifblue = true;
            }
        }
    }
}
DWORD WINAPI Window0(LPVOID is8) {
    for (;;) {
        if (is8) {
            MessageBox(0, L"Btw,you are running in Win8+,i need to turn off DWM rendering to show GDI shader show currectly.You need to run in Win7-,because i cannot turn off DWM rendering in Win8+.\nBBttww,if close this dialog box,i will show this again.\n\nClick [OK] to show this dialog box again.\nClick [X] to show this dialog again.", L"₧.exe - Error", MB_ICONERROR);
        }
        else {
            MessageBox(0, L"", L"₧.exe - Dialog3", MB_ICONERROR);
        }
    }
}
HWND GDIWindow;
LRESULT CALLBACK WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam) {
    switch (message) {
    case WM_CREATE: {
        ShowWindow(hwnd, SW_SHOW);
        SetTimer(hwnd, 0, 50, 0);
        break;
    }
    case WM_PAINT: {
        ValidateRect(hwnd, 0);
        break;
    }
    case WM_CTLCOLORDLG: {
        return (BOOL)(HBRUSH)GetStockObject(NULL_BRUSH);
        break;
    }
    case WM_TIMER: {
        SetWindowPos(GDIWindow, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOSENDCHANGING | SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE);
        break;
    }
    case WM_DESTROY: {
        if (wParam != 0x7891) { return false; }
        KillTimer(hwnd, 0);
        DestroyWindow(hwnd);
        PostQuitMessage(0);
        break;
    }
    case WM_CLOSE: {
        if (wParam != 0x7891) {
            MessageBoxA(NULL, "Go die!!", "wininit.exe", MB_ICONERROR);
            return false;
        }
        SendMessage(GDIWindow, WM_DESTROY, 0x7891, 0);
        break;
    }
    case WM_SIZE: {
        SetWindowPos(GDIWindow, HWND_TOPMOST, 0, 0, GetSystemMetrics(0), GetSystemMetrics(1), SWP_SHOWWINDOW | SWP_NOACTIVATE);
        break;
    }
    case WM_GETMINMAXINFO: {
        MINMAXINFO* p = (MINMAXINFO*)lParam;
        p->ptMinTrackSize.x = GetSystemMetrics(0); p->ptMinTrackSize.y = GetSystemMetrics(1);
        p->ptMaxTrackSize.x = GetSystemMetrics(0); p->ptMaxTrackSize.y = GetSystemMetrics(1);
        return true;
        break;
    }
    case WM_WINDOWPOSCHANGING: {
        WINDOWPOS* pWindowPos = (WINDOWPOS*)lParam;
        pWindowPos->flags |= SWP_NOMOVE | SWP_NOSIZE;
        return DefWindowProc(hwnd, message, wParam, (LPARAM)pWindowPos);
        break;
    }
    case WM_SYSCOMMAND: {
        break;
    }
    case WM_SHOWWINDOW: {
        ShowWindow(GDIWindow, SW_SHOW);
    }
    case WM_DISPLAYCHANGE: {
        SetWindowPos(GDIWindow, HWND_TOPMOST, 0, 0, GetSystemMetrics(0), GetSystemMetrics(1), SWP_SHOWWINDOW | SWP_NOACTIVATE);
        break;
    }
    }
    return DefWindowProc(hwnd, message, wParam, lParam);
}
BOOL IsWin8newr() {
    typedef LONG(WINAPI* RtlGetVersionPtr)(PRTL_OSVERSIONINFOW);
    HMODULE hNtdll = GetModuleHandleW(L"ntdll.dll");
    RtlGetVersionPtr RtlGetVersion = (RtlGetVersionPtr)GetProcAddress(hNtdll, "RtlGetVersion");
    if (!RtlGetVersion) return FALSE;
    RTL_OSVERSIONINFOW osVer{};
    osVer.dwOSVersionInfoSize = sizeof(osVer);
    if (RtlGetVersion(&osVer) != 0) return FALSE;
    return (osVer.dwMajorVersion > 6) || (osVer.dwMajorVersion == 6 && osVer.dwMinorVersion >= 2);
}
DWORD WINAPI TXT(LPVOID) {
    LPCWSTR txt[] = { L"çéêè çéêè", L"ÿÿÿÿÿ",L"°­òâe", L">?BCFG=<NKJ",L"ÉÊËÌÍÎÏÐ",L"ﬀﬁﬂﬃﬄﬅﬆﬓﬔﬕﬖﬗ",L"⡧⡨⡧⡗⠭⠬⠪⠩⢏⢺⢿", L"by uiui",L"₧.exe" };
    for (;;) {
        int w = GetSystemMetrics(SM_CXSCREEN);
        int h = GetSystemMetrics(SM_CYSCREEN);
        HDC hdc = GetDC(GDIWindow);
        int rrr = rand() % 9;
        LPCWSTR fontname;
        if (rrr == 1 || rrr == 0) fontname = L"Wingdings";
        else if (rrr == 2) fontname = L"Webdings";
        else if (rrr == 3) fontname = L"Wingdings 2";
        else if (rrr == 4) fontname = L"Wingdings 3";
        else if (rrr == 5) fontname = L"Consolas";
        else if (rrr == 6) fontname = L"Cascadia Code";
        else fontname = L"777";
        SetBkMode(hdc, 0); SetTextColor(hdc, Hue(RndRGB));
        HFONT font = CreateFontW(100, 0, 0, 0, FW_THIN, 0, 0, 0, DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH | FF_DONTCARE, fontname);
        HGDIOBJ old = SelectObject(hdc, font);
        TextOutW(hdc, rand() % w, rand() % h, txt[rrr], lstrlenW(txt[rrr]));
        SelectObject(hdc, old);
        DeleteObject(font);
        ReleaseDC(NULL, hdc);
    }
}
DWORD WINAPI ICO(LPVOID) {
    for (;;) {
        int w = GetSystemMetrics(0), h = GetSystemMetrics(1), rrr = rand() % 4, num = (int)ExtractIconA(0, iconLibraryNames[rrr], -1);
        HDC hdc = GetDC(GDIWindow); HICON ico = ExtractIconA(0, iconLibraryNames[rrr], rand() % num);
        DrawIconEx(hdc, rand() % w, rand() % h, ico, 180, 180, 0, 0, DI_NORMAL);
        DestroyIcon(ico); ReleaseDC(0, hdc);
    }
}
DWORD WINAPI Shader1(LPVOID) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc), hdc2;
    BITMAPINFO bmi = { 40,w,h,1,32,BI_RGB };
    PRGBQUAD rgbquad = { 0 };
    HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hcdc, bmp);
    ReleaseDC(0, hdc);
    for (;;) {
        int rgb = RndRGB;
        hdc = GetDC(0); hdc2 = GetDC(GDIWindow);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int i = 0; i < w * h; i++) {
            int x = i % w, y = i / w;
            rgbquad[i].rgb ^= x & y;
        }
        for (int y = 0; y < h; y += 10) {
            BitBlt(hcdc, rand() % 30 - 15, y, w, 30 - 15, hcdc, 0, y, SRCCOPY);
        }
        HBRUSH bru = CreateSolidBrush(rgb), old = (HBRUSH)SelectObject(hcdc, bru);
        PatBlt(hcdc, 0, 0, w, h, PATINVERT);
        SelectObject(hcdc, old); DeleteObject(bru);
        for (int i = 0; i < 10; i++) {
            int x = rand() % w, y = rand() % h;
            RECT r;
            r.top = y; r.left = x; r.bottom = y + 180; r.right = x + 180;
            InvertRect(hcdc, &r);
        }
        BLENDFUNCTION blf = { 0 };
        blf.BlendOp = AC_SRC_OVER;
        blf.BlendFlags = 0;
        blf.SourceConstantAlpha = 128;
        blf.AlphaFormat = 0;
        AlphaBlend(hdc2, rand() % 30 - 15, rand() % 30 - 15, w, h, hcdc, 0, 0, w, h, blf);
        ReleaseDC(0, hdc); ReleaseDC(0, hdc2);
        Sleep(10);
    }
}
DWORD WINAPI Shader2(LPVOID) {
    for (int t = 0;; t += 2) {
        int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
        HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc), hdc2 = GetDC(GDIWindow);
        LPVOID MyMemoryAddress = VirtualAlloc(0, (w * h + w) * sizeof(_RGBQUAD), MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE); _RGBQUAD* data = (_RGBQUAD*)MyMemoryAddress;
        HBITMAP hBitmap = CreateBitmap(w, h, 1, 32, data);
        SelectObject(hcdc, hBitmap);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int y = 0; y < h; y++) {
            int idk = (double)y / 10.0 * (double)t, x = (int)(tan(idk) * 20.0);
            BitBlt(hcdc, x, y, w, 30 - 15, hcdc, 0, y, SRCCOPY);
        }
        for (int x = 0; x < w; x += (w / 10)) {
            BitBlt(hcdc, x, rand() % 30 - 15, (w / 10), h, hcdc, x, 0, SRCAND);
        }GetBitmapBits(hBitmap, w* h * 4, data);
        for (int i = 0; i < w * h; i++) {
            int x = i % w, y = i / w;
            ((BYTE*)(data + i + 1))[1] *= (x + y & x * x * (x | y)) * t;
        }
        SetBitmapBits(hBitmap, w* h * 4, data);
        BitBlt(hdc2, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
        VirtualFree(MyMemoryAddress, 0, MEM_RELEASE);
        ReleaseDC(0, hdc); ReleaseDC(0, hdc2);
        Sleep(10);
    }
}
DWORD WINAPI Shader3(LPVOID) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc), hdc2;
    BITMAPINFO bmi = { 40,w,h,1,32,BI_RGB };
    PRGBQUAD rgbquad = { 0 };
    HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hcdc, bmp);
    ReleaseDC(0, hdc);
    for (int t = 0;; t += 20) {
        hdc = GetDC(0); hdc2 = GetDC(GDIWindow);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int i = 0; i < w * h; i++) {
            int x = i % w, y = i / w;
            rgbquad[i].rgb += t * (x ^ (y + t));
        }
        for (int y = 0; y < h; y += 10) {
            BitBlt(hcdc, rand() % 30 - 15, y, w, 30 - 15, hcdc, 0, y, SRCAND);
        }
        BitBlt(hdc2, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
        ReleaseDC(0, hdc); ReleaseDC(0, hdc2);
        Sleep(10);
    }
}
DWORD WINAPI Shader4(LPVOID) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc), hdc2;
    BITMAPINFO bmi = { 40,w,h,1,32,BI_RGB };
    PRGBQUAD rgbquad = { 0 };
    HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hcdc, bmp);
    ReleaseDC(0, hdc);
    for (int t = 0;; t += 20) {
        hdc = GetDC(0); hdc2 = GetDC(GDIWindow);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int i = 0; i < w * h; i++) {
            int x = i % w, y = i / w;
            rgbquad[i].r += rgbquad[i].g;
            rgbquad[i].b *= rgbquad[i].r ^ (x + t | y * t);
        }int rrr = h / (1 + rand() % 100);
        for (int y = 0; y < h; y += rrr) {
            BitBlt(hcdc, rand() % 30 - 15, y, w, rrr, hcdc, 0, y, SRCAND);
        }
        BitBlt(hdc2, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
        ReleaseDC(0, hdc); ReleaseDC(0, hdc2);
        Sleep(10);
    }
}
DWORD WINAPI Shader5(LPVOID) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc), hdc2;
    BITMAPINFO bmi = { 40,w,h,1,32,BI_RGB };
    PRGBQUAD rgbquad = { 0 };
    HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hcdc, bmp);
    ReleaseDC(0, hdc);
    for (int t = 0;; t += 20) {
        hdc = GetDC(0); hdc2 = GetDC(GDIWindow);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int i = 0; i < w * h; i++) {
            int x = i % w, y = i / w;
            rgbquad[i].r += 0x010101 * (t - (x / 5) * y);
        }int rrr = h / (1 + rand() % 100);
        for (int y = 0; y < h; y += rrr) {
            BitBlt(hcdc, rand() % 30 - 15, y, w, rrr, hcdc, 0, y, SRCAND);
        }
        for (int i = 0; i < 100; i++) {
            BitBlt(hcdc, (rand() % (1 + w / 180)) * 180, (rand() % (1 + h / 180)) * 180, 180, 180, hcdc, (rand() % (1 + w / 180)) * 180, (rand() % (1 + h / 180)) * 180, SRCCOPY);
        }
        BitBlt(hdc2, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
        ReleaseDC(0, hdc); ReleaseDC(0, hdc2);
        Sleep(10);
    }
}
DWORD WINAPI Shader6(LPVOID) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc), hdc2;
    BITMAPINFO bmi = { 40,w,h,1,32,BI_RGB };
    PRGBQUAD rgbquad = { 0 };
    HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hcdc, bmp);
    ReleaseDC(0, hdc);
    for (int t = 0;; t += 20) {
        hdc = GetDC(0); hdc2 = GetDC(GDIWindow);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int i = 0; i < w * h; i++) {
            int x = i % w, y = i / w;
            rgbquad[i].r += (x + t * y | x) * rand() % 5;
        }int rrr = h / (1 + rand() % 40);
        for (int y = 0; y < h; y += rrr) {
            BitBlt(hcdc, rand() % 30 - 15, y, w, rrr, hcdc, 0, y, SRCAND);
        }
        RotateDC(hdc, rand() % 20 - 10, { w / 2,h / 2 });
        BitBlt(hdc2, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
        ReleaseDC(0, hdc); ReleaseDC(0, hdc2);
    }
}
DWORD WINAPI Shader7(LPVOID) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc), hdc2;
    BITMAPINFO bmi = { 40,w,h,1,32,BI_RGB };
    PRGBQUAD rgbquad = { 0 };
    HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hcdc, bmp);
    ReleaseDC(0, hdc);
    for (int t = 0;; t += 20) {
        hdc = GetDC(0); HDC hccdc = CreateCompatibleDC(hdc); hdc2 = GetDC(GDIWindow);
        HBITMAP bmp = CreateCompatibleBitmap(hdc, w, h), old = (HBITMAP)SelectObject(hccdc, bmp);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int i = 0; i < w * h; i++) {
            int x = i % w, y = i / w;
            rgbquad[i].rgb += t * (x | y + 6 / (y + 1) * y);
        }int rrr = h / (1 + rand() % 40);
        for (int y = 0; y < h; y += rrr) {
            BitBlt(hcdc, rand() % 30 - 15, y, w, rrr, hcdc, 0, y, SRCAND);
        }
        BitBlt(hccdc, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
        for (int x = 0; x < w; x++) {
             BitBlt(hcdc, x + 100 * cos((t - (x * t)) * PI / 180.f), 0, 1, h, hccdc, x, 0, SRCCOPY);
        }
        SelectObject(hccdc, old); DeleteObject(bmp); DeleteDC(hccdc);
        BitBlt(hdc2, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
        ReleaseDC(0, hdc); ReleaseDC(0, hdc2);
    }
}
DWORD WINAPI Shader8(LPVOID) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc), hdc2;
    BITMAPINFO bmi = { 40,w,h,1,32,BI_RGB };
    PRGBQUAD rgbquad = { 0 };
    HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hcdc, bmp);
    ReleaseDC(0, hdc);
    for (int t = 0;; t += 20) {
        hdc = GetDC(0); HDC hccdc = CreateCompatibleDC(hdc); hdc2 = GetDC(GDIWindow);
        HBITMAP bmp = CreateCompatibleBitmap(hdc, w, h), old = (HBITMAP)SelectObject(hccdc, bmp);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int i = 0; i < w * h; i++) {
            int x = i % w, y = i / w;
            rgbquad[i].rgb += t + x * (y + 6 * t);
        }int rrr = h / (1 + rand() % 40);
        for (int y = 0; y < h; y += rrr) {
            BitBlt(hcdc, rand() % 30 - 15, y, w, rrr, hcdc, 0, y, SRCAND);
        }
        BitBlt(hccdc, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
        for (int y = 0; y < h; y++) {
            BitBlt(hcdc, 20 * tan((y + t) * PI / 180.f), y, w, 1, hccdc, 0, y, SRCCOPY);
        }
        SelectObject(hccdc, old); DeleteObject(bmp); DeleteDC(hccdc);
        BitBlt(hdc2, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
        ReleaseDC(0, hdc); ReleaseDC(0, hdc2);
    }
}
DWORD WINAPI Shader9(LPVOID) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc), hdc2;
    BITMAPINFO bmi = { 40,w,h,1,32,BI_RGB };
    PRGBQUAD rgbquad = { 0 };
    HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hcdc, bmp);
    ReleaseDC(0, hdc);
    for (int t = 0;; t += 20) {
        hdc = GetDC(0); hdc2 = GetDC(GDIWindow);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int i = 0; i < w * h; i++) {
            int x = i % w, y = i / w;
            rgbquad[i].rgb += x + (x + y) * t + x;
        }int rrr = h / (1 + rand() % 10);
        for (int y = 0; y < h; y += rrr) {
            BitBlt(hcdc, rand() % 30 - 15, y, w, rrr, hcdc, 0, y, SRCINVERT);
        }
        BitBlt(hdc2, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
        ReleaseDC(0, hdc); ReleaseDC(0, hdc2);
    }
}
DWORD WINAPI Shader10(LPVOID) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc), hdc2;
    BITMAPINFO bmi = { 40,w,h,1,32,BI_RGB };
    PRGBQUAD rgbquad = { 0 };
    HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hcdc, bmp);
    ReleaseDC(0, hdc);
    for (;;) {
        int rgb = RndRGB;
        hdc = GetDC(0); hdc2 = GetDC(GDIWindow);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int i = 0; i < w * h; i++) {
            int x = i % w, y = i / w;
            rgbquad[i].rgb += rgb + (x * y) * GetRValue(rgb);
        }int rrr = h / (1 + rand() % 10);
        for (int y = 0; y < h; y += rrr) {
            BitBlt(hcdc, rand() % 10 - 5, y, w, rrr, hcdc, 0, y, SRCAND);
        }
        BitBlt(hdc2, rand() % 30 - 15, rand() % 30 - 15, w, h, hcdc, 0, 0, SRCCOPY);
        ReleaseDC(0, hdc); ReleaseDC(0, hdc2);
    }
}
DWORD WINAPI Shader11(LPVOID) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc), hdc2;
    BITMAPINFO bmi = { 40,w,h,1,32,BI_RGB };
    PRGBQUAD rgbquad = { 0 };
    HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hcdc, bmp);
    ReleaseDC(0, hdc);
    for (int t = 0;; t += 20) {
        int rgb = RndRGB;
        hdc = GetDC(0); hdc2 = GetDC(GDIWindow);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int i = 0; i < w * h; i++) {
            int x = i % w, y = i / w;
            rgbquad[i].rgb *= rgb | (x ^ y);
        }int rrr = h / (1 + rand() % 10);
        for (int y = 0; y < h; y += rrr) {
            BitBlt(hcdc, rand() % 10 - 5, y, w, rrr, hcdc, 0, y, SRCAND);
        }
        for (int x = 0; x < w; x++) {
            BitBlt(hcdc, x, 100 * sinf((x + t) * PI / 180.f), 1, h, hcdc, x, 0, SRCAND);
        }
        for (int y = 0; y < h; y++) {
            BitBlt(hcdc, 100 * sinf((y - t) * PI / 180.f), y, w, 1, hcdc, 0, y, SRCAND);
        }
        BitBlt(hdc2, rand() % 30 - 15, rand() % 30 - 15, w, h, hcdc, 0, 0, SRCCOPY);
        ReleaseDC(0, hdc); ReleaseDC(0, hdc2);
    }
}
DWORD WINAPI Shader12(LPVOID) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc), hdc2;
    BITMAPINFO bmi = { 40,w,h,1,32,BI_RGB };
    PRGBQUAD rgbquad = { 0 };
    HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hcdc, bmp);
    ReleaseDC(0, hdc);
    for (int t = 0;; t += 20) {
        hdc = GetDC(0); hdc2 = GetDC(GDIWindow);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int i = 0; i < w * h; i++) {
            int x = i % w, y = i / w;
            rgbquad[i].rgb *= (t + x) | (99 | t);
        }int rrr = h / (1 + rand() % 10);
        for (int y = 0; y < h; y += rrr) {
            BitBlt(hcdc, rand() % 10 - 5, y, w, rrr, hcdc, 0, y, SRCAND);
        }
        BitBlt(hdc2, rand() % 30 - 15, rand() % 30 - 15, w, h, hcdc, 0, 0, SRCCOPY);
        ReleaseDC(0, hdc); ReleaseDC(0, hdc2);
    }
}
DWORD WINAPI Shader13(LPVOID) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc), hdc2;
    BITMAPINFO bmi = { 40,w,h,1,32,BI_RGB };
    PRGBQUAD rgbquad = { 0 };
    HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hcdc, bmp);
    ReleaseDC(0, hdc);
    for (int t = 0;; t += 20) {
        hdc = GetDC(0); hdc2 = GetDC(GDIWindow);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int i = 0; i < w * h; i++) {
            int x = i % w, y = i / w;
            rgbquad[i].rgb *= (x + t) * (y + t) * t | t & 55 | 4 * x;
        }int rrr = h / (1 + rand() % 10);
        for (int y = 0; y < h; y += rrr) {
            BitBlt(hcdc, rand() % 10 - 5, y, w, rrr, hcdc, 0, y, SRCAND);
        }
        BitBlt(hdc2, rand() % 30 - 15, rand() % 30 - 15, w, h, hcdc, 0, 0, SRCCOPY);
        ReleaseDC(0, hdc); ReleaseDC(0, hdc2);
    }
}
DWORD WINAPI Shader14(LPVOID) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc), hdc2;
    BITMAPINFO bmi = { 40,w,h,1,32,BI_RGB };
    PRGBQUAD rgbquad = { 0 };
    HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hcdc, bmp);
    ReleaseDC(0, hdc);
    for (int t = 0;; t += 20) {
        hdc2 = GetDC(GDIWindow);
        for (int i = 0; i < w * h; i++) {
            int x = i % w, y = i / w;
            rgbquad[i].rgb = x / abs(y + (x | 977)) | (int)tan(x) * t;
        }
        BitBlt(hdc2, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
        ReleaseDC(0, hdc2);
    }
}
DWORD WINAPI Shader15(LPVOID) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc),hdc2;
    BITMAPINFO bmi = { 40,w,h,1,32,BI_RGB };
    PRGBQUAD rgbquad = { 0 };
    HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hcdc, bmp);
    ReleaseDC(0, hdc);
    for (int t = 0;; t += 20) {
        hdc = GetDC(0); hdc2 = GetDC(GDIWindow);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int i = 0; i < w * h; i++) {
            int x = i % w, y = i / w;
            rgbquad[i].rgb /= abs(1 + (x ^ (y + t)) | y);
        }int rrr = h / (1 + rand() % 10);
        for (int y = 0; y < h; y += rrr) {
            BitBlt(hcdc, rand() % 10 - 5, y, w, rrr, hcdc, 0, y, SRCAND);
        }
        BitBlt(hdc2, rand() % 30 - 15, rand() % 30 - 15, w, h, hcdc, 0, 0, SRCCOPY);
        ReleaseDC(0, hdc); ReleaseDC(0, hdc2);
    }
}
DWORD WINAPI Shader16(LPVOID) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc), hdc2;
    BITMAPINFO bmi = { 40,w,h,1,32,BI_RGB };
    PRGBQUAD rgbquad = { 0 };
    HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hcdc, bmp);
    ReleaseDC(0, hdc);
    for (int t = 0;; t += 20) {
        hdc = GetDC(0); hdc2 = GetDC(GDIWindow);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int i = 0; i < w * h; i++) {
            int x = i % w, y = i / w;
            rgbquad[i].rgb += x ^ y ^ (t + (x | y) + y * i);
        }int rrr = h / (1 + rand() % 10);
        for (int i = 0; i < 10; i++) {
            BitBlt(hcdc, rand() % w, rand() % h, rand() % w, rand() % h, hcdc, 0, 0, SRCCOPY);
        }
        for (int y = 0; y < h; y += rrr) {
            BitBlt(hcdc, rand() % 10 - 5, y, w, rrr, hcdc, 0, y, SRCAND);
        }
        BitBlt(hdc2, rand() % 30 - 15, rand() % 30 - 15, w, h, hcdc, 0, 0, SRCCOPY);
        ReleaseDC(0, hdc); ReleaseDC(0, hdc2);
    }
}
DWORD WINAPI Shader17(LPVOID) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc), hdc2;
    BITMAPINFO bmi = { 40,w,h,1,32,BI_RGB };
    PRGBQUAD rgbquad = { 0 };
    HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hcdc, bmp);
    ReleaseDC(0, hdc);
    for (int t = 0;; t += 20) {
        hdc = GetDC(0); hdc2 = GetDC(GDIWindow);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int i = 0; i < w * h; i++) {
            int x = i % w, y = i / w;
            rgbquad[i].rgb ^= t * ((x + t) | (y - t) | y) | y;
        }int rrr = h / (1 + rand() % 10);
        for (int y = 0; y < h; y += rrr) {
            BitBlt(hcdc, rand() % 10 - 5, y, w, rrr, hcdc, 0, y, SRCAND);
        }
        BitBlt(hdc2, rand() % 30 - 15, rand() % 30 - 15, w, h, hcdc, 0, 0, SRCCOPY);
        ReleaseDC(0, hdc); ReleaseDC(0, hdc2);
    }
}
DWORD WINAPI Shader18(LPVOID) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc), hdc2;
    BITMAPINFO bmi = { 40,w,h,1,32,BI_RGB };
    PRGBQUAD rgbquad = { 0 };
    HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hcdc, bmp);
    ReleaseDC(0, hdc);
    for (int t = 0;; t += 20) {
        hdc = GetDC(0); hdc2 = GetDC(GDIWindow);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int i = 0; i < w * h; i++) {
            int x = i % w, y = i / w;
            rgbquad[i].rgb ^= t * (t & 5 | x * (y + 1 >> t));
        }int rrr = h / (1 + rand() % 10);
        for (int y = 0; y < h; y += rrr) {
            BitBlt(hcdc, rand() % 10 - 5, y, w, rrr, hcdc, 0, y, SRCAND);
        }
        BitBlt(hdc2, rand() % 30 - 15, rand() % 30 - 15, w, h, hcdc, 0, 0, rand() % 2 ? SRCINVERT : rand() % 2 ? SRCAND : rand() % 2 ? rand() % 2 ? SRCPAINT : SRCERASE : rand() % 2 ? SRCCOPY : NOTSRCCOPY);
        ReleaseDC(0, hdc); ReleaseDC(0, hdc2);
    }
}
DWORD WINAPI Shader19(LPVOID) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc), hdc2;
    BITMAPINFO bmi = { 40,w,h,1,32,BI_RGB };
    PRGBQUAD rgbquad = { 0 };
    HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hcdc, bmp);
    ReleaseDC(0, hdc);
    for (int t = 0;; t += 20) {
        hdc = GetDC(0); hdc2 = GetDC(GDIWindow);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int i = 0; i < w * h; i++) {
            int x = i % w, y = i / w;
            rgbquad[i].rgb /= t + (x | (y | (t + y) & t ^ x + 5) / 5) + 1;
        }int rrr = h / (1 + rand() % 10);
        for (int y = 0; y < h; y += rrr) {
            BitBlt(hcdc, rand() % 10 - 5, y, w, rrr, hcdc, 0, y, SRCAND);
        }
        BitBlt(hdc2, rand() % 30 - 15, rand() % 30 - 15, w, h, hcdc, 0, 0, SRCCOPY);
        ReleaseDC(0, hdc); ReleaseDC(0, hdc2);
    }
}
DWORD WINAPI Shader20(LPVOID) {
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc), hdc2;
    BITMAPINFO bmi = { 40,w,h,1,32,BI_RGB };
    PRGBQUAD rgbquad = { 0 };
    HBITMAP bmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hcdc, bmp);
    ReleaseDC(0, hdc);
    for (int t = 0;; t += 20) {
        hdc = GetDC(0); hdc2 = GetDC(GDIWindow);
        BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int i = 0; i < w * h; i++) {
            int x = i % w, y = i / w;
            rgbquad[i].rgb *= t + (x >> 3 ^ y >> 4) | t + x & 4 + (x & y * x | y);
        }int rrr = h / (1 + rand() % 10);
        for (int y = 0; y < h; y += rrr) {
            BitBlt(hcdc, rand() % 10 - 5, y, w, rrr, hcdc, 0, y, SRCAND);
        }
        BitBlt(hdc2, rand() % 30 - 15, rand() % 30 - 15, w, h, hcdc, 0, 0, SRCCOPY);
        ReleaseDC(0, hdc); ReleaseDC(0, hdc2);
    }
}
VOID WINAPI sound1() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(t + 12 - (t * 3) * (int)cos(t >> 2) ^ t * (int)tan(t >> 3));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound2() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 32000, 32000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[32000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(t * (t & t >> 6 & t >> 11) ^ (t + (t >> 12)));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound3() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 16000, 16000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[16000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(t * (t ^ t >> 2 & t >> 8));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound4() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 22050, 22050, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[22050 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(t ^ t * (int)((t >> 11 & t) * cos(t >> 12)));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound5() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(t * (t >> 8 & t ^ (t >> 10 + t >> 3)));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound6() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(128 + (int)(sin(t + (t >> 10 & t) & t) * 128) & 128);
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound7() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 32000, 32000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[32000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(((t * t / (9 + (t >> 4 & t >> 1 & t))) & 1) * 255 | t * (t >> 3));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound8() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 16000, 16000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[16000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(t * (33 & t ^ (int)tan(t >> 10 & t)) - t * (t << (t << 11)));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound9() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(t + (t | t >> 11) + (t / 11 + 11 & t) + (t >> 1) | t >> 4);
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound10() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 16000, 16000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[16000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>((3 * (t >> 10 | t | t >> 16) + (t >> 13 | t * 3) | t) + (t >> 16));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound11() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(t * (t >> 8 & t >> 9 & t) - cos(t >> 2 & t * (t >> 1 & t)));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound12() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 7000, 7000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[7000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(tan(t / 114 + 514 >> t & t ^ (t >> 4 | t & t >> 2)));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound13() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 32000, 32000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[32000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>((t >> 2) ^ (t >> 2 + t / 11) * (t >> 6 % (t ? t : 1)));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound14() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 16000, 16000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[16000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>((t & (5 * t & t >> 8) | t >> 12) - (t & t >> 4));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound15() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 11025, 11025, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[11025 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>((t | t >> 4) + (t & t >> 3) - (t & t >> 8) - (t << 1));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound16() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 32000, 32000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[32000 * 30] = { 0 };
    for (int t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>((t + 5 / abs(1 + (t | 77 * (t >> 5)))) | t >> 5 * (t >> 4 & t));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound17() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>((t >> 5 & t & t >> 11 & t >> 8) * t | t * 16 & t >> 5 - t * rand());
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound18() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 16000, 16000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[16000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(t ^ t >> 1 & t >> 2 & t >> 3 | t << 3);
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound19() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 32000, 32000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[32000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>((t + t | t) + (t * t >> 20));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound20() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = { 0 };
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>((t * t) * (t >> 4 ^ t >> 3));
    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
void ShowHide_GDIEffectWindow(bool a) {
    if (a == false) {
        SetWindowPos(GDIWindow, HWND_TOPMOST, 0, 0, 0, 0, SWP_HIDEWINDOW | SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE);
        ShowWindow(GDIWindow, false);
    }
    else {
        SetWindowPos(GDIWindow, HWND_TOPMOST, 0, 0, 0, 0, SWP_SHOWWINDOW | SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE);
        ShowWindow(GDIWindow, true);
    }
}
void clean() {
    RedrawWindow(GDIWindow, NULL, NULL, RDW_ERASE | RDW_INVALIDATE | RDW_FRAME | RDW_ALLCHILDREN);
    RedrawWindow(NULL, NULL, NULL, RDW_ERASE | RDW_INVALIDATE | RDW_FRAME | RDW_ALLCHILDREN);
    InvalidateRect(GDIWindow, 0, 1);
    InvalidateRect(0, 0, 0);
    HDC hdc = GetDC(GDIWindow), hdc2 = GetDC(0);
    BitBlt(hdc, 0, 0, GetSystemMetrics(0), GetSystemMetrics(1), hdc2, 0, 0, SRCCOPY);
    ReleaseDC(0, hdc); ReleaseDC(0, hdc2);
    DeleteDC(hdc); DeleteDC(hdc2);
    UpdateWindow(GDIWindow);
}
void SPtime() {
    Sleep(30000);
}
void stopThread(HANDLE h) {
    TerminateThread(h, 0);
    CloseHandle(h);
}
DWORD WINAPI runSP(LPVOID) {
    DwmEnableComposition(0);
    HANDLE wnd0 = CreateThread(NULL, 0, Window0, (LPVOID)(IsWin8newr ? 1 : 0), 0, NULL);
    HANDLE fh1 = CreateThread(NULL, 0, TXT, NULL, 0, NULL);
    sound1();
    HANDLE sh1 = CreateThread(NULL, 0, Shader1, NULL, 0, NULL);
    SPtime();
    stopThread(sh1);
    clean();
    sound2();
    HANDLE sh2 = CreateThread(NULL, 0, Shader2, NULL, 0, NULL);
    SPtime();
    stopThread(sh2);
    clean();
    sound3();
    HANDLE sh3 = CreateThread(NULL, 0, Shader3, NULL, 0, NULL);
    SPtime();
    stopThread(sh3);
    clean();
    sound4();
    HANDLE sh4 = CreateThread(NULL, 0, Shader4, NULL, 0, NULL);
    SPtime();
    stopThread(sh4);
    clean();
    sound5();
    HANDLE sh5 = CreateThread(NULL, 0, Shader5, NULL, 0, NULL);
    SPtime();
    stopThread(sh5);
    clean();
    sound6();
    HANDLE sh6 = CreateThread(NULL, 0, Shader6, NULL, 0, NULL);
    SPtime();
    stopThread(sh6);
    clean();
    sound7();
    HANDLE sh7 = CreateThread(NULL, 0, Shader7, NULL, 0, NULL);
    SPtime();
    stopThread(sh7);
    clean();
    sound8();
    HANDLE sh8 = CreateThread(NULL, 0, Shader8, NULL, 0, NULL);
    SPtime();
    stopThread(sh8);
    clean();
    sound9();
    HANDLE sh9 = CreateThread(NULL, 0, Shader9, NULL, 0, NULL);
    SPtime();
    stopThread(sh9);
    clean();
    sound10();
    HANDLE sh10 = CreateThread(NULL, 0, Shader10, NULL, 0, NULL);
    HANDLE fh2 = CreateThread(NULL, 0, ICO, NULL, 0, NULL);
    SPtime();
    stopThread(sh10);
    clean();
    sound11();
    HANDLE sh11 = CreateThread(NULL, 0, Shader11, NULL, 0, NULL);
    SPtime();
    stopThread(sh11);
    clean();
    sound12();
    HANDLE sh12 = CreateThread(NULL, 0, Shader12, NULL, 0, NULL);
    SPtime();
    stopThread(sh12);
    clean();
    sound13();
    HANDLE sh13 = CreateThread(NULL, 0, Shader13, NULL, 0, NULL);
    SPtime();
    stopThread(sh13);
    clean();
    sound14();
    HANDLE sh14 = CreateThread(NULL, 0, Shader14, NULL, 0, NULL);
    SPtime();
    stopThread(sh14);
    clean();
    sound15();
    HANDLE sh15 = CreateThread(NULL, 0, Shader15, NULL, 0, NULL);
    SPtime();
    stopThread(sh15);
    clean();
    sound16();
    HANDLE sh16 = CreateThread(NULL, 0, Shader16, NULL, 0, NULL);
    SPtime();
    stopThread(sh16);
    clean();
    sound17();
    HANDLE sh17 = CreateThread(NULL, 0, Shader17, NULL, 0, NULL);
    SPtime();
    stopThread(sh17);
    clean();
    sound18();
    HANDLE sh18 = CreateThread(NULL, 0, Shader18, NULL, 0, NULL);
    SPtime();
    stopThread(sh18);
    clean();
    sound19();
    HANDLE sh19 = CreateThread(NULL, 0, Shader19, NULL, 0, NULL);
    SPtime();
    stopThread(sh19);
    clean();
    sound20();
    HANDLE sh20 = CreateThread(NULL, 0, Shader20, NULL, 0, NULL);
    SPtime();
    stopThread(sh20);
    stopThread(fh1);
    stopThread(fh2);
    clean();
    SendMessage(GDIWindow, WM_DESTROY, 0x7891, 0);
    ExitProcess(0);
    return 0x00;
}
void StartMalware() {
    WNDCLASSEXW wcex = { 0 };
    wcex.cbSize = sizeof(WNDCLASSEX); wcex.cbClsExtra = 0; wcex.cbWndExtra = 0;
    wcex.lpfnWndProc = WndProc;
    wcex.lpszClassName = L"₧.exe-GDI effect window";
    RegisterClassExW(&wcex);
    HWND hwnd = CreateWindowExW(WS_EX_TOOLWINDOW | WS_EX_LAYERED | WS_EX_TOPMOST | WS_EX_TRANSPARENT, wcex.lpszClassName, L"₧.exe - GDI effect window", WS_CLIPSIBLINGS | WS_POPUP | WS_DISABLED | WS_MAXIMIZE, 0, 0, GetSystemMetrics(0), GetSystemMetrics(1), nullptr, nullptr, 0, nullptr);
    if (!hwnd && !IsWindow(hwnd)) { return; }
    SetLayeredWindowAttributes(hwnd, 0, 255, LWA_ALPHA);
    UpdateWindow(hwnd);
    GDIWindow = hwnd;
    DwmEnableComposition(0);
    CreateThread(0, 0, runSP, 0, 0, 0);
    MSG msg;
    while (GetMessage(&msg, nullptr, 0, 0)) {
        if (!TranslateAccelerator(msg.hwnd, NULL, &msg)) {
            TranslateMessage(&msg);
            DispatchMessage(&msg);
        }
    }
}
int main() {
    FreeConsole();
    SetProcessDPIAware();
    srand(time(NULL));
    if (MessageBoxW(0, L"Warning!!!\n\nYou Just run a malware!!I will make your computer cannot work normally!Do you want to run me?Especially you're running my harmfull edit,my harmfull edit will break the MBR,and you cannot open you computer!If you just for a test,you could use a useless computer or a virtual computer.If you run me on a public computer or an important computer wich isn't your,my writer has no responsible.You shouldn't copy my code without asking my writer.You maybe can g0d1e(write for n17pro3426)\n\nClick [Yes] to run.\nClick [No] to exit.", L"₧.exe - Warning", MB_YESNO | MB_ICONWARNING | MB_DEFBUTTON2) == IDNO) { ExitProcess(0); }
    else {
        if (MessageBoxW(0, L"Last Warning!!!\n\nYou still want to run me?huh??I will make your computer cannot work normally!!Before you run me,check your operating environment.My writer has no responsible!!And if you click [Yes],I will start to break this computer because this is last warning.You should click [No] to exit if you're not for a test.", L"₧.exe - Last warning", MB_YESNO | MB_ICONWARNING | MB_DEFBUTTON2) == IDNO) { ExitProcess(0); }
        else {
            StartMalware();
        }
    }
    return 0;
}